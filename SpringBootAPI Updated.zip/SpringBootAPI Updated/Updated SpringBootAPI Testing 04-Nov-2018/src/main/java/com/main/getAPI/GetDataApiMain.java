package com.main.getAPI;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.client.RestTemplate;

//import com.google.gson.JsonArray;

public class GetDataApiMain {

	public static void main(String[] args) throws MalformedURLException, URISyntaxException, JSONException {
		//ElasticAPI/attachid?jobId=113d896e-2937-2afa-86f6-56334883f695
		GetDataApiMain obj = new GetDataApiMain();
		obj.esAttachJobid("113d896e-2937-2afa-86f6-56334883f695");
		
		
	}
    
	
	
    public  String esAttachJobid( String jobId)
                  throws MalformedURLException, URISyntaxException, JSONException {
           //int start = perPage * (next);
           RestTemplate restTemplate=new RestTemplate();
           String urlAttach = "";
           String jsonAttachData = "";
           String urlCandidate = "";
           String jsonCandidateData = "";
           urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume
           URL urlAttachdata = new URL(urlAttach);
           String nullFragment = null;
           // System.out.println("urlJobdata >> "+urlJobdata);
           URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
                        urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);
           System.out.println("urlAttach >> " + urlAttach);
           jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
           System.out.println("jsonAttachData >> "+jsonAttachData);
           
           
           
           JSONObject jsonObject=new JSONObject(jsonAttachData);
           jsonObject=(JSONObject) jsonObject.get("_shards");
           System.out.println("jsonObject >> "+jsonObject);
           
           JSONObject jsonObject2=new JSONObject(jsonAttachData);
           jsonObject2=(JSONObject) jsonObject2.get("hits");
           System.out.println("jsonObject2 >> "+jsonObject2);
           
           JSONArray jsonarray=(JSONArray) jsonObject2.get("hits");
           System.out.println("jsonArray >> "+jsonarray);
           
           JSONObject jsonObject3=(JSONObject) jsonarray.get(0);
           System.out.println("jsonObject3 >> "+jsonObject3);
           
           JSONObject jsonObject4=new JSONObject(jsonAttachData);
           jsonObject4=(JSONObject) jsonObject3.get("_source");
           System.out.println("jsonObject4 >> "+jsonObject4);
           
           
           String id="";
           String objectId="";
           String jobIdd="";
           String drop="";
           String dropComment="";
           String lastModifiedBy="";
           String createdDate="";
           String anchor="";
           String anchorId="";
           String status="";
           id= jsonObject4.getString("id");
           objectId=jsonObject4.getString("objectId");
           jobIdd=jsonObject4.getString("jobId");
           drop=jsonObject4.getString("dropComment");
           lastModifiedBy=jsonObject4.getString("lastModifiedBy");
           createdDate=jsonObject4.getString("createdDate");
           anchor=jsonObject4.getString("anchor");
           anchorId=jsonObject4.getString("anchorId");
           status=jsonObject4.getString("status");
           //id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment
           //urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume
           urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,jobId,objectId,drop,dropComment,lastModifiedBy,createdDate,anchor,anchorId,status";//,resumeName,resume
           
           System.out.println("urlAttach >> " + urlAttach);
           jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
           System.out.println("jsonAttachData >> "+jsonAttachData);
           
           
           
           urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
           System.out.println("urlCandidate >> " + urlCandidate);
           jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
           System.out.println("jsonCandidateData >> "+jsonCandidateData);
           
           JSONObject jsonCand=new JSONObject(jsonCandidateData);
           jsonCand=(JSONObject) jsonCand.get("_shards");
           System.out.println("jsonCand >> "+jsonObject);
           
           JSONObject jsonCand2=new JSONObject(jsonCandidateData);
           jsonCand2=(JSONObject) jsonCand2.get("hits");
           System.out.println("jsonCand2 >> "+jsonCand2);
           
           JSONArray jsonarrayCand=(JSONArray) jsonCand2.get("hits");
           System.out.println("jsonArrayCand >> "+jsonarrayCand);
           
           JSONObject jsonCand3=(JSONObject) jsonarrayCand.get(0);
           System.out.println("jsonCand3 >> "+jsonCand3);
           
           //JSONObject jsonCand4=new JSONObject(jsonCandidateData);
           JSONObject jsonCand4=(JSONObject) jsonCand3.get("_source");
           System.out.println("jsonCand4 >> "+jsonCand4);

    
           
           
           
           
           String ids="";
           String name="";
           String email="";
           String alternateEmail="";
           String birthdate="";
           String mobileNumber="";
           String lastModified="";
           String education="";
           String ug="";
           String degree="";
           String degreeType="";
           String course="";
           String institute="";
           String universityOrBoard="";
           String city="";
           String fromMonth="";
           String fromYear="";
           String toMonth="";
           String toYear="";
           String percentage="";
           String pg="";
           
           String doctorate="";
           String diploma="";
           
           
           
           String twelveth="";
           String tenth="";
           
           String address="";
           String permanentAddress="";
           String country="";
           String state="";
           String street="";
           String pincode="";
           String location="";
           String currentAddress="";
           
           String preferredLocation="";
           String salary="";
           String currentCTCType="";
           String currentCTC="";
           String negotiableCTC="";
           String expectedCTCType="";
           String expectedCTC="";
           String takeHome="";
           String fixed="";
           JSONObject employment;
          JSONObject current;
           String companyName="";
           String designation="";
           
           String isCurrent="";
           String desc="";
           String workLocation="";
           String role="";
           String level="";
           String teamSize="";
           JSONArray previous;
           
           String experience="";
           String months="";
           String TotalExp="";
           String years="";
    
           String createdBy="";
           String username="";

           String previousOrganization = "";
           String previousDesignation  = "";
           String previousLevel  = "";
           String previousCity  = "";
           String previousFromMonth  = "";
           String previousFromYear  = "";
           String previousToMonth  = "";
           String previousToYear  = "";
           String previousDescription  = "";
           ids=jsonCand4.getString("id");
           System.out.println("ids >> "+ids);
           name=jsonCand4.getString("name");
           System.out.println("name >> "+name);
           email=jsonCand4.getString("email");
           System.out.println("email >> "+email);
           if(!jsonCand4.get("alternateEmail").equals(null)){
                  alternateEmail=(String) jsonCand4.get("alternateEmail");
                  System.out.println("alternagteEmail....."+alternateEmail);
           }else{
                  
                   alternateEmail="";
                  System.out.println("alternateEmgdfgsdfgail....."+alternateEmail);
           }
           
            ArrayList<String> alternateEmails = new ArrayList<String>();
                  System.out.println("If loop......");
                  alternateEmails = (ArrayList<String>) jsonCand4.get("alternateEmail");
           System.out.println("alternateEmail:::"+alternateEmail);
           
            
            birthdate=jsonCand4.getString("birthdate");
           System.out.println("birthdate >> "+birthdate);
           mobileNumber=jsonCand4.getString("mobileNumber");
           if (!jsonCand4.get("lastModified").equals(null)) {
                  lastModified=(String) jsonCand4.get("lastModified");
                  System.out.println("lastModified dfs>> "+lastModified);
           }else {
                  lastModified="";
                  System.out.println("lastModified fsdss >> "+lastModified);
           }
           
           
           
           if(!jsonCand4.get("salary").equals(null)){
                  JSONObject salary1=(JSONObject) jsonCand4.get("salary");
                  System.out.println("salry1 >> "+salary1);
                  if (!salary1.get("currentCTCType").equals(null)) {
                        currentCTCType=(String) salary1.get("currentCTCType");
                        System.out.println("currentCTCType >> "+currentCTCType);
                  }else {
                        currentCTCType="";
                        System.out.println("currentCTCType >> "+currentCTCType);
                  }if(!salary1.get("currentCTC").equals(null)){
                        currentCTC=(String) salary1.get("currentCTC");
                        System.out.println("currentCTC >> "+currentCTC);
                  }else {
                        currentCTC="";
                        System.out.println("currentCTC >> "+currentCTC);
                  }if (!salary1.get("negotiableCTC").equals(null)) {
                        negotiableCTC=(String) salary1.get("negotiableCTC");
                        System.out.println("negotiableCTC >> "+negotiableCTC);
                  }else {
                        negotiableCTC="";
                        System.out.println("negotiableCTC >> "+negotiableCTC);
                  }if (!salary1.get("expectedCTCType").equals(null)) {
                        expectedCTCType=(String) salary1.get("expectedCTCType");
                        System.out.println("expectedCTCType >> "+expectedCTCType);
                  }else {
                        expectedCTCType="";
                        System.out.println("expectedCTCType >> "+expectedCTCType);
                  }if (!salary1.get("expectedCTC").equals(null)) {
                        expectedCTC=(String) salary1.get("expectedCTC");
                        System.out.println("expectedCTC >> "+expectedCTC);
                  }else {
                        expectedCTC="";
                        System.out.println("expectedCTC >> "+expectedCTC);
                  }if (!salary1.get("takeHome").equals(null)) {
                        takeHome=(String) salary1.get("takeHome");
                        System.out.println("takeHome >> "+takeHome);
                  }else {
                        takeHome="";
                        System.out.println("takeHome >> "+takeHome);
                  }if (!salary1.get("fixed").equals(null)) {
                        fixed=(String) salary1.get("fixed");
                        System.out.println("fixed >> "+fixed);
                  }else {
                        fixed="";
                        System.out.println("fixed >> "+fixed);
                  }
                  
            }else {
                  salary="";
                  System.out.println("salary >> "+salary);
           }
           
            
            
            
            if(!jsonCand4.get("address").equals(null)){
                  JSONObject permanentAddressJson=(JSONObject) jsonCand4.get("address");
                  if(!permanentAddressJson.get("permanentAddress").equals(null)){
                        System.out.println("permanentAddress >> "+permanentAddressJson.get("permanentAddress"));
                        JSONObject permanentAddress1=new JSONObject();
                        permanentAddress1=(JSONObject) permanentAddressJson.get("permanentAddress");
                        System.out.println("permanentAddress1 >>> "+permanentAddress1);
                        if (!permanentAddress1.get("country").equals(null)) {
                               country=(String) permanentAddress1.get("country");
                               System.out.println("country >> "+country);
                        }else {
                               country="";
                               System.out.println("country >> "+country);
                        }
                        if(!permanentAddress1.get("state").equals(null)){
                               state=(String) permanentAddress1.get("state");
                               System.out.println("state >> "+state);
                        }else {
                               state="";
                               System.out.println("state >> "+state);
                        }
                        if (!permanentAddress1.get("city").equals(null)) {
                               city=(String) permanentAddress1.get("city");
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if (!permanentAddress1.get("street").equals(null)) {
                               street=(String) permanentAddress1.get("street");
                               System.out.println("street >> "+street);
                        }else {
                               street="";
                               System.out.println("street >> "+street);
                        }
                        if(!permanentAddress1.get("pincode").equals(null)){
                               pincode=(String) permanentAddress1.get("pincode");
                               System.out.println("pincode >> "+pincode);
                        }else {
                               pincode="";
                               System.out.println("pincode >> "+pincode);
                        }if (!permanentAddress1.get("location").equals(null)) {
                               location=(String) permanentAddress1.get("location");
                               System.out.println("location >> "+location);
                        }else {
                               location="";
                               System.out.println("location >> "+location);
                        }
                  }
                  else {
                        permanentAddress="";
                        System.out.println("permanentAddress >> "+permanentAddress);
                  }
                        ///current address write code.. START
                  
                   
                   JSONObject currentAddressJson=(JSONObject) jsonCand4.get("address");
                  if(!currentAddressJson.get("currentAddress").equals(null)){
                        System.out.println("currentAddress >> "+currentAddressJson.get("currentAddress"));
                        JSONObject currentAddress1=new JSONObject();
                        currentAddress1=(JSONObject) currentAddressJson.get("currentAddress");
                        System.out.println("currentAddress1 >>> "+currentAddress1);
                        if (!currentAddress1.get("country").equals(null)) {
                               country=(String) currentAddress1.get("country");
                               System.out.println("country >> "+country);
                        }else {
                               country="";
                               System.out.println("country current >> "+country);
                        }
                        if(!currentAddress1.get("state").equals(null)){
                               state=(String) currentAddress1.get("state");
                               System.out.println("state  current>> "+state);
                        }else {
                               state="";
                               System.out.println("state current>> "+state);
                        }
                        if (!currentAddress1.get("city").equals(null)) {
                               city=(String) currentAddress1.get("city");
                        }else {
                               city="";
                               System.out.println("city current>> "+city);
                        }
                        if (!currentAddress1.get("street").equals(null)) {
                               street=(String) currentAddress1.get("street");
                               System.out.println("street current>> "+street);
                        }else {
                               street="";
                               System.out.println("street current>> "+street);
                        }
                        if(!currentAddress1.get("pincode").equals(null)){
                               pincode=(String) currentAddress1.get("pincode");
                               System.out.println("pincode current>> "+pincode);
                        }else {
                               pincode="";
                               System.out.println("pincode current >> "+pincode);
                        }if (!currentAddress1.get("location").equals(null)) {
                               location=(String) currentAddress1.get("location");
                               System.out.println("location current >> "+location);
                        }else {
                               location="";
                               System.out.println("location current >> "+location);
                        }
                  }
                  else {
                        currentAddress="";
                        System.out.println("currentAddress current >> "+currentAddress);
                  }
           }else {
                  address="";
                  System.out.println("address >> "+address);
           }
           
            
            
            ///Education..
           
           if (!jsonCand4.get("education").equals(null)) {
                  //education=(String) jsonCand4.get("education");
                  JSONObject ugjson = (JSONObject) jsonCand4.get("education");
                  if(!ugjson.get("ug").equals(null)){
                        System.out.println("ug >>> "+ugjson.get("ug"));
                        JSONObject ug1=new JSONObject();
                        
                        ug1=(JSONObject) ugjson.get("ug");
                        System.out.println("ug1 >> "+ug1);
                        if(!ug1.get("degree").equals(null)){
                               degree=(String) ug1.get("degree");
                               System.out.println("degree >>> "+ug1.get("degree"));
                        }else {
                               degree="";
                               System.out.println("degree >> "+degree);
                        }
                         if(!ug1.get("degreeType").equals(null)){
                               degreeType=(String) ug1.get("degreeType");
                               System.out.println("degreeType >>> "+ug1.get("degreeType"));
                        }else {
                               degreeType="";
                               System.out.println("degreeType >> "+degreeType);
                        }
                        
                         if(!ug1.get("course").equals(null)){
                               course=(String) ug1.get("course");
                               System.out.println("course >>> "+ug1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!ug1.get("institute").equals(null)){
                               institute=(String) ug1.get("institute");
                               System.out.println("institute >>> "+ug1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!ug1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) ug1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+ug1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                               System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!ug1.get("city").equals(null)){
                               city=(String) ug1.get("city");
                               System.out.println("city >>> "+ug1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!ug1.get("fromMonth").equals(null)){
                               fromMonth=(String) ug1.get("fromMonth");
                               System.out.println("fromMonth >>> "+ug1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!ug1.get("fromYear").equals(null)){
                               fromYear=(String) ug1.get("fromYear");
                               System.out.println("fromYear >>> "+ug1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!ug1.get("toMonth").equals(null)) {
                               toMonth=(String) ug1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!ug1.get("toYear").equals(null)) {
                               toYear=(String) ug1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                        if (!ug1.get("percentage").equals(null)) {
                               percentage=(String) ug1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }             
                        
                  }else {
                        ug="";
                        System.out.println("ug >> "+ug);
                  }
                  //for pg
                  System.out.println("Hiiiiiiiiiiiii");
                  JSONObject pgjson = (JSONObject) jsonCand4.get("education");
                  if(!pgjson.get("pg").equals(null)){
                        System.out.println("pg1 Json >>> "+pgjson.get("pg"));
                        
                         JSONObject pg1=new JSONObject();
                        System.out.println("pg1 >> "+pg1);
                        pg1=(JSONObject) pgjson.get("pg");
                        System.out.println("pg1 >> "+pg1);
                        
                         if(!pg1.get("degree").equals(null)){
                               degree=(String) pg1.get("degree");
                               System.out.println("degree >>> "+pg1.get("degree"));
                        }else {
                               degree="";
                               System.out.println("degree >> "+degree);
                        }
                        if(!pg1.get("degreeType").equals(null)){
                               degreeType=(String) pg1.get("degreeType");
                               System.out.println("degreeType >>> "+pg1.get("degreeType"));
                        }else {
                               degreeType="";
                               System.out.println("degreeType >> "+degreeType);
                        }
                        
                         if(!pg1.get("course").equals(null)){
                               course=(String) pg1.get("course");
                               System.out.println("course >>> "+pg1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!pg1.get("institute").equals(null)){
                               institute=(String) pg1.get("institute");
                               System.out.println("institute >>> "+pg1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!pg1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) pg1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+pg1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                               System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!pg1.get("city").equals(null)){
                               city=(String) pg1.get("city");
                               System.out.println("city >>> "+pg1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!pg1.get("fromMonth").equals(null)){
                               fromMonth=(String) pg1.get("fromMonth");
                               System.out.println("fromMonth >>> "+pg1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!pg1.get("fromYear").equals(null)){
                               fromYear=(String) pg1.get("fromYear");
                               System.out.println("fromYear >>> "+pg1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!pg1.get("toMonth").equals(null)) {
                               toMonth=(String) pg1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!pg1.get("toYear").equals(null)) {
                               toYear=(String) pg1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                        if (!pg1.get("percentage").equals(null)) {
                               percentage=(String) pg1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }      
                        
                   }else {
                        pg="";
                        System.out.println("pg >>"+pg);
                  }//end pg
                  
                   //// doctrate start
                  
                   System.out.println("Hiiiiiiiiiiiii");
                  JSONObject doctoratejson = (JSONObject) jsonCand4.get("education");
                  if(!doctoratejson.get("doctorate").equals(null)){
                        System.out.println("doctorate Json >>> "+doctoratejson.get("doctorate"));
                        
                         JSONObject doctorate1=new JSONObject();
                        System.out.println("doctorate1 >> "+doctorate1);
                        doctorate1=(JSONObject) doctoratejson.get("twelveth");
                        System.out.println("doctorate1 >>> "+doctorate1);
                        
                         
                         if(!doctorate1.get("course").equals(null)){
                               course=(String) doctorate1.get("course");
                               System.out.println("course >>> "+doctorate1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!doctorate1.get("institute").equals(null)){
                               institute=(String) doctorate1.get("institute");
                               System.out.println("institute >>> "+doctorate1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!doctorate1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) doctorate1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+doctorate1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                               System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!doctorate1.get("city").equals(null)){
                               city=(String) doctorate1.get("city");
                               System.out.println("city >>> "+doctorate1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!doctorate1.get("fromMonth").equals(null)){
                               fromMonth=(String) doctorate1.get("fromMonth");
                               System.out.println("fromMonth >>> "+doctorate1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!doctorate1.get("fromYear").equals(null)){
                               fromYear=(String) doctorate1.get("fromYear");
                               System.out.println("fromYear >>> "+doctorate1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!doctorate1.get("toMonth").equals(null)) {
                               toMonth=(String) doctorate1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!doctorate1.get("toYear").equals(null)) {
                               toYear=(String) doctorate1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                        if (!doctorate1.get("percentage").equals(null)) {
                               percentage=(String) doctorate1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }      
                        
                   }else {
                        doctorate="";
                        System.out.println("doctorate >>"+doctorate);
                  }
                  
                  
                   /// start Diploma
                  
                   System.out.println("Hiiiiiiiiiiiii");
                  JSONObject diplomajson = (JSONObject) jsonCand4.get("education");
                  if(!diplomajson.get("diploma").equals(null)){
                        System.out.println("diploma Json >>> "+diplomajson.get("diploma"));
                        
                         JSONObject diploma1=new JSONObject();
                        System.out.println("diploma1 >> "+diploma1);
                        diploma1=(JSONObject) diplomajson.get("diploma");
                        System.out.println("diploma1 >>> "+diploma1);
                        
                         
                         if(!diploma1.get("course").equals(null)){
                               course=(String) diploma1.get("course");
                               System.out.println("course >>> "+diploma1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!diploma1.get("institute").equals(null)){
                               institute=(String) diploma1.get("institute");
                               System.out.println("institute >>> "+diploma1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!diploma1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) diploma1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+diploma1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                                System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!diploma1.get("city").equals(null)){
                               city=(String) diploma1.get("city");
                               System.out.println("city >>> "+diploma1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!diploma1.get("fromMonth").equals(null)){
                               fromMonth=(String) diploma1.get("fromMonth");
                               System.out.println("fromMonth >>> "+diploma1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!diploma1.get("fromYear").equals(null)){
                               fromYear=(String) diploma1.get("fromYear");
                               System.out.println("fromYear >>> "+diploma1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!diploma1.get("toMonth").equals(null)) {
                               toMonth=(String) diploma1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!diploma1.get("toYear").equals(null)) {
                               toYear=(String) diploma1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                        if (!diploma1.get("percentage").equals(null)) {
                               percentage=(String) diploma1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }      
                        
                   }else {
                        diploma="";
                        System.out.println("diploma >>"+diploma);
                  }
                  
                   
                   
                   
                   
                   
                   ////////start 12th
                  System.out.println("Hiiiiiiiiiiiii");
                  JSONObject twelvethjson = (JSONObject) jsonCand4.get("education");
                  if(!twelvethjson.get("twelveth").equals(null)){
                        System.out.println("pg1 Json >>> "+twelvethjson.get("twelveth"));
                        
                         JSONObject twelveth1=new JSONObject();
                        System.out.println("twelveth1 >> "+twelveth1);
                         twelveth1=(JSONObject) twelvethjson.get("twelveth");
                        System.out.println("twelveth1 >>> "+twelveth1);
                        
                         
                         if(!twelveth1.get("course").equals(null)){
                               course=(String) twelveth1.get("course");
                               System.out.println("course >>> "+twelveth1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!twelveth1.get("institute").equals(null)){
                               institute=(String) twelveth1.get("institute");
                               System.out.println("institute >>> "+twelveth1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!twelveth1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) twelveth1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+twelveth1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                               System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!twelveth1.get("city").equals(null)){
                               city=(String) twelveth1.get("city");
                               System.out.println("city >>> "+twelveth1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!twelveth1.get("fromMonth").equals(null)){
                               fromMonth=(String) twelveth1.get("fromMonth");
                               System.out.println("fromMonth >>> "+twelveth1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!twelveth1.get("fromYear").equals(null)){
                               fromYear=(String) twelveth1.get("fromYear");
                               System.out.println("fromYear >>> "+twelveth1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!twelveth1.get("toMonth").equals(null)) {
                               toMonth=(String) twelveth1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!twelveth1.get("toYear").equals(null)) {
                               toYear=(String) twelveth1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                         if (!twelveth1.get("percentage").equals(null)) {
                               percentage=(String) twelveth1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }    
                        
                   }else {
                        twelveth="";
                        System.out.println("twelveth >>"+twelveth);
                  }
                  
                   //end twelveth
                  
                   //Start tenth
                  System.out.println("Hiiiiiiiiiiiii");
                  JSONObject tenthjson = (JSONObject) jsonCand4.get("education");
                  if(!tenthjson.get("tenth").equals(null)){
                        System.out.println("tetnth Json >>> "+tenthjson.get("tenth"));
                        
                         JSONObject tenth1=new JSONObject();
                        System.out.println("tenth1 >> "+tenth1);
                        tenth1=(JSONObject) tenthjson.get("tenth");
                        System.out.println("tenth1 >>> "+tenth1);
                        
                         if(!tenth1.get("degree").equals(null)){
                               degree=(String) tenth1.get("degree");
                               System.out.println("degree >>> "+tenth1.get("degree"));
                        }else {
                               degree="";
                               System.out.println("degree >> "+degree);
                        }
                        if(!tenth1.get("degreeType").equals(null)){
                               degreeType=(String) tenth1.get("degreeType");
                               System.out.println("degreeType >>> "+tenth1.get("degreeType"));
                        }else {
                               degreeType="";
                               System.out.println("degreeType >> "+degreeType);
                        }
                        
                         if(!tenth1.get("course").equals(null)){
                               course=(String) tenth1.get("course");
                               System.out.println("course >>> "+tenth1.get("course"));
                        }else {
                               course="";
                               System.out.println("course >> "+course);
                        }
                        if(!tenth1.get("institute").equals(null)){
                               institute=(String) tenth1.get("institute");
                               System.out.println("institute >>> "+tenth1.get("institute"));
                        }else {
                               institute="";
                               System.out.println("institute >> "+institute);
                        }
                        if(!tenth1.get("universityOrBoard").equals(null)){
                               universityOrBoard=(String) tenth1.get("universityOrBoard");
                               System.out.println("universityOrBoard >>> "+tenth1.get("universityOrBoard"));
                        }else {
                               universityOrBoard="";
                               System.out.println("universityOrBoard >> "+universityOrBoard);
                        }
                        if(!tenth1.get("city").equals(null)){
                               city=(String) tenth1.get("city");
                               System.out.println("city >>> "+tenth1.get("city"));
                        }else {
                               city="";
                               System.out.println("city >> "+city);
                        }
                        if(!tenth1.get("fromMonth").equals(null)){
                               fromMonth=(String) tenth1.get("fromMonth");
                               System.out.println("fromMonth >>> "+tenth1.get("fromMonth"));
                        }else {
                               fromMonth="";
                               System.out.println("fromMonth >> "+fromMonth);
                        }
                        if(!tenth1.get("fromYear").equals(null)){
                               fromYear=(String) tenth1.get("fromYear");
                               System.out.println("fromYear >>> "+tenth1.get("fromYear"));
                        }else {
                               fromYear="";
                               System.out.println("fromYear >> "+fromYear);
                        }
                        if (!tenth1.get("toMonth").equals(null)) {
                               toMonth=(String) tenth1.get("toMonth");
                               System.out.println("toMonth >> "+toMonth);
                        }else {
                               toMonth="";
                               System.out.println("toMonth >> "+toMonth);
                        }                          
                        if (!tenth1.get("toYear").equals(null)) {
                               toYear=(String) tenth1.get("toYear");
                               System.out.println("toYear >> "+toYear);
                        }else {
                               toYear="";
                               System.out.println("toYear >> "+toYear);
                        }             
                        if (!tenth1.get("percentage").equals(null)) {
                               percentage=(String) tenth1.get("percentage");
                               System.out.println("percentage >> "+percentage);
                        }else {
                               percentage="";
                               System.out.println("percentage >> "+percentage);
                        }    
                        
                   }else {
                        tenth="";
                        System.out.println("twelveth >>"+tenth);
                  }
                  
                   //end tenth
                  //////////
                        
           }else {
                  education="";
                  System.out.println("education >> "+education);
           }
           
           preferredLocation=jsonCand4.getString("preferredLocation");
           
            employment=jsonCand4.getJSONObject("employment");
            
           current=employment.getJSONObject("current");
           System.out.println("current jsonObject >>"+current);
           if(current.has("companyName"))
           {
           companyName=current.getString("companyName");
           System.out.println("companyName >> "+ companyName);
           }
           else
           {
        	   companyName = "";   
           }
           if(current.has("designation"))
           {
           designation=current.getString("designation");
           System.out.println("desidnation >> "+designation);
           }
           else
           {
        	   designation = "";
           }
           if(current.has("isCurrent"))
           {
           isCurrent=current.getString("isCurrent");
           System.out.println("isCurrent >>" + isCurrent);
           }
           else
           {
        	   isCurrent = "";
           }
           if(current.has("desc"))
           {
        	   desc=current.getString("desc");
               System.out.println("desc >> "+ desc);  
           }
           else
           {
        	   desc="";
           }
           if(current.has("workLocation"))
           {
        	   workLocation=current.getString("workLocation");
               System.out.println("workLocation >>"+ workLocation);
           }
           else
           {
        	   workLocation = "";
           }
           if(current.has("role"))
           {
        	   role=current.getString("role");
               System.out.println("role >> "+ role);  
           }
           else
           {
        	role="";   
           }
           if(current.has("level"))
           {
        	   level=current.getString("level");
               System.out.println("level >> " + level);
           }
           else
           {
        	   level ="";
           }
           if(current.has("teamSize"))
           {
        	   teamSize=current.getString("teamSize");
               System.out.println("teamSize >> "+ teamSize);
           }
           else
           {
        	   teamSize="";
           }

           previous=employment.getJSONArray("previous");
           System.out.println("previous >> "+ previous);
           
           
           for(int i=0;i<previous.length();i++)
        	   {
        	   
        	   JSONObject jsonprevious = previous.getJSONObject(i);
        	   
        	   if(jsonprevious.has("organization"))
        	   {
        		   previousOrganization = jsonprevious.getString("organization");
        		   System.out.println("previousOrganization >>"+previousOrganization);
        	   }
        	   else
        	   {
        		   previousOrganization = "";
        	   }
        	   if(jsonprevious.has("designation"))
        	   {
        		   previousDesignation = jsonprevious.getString("designation");
        		   System.out.println("previousDesignation >>" + previousDesignation);
        	   }
        	   else
        	   {
        		   previousDesignation = "";
        	   }
        	   if(jsonprevious.has("level"))
        	   {
        		   previousLevel= jsonprevious.getString("level");;
        	   }
        	   else
        	   {
        		   previousLevel="";
        	   }
        	   if(jsonprevious.has("city"))
        	   {
        		   previousCity = jsonprevious.getString("city");
        	   }
        	   else
        	   {
        		   previousCity = "";
        	   }
        	   if(jsonprevious.has("fromMonth"))
        	   {
        		  previousFromMonth = jsonprevious.getString("fromMonth"); 
        	   }
        	   else
        	   {
        		   previousFromMonth ="";
        	   }
        	   if(jsonprevious.has("fromYear"))
        	   {
        		   previousFromYear =jsonprevious.getString("fromYear");
        	   }
        	   else
        	   {
        		   previousFromYear ="";
        	   }
        	   if(jsonprevious.has("toMonth"))
        	   {
        		previousToMonth =jsonprevious.getString("toMonth");   
        	   }
        	   else
        	   {
        		   previousToMonth= "";
        	   }
        	   if(jsonprevious.has("toYear"))
        	   {
        		previousToYear =jsonprevious.getString("toYear");   
        	   }
        	   else
        	   {
        		   previousToYear= "";
        	   }
        	   if(jsonprevious.has("description"))
        	   {
        		previousDescription =jsonprevious.getString("description");   
        	   }
        	   else
        	   {
        		   previousDescription= "";
        	   }
        	   
        	   
        	   }
           
           
           
           
           
         //  experience=current.getString("experience");
          // months=current.getString("months");
           //TotalExp=current.getString("TotalExp");
          // years=current.getString("years");
           
           //createdBy=current.getString("createdBy");
           //username=current.getString("username");
           System.out.println("username >> "+username);
           System.out.println("city >> "+city);       
         
    //Candidate Collection
           //urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";//,resumeName,resume
           //id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,currentAddress,preferredLocation,salary,expectedCTC,employment,current,previous,experience,lastModified,createdDate,createdBy,username,username,projectDescription
           urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
           System.out.println("urlCandidate >> " + urlCandidate);
           jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
           System.out.println("jsonCandidateData >> "+jsonCandidateData);
           JSONObject object = new JSONObject();
           JSONArray array = new JSONArray();
           array.put(0, jsonCandidateData);
           array.put(1, jsonAttachData);
           object.put("response", array);
           //return jsonCandidateData+jsonAttachData;
           System.out.println(object);
           //return object.toString();
           
           
            return jsonCandidateData;
           //return jsonAttachData+jsonCandidateData;

    }


	
	
}
