package com.es.properties;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Component
@PropertySource("classpath:searchconfig.properties")
@ConfigurationProperties
public class GlobalProperties {

    //@Value("${aws_access_key_id}")
   // @Max(5)
   // @Min(0)
    private String aws_access_key_id;

    //@Value("${aws_secret_access_key}")
    @NotEmpty
    private String aws_secret_access_key;

   
    public String getAws_access_key_id() {
		return aws_access_key_id;
	}


	public void setAws_access_key_id(String aws_access_key_id) {
		this.aws_access_key_id = aws_access_key_id;
	}


	public String getAws_secret_access_key() {
		return aws_secret_access_key;
	}


	public void setAws_secret_access_key(String aws_secret_access_key) {
		this.aws_secret_access_key = aws_secret_access_key;
	}


	@Override
    public String toString() {
        return "GlobalProperties{" +
                "aws_access_key_id=" + aws_access_key_id +
                ", aws_secret_access_key='" + aws_secret_access_key + '\'' +
                '}';
    }
}
