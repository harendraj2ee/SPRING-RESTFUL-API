package com.es.restServiceImpl;

import java.io.IOException;
import java.util.List;

import sun.misc.BASE64Decoder;

public class RestServiceImpl implements RestService {

	final String loginauth = "globalhuntES:5bb75d0165daee774354cb8e";
	
	@Override
	public boolean isUserAuthenticated(String authentication) {
		// TODO Auto-generated method stub
		String decodedAuth = "";
		
	    String[] authParts = authentication.split("\\s+");
	    String authInfo = authParts[1];
	   
	    byte[] bytes = null;
	    try {
	        bytes = new BASE64Decoder().decodeBuffer(authInfo);
	    } catch (IOException e) {
	      
	        e.printStackTrace();
	    }
	    decodedAuth = new String(bytes);
	    System.out.println("decodedAuth >> "+decodedAuth);
	    if(!loginauth.equals(decodedAuth))
	    	return false;
	    
	    return true;
	}

}
