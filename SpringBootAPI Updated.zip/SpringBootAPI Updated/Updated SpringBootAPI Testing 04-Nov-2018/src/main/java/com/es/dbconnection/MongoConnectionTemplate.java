package com.es.dbconnection;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoConnectionTemplate {
	static MongoClientURI connectionString;
	static MongoClient mongoClient = null;
	static MongoDatabase database;
	static com.mongodb.client.MongoCollection<Document> collection = null;

	public MongoConnectionTemplate() {
		connectionString = new MongoClientURI(
				"mongodb+srv://cloudRouteMap:Candi123@developmentcluster-yfy2g.mongodb.net/CandidateDB");
		
	}

	public static MongoCollection getInstanceTemplate() {
		if (mongoClient == null) {
			mongoClient = new MongoClient(connectionString);
			database = mongoClient.getDatabase("CandidateDB");
			collection = database.getCollection("Template");
		}
		return collection;

	}
}
