package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.swing.plaf.synth.SynthScrollBarUI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.restServiceImpl.RestServiceImpl;

@Controller
public class CandidateProfileController {
//	@Autowired
//	private RestTemplate restTemplate;
	RestTemplate restTemplate = new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();
	//2nd time 
	@RequestMapping(value = "/ElasticAPI/candprofile", method = { RequestMethod.GET })
	public @ResponseBody String candidateProfileId(@RequestParam("id") String UserId,
			@RequestParam(value = ("sortType"), required = false) String sortType, @RequestHeader HttpHeaders headers)
			throws MalformedURLException, URISyntaxException, JSONException {

		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}   
		
		String ids = "";
		String name = "";
		String email = "";
		JSONArray alternateEmail = new JSONArray();
		String birthdate = "";
		String mobileNumber = "";
		String lastModified = "";
		// String education = "";
		String ug = "";
		String degree = "";
		String degreeType = "";
		String course = "";
		String institute = "";
		String universityOrBoard = "";
		String city = "";
		String fromMonth = "";
		String fromYear = "";
		String toMonth = "";
		String toYear = "";
		String percentage = "";
		String pg = "";
		String doctorate = "";
		String diploma = "";
		String twelveth = "";
		String tenth = "";
		String address = "";
		String permanentAddress = "";
		String country = "";

		String permanentcity = "";
		String permanentcountry = "";

		String state = "";
		String permanentstate = "";
		String street = "";

		String permanentstreet = "";
		String pincode = "";

		String permanentpincode = "";

		String location = "";

		String permanentlocation = "";

		String currentAddress = "";
		String preferredLocation = "";
		String ResumeName = "";
		String Resume = "";
		String salary = "";
		String currentCTCType = "";
		String currentCTC = "";
		String negotiableCTC = "";
		String expectedCTCType = "";
		String expectedCTC = "";
		String takeHome = "";
		String fixed = "";
		String employment = "";
		String current = "";
		String companyName = "";
		String designation = "";
		String first_name = "";
		String middle_name = "";
		String last_name = "";
		Integer age = null;
		String gender = "";
		String picture = "";
		String profile = "";
		String website = "";
		String jobType = "";
		String employmentType = "";
		boolean immediateJoiningAvailabilityOrNegotiable = false;
		String minimumDaysRequired = "";
		String salutation = "";
		boolean visibility = false;

		JSONArray alternateMobileNumber = new JSONArray();

		String telePhone = "";
		String officePhone = "";
		String religion = "";
		JSONArray family = new JSONArray();
		String maritalStatus = "";
		JSONArray connectSocialNetwork = new JSONArray();
		String createdDate = "";
		String lastModifiedBy = "";
		String aadharCardNo = "";
		String passportNo = "";
		String passportValidity = "";
		String panNo = "";
		String areaOfSpecialization = "";
		String otherInterest = "";
		String category = "";
		boolean confidential = false;
		String employmentStatus = "";
		String nationality = "";
		String exNationality = "";
		String experiencedIndustry = "";
		String preferredIndustry = "";
		String experiencedFunctionalArea = "";
		String preferredFunctionalArea = "";
		String language = "";
		String notes = "";
		String noticePeriod = "";
		String reasonForRelocate = "";
		String preferredDistance = "";
		String physicallyChallenged = "";
		String reasonForLeaving = "";
		String willingToRelocate = "";
		String willingToChangeJob = "";
		String resumeHeadLine = "";
		boolean experienced = false;
		boolean fresher = false;
		String shiftWork = "";
		String skillSummary = "";
		String summary = "";
		String federated = "";
		String officePhoneExtention = "";
		boolean isMobileNumberVerified = false;
		String locale = "";
		String isCurrent = "";
		String desc = "";
		String workLocation = "";
		String role = "";
		String level = "";
		String teamSize = "";
		// String previous = "";
		String experience = "";
		Integer months;
		String TotalExp = "";
		Integer years;
		String createdBy = "";
		String username = "";
		JSONObject Mainjson = new JSONObject();
		JSONArray obj = new JSONArray();
		// int start = perpage * (next);
		String objectId = "";
		String jobNames = "";
		String status = "";
		String anchor = "";
		String urlAttach = "";
		String jsonAttachData = "";
		String urlCandidate = "";
		String jsonCandidateData = "";

		String JsonSimilardata = "";

		JSONObject JobHits = new JSONObject();
		JSONObject CandidateHits = new JSONObject();
		JSONObject mainjson = new JSONObject();
		Map<String, String> SkillsMap = new HashMap<String, String>();
		JSONArray previous = new JSONArray();
		JSONArray SkillsObj = new JSONArray();
		JSONArray achievementObj = new JSONArray();
		JSONArray familyObj = new JSONArray();
		JSONArray connectSocialObj = new JSONArray();
		JSONArray refralObj = new JSONArray();
		JSONArray certificateObj = new JSONArray();
		JSONArray projectObj = new JSONArray();

		String candidateProfileUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
				+ UserId + "\")&pretty=true";
		JSONArray skillList = new JSONArray();
		JSONArray project = new JSONArray();
		JSONArray achievement = new JSONArray();
		JSONArray referal = new JSONArray();

		JSONArray previouss = new JSONArray();
		JSONArray certificates = new JSONArray();

		Map<String, Object> candijson = new HashMap<String, Object>();

		JSONObject html1 = new JSONObject();

		Map<String, JSONArray> Skills = new HashMap<String, JSONArray>();
		Map<String, JSONArray> refral = new HashMap<String, JSONArray>();
		Map<String, JSONArray> projects = new HashMap<String, JSONArray>();
		Map<String, JSONArray> map = new HashMap<String, JSONArray>();
		Map<String, JSONObject> map1 = new HashMap<String, JSONObject>();
		Map<String, JSONArray> achievements = new HashMap<String, JSONArray>();
		Map<String, JSONArray> alternateEmailmap = new HashMap<String, JSONArray>();

		// Map<String, JSONArray> previous = new HashMap<String, JSONArray>();

		Map<String, JSONArray> certificatess = new HashMap<String, JSONArray>();

		URL urlcandiateProfile = new URL(candidateProfileUrl);

		// System.out.println("urlJobdata >> "+urlJobdata);
		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateProfileUrl);

		System.out.println("urlcandidateProfileUrl >> " + candidateProfileUrl);

		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

		JSONObject jsonCand = new JSONObject(jsonCandidateData);
		jsonCand = (JSONObject) jsonCand.get("_shards");

		JSONObject jsonCand2 = new JSONObject(jsonCandidateData);
		jsonCand2 = (JSONObject) jsonCand2.get("hits");

		JSONArray jsonarrayCand = (JSONArray) jsonCand2.get("hits");
		System.out.println("Candidate Hits Array..... >> " + jsonarrayCand);

		mainjson.put("candidate", CandidateHits);

		if (jsonarrayCand.isNull(0) == false) {
			JSONObject jsonCand3 = (JSONObject) jsonarrayCand.get(0);
			System.out.println("Getting Object From Candiate Array.... >> " + jsonCand3);

			// JSONObject jsonCand4=new JSONObject(jsonCandidateData);
			JSONObject jsonCand4 = (JSONObject) jsonCand3.get("_source");
			System.out.println("jsonCand4 >> " + jsonCand4);

			if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
				preferredLocation = jsonCand4.getString("preferredLocation");
			}
			if (jsonCand4.has("lastModifiedBy") && !jsonCand4.get("lastModifiedBy").equals(null)) {
				lastModifiedBy = jsonCand4.getString("lastModifiedBy");
			}

			if (jsonCand4.has("resumeName") && !jsonCand4.get("resumeName").equals(null)) {
				ResumeName = jsonCand4.getString("resumeName");
			}

			if (jsonCand4.has("resume") && !jsonCand4.get("resume").equals(null)) {
				Resume = jsonCand4.getString("resume");
			}

			if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
				createdBy = jsonCand4.getString("createdBy");
			}
			if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
				username = jsonCand4.getString("username");
			}
			if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
				ids = jsonCand4.getString("id");
			}
			if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
				name = jsonCand4.getString("name");

			}
			if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
				email = jsonCand4.getString("email");
			}
			if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
				birthdate = jsonCand4.getString("birthdate");
			}
			if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
				mobileNumber = jsonCand4.getString("mobileNumber");
			}
			// ...................

			if (jsonCand4.has("first_name") && !jsonCand4.get("first_name").equals(null)) {
				first_name = jsonCand4.getString("first_name");

			}

			if (jsonCand4.has("middle_name") && !jsonCand4.get("middle_name").equals(null)) {
				middle_name = (String) jsonCand4.get("middle_name");
			}

			if (jsonCand4.has("last_name") && !jsonCand4.get("last_name").equals(null)) {
				last_name = jsonCand4.getString("last_name");

			}

			if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
				alternateEmail = (JSONArray) jsonCand4.get("alternateEmail");

			}

			if (jsonCand4.has("age") && !jsonCand4.get("age").equals(null)) {

				age = (Integer) jsonCand4.get("age");
			}

			if (jsonCand4.has("gender") && !jsonCand4.get("gender").equals(null)) {
				gender = jsonCand4.getString("gender");
			}

			if (jsonCand4.has("picture") && !jsonCand4.get("picture").equals(null)) {
				picture = jsonCand4.getString("picture");
			}

			if (jsonCand4.has("profile") && !jsonCand4.get("profile").equals(null)) {
				profile = jsonCand4.getString("profile");
			}

			if (jsonCand4.has("website") && !jsonCand4.get("website").equals(null)) {
				website = jsonCand4.getString("website");
			}

			if (jsonCand4.has("jobType") && !jsonCand4.get("jobType").equals(null)) {
				jobType = jsonCand4.getString("jobType");
			}

			if (jsonCand4.has("employmentType") && !jsonCand4.get("employmentType").equals(null)) {
				employmentType = jsonCand4.getString("employmentType");
			}

			if (jsonCand4.has("immediateJoiningAvailabilityOrNegotiable")
					&& !jsonCand4.get("immediateJoiningAvailabilityOrNegotiable").equals(null)) {
				immediateJoiningAvailabilityOrNegotiable = (boolean) jsonCand4
						.get("immediateJoiningAvailabilityOrNegotiable");

			}

			if (jsonCand4.has("minimumDaysRequired") && !jsonCand4.get("minimumDaysRequired").equals(null)) {
				minimumDaysRequired = jsonCand4.getString("minimumDaysRequired");
			}

			if (jsonCand4.has("salutation") && !jsonCand4.get("salutation").equals(null)) {
				salutation = jsonCand4.getString("salutation");
			}

			if (jsonCand4.has("visibility") && !jsonCand4.get("visibility").equals(null)) {
				visibility = (boolean) jsonCand4.get("visibility");
			}

			if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
				mobileNumber = jsonCand4.getString("mobileNumber");
			}

			if (jsonCand4.has("alternateMobileNumber") && !jsonCand4.get("alternateMobileNumber").equals(null)) {
				alternateMobileNumber = (JSONArray) jsonCand4.get("alternateMobileNumber");
			}

			if (jsonCand4.has("telePhone") && !jsonCand4.get("telePhone").equals(null)) {
				telePhone = jsonCand4.getString("telePhone");
			}

			if (jsonCand4.has("officePhone") && !jsonCand4.get("officePhone").equals(null)) {
				officePhone = jsonCand4.getString("officePhone");
			}

			if (jsonCand4.has("officePhoneExtention") && !jsonCand4.get("officePhoneExtention").equals(null)) {
				officePhoneExtention = jsonCand4.getString("officePhoneExtention");
			}

			if (jsonCand4.has("isMobileNumberVerified") && !jsonCand4.get("isMobileNumberVerified").equals(null)) {
				isMobileNumberVerified = (boolean) jsonCand4.get("isMobileNumberVerified");
			}

			if (jsonCand4.has("locale") && !jsonCand4.get("locale").equals(null)) {
				locale = jsonCand4.getString("locale");
			}

			if (jsonCand4.has("religion") && !jsonCand4.get("religion").equals(null)) {
				religion = jsonCand4.getString("religion");
			}

			if (jsonCand4.has("maritalStatus") && !jsonCand4.get("maritalStatus").equals(null)) {
				maritalStatus = jsonCand4.getString("maritalStatus");
			}

			if (jsonCand4.has("createdDate") && !jsonCand4.get("createdDate").equals(null)) {
				createdDate = jsonCand4.getString("createdDate");
			}

			if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
				lastModified = jsonCand4.getString("lastModified");
			}

			if (jsonCand4.has("aadharCardNo") && !jsonCand4.get("aadharCardNo").equals(null)) {
				aadharCardNo = jsonCand4.getString("aadharCardNo");
			}

			if (jsonCand4.has("passportNo") && !jsonCand4.get("passportNo").equals(null)) {
				passportNo = jsonCand4.getString("passportNo");
			}
			if (jsonCand4.has("passportValidity") && !jsonCand4.get("passportValidity").equals(null)) {
				passportValidity = jsonCand4.getString("passportValidity");
			}
			if (jsonCand4.has("panNo") && !jsonCand4.get("panNo").equals(null)) {
				panNo = jsonCand4.getString("panNo");
			}

			if (jsonCand4.has("areaOfSpecialization") && !jsonCand4.get("areaOfSpecialization").equals(null)) {
				areaOfSpecialization = jsonCand4.getString("areaOfSpecialization");
			}

			if (jsonCand4.has("otherInterest") && !jsonCand4.get("otherInterest").equals(null)) {
				otherInterest = jsonCand4.getString("otherInterest");
			}

			if (jsonCand4.has("category") && !jsonCand4.get("category").equals(null)) {
				category = jsonCand4.getString("category");
			}

			if (jsonCand4.has("confidential") && !jsonCand4.get("confidential").equals(null)) {
				confidential = (boolean) jsonCand4.get("confidential");
			}

			if (jsonCand4.has("employmentStatus") && !jsonCand4.get("employmentStatus").equals(null)) {
				employmentStatus = jsonCand4.getString("employmentStatus");
			}

			if (jsonCand4.has("nationality") && !jsonCand4.get("nationality").equals(null)) {
				nationality = jsonCand4.getString("nationality");
			}

			if (jsonCand4.has("exNationality") && !jsonCand4.get("exNationality").equals(null)) {
				exNationality = jsonCand4.getString("exNationality");
			}

			if (jsonCand4.has("experiencedIndustry") && !jsonCand4.get("experiencedIndustry").equals(null)) {
				experiencedIndustry = jsonCand4.getString("experiencedIndustry");

			}

			if (jsonCand4.has("preferredIndustry") && !jsonCand4.get("preferredIndustry").equals(null)) {
				preferredIndustry = jsonCand4.getString("preferredIndustry");
			}

			if (jsonCand4.has("experiencedFunctionalArea")
					&& !jsonCand4.get("experiencedFunctionalArea").equals(null)) {
				experiencedFunctionalArea = jsonCand4.getString("experiencedFunctionalArea");
			}

			if (jsonCand4.has("preferredFunctionalArea") && !jsonCand4.get("preferredFunctionalArea").equals(null)) {
				preferredFunctionalArea = jsonCand4.getString("preferredFunctionalArea");
			}

			if (jsonCand4.has("language") && !jsonCand4.get("language").equals(null)) {
				language = jsonCand4.getString("language");
			}

			if (jsonCand4.has("notes") && !jsonCand4.get("notes").equals(null)) {
				notes = jsonCand4.getString("notes");
			}

			if (jsonCand4.has("noticePeriod") && !jsonCand4.get("noticePeriod").equals(null)) {
				noticePeriod = jsonCand4.getString("noticePeriod");
			}

			if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
				preferredLocation = jsonCand4.getString("preferredLocation");
			}

			if (jsonCand4.has("preferredDistance") && !jsonCand4.get("preferredDistance").equals(null)) {
				preferredDistance = jsonCand4.getString("preferredDistance");
			}

			if (jsonCand4.has("physicallyChallenged") && !jsonCand4.get("physicallyChallenged").equals(null)) {
				physicallyChallenged = jsonCand4.getString("physicallyChallenged");
			}

			if (jsonCand4.has("reasonForLeaving") && !jsonCand4.get("reasonForLeaving").equals(null)) {
				reasonForLeaving = jsonCand4.getString("reasonForLeaving");
			}

			if (jsonCand4.has("reasonForRelocate") && !jsonCand4.get("reasonForRelocate").equals(null)) {
				reasonForRelocate = jsonCand4.getString("reasonForRelocate");
			}

			if (jsonCand4.has("willingToRelocate") && !jsonCand4.get("willingToRelocate").equals(null)) {
				willingToRelocate = jsonCand4.getString("willingToRelocate");
			}

			if (jsonCand4.has("willingToChangeJob") && !jsonCand4.get("willingToChangeJob").equals(null)) {
				willingToChangeJob = jsonCand4.getString("willingToChangeJob");
			}
			if (jsonCand4.has("resumeHeadLine") && !jsonCand4.get("resumeHeadLine").equals(null)) {
				resumeHeadLine = jsonCand4.getString("resumeHeadLine");
			}
			if (jsonCand4.has("experienced") && !jsonCand4.get("experienced").equals(null)) {
				experienced = (boolean) jsonCand4.get("experienced");
			}

			if (jsonCand4.has("fresher") && !jsonCand4.get("fresher").equals(null)) {
				fresher = (boolean) jsonCand4.get("fresher");
			}

			if (jsonCand4.has("shiftWork") && !jsonCand4.get("shiftWork").equals(null)) {
				shiftWork = jsonCand4.getString("shiftWork");
			}
			if (jsonCand4.has("skillSummary") && !jsonCand4.get("skillSummary").equals(null)) {
				skillSummary = jsonCand4.getString("skillSummary");
			}
			if (jsonCand4.has("summary") && !jsonCand4.get("summary").equals(null)) {
				summary = jsonCand4.getString("summary");
			}
			if (jsonCand4.has("federated") && !jsonCand4.get("federated").equals(null)) {
				federated = jsonCand4.getString("federated");
			}
			// ...............................................................................................
			String skillTest = "";
			String skillfromYear = "";
			String skillEXP = "";
			String skillfromMonth = "";
			String skilltoYear = "";
			String skilltoMonth = "";
			if (jsonCand4.has("skills")) {
				JSONObject skillobject = new JSONObject();

				skillList = (JSONArray) jsonCand4.get("skills");

				for (int i = 0; i < skillList.length(); i++) {

					skillobject = (JSONObject) skillList.get(i);

					if (skillobject.has("text")) {
						skillTest = (String) skillobject.get("text");
					}

					if (skillobject.has("experience")) {
						skillEXP = (String) skillobject.get("experience");
					}

					if (skillobject.has("fromMonth")) {
						skillfromMonth = (String) skillobject.get("fromMonth");
					}

					if (skillobject.has("fromYear")) {
						skillfromYear = (String) skillobject.get("fromYear");
					}
					if (skillobject.has("toMonth")) {
						skilltoMonth = (String) skillobject.get("toMonth");
					}
					if (skillobject.has("toYear")) {
						skilltoYear = (String) skillobject.get("toYear");
					}

					SkillsMap.put("text", skillTest);

					SkillsMap.put("experience", skillEXP);

					SkillsMap.put("fromMonth", skillfromMonth);

					SkillsMap.put("fromYear", skillfromYear);

					SkillsMap.put("toMonth", skilltoMonth);
					SkillsMap.put("toYear", skilltoYear);

					SkillsObj.put(SkillsMap);
				}

				System.out.println("skill......" + skillList);
			}

			else {
				SkillsMap.put("text", skillTest);

				SkillsMap.put("experience", skillEXP);

				SkillsMap.put("fromMonth", skillfromMonth);

				SkillsMap.put("fromYear", skillfromYear);

				SkillsMap.put("toMonth", skilltoMonth);
				SkillsMap.put("toYear", skilltoYear);

				SkillsObj.put(SkillsMap);
			}

			String connectSocialNetworkname = "";
			String connectSocialNetworkurl = "";

			Map<String, String> connectSocialNetworkMap = new HashMap<String, String>();

			if (jsonCand4.has("connectSocialNetwork")) {
				connectSocialNetwork = (JSONArray) jsonCand4.get("connectSocialNetwork");

				JSONObject connectSocialNetworkject = new JSONObject();

				for (int i = 0; i < connectSocialNetwork.length(); i++) {

					connectSocialNetworkject = (JSONObject) connectSocialNetwork.get(i);

					if (connectSocialNetworkject.has("name")) {
						connectSocialNetworkname = (String) connectSocialNetworkject.get("name");
					}

					if (connectSocialNetworkject.has("url")) {
						connectSocialNetworkurl = (String) connectSocialNetworkject.get("url");
					}

					connectSocialNetworkMap.put("name", connectSocialNetworkname);

					connectSocialNetworkMap.put("url", connectSocialNetworkurl);

					connectSocialObj.put(connectSocialNetworkMap);

				}

			} else {

				connectSocialNetworkMap.put("name", connectSocialNetworkname);

				connectSocialNetworkMap.put("url", connectSocialNetworkurl);

				connectSocialObj.put(connectSocialNetworkMap);
			}

			String familyoccupation = "";
			String familyname = "";
			String familylocation = "";
			String familyrelationship = "";

			Map<String, String> familyMap = new HashMap<String, String>();

			if (jsonCand4.has("family")) {

				family = (JSONArray) jsonCand4.get("family");

				JSONObject familyobject = new JSONObject();

				for (int i = 0; i < family.length(); i++) {

					familyobject = (JSONObject) family.get(i);

					if (familyobject.has("occupation")) {
						familyoccupation = (String) familyobject.get("occupation");
					}

					if (familyobject.has("name")) {
						familyname = (String) familyobject.get("name");
					}

					if (familyobject.has("location")) {
						familylocation = (String) familyobject.get("location");
					}
					if (familyobject.has("relationship")) {
						familyrelationship = (String) familyobject.get("relationship");
					}

					familyMap.put("occupation", familyoccupation);

					familyMap.put("name", familyname);

					familyMap.put("location", familylocation);

					familyMap.put("relationship", familyrelationship);

					familyObj.put(familyMap);

				}

			} else {
				familyMap.put("occupation", familyoccupation);

				familyMap.put("name", familyname);

				familyMap.put("location", familylocation);

				familyMap.put("relationship", familyrelationship);

				familyObj.put(familyMap);
			}

			String achievementTitle = "";
			String achievementRole = "";
			String achievementDescription = "";
			Map<String, String> achievementMap = new HashMap<String, String>();
			if (jsonCand4.has("achievement")) {

				achievement = (JSONArray) jsonCand4.get("achievement");
				JSONObject Achievementobject = new JSONObject();

				for (int i = 0; i < achievement.length(); i++) {

					Achievementobject = (JSONObject) achievement.get(i);

					if (Achievementobject.has("achievementTitle")) {
						achievementTitle = (String) Achievementobject.get("achievementTitle");
					}

					if (Achievementobject.has("achievementRole")) {
						achievementRole = (String) Achievementobject.get("achievementRole");
					}

					if (Achievementobject.has("achievementDescription")) {
						achievementDescription = (String) Achievementobject.get("achievementDescription");
					}

					achievementMap.put("achievementTitle", achievementTitle);

					achievementMap.put("achievementRole", achievementRole);

					achievementMap.put("achievementDescription", achievementDescription);

					achievementObj.put(achievementMap);

				}

			} else {
				achievementMap.put("achievementTitle", achievementTitle);

				achievementMap.put("achievementRole", achievementRole);

				achievementMap.put("achievementDescription", achievementDescription);

				achievementObj.put(achievementMap);
			}

			String referralname = "";
			String referralofficeEmail = "";
			String referralofficePhone = "";

			String referralcompany = "";
			String referraltitle = "";
			String referraldescription = "";

			Map<String, String> referalMap = new HashMap<String, String>();
			if (jsonCand4.has("referral")) {

				referal = (JSONArray) jsonCand4.get("referral");
				JSONObject referralobject = new JSONObject();

				for (int i = 0; i < achievement.length(); i++) {

					referralobject = (JSONObject) achievement.get(i);

					if (referralobject.has("name")) {
						referralname = (String) referralobject.get("name");
					}

					if (referralobject.has("officeEmail")) {
						referralofficeEmail = (String) referralobject.get("officeEmail");
					}

					if (referralobject.has("officePhone")) {
						referralofficePhone = (String) referralobject.get("officePhone");
					}

					if (referralobject.has("company")) {
						referralcompany = (String) referralobject.get("company");
					}

					if (referralobject.has("title")) {
						referraltitle = (String) referralobject.get("title");
					}

					if (referralobject.has("description")) {
						referraldescription = (String) referralobject.get("description");
					}

					referalMap.put("achievementTitle", referralname);

					referalMap.put("achievementRole", referralofficeEmail);

					referalMap.put("achievementDescription", referralofficePhone);

					referalMap.put("achievementDescription", referralcompany);

					referalMap.put("achievementDescription", referraltitle);

					referalMap.put("achievementDescription", referraldescription);

					refralObj.put(referalMap);

				}

			} else {
				referalMap.put("achievementTitle", referralname);

				referalMap.put("achievementRole", referralofficeEmail);

				referalMap.put("achievementDescription", referralofficePhone);

				referalMap.put("achievementDescription", referralcompany);

				referalMap.put("achievementDescription", referraltitle);

				referalMap.put("achievementDescription", referraldescription);

				refralObj.put(referalMap);

			}

			String certificatesTitle = "";
			String certificatesmonth = "";
			String certificateyear = "";
			String certificatesDescription = "";

			Map<String, String> certificateMap = new HashMap<String, String>();

			if (jsonCand4.has("certificates")) {
				certificates = (JSONArray) jsonCand4.get("certificates");
				JSONObject certificatesobject = new JSONObject();

				for (int i = 0; i < achievement.length(); i++) {

					certificatesobject = (JSONObject) certificates.get(i);

					if (certificatesobject.has("certificatesTitle")) {
						certificatesTitle = (String) certificatesobject.get("certificatesTitle");
					}

					if (certificatesobject.has("month")) {
						certificatesmonth = (String) certificatesobject.get("month");
					}

					if (certificatesobject.has("year")) {
						certificateyear = (String) certificatesobject.get("year");
					}

					if (certificatesobject.has("certificatesDescription")) {
						certificatesDescription = (String) certificatesobject.get("certificatesDescription");
					}

					certificateMap.put("certificatesTitle", certificatesTitle);

					certificateMap.put("month", certificatesmonth);
					certificateMap.put("year", certificateyear);
					certificateMap.put("certificatesDescription", certificatesDescription);

					certificateObj.put(certificateMap);

				}

			} else {
				certificateMap.put("certificatesTitle", certificatesTitle);

				certificateMap.put("month", certificatesmonth);
				certificateMap.put("year", certificateyear);
				certificateMap.put("certificatesDescription", certificatesDescription);

				certificateObj.put(certificateMap);
			}

			String projectTitle = "";
			String projectRole = "";
			String projectfromMonth = "";
			String projectfromYear = "";

			String projecttoMonth = "";
			String projecttoYear = "";
			String projecturl = "";
			String projectDescription = "";

			Map<String, String> projectMap = new HashMap<String, String>();

			if (jsonCand4.has("project")) {

				project = (JSONArray) jsonCand4.get("project");

				JSONObject projectobject = new JSONObject();

				for (int i = 0; i < project.length(); i++) {

					projectobject = (JSONObject) project.get(i);

					if (projectobject.has("projectTitle")) {
						projectTitle = (String) projectobject.get("projectTitle");
					}

					if (projectobject.has("projectRole")) {
						projectRole = (String) projectobject.get("projectRole");
					}

					if (projectobject.has("fromMonth")) {
						projectfromMonth = (String) projectobject.get("fromMonth");
					}

					if (projectobject.has("fromYear")) {
						projectfromYear = (String) projectobject.get("fromYear");
					}

					if (projectobject.has("toMonth")) {
						projecttoMonth = (String) projectobject.get("toMonth");
					}
					if (projectobject.has("toYear")) {
						projecttoYear = (String) projectobject.get("toYear");
					}
					if (projectobject.has("url")) {
						projecturl = (String) projectobject.get("url");
					}
					if (projectobject.has("projectDescription")) {
						projectDescription = (String) projectobject.get("projectDescription");
					}

					projectMap.put("projectTitle", projectTitle);

					projectMap.put("projectRole", projectRole);
					projectMap.put("fromMonth", projectfromMonth);
					projectMap.put("fromYear", projectfromYear);

					projectMap.put("toMonth", projecttoMonth);
					projectMap.put("toYear", projecttoYear);
					projectMap.put("url", projecturl);
					projectMap.put("projectDescription", projectDescription);

					projectObj.put(projectMap);

				}

			}

			else {
				projectMap.put("projectTitle", projectTitle);

				projectMap.put("projectRole", projectRole);
				projectMap.put("fromMonth", projectfromMonth);
				projectMap.put("fromYear", projectfromYear);

				projectMap.put("toMonth", projecttoMonth);
				projectMap.put("toYear", projecttoYear);
				projectMap.put("url", projecturl);
				projectMap.put("projectDescription", projectDescription);

				projectObj.put(projectMap);

			}
			if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
				preferredLocation = (String) jsonCand4.get("preferredLocation");
			} else {
				preferredLocation = "";
			}
			if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
				createdBy = (String) jsonCand4.get("createdBy");
			} else {
				createdBy = "";
			}
			if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
				username = (String) jsonCand4.get("username");
			} else {
				username = "";
			}
			if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
				ids = (String) jsonCand4.get("id");
			} else {
				String id = "";
			}
			if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
				name = (String) jsonCand4.get("name");
			} else {
				name = "";
			}
			if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
				email = (String) jsonCand4.get("email");
			} else {
				email = "";
			}
			if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
				birthdate = (String) jsonCand4.get("birthdate");
			} else {
				birthdate = "";
				System.out.println("birthdate >> " + birthdate);
			}
			if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
				mobileNumber = (String) jsonCand4.get("mobileNumber");
			} else {
				mobileNumber = "";
			}

			if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
				lastModified = (String) jsonCand4.get("lastModified");
			} else {
				lastModified = "";
			}

			//// experience....

			JSONObject experience1 = null;
			if (jsonCand4.has("experience") && !jsonCand4.get("experience").equals(null)) {
				experience1 = (JSONObject) jsonCand4.get("experience");
				System.out.println("experience1 >> " + experience1);
				if (experience1.has("months") && !experience1.get("months").equals(null)) {
					months = (Integer) experience1.get("months");
				} else {
					months = null;
				}
				if (experience1.has("TotalExp") && !experience1.get("TotalExp").equals(null)) {
					TotalExp = (String) experience1.get("TotalExp");
				} else {
					TotalExp = "";
				}
				if (experience1.has("years") && !experience1.get("years").equals(null)) {
					years = (Integer) experience1.get("years");
					System.out.println("years >> " + years);
				} else {
					years = null;
				}
			} else {
				experience = "";
			}

			// salary......
			JSONObject salary1 = null;

			if (jsonCand4.has("salary") && !jsonCand4.get("salary").equals(null)) {
				salary1 = (JSONObject) jsonCand4.get("salary");
				System.out.println("salry1 >> " + salary1);
				if (salary1.has("currentCTCType") && !salary1.get("currentCTCType").equals(null)) {
					currentCTCType = (String) salary1.get("currentCTCType");
				} else {
					currentCTCType = "";
				}
				if (salary1.has("currentCTC") && !salary1.get("currentCTC").equals(null)) {
					currentCTC = (String) salary1.get("currentCTC");
				} else {
					currentCTC = "";
				}
				if (salary1.has("negotiableCTC") && !salary1.get("negotiableCTC").equals(null)) {
					negotiableCTC = (String) salary1.get("negotiableCTC");
				} else {
					negotiableCTC = "";
				}
				if (salary1.has("expectedCTCType") && !salary1.get("expectedCTCType").equals(null)) {
					expectedCTCType = (String) salary1.get("expectedCTCType");
				} else {
					expectedCTCType = "";
				}
				if (salary1.has("expectedCTC") && !salary1.get("expectedCTC").equals(null)) {
					expectedCTC = (String) salary1.get("expectedCTC");
				} else {
					expectedCTC = "";
				}
				if (salary1.has("takeHome") && !salary1.get("takeHome").equals(null)) {
					takeHome = (String) salary1.get("takeHome");
				} else {
					takeHome = "";
				}
				if (salary1.has("fixed") && !salary1.get("fixed").equals(null)) {
					fixed = (String) salary1.get("fixed");
				} else {
					fixed = "";
				}

			} else {
				salary = "";
			}

			/// address......permanent
			// JSONObject permanentAddressJson = new JSONObject();
			Map<String, String> permanentAddressJson = new HashMap<String, String>();
			JSONObject permanentAddressJson123 = new JSONObject();
			JSONObject currentAddressJson = new JSONObject();
			JSONObject addressJson2 = new JSONObject();

			JSONObject addressJson1 = new JSONObject();
			JSONObject currentaddressJson1 = new JSONObject();
			//
			// if (jsonCand4.has("address") &&
			// !jsonCand4.get("address").equals(null)) {
			// permanentAddressJson123 = (JSONObject) jsonCand4.get("address");
			//
			// System.out.println("ssssssssssssaddrews" +
			// permanentAddressJson123);
			//
			// if (permanentAddressJson123.has("permanentAddress")) {
			//
			// System.out.println("Address Json Permanent....." +
			// permanentAddressJson123);
			//
			// if (permanentAddressJson123.has("country")) {
			// permanentcountry = (String)
			// permanentAddressJson123.get("country");
			//
			// permanentAddressJson.put("country", permanentcountry);
			//
			// }
			// if (permanentAddressJson123.has("state")) {
			// permanentstate = (String) permanentAddressJson123.get("state");
			// permanentAddressJson.put("state", permanentstate);
			//
			// }
			// if (permanentAddressJson123.has("city")) {
			// permanentcity = (String) permanentAddressJson123.get("city");
			// permanentAddressJson.put("city", permanentcity);
			// }
			// if (permanentAddressJson123.has("street")) {
			// permanentstreet = (String) permanentAddressJson123.get("street");
			// System.out.println("permanentstreet...." + permanentstreet);
			// permanentAddressJson.put("street", permanentstreet);
			//
			// }
			// if (permanentAddressJson123.has("pincode")) {
			// permanentpincode = (String)
			// permanentAddressJson123.get("pincode");
			// System.out.println("pincode...." + permanentpincode);
			// permanentAddressJson.put("pincode", permanentpincode);
			//
			// }
			// if (permanentAddressJson123.has("location")) {
			// permanentlocation = (String)
			// permanentAddressJson123.get("location");
			// System.out.println("location...." + permanentlocation);
			// permanentAddressJson.put("location", permanentlocation);
			//
			// }
			// System.out.println("If .........." + permanentAddressJson);
			// } else {
			//
			// permanentAddressJson.put("country", permanentcountry);
			// permanentAddressJson.put("state", permanentstate);
			// permanentAddressJson.put("city", permanentcity);
			// permanentAddressJson.put("street", permanentstreet);
			// permanentAddressJson.put("pincode", permanentpincode);
			// permanentAddressJson.put("location", permanentlocation);
			//
			// System.out.println("Else .........." + permanentAddressJson);
			//
			// System.out.println("ssssssssssss" + permanentAddressJson);
			//
			// }
			//
			// addressJson2.put("permanentAddress", permanentAddressJson);
			//
			// System.out.println("Permanent Address......" +
			// permanentAddressJson);
			//
			// if (addressJson1.has("currentAddress") &&
			// !addressJson1.get("currentAddress").equals(null)) {
			// System.out.println("currentAddress >> " +
			// addressJson1.get("currentAddress"));
			//
			// currentaddressJson1 = (JSONObject)
			// addressJson1.get("currentAddress");
			// System.out.println("currentAddress1 >>> " + addressJson1);
			// if (currentaddressJson1.has("country") &&
			// !currentaddressJson1.get("country").equals(null)) {
			// country = (String) currentaddressJson1.get("country");
			// currentAddressJson.put("country", country);
			//
			// } else {
			// country = "";
			//
			// }
			// if (currentaddressJson1.has("state") &&
			// !currentaddressJson1.get("state").equals(null)) {
			//
			// state = (String) currentaddressJson1.get("state");
			// currentAddressJson.put("state", state);
			// } else {
			// state = "";
			//
			// }
			// if (currentaddressJson1.has("city") &&
			// !currentaddressJson1.get("city").equals(null)) {
			// city = (String) currentaddressJson1.get("city");
			// currentAddressJson.put("city", city);
			// } else {
			// city = "";
			// System.out.println("city current>> " + city);
			// }
			// if (currentaddressJson1.has("street") &&
			// !currentaddressJson1.get("street").equals(null)) {
			// street = (String) currentaddressJson1.get("street");
			// currentAddressJson.put("street", street);
			// System.out.println("street current>> " + street);
			// } else {
			// street = "";
			// System.out.println("street current>> " + street);
			// }
			// if (currentaddressJson1.has("pincode") &&
			// !currentaddressJson1.get("pincode").equals(null)) {
			// pincode = (String) currentaddressJson1.get("pincode");
			// currentAddressJson.put("pincode", pincode);
			// System.out.println("pincode current>> " + pincode);
			// } else {
			// pincode = "";
			// System.out.println("pincode current >> " + pincode);
			// }
			// if (currentaddressJson1.has("location") &&
			// !currentaddressJson1.get("location").equals(null)) {
			// location = (String) currentaddressJson1.get("location");
			// currentAddressJson.put("location", location);
			// System.out.println("location current >> " + location);
			// } else {
			// location = "";
			// System.out.println("location current >> " + location);
			// }
			// } else {
			//
			// currentAddressJson.put("country", country);
			// currentAddressJson.put("state", state);
			// currentAddressJson.put("city", city);
			// currentAddressJson.put("street", street);
			//
			// currentAddressJson.put("pincode", pincode);
			// currentAddressJson.put("location", location);
			//
			// }
			//
			// addressJson2.accumulate("currentAddress", currentAddressJson);
			// }

			if (jsonCand4.has("address")) {

				JSONObject addressJson = (JSONObject) jsonCand4.get("address");
				JSONObject addressJ = new JSONObject();

				if (addressJson.has("permanentAddress")) {

					addressJson1 = (JSONObject) addressJson.get("permanentAddress");

					if (addressJson1.has("country"))
						addressJ.accumulate("country", addressJson1.getString("country"));
					else
						addressJ.accumulate("country", "");

					if (addressJson1.has("state"))
						addressJ.accumulate("state", addressJson1.getString("state"));
					else
						addressJ.accumulate("state", "");

					if (addressJson1.has("city"))
						addressJ.accumulate("city", addressJson1.getString("city"));
					else
						addressJ.accumulate("city", "");

					if (addressJson1.has("street"))
						addressJ.accumulate("street", addressJson1.getString("street"));
					else
						addressJ.accumulate("street", "");

					if (addressJson1.has("pincode"))
						addressJ.accumulate("pincode", addressJson1.getString("pincode"));
					else
						addressJ.accumulate("pincode", "");

					if (addressJson1.has("location"))
						addressJ.accumulate("location", addressJson1.getString("location"));
					else
						addressJ.accumulate("location", "");

					addressJson2.accumulate("permanentAddress", addressJ);
				}

				else {

					currentAddressJson.put("country", "");
					currentAddressJson.put("state", "");
					currentAddressJson.put("city", "");
					currentAddressJson.put("street", "");

					currentAddressJson.put("pincode", "");
					currentAddressJson.put("location", "");
					addressJson2.accumulate("permanentAddress", currentAddressJson);
				}

				JSONObject addressJ1 = new JSONObject();
				if (addressJson.has("currentAddress")) {

					addressJson1 = (JSONObject) addressJson.get("currentAddress");
					System.out.println("Address json....." + addressJson1);

					addressJ1.accumulate("country", addressJson1.getString("country"));

					addressJ1.accumulate("state", addressJson1.getString("state"));

					addressJ1.accumulate("city", addressJson1.getString("city"));

					addressJ1.accumulate("street", addressJson1.getString("street"));

					addressJ1.accumulate("pincode", addressJson1.getString("pincode"));

					addressJ1.accumulate("location", addressJson1.getString("location"));

					addressJson2.put("currentAddress", addressJ1);

					System.out.println("Current addtess......." + addressJ1);
				}

				else {
					currentAddressJson.put("country", "");
					currentAddressJson.put("state", "");
					currentAddressJson.put("city", "");
					currentAddressJson.put("street", "");

					currentAddressJson.put("pincode", "");
					currentAddressJson.put("location", "");

					addressJson2.accumulate("currentAddress", currentAddressJson);
				}

			}

			/// Education..
			JSONObject ugjson = null;
			JSONObject ug1 = null;
			JSONObject pgjson = null;
			JSONObject pg1 = null;
			JSONObject twelvethjson = null;
			JSONObject twelveth1 = null;
			JSONObject tenthjson = null;
			JSONObject tenth1 = null;

			JSONObject educationjson = null;
			JSONObject educationjson1 = null;

			// if (jsonCand4.has("education") &&
			// !jsonCand4.get("education").equals(null)) {
			//
			//
			//
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("ug") &&
			// !educationjson.get("ug").equals(null)) {
			// System.out.println("ug >>> " + educationjson.get("ug"));
			// // ug1=new JSONObject();
			// // ug1=(JSONObject) ugjson.get("ug");
			//
			// educationjson1 = (JSONObject) educationjson.get("ug");
			// System.out.println("ug1 >> " + educationjson1);
			// if (educationjson1.has("degree") &&
			// !educationjson1.get("degree").equals(null)) {
			// degree = (String) educationjson1.get("degree");
			// System.out.println("degree >>> " + educationjson1.get("degree"));
			// } else {
			// degree = "";
			// System.out.println("degree >> " + degree);
			// }
			//
			//
			// if (educationjson1.has("degreeType") &&
			// !educationjson1.get("degreeType").equals(null)) {
			// degreeType = (String) educationjson1.get("degreeType");
			// System.out.println("degreeType >>> " +
			// educationjson1.get("degreeType"));
			// } else {
			// degreeType = "";
			// System.out.println("degreeType >> " + degreeType);
			// }
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			//
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			//
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			//
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			//
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			//
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			//
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			//
			// } else {
			// toYear = "";
			//
			// }
			// if (educationjson1.has("percentage") &&
			// !educationjson1.get("percentage").equals(null)) {
			// percentage = (String) educationjson1.get("percentage");
			//
			// } else {
			// percentage = "";
			//
			// }
			//
			// } else {
			// ug = "";
			// System.out.println("ug >> " + ug);
			// }
			//
			//
			// System.out.println("Hiiiiiiiiiiiii");
			//
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("pg") &&
			// !educationjson.get("pg").equals(null)) {
			//
			//
			//
			// educationjson1 = (JSONObject) educationjson.get("pg");
			// System.out.println("pg1 >> " + educationjson1);
			//
			// if (educationjson1.has("degree") &&
			// !educationjson1.get("degree").equals(null)) {
			// degree = (String) educationjson1.get("degree");
			// System.out.println("degree >>> " + educationjson1.get("degree"));
			// } else {
			// degree = "";
			// System.out.println("degree >> " + degree);
			// }
			// if (educationjson1.has("degreeType") &&
			// !educationjson1.get("degreeType").equals(null)) {
			// degreeType = (String) educationjson1.get("degreeType");
			// System.out.println("degreeType >>> " +
			// educationjson1.get("degreeType"));
			// } else {
			// degreeType = "";
			// System.out.println("degreeType >> " + degreeType);
			// }
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			// System.out.println("institute >>> " +
			// educationjson1.get("institute"));
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			// System.out.println("universityOrBoard >>> " +
			// educationjson1.get("universityOrBoard"));
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			// System.out.println("city >>> " + educationjson1.get("city"));
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			// System.out.println("fromMonth >>> " +
			// educationjson1.get("fromMonth"));
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			// System.out.println("fromYear >>> " +
			// educationjson1.get("fromYear"));
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			// System.out.println("toMonth >> " + toMonth);
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			// System.out.println("toYear >> " + toYear);
			// }
			//
			// else {
			// toYear = "";
			// System.out.println("toYear >> " + toYear);
			// }
			// if (educationjson1.has("percentage") &&
			// !educationjson1.get("percentage").equals(null)) {
			// percentage = (String) educationjson1.get("percentage");
			// System.out.println("percentage >> " + percentage);
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			//
			// } else {
			// pg = "";
			// System.out.println("pg >>" + pg);
			// } // end pg
			//
			// //// doctrate start
			//
			// System.out.println("Hiiiiiiiiiiiii");
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("doctorate") &&
			// !educationjson.get("doctorate").equals(null)) {
			// System.out.println("doctorate Json >>> " +
			// educationjson.get("doctorate"));
			//
			// // JSONObject doctorate1=new JSONObject();
			// // System.out.println("doctorate1 >> "+doctorate1);
			// educationjson1 = (JSONObject) educationjson.get("twelveth");
			// System.out.println("doctorate1 >>> " + educationjson1);
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			// System.out.println("institute >>> " +
			// educationjson1.get("institute"));
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			// System.out.println("universityOrBoard >>> " +
			// educationjson1.get("universityOrBoard"));
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			// System.out.println("city >>> " + educationjson1.get("city"));
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			// System.out.println("fromMonth >>> " +
			// educationjson1.get("fromMonth"));
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			// System.out.println("fromYear >>> " +
			// educationjson1.get("fromYear"));
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			// System.out.println("toMonth >> " + toMonth);
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			// System.out.println("toYear >> " + toYear);
			// } else {
			// toYear = "";
			// System.out.println("toYear >> " + toYear);
			// }
			// if (educationjson1.has("percentage") &&
			// !educationjson1.get("percentage").equals(null)) {
			// percentage = (String) educationjson1.get("percentage");
			// System.out.println("percentage >> " + percentage);
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			//
			// } else {
			// doctorate = "";
			// System.out.println("doctorate >>" + doctorate);
			// }
			//
			// /// start Diploma
			//
			// System.out.println("Hiiiiiiiiiiiii");
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("diploma") &&
			// !educationjson.get("diploma").equals(null)) {
			// System.out.println("diploma Json >>> " +
			// educationjson.get("diploma"));
			//
			// // JSONObject diploma1=new JSONObject();
			// // System.out.println("diploma1 >> "+diploma1);
			// educationjson1 = (JSONObject) educationjson.get("diploma");
			// System.out.println("diploma1 >>> " + educationjson1);
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			// System.out.println("institute >>> " +
			// educationjson1.get("institute"));
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			// System.out.println("universityOrBoard >>> " +
			// educationjson1.get("universityOrBoard"));
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			// System.out.println("city >>> " + educationjson1.get("city"));
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			// System.out.println("fromMonth >>> " +
			// educationjson1.get("fromMonth"));
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			// System.out.println("fromYear >>> " +
			// educationjson1.get("fromYear"));
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			// System.out.println("toMonth >> " + toMonth);
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			// System.out.println("toYear >> " + toYear);
			// } else {
			// toYear = "";
			// System.out.println("toYear >> " + toYear);
			// }
			// if (educationjson1.has("percentage") &&
			// !educationjson1.get("percentage").equals(null)) {
			// percentage = (String) educationjson1.get("percentage");
			// System.out.println("percentage >> " + percentage);
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			//
			// } else {
			// diploma = "";
			// System.out.println("diploma >>" + diploma);
			// }
			//
			// //////// start 12th
			// System.out.println("Hiiiiiiiiiiiii");
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("twelveth") &&
			// !educationjson.get("twelveth").equals(null)) {
			// System.out.println("pg1 Json >>> " +
			// educationjson.get("twelveth"));
			//
			// // twelveth1=new JSONObject();
			// // System.out.println("twelveth1 >> "+twelveth1);
			// educationjson1 = (JSONObject) educationjson.get("twelveth");
			// System.out.println("twelveth1 >>> " + educationjson1);
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			// System.out.println("institute >>> " +
			// educationjson1.get("institute"));
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			// System.out.println("universityOrBoard >>> " +
			// educationjson1.get("universityOrBoard"));
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			// System.out.println("city >>> " + educationjson1.get("city"));
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			// System.out.println("fromMonth >>> " +
			// educationjson1.get("fromMonth"));
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			// System.out.println("fromYear >>> " +
			// educationjson1.get("fromYear"));
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			// System.out.println("toMonth >> " + toMonth);
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			// System.out.println("toYear >> " + toYear);
			// } else {
			// toYear = "";
			// System.out.println("toYear >> " + toYear);
			// }
			// if (!educationjson1.get("percentage").equals(null)) {
			// percentage = (String) educationjson1.get("percentage");
			// System.out.println("percentage >> " + percentage);
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			//
			// System.out.println("educationjson1 >> " + educationjson1);
			// if (educationjson1.has("percentage")) {
			// if (!educationjson1.get("percentage").equals(null)) {
			// if (educationjson1.has("percentage")) {
			// percentage = (String) educationjson1.get("percentage");
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			// }
			// }
			//
			// } else {
			// twelveth = "";
			// System.out.println("twelveth >>" + twelveth);
			// }
			//
			// // end twelveth
			//
			// // Start tenth
			// System.out.println("Hiiiiiiiiiiiii");
			// educationjson = (JSONObject) jsonCand4.get("education");
			// if (educationjson.has("tenth") &&
			// !educationjson.get("tenth").equals(null)) {
			// System.out.println("tetnth Json >>> " +
			// educationjson.get("tenth"));
			//
			// // tenth1=new JSONObject();
			// // System.out.println("tenth1 >> "+tenth1);
			// educationjson1 = (JSONObject) educationjson.get("tenth");
			// System.out.println("tenth1 >>> " + educationjson1);
			//
			// if (educationjson1.has("degree") &&
			// !educationjson1.get("degree").equals(null)) {
			// degree = (String) educationjson1.get("degree");
			// System.out.println("degree >>> " + educationjson1.get("degree"));
			// } else {
			// degree = "";
			// System.out.println("degree >> " + degree);
			// }
			// if (educationjson1.has("degreeType") &&
			// !educationjson1.get("degreeType").equals(null)) {
			// degreeType = (String) educationjson1.get("degreeType");
			// System.out.println("degreeType >>> " +
			// educationjson1.get("degreeType"));
			// } else {
			// degreeType = "";
			// System.out.println("degreeType >> " + degreeType);
			// }
			//
			// if (educationjson1.has("course") &&
			// !educationjson1.get("course").equals(null)) {
			// course = (String) educationjson1.get("course");
			// System.out.println("course >>> " + educationjson1.get("course"));
			// } else {
			// course = "";
			// System.out.println("course >> " + course);
			// }
			// if (educationjson1.has("institute") &&
			// !educationjson1.get("institute").equals(null)) {
			// institute = (String) educationjson1.get("institute");
			// System.out.println("institute >>> " +
			// educationjson1.get("institute"));
			// } else {
			// institute = "";
			// System.out.println("institute >> " + institute);
			// }
			// if (educationjson1.has("universityOrBoard")
			// && !educationjson1.get("universityOrBoard").equals(null)) {
			// universityOrBoard = (String)
			// educationjson1.get("universityOrBoard");
			// System.out.println("universityOrBoard >>> " +
			// educationjson1.get("universityOrBoard"));
			// } else {
			// universityOrBoard = "";
			// System.out.println("universityOrBoard >> " + universityOrBoard);
			// }
			// if (educationjson1.has("city") &&
			// !educationjson1.get("city").equals(null)) {
			// city = (String) educationjson1.get("city");
			// System.out.println("city >>> " + educationjson1.get("city"));
			// } else {
			// city = "";
			// System.out.println("city >> " + city);
			// }
			// if (educationjson1.has("fromMonth") &&
			// !educationjson1.get("fromMonth").equals(null)) {
			// fromMonth = (String) educationjson1.get("fromMonth");
			// System.out.println("fromMonth >>> " +
			// educationjson1.get("fromMonth"));
			// } else {
			// fromMonth = "";
			// System.out.println("fromMonth >> " + fromMonth);
			// }
			// if (educationjson1.has("fromYear") &&
			// !educationjson1.get("fromYear").equals(null)) {
			// fromYear = (String) educationjson1.get("fromYear");
			// System.out.println("fromYear >>> " +
			// educationjson1.get("fromYear"));
			// } else {
			// fromYear = "";
			// System.out.println("fromYear >> " + fromYear);
			// }
			// if (educationjson1.has("toMonth") &&
			// !educationjson1.get("toMonth").equals(null)) {
			// toMonth = (String) educationjson1.get("toMonth");
			// System.out.println("toMonth >> " + toMonth);
			// } else {
			// toMonth = "";
			// System.out.println("toMonth >> " + toMonth);
			// }
			// if (educationjson1.has("toYear") &&
			// !educationjson1.get("toYear").equals(null)) {
			// toYear = (String) educationjson1.get("toYear");
			// System.out.println("toYear >> " + toYear);
			// } else {
			// toYear = "";
			// System.out.println("toYear >> " + toYear);
			// }
			//
			// System.out.println("educationjson1 >> " + educationjson1);
			// if (educationjson1.has("percentage")) {
			// if (!educationjson1.get("percentage").equals(null)) {
			// if (educationjson1.has("percentage")) {
			// percentage = (String) educationjson1.get("percentage");
			// } else {
			// percentage = "";
			// System.out.println("percentage >> " + percentage);
			// }
			// }
			// }
			//
			// } else {
			// tenth = "";
			// System.out.println("twelveth >>" + tenth);
			// }
			//
			// // end tenth
			// //////////
			//
			// } else {
			// education = "";
			// System.out.println("education >> " + education);
			// }

			JSONObject education = new JSONObject();
			if (education.has("education")) {
				
			

			educationjson = (JSONObject) jsonCand4.get("education");

			JSONObject blankEdu = new JSONObject();

			blankEdu.put("degree", "");
			blankEdu.put("degreeType", "");
			blankEdu.put("course", "");
			blankEdu.put("institute", "");
			blankEdu.put("universityOrBoard", "");
			blankEdu.put("city", "");
			blankEdu.put("fromMonth", "");
			blankEdu.put("fromYear", "");
			blankEdu.put("toMonth", "");
			blankEdu.put("toYear", "");
			blankEdu.put("percentage", "");

			if (educationjson.has("ug")) {
				JSONObject subEdu = new JSONObject();

				educationjson1 = (JSONObject) educationjson.get("ug");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("ug", subEdu);
			} else
				education.put("ug", blankEdu);

			if (educationjson.has("pg")) {

				JSONObject subEdu = new JSONObject();

				educationjson1 = (JSONObject) educationjson.get("pg");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("pg", subEdu);

			} else
				education.put("pg", blankEdu); // end pg

			if (educationjson.has("doctorate")) {

				JSONObject subEdu = new JSONObject();

				educationjson1 = (JSONObject) educationjson.get("doctorate");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("doctorate", subEdu);

			} else
				education.put("doctorate", blankEdu);

			if (educationjson.has("diploma")) {

				JSONObject subEdu = new JSONObject();

				educationjson1 = (JSONObject) educationjson.get("diploma");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("diploma", subEdu);

			} else
				education.put("diploma", blankEdu);

			if (educationjson.has("twelveth")) {

				JSONObject subEdu = new JSONObject();

				educationjson1 = (JSONObject) educationjson.get("twelveth");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("twelveth", subEdu);

			} else
				education.put("twelveth", blankEdu);
			JSONObject subEdu = new JSONObject();

			if (educationjson.has("tenth")) {

				educationjson1 = (JSONObject) educationjson.get("tenth");

				if (educationjson1.has("degree"))
					subEdu.put("degree", educationjson1.getString("degree"));
				else
					subEdu.put("degree", "");

				if (educationjson1.has("degreeType"))
					subEdu.put("degreeType", educationjson1.getString("degreeType"));
				else
					subEdu.put("degreeType", "");

				if (educationjson1.has("course"))
					subEdu.put("course", educationjson1.getString("course"));
				else
					subEdu.put("course", "");

				if (educationjson1.has("institute"))
					subEdu.put("institute", educationjson1.getString("institute"));
				else
					subEdu.put("institute", "");

				if (educationjson1.has("universityOrBoard"))
					subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
				else
					subEdu.put("universityOrBoard", "");

				if (educationjson1.has("city"))
					subEdu.put("city", educationjson1.getString("city"));
				else
					subEdu.put("city", "");

				if (educationjson1.has("fromMonth"))
					subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
				else
					subEdu.put("fromMonth", "");

				if (educationjson1.has("fromYear"))
					subEdu.put("fromYear", educationjson1.getString("fromYear"));
				else
					subEdu.put("fromYear", "");

				if (educationjson1.has("toMonth"))
					subEdu.put("toMonth", educationjson1.getString("toMonth"));
				else
					subEdu.put("toMonth", "");

				if (educationjson1.has("toYear"))
					subEdu.put("toYear", educationjson1.getString("toYear"));
				else
					subEdu.put("toYear", "");

				if (educationjson1.has("percentage"))
					subEdu.put("percentage", educationjson1.getString("percentage"));
				else
					subEdu.put("percentage", "");

				education.put("tenth", subEdu);

			} else
				education.put("tenth", blankEdu);
			}
			else
				education.put("education", "");
			// candijson.put("education", education);

			JSONObject employment1 = null;

			JSONArray previous1 = null;
			String previousOrganization = "";
			String previousDesignation = "";
			String previousLevel = "";
			String previousCity = "";
			String previousFromMonth = "";
			String previousFromYear = "";
			String previousToMonth = "";
			String previousToYear = "";
			String previousDescription = "";

			JSONObject current1 = new JSONObject();
			JSONObject employement = new JSONObject();

			JSONObject getemployment = jsonCand4.getJSONObject("employment");

			if (getemployment.has("current")) {

				JSONObject getcurrent = getemployment.getJSONObject("current");

				if (getcurrent.has("companyName"))
					current1.put("companyName", getcurrent.getString("companyName"));
				else
					current1.put("companyName", "");

				if (getcurrent.has("designation"))
					current1.put("designation", getcurrent.getString("designation"));
				else
					current1.put("designation", "");

				if (getcurrent.has("isCurrent"))
					current1.put("isCurrent", getcurrent.get("isCurrent"));
				else
					current1.put("isCurrent", "");

				if (getcurrent.has("desc"))
					current1.put("desc", getcurrent.getString("desc"));
				else
					current1.put("desc", "");

				if (getcurrent.has("workLocation"))
					current1.put("workLocation", getcurrent.getString("workLocation"));
				else
					current1.put("workLocation", "");

				if (getcurrent.has("role"))
					current1.put("role", getcurrent.getString("role"));
				else
					current1.put("role", "");

				if (getcurrent.has("level"))
					current1.put("level", getcurrent.getString("level"));
				else
					current1.put("level", "");

				if (getcurrent.has("teamSize"))
					current1.put("teamSize", getcurrent.getString("teamSize"));
				else
					current1.put("teamSize", "");

				employement.put("current", current1);
			} else
				employement.put("current", current1);

			if (getemployment.has("previous")) {

				// JSONArray previous = new JSONArray();

				JSONArray getprevious = getemployment.getJSONArray("previous");
				int i = 0;

				for (i = 0; i < getprevious.length(); i++) {

					JSONObject jsonprevious = (JSONObject) getprevious.get(i);

					if (jsonprevious.has("organization"))
						jsonprevious.put("organization", jsonprevious.getString("organization"));
					else
						jsonprevious.put("organization", "");

					if (jsonprevious.has("designation"))
						jsonprevious.put("designation", jsonprevious.getString("designation"));
					else
						jsonprevious.put("designation", "");

					if (jsonprevious.has("level"))
						jsonprevious.put("level", jsonprevious.getString("level"));
					else
						jsonprevious.put("level", "");

					if (jsonprevious.has("city"))
						jsonprevious.put("city", jsonprevious.getString("city"));
					else
						jsonprevious.put("city", "");

					if (jsonprevious.has("fromMonth"))
						jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
					else
						jsonprevious.put("fromMonth", "");

					if (jsonprevious.has("fromYear"))
						jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
					else
						jsonprevious.put("fromYear", "");

					if (jsonprevious.has("toMonth"))
						jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
					else
						jsonprevious.put("toMonth", "");

					if (jsonprevious.has("toYear"))
						jsonprevious.put("toYear", jsonprevious.getString("toYear"));
					else
						jsonprevious.put("toYear", "");

					if (jsonprevious.has("description"))
						jsonprevious.put("description", jsonprevious.getString("description"));
					else
						jsonprevious.put("description", "");

					previous.put(jsonprevious);
				}
				employement.put("previous", previous);
			} else
				employement.put("previous", previous);

			// if (jsonCand4.has("employement") &&
			// !jsonCand4.get("employement").equals(null)) {
			// employment1 = jsonCand4.getJSONObject("employement");
			// if (employment1.has("current") &&
			// !employment1.get("current").equals(null)) {
			// current1 = employment1.getJSONObject("current");
			// System.out.println("current jsonObject >>" + current);
			// if (current1.has("companyName") &&
			// !current1.get("companyName").equals(null)) {
			// companyName = current1.getString("companyName");
			// System.out.println("companyName >> " + companyName);
			// } else {
			// companyName = "";
			// }
			// if (current1.has("designation") &&
			// !current1.get("designation").equals(null)) {
			// designation = current1.getString("designation");
			// System.out.println("desidnation >> " + designation);
			// } else {
			// designation = "";
			// }
			// if (current1.has("isCurrent") &&
			// !current1.get("isCurrent").equals(null)) {
			// isCurrent = current1.getString("isCurrent");
			// System.out.println("isCurrent >>" + isCurrent);
			// } else {
			// isCurrent = "";
			// }
			// if (current1.has("desc") && !current1.get("desc").equals(null)) {
			// desc = current1.getString("desc");
			// System.out.println("desc >> " + desc);
			// } else {
			// desc = "";
			// }
			// if (current1.has("workLocation") &&
			// !current1.get("workLocation").equals(null)) {
			// workLocation = current1.getString("workLocation");
			// System.out.println("workLocation >>" + workLocation);
			// } else {
			// workLocation = "";
			// }
			// if (current1.has("role") && !current1.get("role").equals(null)) {
			// role = current1.getString("role");
			// System.out.println("role >> " + role);
			// } else {
			// role = "";
			// }
			// if (current1.has("level") && !current1.get("level").equals(null))
			// {
			// level = current1.getString("level");
			// System.out.println("level >> " + level);
			// } else {
			// level = "";
			// }
			// if (current1.has("teamSize") &&
			// !current1.get("teamSize").equals(null)) {
			// teamSize = current1.getString("teamSize");
			// System.out.println("teamSize >> " + teamSize);
			// } else {
			// teamSize = "";
			// }
			//
			// }
			//
			// if (employment1.has("previous") &&
			// !employment1.get("previous").equals(null)
			// || !employment1.isNull("previous")) {
			// previous1 = employment1.getJSONArray("previous");
			// System.out.println("previous1 >> " + previous1);
			// int i = 0;
			// for (i = 0; i < previous1.length(); i++) {
			// JSONObject jsonprevious = previous1.getJSONObject(i);
			// if (jsonprevious.has("organization") &&
			// !jsonprevious.get("organization").equals(null)) {
			// previousOrganization = jsonprevious.getString("organization");
			// System.out.println("previousOrganization >>" +
			// previousOrganization);
			// } else {
			// previousOrganization = "";
			// }
			// if (jsonprevious.has("designation") &&
			// !jsonprevious.get("designation").equals(null)) {
			// previousDesignation = jsonprevious.getString("designation");
			// System.out.println("previousDesignation >>" +
			// previousDesignation);
			// } else {
			// previousDesignation = "";
			// }
			// if (jsonprevious.has("level") &&
			// !jsonprevious.get("level").equals(null)) {
			// previousLevel = jsonprevious.getString("level");
			//
			// } else {
			// previousLevel = "";
			// }
			// if (jsonprevious.has("city") &&
			// !jsonprevious.get("city").equals(null)) {
			// previousCity = jsonprevious.getString("city");
			// } else {
			// previousCity = "";
			// }
			// if (jsonprevious.has("fromMonth") &&
			// !jsonprevious.get("fromMonth").equals(null)) {
			// previousFromMonth = jsonprevious.getString("fromMonth");
			// } else {
			// previousFromMonth = "";
			// }
			// if (jsonprevious.has("fromYear") &&
			// !jsonprevious.get("fromYear").equals(null)) {
			// previousFromYear = jsonprevious.getString("fromYear");
			// } else {
			// previousFromYear = "";
			// }
			// if (jsonprevious.has("toMonth") &&
			// !jsonprevious.get("toMonth").equals(null)) {
			// previousToMonth = jsonprevious.getString("toMonth");
			// } else {
			// previousToMonth = "";
			// }
			// if (jsonprevious.has("toYear") &&
			// !jsonprevious.get("toYear").equals(null)) {
			// previousToYear = jsonprevious.getString("toYear");
			// } else {
			// previousToYear = "";
			// }
			// if (jsonprevious.has("description") &&
			// !jsonprevious.get("description").equals(null)) {
			// previousDescription = jsonprevious.getString("description");
			// } else {
			// previousDescription = "";
			// }
			// }
			//
			// }
			// }

			if (jsonCand4.has("html")) {
				JSONObject gethtml = (JSONObject) jsonCand4.get("html");
				JSONObject html = new JSONObject();

				if (gethtml.has("naukri")) {

					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();

					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", "");

					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", "");

					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", "");

					html.put("naukri", naukri);

				} else
					html.put("naukri", "");

				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

					JSONObject linkedIn = new JSONObject();

					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", "");

					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", "");

					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", "");

					html.put("linkedIn", linkedIn);

				} else
					html.put("linkedIn", "");

				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");

					JSONObject monster = new JSONObject();

					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", "");

					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", "");

					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", "");

					html.put("monster", monster);

				} else
					html.put("monster", "");

				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

					JSONObject naukriGulf = new JSONObject();

					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", "");

					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", "");

					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", "");

					html.put("naukriGulf", naukriGulf);

				} else
					html.put("naukriGulf", "");

				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

					JSONObject careerBuilder = new JSONObject();

					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", "");

					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", "");

					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", "");

					html.put("careerBuilder", careerBuilder);

				} else
					html.put("careerBuilder", "");

				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

					JSONObject monsterUS = new JSONObject();

					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", "");

					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", "");

					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", "");

					html.put("monsterUS", monsterUS);

				} else
					html.put("monsterUS", "");

				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");

					JSONObject dice = new JSONObject();

					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", "");

					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", "");

					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", "");

					html.put("dice", dice);

				} else
					html.put("dice", "");

				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

					JSONObject jobDiva = new JSONObject();

					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", "");

					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", "");

					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", "");

					html.put("jobDiva", jobDiva);

				} else
					html.put("jobDiva", "");

				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");

					JSONObject indeed = new JSONObject();

					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", "");

					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", "");

					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", "");

					html.put("indeed", indeed);

				} else
					html.put("indeed", "");

				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

					JSONObject jobServe = new JSONObject();

					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", "");

					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", "");

					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", "");

					html.put("jobServe", jobServe);

				} else
					html.put("jobServe", "");

				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");

					JSONObject other = new JSONObject();

					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", "");

					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", "");

					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", "");

					html.put("other", other);

				} else
					html.put("other", "");

				html1.put("html", html);
			} else
				html1.put("html", "");

			JSONArray altenaiteEmail1 = new JSONArray();
			int m = 0;
			if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
				altenaiteEmail1 = (JSONArray) jsonCand4.get("alternateEmail");
				System.out.println("altenail:::" + altenaiteEmail1);
				for (m = 0; m < altenaiteEmail1.length(); m++) {
					altenaiteEmail1.get(m);
					System.out.println("AlernateEmail ::" + altenaiteEmail1.get(m));
				}
				System.out.println("alternateEmail:::" + alternateEmail);
			}
			
			candijson.put("lastModifiedBy", lastModifiedBy);
			candijson.put("ResumeName", ResumeName);
			candijson.put("Resume", Resume);

			candijson.put("preferredLocation", preferredLocation);
			candijson.put("createdBy", createdBy);
			candijson.put("username", username);
			candijson.put("id", ids);
			candijson.put("name", name);
			candijson.put("email", email);
			candijson.put("birthdate", birthdate);
			candijson.put("mobileNumber", mobileNumber);
			candijson.put("lastModified", lastModified);
			candijson.put("first_name", first_name);
			candijson.put("middle_name", middle_name);
			candijson.put("last_name", last_name);

			// candijson.put("alternateEmail", alternateEmail1);

			candijson.put("age", String.valueOf(age));

			candijson.put("gender", gender);

			candijson.put("picture", picture);

			candijson.put("profile", profile);

			candijson.put("website", website);

			candijson.put("jobType", jobType);

			candijson.put("employmentType", employmentType);

			// candijson.put("immediateJoiningAvailabilityOrNegotiable",
			// immediateJoiningAvailabilityOrNegotiable);

			candijson.put("employmentType", employmentType);

			candijson.put("immediateJoiningAvailabilityOrNegotiable",
					String.valueOf(immediateJoiningAvailabilityOrNegotiable));

			candijson.put("minimumDaysRequired", minimumDaysRequired);

			candijson.put("salutation", salutation);

			candijson.put("visibility", String.valueOf(visibility));

			candijson.put("mobileNumber", mobileNumber);

			candijson.put("telePhone", telePhone);

			candijson.put("officePhone", officePhone);

			candijson.put("officePhoneExtention", officePhoneExtention);

			candijson.put("isMobileNumberVerified", String.valueOf(isMobileNumberVerified));

			candijson.put("locale", locale);

			candijson.put("religion", religion);

			candijson.put("maritalStatus", maritalStatus);

			candijson.put("createdDate", createdDate);
			candijson.put("lastModified", lastModified);
			candijson.put("aadharCardNo", aadharCardNo);

			candijson.put("passportNo", passportNo);

			candijson.put("passportValidity", passportValidity);

			candijson.put("panNo", panNo);

			candijson.put("areaOfSpecialization", areaOfSpecialization);

			candijson.put("otherInterest", otherInterest);

			candijson.put("category", category);

			candijson.put("confidential", String.valueOf(confidential));

			candijson.put("employmentStatus", employmentStatus);

			candijson.put("nationality", nationality);
			candijson.put("exNationality", exNationality);
			candijson.put("experiencedIndustry", experiencedIndustry);
			candijson.put("preferredIndustry", preferredIndustry);
			candijson.put("experiencedFunctionalArea", experiencedFunctionalArea);
			candijson.put("preferredFunctionalArea", preferredFunctionalArea);
			candijson.put("language", language);
			candijson.put("notes", notes);
			candijson.put("noticePeriod", noticePeriod);
			candijson.put("preferredLocation", preferredLocation);

			candijson.put("preferredDistance", preferredDistance);
			candijson.put("physicallyChallenged", physicallyChallenged);
			candijson.put("reasonForLeaving", reasonForLeaving);
			candijson.put("reasonForRelocate", reasonForRelocate);

			candijson.put("willingToRelocate", willingToRelocate);
			candijson.put("willingToChangeJob", willingToChangeJob);
			candijson.put("resumeHeadLine", resumeHeadLine);
			candijson.put("experienced", String.valueOf(experienced));

			candijson.put("fresher", String.valueOf(fresher));

			candijson.put("shiftWork", shiftWork);

			candijson.put("skillSummary", skillSummary);

			candijson.put("summary", summary);

			candijson.put("federated", federated);

			System.out.println("candidate Json......" + candijson);
			candijson.put("achievement", achievementObj);
			candijson.put("certificate", certificateObj);
			// previous.put("previous", previouss);
			candijson.put("project", projectObj);
			candijson.put("skills", SkillsObj);
			candijson.put("referral", refralObj);
			candijson.put("alternateEmail", altenaiteEmail1);
			candijson.put("alternateMobile", alternateMobileNumber);
			candijson.put("family", familyObj);
			candijson.put("connectSocialNetwork", connectSocialObj);
			candijson.put("experience", experience1);
			candijson.put("salary", salary1);
			candijson.put("address", addressJson2);

			candijson.put("education", education);
			candijson.put("employment", employement);

			obj.put(candijson);
//			obj.put(map1);
//			obj.put(map);
//			obj.put(Skills);
//			obj.put(refral);
//
//			obj.put(projects);
//			obj.put(achievements);
//			obj.put(certificatess);

		}

		Mainjson.put("response", obj);

		return Mainjson.toString();
	}
	
	// by Hks--------------------------------------------------------------------------------
	
	//Candidate Profile behalf of id for Vijay 1st time SS
	@RequestMapping(value = "/ElasticAPI/candprofileh", method = { RequestMethod.GET })
		public @ResponseBody String candidateProfileIdhks(@RequestParam("id") String UserId,
				@RequestParam(value = ("sortType"), required = false) String sortType)
			throws JSONException, URISyntaxException, MalformedURLException {
		JSONObject mainjson = new JSONObject();
		JSONArray obj = new JSONArray();
		JSONObject candijson = new JSONObject();
		
		

		String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+ UserId+"\")" ;

		System.out.println("url :: " + candidateUrl);

		URL urlcandiateProfile = new URL(candidateUrl);

		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateUrl);
		String jsonCandidateData = "";
		
		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

		JSONObject jsonAttach = new JSONObject(jsonCandidateData);
		JSONObject hits = jsonAttach.getJSONObject("hits");

		JSONArray hitsArr = hits.getJSONArray("hits");

		for (int k = 0; k < hitsArr.length(); k++) {

			JSONObject arrobj = (JSONObject) hitsArr.get(k);
			JSONObject arrObj1 = arrobj.getJSONObject("_source");
			
			if (arrObj1.has("id"))
				candijson.put("id", arrObj1.getString("id"));
			else 
				candijson.put("id", arrObj1.getString("id"));
				
			if (arrObj1.has("name"))
				candijson.put("name", arrObj1.getString("name"));
			else
				candijson.put("name", JSONObject.NULL);

			if (arrObj1.has("first_name"))
				candijson.put("first_name", arrObj1.getString("first_name"));
			else
				candijson.put("first_name", JSONObject.NULL);

			if (arrObj1.has("middle_name"))
				candijson.put("middle_name", arrObj1.getString("middle_name"));
			else
				candijson.put("middle_name", JSONObject.NULL);

			if (arrObj1.has("last_name"))
				candijson.put("last_name", arrObj1.getString("last_name"));
			else
				candijson.put("last_name", JSONObject.NULL);

			if (arrObj1.has("username"))
				candijson.put("username", arrObj1.getString("username"));
			else
				candijson.put("username", JSONObject.NULL);

			if (arrObj1.has("email"))
				candijson.put("email", arrObj1.getString("email"));
			else
				candijson.put("email", JSONObject.NULL);

			if (arrObj1.has("alternateEmail"))
				candijson.put("alternateEmail", (JSONArray) arrObj1.get("alternateEmail"));
			else
				candijson.put("alternateEmail", JSONObject.NULL);

			if (arrObj1.has("birthdate"))
				candijson.put("birthdate", arrObj1.getString("birthdate"));
			else
				candijson.put("birthdate", JSONObject.NULL);

			if (arrObj1.has("age"))
				candijson.put("age", arrObj1.getInt("age"));
			else
				candijson.put("age", JSONObject.NULL);

			if (arrObj1.has("gender"))
				candijson.put("gender", arrObj1.getString("gender"));
			else
				candijson.put("gender", JSONObject.NULL);

			if (arrObj1.has("picture"))
				candijson.put("picture", arrObj1.get("picture"));
			else
				candijson.put("picture", JSONObject.NULL);

			if (arrObj1.has("profile"))
				candijson.put("profile", arrObj1.getString("profile"));
			else
				candijson.put("profile", JSONObject.NULL);

			if (arrObj1.has("mobileNumber"))
				candijson.put("mobileNumber", arrObj1.getString("mobileNumber"));
			else
				candijson.put("mobileNumber", JSONObject.NULL);

			if (arrObj1.has("alternateMobileNumber"))
				candijson.put("alternateMobileNumber", (JSONArray) arrObj1.get("alternateMobileNumber"));
			else
				candijson.put("alternateMobileNumber", JSONObject.NULL);

			if (arrObj1.has("officePhone"))
				candijson.put("officePhone", arrObj1.getString("officePhone"));
			else
				candijson.put("officePhone", JSONObject.NULL);

			if (arrObj1.has("officePhoneExtention"))
				candijson.put("officePhoneExtention", arrObj1.getString("officePhoneExtention"));
			else
				candijson.put("officePhoneExtention", JSONObject.NULL);

			if (arrObj1.has("isMobileNumberVerified"))
				candijson.put("isMobileNumberVerified", (Boolean) arrObj1.get("isMobileNumberVerified"));
			else
				candijson.put("isMobileNumberVerified", JSONObject.NULL);

			if (arrObj1.has("religion"))
				candijson.put("religion", arrObj1.getString("religion"));
			else
				candijson.put("religion", JSONObject.NULL);

			if (arrObj1.has("maritalStatus"))
				candijson.put("maritalStatus", arrObj1.getString("maritalStatus"));
			else
				candijson.put("maritalStatus", JSONObject.NULL);

			if (arrObj1.has("federated"))
				candijson.put("federated", arrObj1.getString("federated"));
			else
				candijson.put("federated", JSONObject.NULL);


			

			if (arrObj1.has("address")) {
				
				JSONObject addressJson1 = null;
				JSONObject addressJson = (JSONObject) arrObj1.get("address");

				if (addressJson.has("permanentAddress")) {

					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("permanentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("permanentAddress", addressJ);
				}

				if (addressJson.has("currentAddress")) {
					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("currentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("currentAddress", addressJ);
				}
			} else
				candijson.put("address", JSONObject.NULL);

			/*
			 * notification Array
			 */
			if (arrObj1.has("notification")) {

				JSONObject notification = new JSONObject();
				JSONObject getnotification = (JSONObject) arrObj1.get("notification");

				if (getnotification.has("resumeDownload"))
					notification.put("resumeDownload", (Boolean) getnotification.get("resumeDownload"));
				else
					notification.put("resumeDownload", JSONObject.NULL);

				if (getnotification.has("profileViewed"))
					notification.put("profileViewed", (Boolean) getnotification.get("profileViewed"));
				else
					notification.put("profileViewed", JSONObject.NULL);

				if (getnotification.has("newJobPost"))
					notification.put("newJobPost", (Boolean) getnotification.get("newJobPost"));
				else
					notification.put("newJobPost", JSONObject.NULL);

				if (getnotification.has("recruiterConnect"))
					notification.put("recruiterConnect", (Boolean) getnotification.get("recruiterConnect"));
				else
					notification.put("recruiterConnect", JSONObject.NULL);

				if (getnotification.has("google"))
					notification.put("google", (Boolean) getnotification.get("google"));
				else
					notification.put("google", JSONObject.NULL);

				if (getnotification.has("twitter"))
					notification.put("twitter", (Boolean) getnotification.get("twitter"));
				else
					notification.put("twitter", JSONObject.NULL);

				if (getnotification.has("linkedIn"))
					notification.put("linkedIn", (Boolean) getnotification.get("linkedIn"));
				else
					notification.put("linkedIn", JSONObject.NULL);

				if (getnotification.has("facebook"))
					notification.put("facebook", (Boolean) getnotification.get("facebook"));
				else
					notification.put("facebook", JSONObject.NULL);

				candijson.put("notification", notification);
			} else
				candijson.put("notification", JSONObject.NULL);

			if (arrObj1.has("jobType"))
				candijson.put("jobType", arrObj1.getString("jobType"));
			else
				candijson.put("jobType", JSONObject.NULL);

			if (arrObj1.has("employmentType"))
				candijson.put("employmentType", arrObj1.getString("employmentType"));
			else
				candijson.put("employmentType", JSONObject.NULL);

			if (arrObj1.has("createdDate"))
				candijson.put("createdDate", arrObj1.getString("createdDate"));
			else
				candijson.put("createdDate", JSONObject.NULL);

			if (arrObj1.has("lastModified"))
				candijson.put("lastModified", arrObj1.getString("lastModified"));
			else
				candijson.put("lastModified", JSONObject.NULL);

			if (arrObj1.has("createdBy"))
				candijson.put("createdBy", arrObj1.getString("createdBy"));
			else
				candijson.put("createdBy", JSONObject.NULL);

			if (arrObj1.has("lastModifiedBy"))
				candijson.put("lastModifiedBy", arrObj1.getString("lastModifiedBy"));
			else
				candijson.put("lastModifiedBy", JSONObject.NULL);

			if (arrObj1.has("aadharCardNo"))
				candijson.put("aadharCardNo", arrObj1.getString("aadharCardNo"));
			else
				candijson.put("aadharCardNo", JSONObject.NULL);

			if (arrObj1.has("passportNo"))
				candijson.put("passportNo", arrObj1.getString("passportNo"));
			else
				candijson.put("passportNo", JSONObject.NULL);

			if (arrObj1.has("passportValidity"))
				candijson.put("passportValidity", arrObj1.getString("passportValidity"));
			else
				candijson.put("passportValidity", JSONObject.NULL);

			if (arrObj1.has("panNo"))
				candijson.put("panNo", arrObj1.getString("panNo"));
			else
				candijson.put("panNo", JSONObject.NULL);

			if (arrObj1.has("areaOfSpecialization"))
				candijson.put("areaOfSpecialization", arrObj1.getString("areaOfSpecialization"));
			else
				candijson.put("areaOfSpecialization", JSONObject.NULL);

			if (arrObj1.has("category"))
				candijson.put("category", arrObj1.getString("category"));
			else
				candijson.put("category", JSONObject.NULL);

			if (arrObj1.has("confidential"))
				candijson.put("confidential", (Boolean) arrObj1.get("confidential"));
			else
				candijson.put("confidential", JSONObject.NULL);

			if (arrObj1.has("employmentStatus"))
				candijson.put("employmentStatus", arrObj1.getString("employmentStatus"));
			else
				candijson.put("employmentStatus", JSONObject.NULL);

			if (arrObj1.has("nationality"))
				candijson.put("nationality", arrObj1.getString("nationality"));
			else
				candijson.put("nationality", JSONObject.NULL);

			if (arrObj1.has("exNationality"))
				candijson.put("exNationality", arrObj1.getInt("exNationality"));
			else
				candijson.put("exNationality", JSONObject.NULL);

			if (arrObj1.has("experiencedIndustry"))
				candijson.put("experiencedIndustry", arrObj1.getString("experiencedIndustry"));
			else
				candijson.put("experiencedIndustry", JSONObject.NULL);

			if (arrObj1.has("experiencedFunctionalArea"))
				candijson.put("experiencedFunctionalArea", arrObj1.getString("experiencedFunctionalArea"));
			else
				candijson.put("experiencedFunctionalArea", JSONObject.NULL);

			if (arrObj1.has("language"))
				candijson.put("language", arrObj1.getString("language"));
			else
				candijson.put("language", JSONObject.NULL);

			if (arrObj1.has("notes"))
				candijson.put("notes", arrObj1.getString("notes"));
			else
				candijson.put("notes", JSONObject.NULL);

			if (arrObj1.has("preferredLocation"))
				candijson.put("preferredLocation", arrObj1.getString("preferredLocation"));
			else
				candijson.put("preferredLocation", JSONObject.NULL);

			if (arrObj1.has("physicallyChallenged"))
				candijson.put("physicallyChallenged", arrObj1.getString("physicallyChallenged"));
			else
				candijson.put("physicallyChallenged", JSONObject.NULL);

			if (arrObj1.has("reasonForLeaving"))
				candijson.put("reasonForLeaving", arrObj1.getString("reasonForLeaving"));
			else
				candijson.put("reasonForLeaving", JSONObject.NULL);

			if (arrObj1.has("reasonForRelocate"))
				candijson.put("reasonForRelocate", arrObj1.getString("reasonForRelocate"));
			else
				candijson.put("reasonForRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToRelocate"))
				candijson.put("willingToRelocate", arrObj1.getString("willingToRelocate"));
			else
				candijson.put("willingToRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToChangeJob"))
				candijson.put("willingToChangeJob", arrObj1.getString("willingToChangeJob"));
			else
				candijson.put("willingToChangeJob", JSONObject.NULL);

			if (arrObj1.has("resumeHeadLine"))
				candijson.put("resumeHeadLine", arrObj1.getString("resumeHeadLine"));
			else
				candijson.put("resumeHeadLine", JSONObject.NULL);

			if (arrObj1.has("experienced"))
				candijson.put("experienced", (Boolean) arrObj1.get("experienced"));
			else
				candijson.put("experienced", JSONObject.NULL);

			if (arrObj1.has("fresher"))
				candijson.put("fresher", (Boolean) arrObj1.get("fresher"));
			else
				candijson.put("fresher", JSONObject.NULL);

			if (arrObj1.has("skillSummary"))
				candijson.put("skillSummary", arrObj1.getString("skillSummary"));
			else
				candijson.put("skillSummary", JSONObject.NULL);

			if (arrObj1.has("skills")) {
				JSONArray SkillsObj = new JSONArray();

				JSONObject getskillobject = new JSONObject();

				JSONArray skillList = (JSONArray) arrObj1.get("skills");

				for (int i = 0; i < skillList.length(); i++) {

					getskillobject = (JSONObject) skillList.get(i);
					JSONObject Skills = new JSONObject();

					if (getskillobject.has("keySkill"))
						Skills.put("keySkill", getskillobject.getString("keySkill"));
					else
						Skills.put("keySkill", JSONObject.NULL);

					if (getskillobject.has("experience"))
						Skills.put("experience", getskillobject.getString("experience"));
					else
						Skills.put("experience", JSONObject.NULL);

					if (getskillobject.has("fromMonth"))
						Skills.put("fromMonth", getskillobject.getString("fromMonth"));
					else
						Skills.put("fromMonth", JSONObject.NULL);

					if (getskillobject.has("fromYear"))
						Skills.put("fromYear", getskillobject.getString("fromYear"));
					else
						Skills.put("fromYear", JSONObject.NULL);

					if (getskillobject.has("toMonth"))
						Skills.put("toMonth", getskillobject.getString("toMonth"));
					else
						Skills.put("toMonth", JSONObject.NULL);

					if (getskillobject.has("toYear"))
						Skills.put("toYear", getskillobject.getString("toYear"));
					else
						Skills.put("toYear", JSONObject.NULL);

					SkillsObj.put(Skills);
				}

				candijson.put("skills", SkillsObj);
			}

			else
				candijson.put("skills", JSONObject.NULL);

			if (arrObj1.has("education")) {
				JSONObject education = new JSONObject();

				JSONObject educationjson = (JSONObject) arrObj1.get("education");

				if (educationjson.has("ug")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("ug");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("ug", subEdu);
				} else
					education.put("ug", JSONObject.NULL);

				if (educationjson.has("pg")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("pg");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("pg", subEdu);

				} else
					education.put("pg", JSONObject.NULL); // end pg

				if (educationjson.has("doctorate")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("doctorate");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("doctorate", subEdu);

				} else
					education.put("doctorate", JSONObject.NULL);

				if (educationjson.has("diploma")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("diploma");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("diploma", subEdu);

				} else
					education.put("diploma", JSONObject.NULL);

				if (educationjson.has("twelveth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("twelveth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("twelveth", subEdu);

				} else
					education.put("twelveth", JSONObject.NULL);

				if (educationjson.has("tenth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("tenth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("tenth", subEdu);

				} else
					education.put("tenth", JSONObject.NULL);

				candijson.put("education", education);
			} else
				candijson.put("education", JSONObject.NULL);

			if (arrObj1.has("employment")) {

				JSONObject employement = new JSONObject();

				JSONObject getemployment = arrObj1.getJSONObject("employment");

				if (getemployment.has("current")) {

					JSONObject current = new JSONObject();
					JSONObject getcurrent = getemployment.getJSONObject("current");

					if (getcurrent.has("companyName"))
						current.put("companyName", getcurrent.getString("companyName"));
					else
						current.put("companyName", JSONObject.NULL);

					if (getcurrent.has("designation"))
						current.put("designation", getcurrent.getString("designation"));
					else
						current.put("designation", JSONObject.NULL);

					if (getcurrent.has("isCurrent"))
						current.put("isCurrent", getcurrent.get("isCurrent"));
					else
						current.put("isCurrent", JSONObject.NULL);

					if (getcurrent.has("desc"))
						current.put("desc", getcurrent.getString("desc"));
					else
						current.put("desc", JSONObject.NULL);

					if (getcurrent.has("workLocation"))
						current.put("workLocation", getcurrent.getString("workLocation"));
					else
						current.put("workLocation", JSONObject.NULL);

					if (getcurrent.has("role"))
						current.put("role", getcurrent.getString("role"));
					else
						current.put("role", JSONObject.NULL);

					if (getcurrent.has("level"))
						current.put("level", getcurrent.getString("level"));
					else
						current.put("level", JSONObject.NULL);

					if (getcurrent.has("teamSize"))
						current.put("teamSize", getcurrent.getString("teamSize"));
					else
						current.put("teamSize", JSONObject.NULL);

					employement.put("current", current);
				} else
					employement.put("current", JSONObject.NULL);

				if (getemployment.has("previous")) {

					JSONArray previous = new JSONArray();

					JSONArray getprevious = getemployment.getJSONArray("previous");
					int i = 0;

					for (i = 0; i < getprevious.length(); i++) {

						JSONObject jsonprevious = (JSONObject) getprevious.get(i);

						if (jsonprevious.has("organization"))
							jsonprevious.put("organization", jsonprevious.getString("organization"));
						else
							jsonprevious.put("organization", JSONObject.NULL);

						if (jsonprevious.has("designation"))
							jsonprevious.put("designation", jsonprevious.getString("designation"));
						else
							jsonprevious.put("designation", JSONObject.NULL);

						if (jsonprevious.has("level"))
							jsonprevious.put("level", jsonprevious.getString("level"));
						else
							jsonprevious.put("level", JSONObject.NULL);

						if (jsonprevious.has("city"))
							jsonprevious.put("city", jsonprevious.getString("city"));
						else
							jsonprevious.put("city", JSONObject.NULL);

						if (jsonprevious.has("fromMonth"))
							jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
						else
							jsonprevious.put("fromMonth", JSONObject.NULL);

						if (jsonprevious.has("fromYear"))
							jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
						else
							jsonprevious.put("fromYear", JSONObject.NULL);

						if (jsonprevious.has("toMonth"))
							jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
						else
							jsonprevious.put("toMonth", JSONObject.NULL);

						if (jsonprevious.has("toYear"))
							jsonprevious.put("toYear", jsonprevious.getString("toYear"));
						else
							jsonprevious.put("toYear", JSONObject.NULL);

						if (jsonprevious.has("description"))
							jsonprevious.put("description", jsonprevious.getString("description"));
						else
							jsonprevious.put("description", JSONObject.NULL);

						previous.put(jsonprevious);
					}
					employement.put("previous", previous);
				} else
					employement.put("previous", JSONObject.NULL);

				candijson.put("employment", employement);

			} else
				candijson.put("employment", JSONObject.NULL);

			/* salary array */

			if (arrObj1.has("salary") && !arrObj1.get("salary").equals(null)) {

				JSONObject getsalary = (JSONObject) arrObj1.get("salary");
				JSONObject salary = new JSONObject();

				if (getsalary.has("currentCTCType"))
					salary.put("currentCTCType", getsalary.getString("currentCTCType"));
				else
					salary.put("currentCTCType", JSONObject.NULL);

				if (getsalary.has("currentCTC"))
					salary.put("currentCTC", getsalary.getString("currentCTC"));
				else
					salary.put("currentCTC", JSONObject.NULL);

				if (getsalary.has("negotiableCTC"))
					salary.put("negotiableCTC", getsalary.getString("negotiableCTC"));
				else
					salary.put("negotiableCTC", JSONObject.NULL);

				if (getsalary.has("expectedCTCType"))
					salary.put("expectedCTCType", getsalary.getString("expectedCTCType"));
				else
					salary.put("expectedCTCType", JSONObject.NULL);

				if (getsalary.has("expectedCTC"))
					salary.put("expectedCTC", getsalary.getString("expectedCTC"));
				else
					salary.put("expectedCTC", JSONObject.NULL);

				if (getsalary.has("takeHome"))
					salary.put("takeHome", getsalary.getString("takeHome"));
				else
					salary.put("takeHome", JSONObject.NULL);

				if (getsalary.has("fixed"))
					salary.put("fixed", getsalary.getString("fixed"));
				else
					salary.put("fixed", JSONObject.NULL);

				candijson.put("salary", salary);

			} else
				candijson.put("salary", JSONObject.NULL);

			if (arrObj1.has("ctc"))
				candijson.put("ctc", (Double) arrObj1.get("ctc"));
			else
				candijson.put("ctc", JSONObject.NULL);

			if (arrObj1.has("exp"))
				candijson.put("exp", (Double) arrObj1.get("exp"));
			else
				candijson.put("exp", JSONObject.NULL);

			/* experience array */

			if (arrObj1.has("experience")) {

				JSONObject experience = new JSONObject();

				JSONObject getexperience = (JSONObject) arrObj1.get("experience");

				if (getexperience.has("months"))
					experience.put("months", (Integer) getexperience.get("months"));
				else
					experience.put("months", JSONObject.NULL);

				if (getexperience.has("totalExperience"))
					experience.put("totalExperience", getexperience.getString("totalExperience"));
				else
					experience.put("totalExperience", JSONObject.NULL);

				if (getexperience.has("years"))
					experience.put("years", (Integer) getexperience.get("years"));
				else
					experience.put("years", JSONObject.NULL);

				candijson.put("experience", experience);

			} else
				candijson.put("experience", JSONObject.NULL);

			/* Achievements */

			if (arrObj1.has("achievement")) {

				JSONArray achievement = new JSONArray();
				JSONArray getachievement = arrObj1.getJSONArray("achievement");

				for (int i = 0; i < getachievement.length(); i++) {

					JSONObject Achievementobject = (JSONObject) getachievement.get(i);

					if (Achievementobject.has("achievementTitle"))
						Achievementobject.put("achievementTitle", Achievementobject.getString("achievementTitle"));
					else
						Achievementobject.put("achievementTitle", JSONObject.NULL);

					if (Achievementobject.has("achievementRole"))
						Achievementobject.put("achievementRole", Achievementobject.getString("achievementRole"));
					else
						Achievementobject.put("achievementRole", JSONObject.NULL);

					if (Achievementobject.has("achievementDescription"))
						Achievementobject.put("achievementDescription",
								Achievementobject.getString("achievementDescription"));
					else
						Achievementobject.put("achievementDescription", JSONObject.NULL);

					achievement.put(Achievementobject);
				}

				candijson.put("achievement", achievement);

			} else
				candijson.put("achievement", JSONObject.NULL);

			/* Certificates */

			if (arrObj1.has("certificates")) {

				JSONArray getcertificates = (JSONArray) arrObj1.get("certificates");
				JSONArray certificates = new JSONArray();

				for (int i = 0; i < getcertificates.length(); i++) {

					JSONObject certificatesobject = (JSONObject) getcertificates.get(i);

					if (certificatesobject.has("certificatesTitle"))
						certificatesobject.put("certificatesTitle", certificatesobject.getString("certificatesTitle"));
					else
						certificatesobject.put("certificatesTitle", JSONObject.NULL);

					if (certificatesobject.has("month"))
						certificatesobject.put("month", certificatesobject.getString("month"));
					else
						certificatesobject.put("month", JSONObject.NULL);

					if (certificatesobject.has("year"))
						certificatesobject.put("year", certificatesobject.getString("year"));
					else
						certificatesobject.put("year", JSONObject.NULL);

					if (certificatesobject.has("certificatesDescription"))
						certificatesobject.put("certificatesDescription",
								certificatesobject.getString("certificatesDescription"));
					else
						certificatesobject.put("certificatesDescription", JSONObject.NULL);

					certificates.put(certificatesobject);

				}

				candijson.put("certificates", certificates);
			} else
				candijson.put("certificates", JSONObject.NULL);

			/* Project */

			if (arrObj1.has("project")) {

				JSONArray project = new JSONArray();
				JSONArray getproject = (JSONArray) arrObj1.get("project");

				JSONObject projectobject = new JSONObject();

				for (int i = 0; i < getproject.length(); i++) {

					JSONObject projectObj = new JSONObject();

					projectobject = (JSONObject) getproject.get(i);

					if (projectobject.has("projectTitle"))
						projectObj.put("projectTitle", projectobject.getString("projectTitle"));
					else
						projectObj.put("projectTitle", JSONObject.NULL);

					if (projectobject.has("projectRole"))
						projectObj.put("projectRole", projectobject.getString("projectRole"));
					else
						projectObj.put("projectRole", JSONObject.NULL);

					if (projectobject.has("fromMonth"))
						projectObj.put("fromMonth", projectobject.getString("fromMonth"));
					else
						projectObj.put("fromMonth", JSONObject.NULL);

					if (projectobject.has("fromYear"))
						projectObj.put("fromYear", projectobject.getString("fromYear"));
					else
						projectObj.put("fromYear", JSONObject.NULL);

					if (projectobject.has("toMonth"))
						projectObj.put("toMonth", projectobject.getString("toMonth"));
					else
						projectObj.put("toMonth", JSONObject.NULL);

					if (projectobject.has("toYear"))
						projectObj.put("toYear", projectobject.getString("toYear"));
					else
						projectObj.put("toYear", JSONObject.NULL);

					if (projectobject.has("url"))
						projectObj.put("url", projectobject.getString("url"));
					else
						projectObj.put("url", JSONObject.NULL);

					if (projectobject.has("projectDescription"))
						projectObj.put("projectDescription", projectobject.getString("projectDescription"));
					else
						projectObj.put("projectDescription", JSONObject.NULL);

					project.put(projectObj);

				}

				candijson.put("project", project);
			} else
				candijson.put("project", JSONObject.NULL);

			/* html array */

			if (arrObj1.has("html")) {
				JSONObject gethtml = (JSONObject) arrObj1.get("html");
				JSONObject html = new JSONObject();

				if (gethtml.has("naukri")) {

					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();

					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", JSONObject.NULL);

					html.put("naukri", naukri);

				} else
					html.put("naukri", JSONObject.NULL);

				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

					JSONObject linkedIn = new JSONObject();

					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", JSONObject.NULL);

					html.put("linkedIn", linkedIn);

				} else
					html.put("linkedIn", JSONObject.NULL);

				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");

					JSONObject monster = new JSONObject();

					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", JSONObject.NULL);

					html.put("monster", monster);

				} else
					html.put("monster", JSONObject.NULL);

				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

					JSONObject naukriGulf = new JSONObject();

					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", JSONObject.NULL);

					html.put("naukriGulf", naukriGulf);

				} else
					html.put("naukriGulf", JSONObject.NULL);

				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

					JSONObject careerBuilder = new JSONObject();

					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", JSONObject.NULL);

					html.put("careerBuilder", careerBuilder);

				} else
					html.put("careerBuilder", JSONObject.NULL);

				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

					JSONObject monsterUS = new JSONObject();

					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", JSONObject.NULL);

					html.put("monsterUS", monsterUS);

				} else
					html.put("monsterUS", JSONObject.NULL);

				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");

					JSONObject dice = new JSONObject();

					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", JSONObject.NULL);

					html.put("dice", dice);

				} else
					html.put("dice", JSONObject.NULL);

				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

					JSONObject jobDiva = new JSONObject();

					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", JSONObject.NULL);

					html.put("jobDiva", jobDiva);

				} else
					html.put("jobDiva", JSONObject.NULL);

				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");

					JSONObject indeed = new JSONObject();

					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", JSONObject.NULL);

					html.put("indeed", indeed);

				} else
					html.put("indeed", JSONObject.NULL);

				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

					JSONObject jobServe = new JSONObject();

					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", JSONObject.NULL);

					html.put("jobServe", jobServe);

				} else
					html.put("jobServe", JSONObject.NULL);

				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");

					JSONObject other = new JSONObject();

					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", JSONObject.NULL);

					html.put("other", other);

				} else
					html.put("other", JSONObject.NULL);

				candijson.put("html", html);
			} else
				candijson.put("html", JSONObject.NULL);

			if (arrObj1.has("resumeName"))
				candijson.put("resumeName", arrObj1.get("resumeName"));
			else
				candijson.put("resumeName", JSONObject.NULL);

			if (arrObj1.has("resume"))
				candijson.put("resume", arrObj1.get("resume"));
			else
				candijson.put("resume", JSONObject.NULL);

			if (arrObj1.has("connectSocialNetwork")) {

				JSONArray cns = new JSONArray();

				JSONArray getcns = (JSONArray) arrObj1.get("connectSocialNetwork");

				for (int i = 0; i < getcns.length(); i++) {
					JSONObject subcns = new JSONObject();
					JSONObject cnsobject = (JSONObject) getcns.get(i);

					if (cnsobject.has("name"))
						subcns.put("name", cnsobject.getString("name"));
					else
						subcns.put("name", JSONObject.NULL);

					if (cnsobject.has("url"))
						subcns.put("url", cnsobject.getString("url"));
					else
						subcns.put("url", JSONObject.NULL);

					cns.put(subcns);

				}

				candijson.put("connectSocialNetwork", cns);
			} else
				candijson.put("connectSocialNetwork", JSONObject.NULL);

			if (arrObj1.has("family")) {

				JSONArray family = new JSONArray();

				JSONArray getfamily = (JSONArray) arrObj1.get("family");

				for (int i = 0; i < getfamily.length(); i++) {
					JSONObject subfamily = new JSONObject();
					JSONObject familyobject = (JSONObject) getfamily.get(i);

					if (familyobject.has("name"))
						subfamily.put("name", familyobject.getString("name"));
					else
						subfamily.put("name", JSONObject.NULL);

					if (familyobject.has("occupation"))
						subfamily.put("occupation", familyobject.getString("occupation"));
					else
						subfamily.put("occupation", JSONObject.NULL);

					if (familyobject.has("location"))
						subfamily.put("location", familyobject.getString("location"));
					else
						subfamily.put("location", JSONObject.NULL);

					if (familyobject.has("relationship"))
						subfamily.put("relationship", familyobject.getString("relationship"));
					else
						subfamily.put("relationship", JSONObject.NULL);

					family.put(subfamily);

				}

				candijson.put("family", family);
			} else
				candijson.put("family", JSONObject.NULL);

			if (arrObj1.has("referral")) {

				JSONArray referal = new JSONArray();

				JSONArray getreferal = (JSONArray) arrObj1.get("referral");

				for (int i = 0; i < getreferal.length(); i++) {
					JSONObject subreferral = new JSONObject();
					JSONObject referralobject = (JSONObject) getreferal.get(i);

					if (referralobject.has("name"))
						subreferral.put("name", referralobject.getString("name"));
					else
						subreferral.put("name", JSONObject.NULL);

					if (referralobject.has("officeEmail"))
						subreferral.put("officeEmail", referralobject.getString("officeEmail"));
					else
						subreferral.put("officeEmail", JSONObject.NULL);

					if (referralobject.has("officePhone"))
						subreferral.put("officePhone", referralobject.getString("officePhone"));
					else
						subreferral.put("officePhone", JSONObject.NULL);

					if (referralobject.has("company"))
						subreferral.put("company", referralobject.getString("company"));
					else
						subreferral.put("company", JSONObject.NULL);

					if (referralobject.has("title"))
						subreferral.put("title", referralobject.getString("title"));
					else
						subreferral.put("title", JSONObject.NULL);

					if (referralobject.has("description"))
						subreferral.put("description", referralobject.getString("description"));
					else
						subreferral.put("description", JSONObject.NULL);

					referal.put(subreferral);

				}

				candijson.put("referral", referal);
			} else
				candijson.put("referral", JSONObject.NULL);

		}
		obj.put(candijson);
		mainjson.put("response", obj);
		return mainjson.toString();
	}


}
