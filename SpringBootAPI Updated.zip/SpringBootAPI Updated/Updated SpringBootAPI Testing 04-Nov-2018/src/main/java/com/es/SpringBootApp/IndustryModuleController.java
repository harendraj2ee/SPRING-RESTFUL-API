package com.es.SpringBootApp;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;


@RestController
public class IndustryModuleController {
@RequestMapping("/action")
	public static String getString() {
		return "Done";
	}
	
	@RequestMapping(value = "/logs", method = RequestMethod.POST)
	public String postData(@RequestBody String insert, @RequestParam("type") String type,
			@RequestParam(value = "perpage", required = false) Integer perpage,
			@RequestParam(value = "next", required = false) Integer next,
			@RequestParam(value = "sort", required = false) String sort, @RequestHeader HttpHeaders headers)
			throws IOException, URISyntaxException, JSONException {

		String authString = headers.getFirst("token");

		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if (validity.equals("valid")) {
			String collectionName = "";

			if (sort != null) {
				if (!sort.equals("") && sort.endsWith("a"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "asc";
				else if (!sort.equals("") && sort.endsWith("d"))
					sort = "&sort=" + sort.substring(0, sort.length() - 1) + ".keyword:" + "desc";
			}

			if (type.contains("system"))
				collectionName = "systemlog";
			else if (type.contains("data"))
				collectionName = "dataauditlog";

			if (type.startsWith("post")) {

//				ElasticInsertion.insertIntoElastic(insert, collectionName);

				return "Inserted";
			} else {

				RestTemplate restTemplate = new RestTemplate();

				if (!insert.trim().equals("all")) {
					insert = insert.replace("{", "").replace("\":", ":").replace(",\"", ",").replace("}", "");
					insert = insert.replace(",", ")AND(").trim();
					insert = insert.replaceFirst("\"", "").trim();
					insert = "?q=(" + insert + ")";
					System.out.println(insert);
				} else
					insert = "";

				String url = "";

				url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/" + collectionName
						+ "/_search" + insert;

				if (perpage != null && next != null) {
					int start = perpage * (next - 1);
					url += "&size=" + perpage + "&from=" + start;
				} else if (sort != null)
					url += sort;

				System.out.println(url);
				String json = restTemplate.getForObject(url, String.class);
				JSONObject obj = null;
				ArrayList<JSONObject> al = new ArrayList<>();
				JSONObject jsonObject = (JSONObject) new JSONObject(json).get("hits");
				JSONArray array = jsonObject.getJSONArray("hits");
				for (int i = 0; i < array.length(); i++) {
					obj = array.getJSONObject(i).getJSONObject("_source");
					al.add(obj);
				}

				JSONObject jsonObject2 = new JSONObject();
				jsonObject2.put(collectionName, al);
				jsonObject2.put("numFound", al.size());
				return jsonObject2.toString();
			}
		} else {
			return validity;
		}
	}
}
