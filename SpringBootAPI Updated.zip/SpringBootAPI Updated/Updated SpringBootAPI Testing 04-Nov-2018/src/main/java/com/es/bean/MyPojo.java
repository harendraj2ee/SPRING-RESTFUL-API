package com.es.bean;

public class MyPojo {
private String comapny;

public String getComapny() {
	return comapny;
}

public void setComapny(String comapny) {
	this.comapny = comapny;
}

}
