package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.restServiceImpl.RestServiceImpl;

import ch.qos.logback.core.joran.conditional.ElseAction;
import ch.qos.logback.core.net.SyslogOutputStream;

@RestController
public class HitechBrowserController {
	RestTemplate restTemplate = new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();
	
//	  AttachData
	 


	       @RequestMapping(value = "/ElasticAPI/empidhtml", method = { RequestMethod.GET })
	       public @ResponseBody String empIdHTMl(@RequestParam("empid") String empId,@RequestHeader HttpHeaders headers)
	                     throws JSONException, URISyntaxException, MalformedURLException {
	             
//	  		 if (!headers.containsKey("authorization")) {
//					System.out.println("No Authentication");
//					return "{\"error\":\"Please Provide The Authentication\"}";
//				}
//				String authString = headers.getFirst("authorization");
//				if (!restService.isUserAuthenticated(authString)) {
//					System.out.println("Wrong Authentication.....");
//					return "{\"error\":\"User not authenticated\"}";
//				}
	    	   
	    	String authString = headers.getFirst("token");
	   		String validity = CognitoAuthentication.getValidAuthentication(authString);
	   		if(validity.equals("valid")){
	    	   
	    	   String htmlFlag = "notFound";
	              JSONObject candijson = new JSONObject();

	              String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.naukri.empId:\""
	                           + empId + "\"";

	              System.out.println("url :: " + candidateUrl);

	              URL urlcandiateProfile = new URL(candidateUrl);

	              URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                           urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                           urlcandiateProfile.getQuery(), candidateUrl);
	              String jsonCandidateData = "";

	              jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	              System.out.println(jsonCandidateData);

	              JSONObject jsonAttach = new JSONObject(jsonCandidateData);
	              JSONObject hits = jsonAttach.getJSONObject("hits");

	              JSONArray hitsArr = hits.getJSONArray("hits");

	              if (hitsArr.length() > 0)
	                     htmlFlag = "naukri";

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.linkedIn.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "linkedIn";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.monster.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "monster";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.naukriGulf.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "naukriGulf";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.careerBuilder.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "careerBuilder";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.monsterUS.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "monsterUS";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.dice.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "dice";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.jobDiva.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "jobDiva";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.indeed.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "indeed";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.jobServe.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "jobServe";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.other.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "other";
	              }

	              for (int k = 0; k < hitsArr.length(); k++) {

	                     JSONObject arrobj = (JSONObject) hitsArr.get(k);
	                     JSONObject arrObj1 = arrobj.getJSONObject("_source");

	                     if (arrObj1.has("id"))
	                           candijson.put("id", arrObj1.getString("id"));
	                     else
	                           candijson.put("id", JSONObject.NULL);

	                     if (arrObj1.has("federated"))
	                           candijson.put("federated", arrObj1.getString("federated"));
	                     else
	                           candijson.put("federated", JSONObject.NULL);

	                     /* html array */

	                     if (arrObj1.has("html")) {
	                           JSONObject gethtml = (JSONObject) arrObj1.get("html");
	                           JSONObject html = new JSONObject();

	                           if (gethtml.has(htmlFlag)) {

	                                  JSONObject subHTML = (JSONObject) gethtml.get(htmlFlag);
	                                  JSONObject putJson = new JSONObject();

	                                  if (subHTML.has("empId"))
	                                         putJson.put("empId", subHTML.getString("empId"));
	                                  else
	                                         putJson.put("empId", JSONObject.NULL);

	                                  if (subHTML.has("lastModified"))
	                                         putJson.put("lastModified", subHTML.getString("lastModified"));
	                                  else
	                                         putJson.put("lastModified", JSONObject.NULL);

	                                  if (subHTML.has("html"))
	                                         putJson.put("html", subHTML.getString("html"));
	                                  else
	                                         putJson.put("html", JSONObject.NULL);

	                                  html.put(htmlFlag, putJson);

	                           }

	                           candijson.put("html", html);
	                     } else
	                           candijson.put("html", JSONObject.NULL);

	              }

	              return candijson.toString();
	       }
	       else{
				return validity;
			}
	    }
}
