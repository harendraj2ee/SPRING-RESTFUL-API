package com.es.SpringBootApp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.restServiceImpl.RestServiceImpl;
@RestController
public class InternalSearchController {
	RestServiceImpl restService = new RestServiceImpl();
	RestTemplate restTemplate = new RestTemplate();
	@RequestMapping(value = "/test", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String test(@RequestBody String data) throws Exception {
		
		 URL url1 = new URL(data);
		 String nullFragment1 = null;

		 URI UOrig1 = new URI(url1.getProtocol(), url1.getUserInfo(), url1.getHost(), url1.getPort(), url1.getPath(),url1.getQuery(), nullFragment1);
		
		   
		 //System.out.println("url for htmlData without cmpny::: "+Rooturl);
		   
		// jsonData=restTemplate.getForObject(UOrig1, String.class);
		String json  = restTemplate.getForObject(UOrig1, String.class);
		return json;
	}
	
	
	@RequestMapping(value="/is")
	public @ResponseBody String getInternalDatas(@RequestParam("qall") String qall,@RequestParam("qany") String qany,@RequestParam("qbol") String qbol, @RequestParam("qexclude") String qexclude, @RequestParam("qctc") String qctc,
	          @RequestParam("qexp") String qexp, @RequestParam("qloc") String qloc, @RequestParam("qploc") String qploc, @RequestParam("qindtyp") String qindtyp, @RequestParam("qcemp") String qcemp,
	          @RequestParam("qpemp")  String qpemp, @RequestParam("qexemp")  String qexemp,@RequestParam("qcurdesig") String qcurdesig, @RequestParam("qprdesig") String qprdesig, @RequestParam("qfarea") String qfarea, @RequestParam("highlight") String highlight, 
	          @RequestParam("ugcourse") String ugcourse ,@RequestParam("ugspe") String ugspe, @RequestParam ("uginst") String uginst, @RequestParam ("ugyr") String ugyr ,@RequestParam("pgcourse") String pgcourse, 
	          @RequestParam("pgspe") String pgspe, @RequestParam ("pginst") String pginst, @RequestParam ("pgyr") String pgyr,  @RequestParam("ppgcourse") String ppgcourse, @RequestParam ("ppginst") String ppginst , @RequestParam ("ppgyr") String ppgyr,
	          @RequestParam("ctgry") String ctgry, @RequestParam("femail") String femail, @RequestParam("age") String age, @RequestParam("wrksts") String wrksts ,@RequestParam("othrcntry") String othrcntry, @RequestParam("notic") String notic, @RequestParam("next") int next,
	          @RequestParam("sort") String sort){
	       
		   
		   if(sort.length()>=1){
			   
		   }else{
			   sort="";
		   }
		
	       
	       String jsonData ="";
	       
	       try{
	       
	              String dynamiCQuery="";
	              
	              String dynamiCQuery4Location="";
	              
	              
	              System.out.println("qany>>>>>>>>>>"+qany);
	              
	              
	              if( dochek4Null(qany)){
	             
	            	  qany =  qany.replace("&", "%26");
	              String  mailany =URLEncoder.encode(qany, "UTF-8");
	              String  regex="[0-9]";
	              Pattern pattern = Pattern.compile(regex);
	              Matcher matcher = pattern.matcher(qany);
	              
	         	 if(mailany.contains("%40")){
	         		 
	         		qany = getAndwithData(qany, "html.naukri.html OR email", "OR", "");
	         		 
	         		 qany=qany.replace("*", ""); 
	         	 }else if(matcher.find()){
//	         		   
	         		    qany= getAndwithData(qany,"html.naukri.html OR mobileNumber","OR","");
	         		     
	         		     qany=qany.replace("*", ""); 
	         	 }else{
//	         		 
	         		 qany= getAndwithData(qany,"html.naukri.html","OR",""); //org
	         		
	         	 }
	         	 
	         	
	              if( dochek4Null(dynamiCQuery)){
	    	             
	            	      dynamiCQuery=dynamiCQuery + "OR"+ "("+qany+")";
	    	             }else{
	    	            	 dynamiCQuery="("+qany+")";
	    	             }
	              }
	              
	              
	           
	             if( dochek4Null(qall)){
	            	 qall =  qall.replace("&", "%26");
	            	String  mail =URLEncoder.encode(qall, "UTF-8");
	            	String  regex="[0-9]";
	                Pattern pattern = Pattern.compile(regex);
	                Matcher matcher = pattern.matcher(qany);
	            	
	            	if(mail.contains("%40")){
	            		
	            		 qall= getAndwithData(qall,"html.naukri.html OR email","AND","");
	            		 
	            		 
	               	     qall=qall.replace("*", ""); 
	               	    
	            	 } 
	            	  else if(matcher.find()){
	         		   
	            		  qall= getAndwithData(qall,"html.naukri.html OR mobileNumber","OR","");
	         		     
	            		  qall=qall.replace("*", "");
	         		     
	         	     }else {
//	            	
	            		 qall= getAndwithData(qall,"html.naukri.html","AND","");
	            		
	            		 qall=qall.replace("\"", "");
	            		
	            	 }              
	              
	            
	              if( dochek4Null(dynamiCQuery)){
	   	             dynamiCQuery=dynamiCQuery + "AND"+ "("+qall+")";  //OR
	   	             }else{
	   	            	 dynamiCQuery="("+qall+")";
	   	             }
	             }
	         
	             if( dochek4Null(qbol)){
	            	 qbol = qbol.replace("&", "%26");
	              qbol= getAndwithData(qbol,"html.naukri.html","OR","");
	              System.out.println("qbol::::"+qbol);
	              if( dochek4Null(dynamiCQuery)){
	  	             dynamiCQuery=dynamiCQuery + "OR"+ "("+qbol+")";
	  	             }else{
	  	            	 dynamiCQuery="("+qbol+")";
	  	             }
	             }
	           
	             if( dochek4Null(qexclude)){
	            	 qexclude = qexclude.replace("&", "%26");
	            	
	                 qexclude= getAndwithData(qexclude,"","","NOT");
	            	
	            	
	            	 System.out.println("qexclude::::"+qexclude);
	              if( dochek4Null(dynamiCQuery)){
	            	 dynamiCQuery=dynamiCQuery + "NOT"+ "("+qexclude+")";
	 	             }else{
	 	            	 dynamiCQuery="NOT("+qexclude+")";
	 	            }
	              }
	            
	           
	             if( dochek4Null(qexp)){
	            	
	         			qexp = "exp:[" + qexp.replace(",", " TO ") + "}";
	         			if( dochek4Null(dynamiCQuery)){
	       	             dynamiCQuery=dynamiCQuery + "AND"+ "("+qexp+")";   //OR
	       	             }else{
	       	            	 dynamiCQuery="("+qexp+")";
	       	             }
	         			System.out.println("dynamic query after exp____________"+dynamiCQuery);
	         			
	             }
	             
	             
	             
	             
	             
	             
	             
	        
	             
	             if( dochek4Null(qctc)){
	            	 System.out.println("::::::::::::::");
	            	
	            	 qctc = "ctc:[" + qctc.replace(",", " TO ") + "}";
	      			if( dochek4Null(dynamiCQuery)){
	    	             dynamiCQuery=dynamiCQuery + "AND"+ "("+qctc+")";   //OR
	    	             }else{
	    	            	 dynamiCQuery="("+qctc+")";
	    	             }
	      			System.out.println("dynamic query after qctc____________"+dynamiCQuery);
	              
	             }
	            
	            	 
	            	 
	            
	             if( dochek4Null(qloc)){
	            	 if(qloc.contains("Daman &")){
	            		 qloc = qloc.replace("Daman & Diu","Daman,Diu");
	                  }
	                  if(qloc.contains("Dadra & Nagar")){
	                	  qloc = qloc.replace("Dadra & Nagar Haveli - Silvassa","Dadra,Nagar Haveli - Silvassa");
	                  }
	            	 if(qloc.contains("&")){
	            		 qloc=qloc.replace("&", "%26");
	            		 //System.out.println("qlocccccccc"+qloc);
	            	 }
	            	 if(qloc.contains("Bengaluru")){
	            		 qloc = qloc.concat(",Bengaluru");
	                 }
	            	 
	            
	             qloc= getAndwithDataLocation(qloc,"employment.current.workLocation","OR","");
	             
	             
	             
	            
	             qloc=qloc.replace("*", "");
	             qloc = "(" + qloc + ")"; //31-8-2018
	            
	           
	             if( dochek4Null(dynamiCQuery4Location)){
	            	
	            	 dynamiCQuery4Location=dynamiCQuery4Location + "AND"+ "("+qloc+")"; //OR
		             }else{
		            	 dynamiCQuery4Location=qloc;
		             }
	             }
	             
	         
	             System.out.println("qploc>>>>>>>>>>"+qploc);
	             if( dochek4Null(qploc)){  
	            	 
	            	 
	            	 if(qploc.contains("Daman &")){
	            		 qploc = qploc.replace("Daman & Diu","Daman,Diu,Daman & Diu");
	                  }
	                  if(qploc.contains("Dadra & Nagar")){
	                	  qploc = qploc.replace("Dadra & Nagar Haveli - Silvassa","Dadra,Nagar Haveli - Silvassa,Dadra & Nagar Haveli - Silvassa");
	                  }
	                  if(qploc.contains("Bengaluru")){
	                	  qploc = qploc.concat(",Bengaluru");
	                  }
	            	 
	            	 if(qploc.contains("&")){
	            		 qploc=qploc.replace("&", "%26");
	            		 System.out.println("qploc_____"+qploc);
	            	 }
	            	 
	            	 
	            	 
	             qploc= getAndwithData(qploc,"preferredLocation","OR",""); 
	           
	             qploc=qploc.replace("*", "");
	            
	             
	             qploc = qploc.replace("\" OR \"", "\") OR (preferredLocation:\"");
	             qploc = "(" + qploc + ")";
	             System.out.println("qploc_______________"+qploc);
	             
	             
	             System.out.println("dynamicquery:::::::::::"+dynamiCQuery);
		             if( dochek4Null(dynamiCQuery)){
		             dynamiCQuery=dynamiCQuery + "AND"+ "(("+qploc+"))";   //OR
		             }else{
		            	 dynamiCQuery="("+qploc+")";
		             }
	             }
	             System.out.println("qploc dynamic query::::::::::::"+dynamiCQuery);
	             
	            
	              if( dochek4Null(qcemp)){ 
	            	  String c="at <span class='cOrg bkt4'>";
	            	  
	            	  if(qcemp.contains(",")){
	            		 
	            		  qcemp=qcemp.replace("+,", ",").replace(",+", ",");
	            		  
	            		  qcemp =qcemp.replace(",", "\")+OR+(employment.current.organization:\""); //added on 7-9-2018
	            		  
	                   	 
	                  }
	            	  
	                 
	                 
	            	  qcemp= getAndwithData(qcemp,"employment.current.organization","SPACE",""); //added on 7-9-2018
	            	  
	            	 
	 	              if( dochek4Null(dynamiCQuery)){
	 	              dynamiCQuery=dynamiCQuery + "AND"+ "("+qcemp+")";
	 	              }else{
	 	            	 dynamiCQuery="("+qcemp+")";
	 	             }
	              }
	              
	            
	               if( dochek4Null(qexemp)){  
	            	   qexemp= getAndwithData(qexemp,"employment.current.organization","SPACE","");              
	                 
	  	             if( dochek4Null(dynamiCQuery)){
	  	             dynamiCQuery=dynamiCQuery + "NOT"+ "("+qexemp+")";
	  	             }else{
	  	            	 dynamiCQuery="NOT("+qexemp+")";
	  	             }
	               }
	              
	              
	              if( dochek4Null(qpemp)){   
	            	  String pc="at <span class='pOrg'>";
	                 
	                  qpemp=pc+qpemp;
	                   System.out.println("previous employer:::"+qpemp);
	            	  qpemp= getAndwithData(qpemp,"html_data","SPACE",""); 
	            	 qpemp=qpemp.replace("\"", "\"\"");
	                 System.out.println("qpemp::::"+qpemp);
	 	             if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "AND"+ "("+qpemp+")";  //OR
	 	             }else{
	 	            	 dynamiCQuery="("+qpemp+")";
	 	             }
	              }
	              
	             
	              if( dochek4Null(qfarea)){   
	            	  qfarea= getAndwithData(qfarea,"experiencedFunctionalArea","SPACE",""); 
	            	  qfarea=qfarea.replace("/", "%2F"); //.replace("\"", "\"\"") 5-7-2018
	                  System.out.println("qfarea::::"+qfarea);
	 	             if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+qfarea+")";
	 	             }else{
	 	            	 dynamiCQuery="("+qfarea+")";
	 	             }
	              }
	               
	           
	              
	              if( dochek4Null(ctgry)){   
	            	  ctgry= getAndwithData(ctgry,"category","SPACE","");
	            	
	 	             if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+ctgry+")";  
	 	             }else{
	 	            	 dynamiCQuery="("+ctgry+")";
	 	             }
	              }
	             if( dochek4Null(femail)){   
	            	  femail= getAndwithData(femail,"gender","SPACE","");
	            	  
	            	 if( dochek4Null(dynamiCQuery)){
	 	              dynamiCQuery=dynamiCQuery + "AND"+ "("+femail+")";
	 	             }else{
	 	             	 dynamiCQuery="("+femail+")";
	 	             }
	              }  
	              
	              
	              
	             
	              if( dochek4Null(age)){
	            	  age= getAndwithData(age,"age","TO","");  
	              if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+age+")";
	 	             }else{
	 	            	 dynamiCQuery="("+age+")";
	 	             }
	              }
	              
	             
	             System.out.println("workstatus::::"+wrksts);
	              if( dochek4Null(wrksts)){
	            	  wrksts= getAndwithData(wrksts,"html.naukri.html","SPACE","");
	            	  
	            	  wrksts = "*" + wrksts + "*"; //added on 7-9-2018
	            	  
	                 if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+wrksts+")";
	 	             }else{
	 	            	 dynamiCQuery="("+wrksts+")";
	 	             }
	              }
	              
	             
	              
	              System.out.println("notice................"+notic);
	              
	              if( dochek4Null(notic)){   
	               notic= getAndwithData(notic,"noticePeriod","SPACE","");              
	               
	 	             if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "AND"+ "("+notic+")";   //OR
	 	             }else{
	 	            	 dynamiCQuery="("+notic+")";
	 	            	 
	 	            	
	 	             }
	              }
	              
	 
	             
	             if( dochek4Null(ugcourse)){   
	            	  ugcourse= getAndwithData(ugcourse,"education.ug.course","SPACE","");  
	            	  
	            	 
	 	              if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+ugcourse+")";
	 	             }else{
	 	            	 dynamiCQuery="("+ugcourse+")";
	 	            	 
	 	             }
	              }
	               
	              
	              if( dochek4Null(ugspe)){   
	            	  ugspe= getAndwithData(ugspe,"html.naukri.html","SPACE",""); 
	            	  ugspe=ugspe.replace("\"", "\"\"");
	            	 
	 	             if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+ugspe+")";
	 	             }else{
	 	            	 dynamiCQuery="("+ugspe+")";
	 	            
	 	             }
	              }
	                 
	             
	              if( dochek4Null(uginst)){   
	            	  uginst= getAndwithData(uginst,"education.ug.institute","SPACE","");  
	            	  
	            	   if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+uginst+")";
	 	             }else{
	 	            	 dynamiCQuery="("+uginst+")";
	 	            
	 	             }
	              }
	              
	             if( dochek4Null(ugyr)){
	            	  ugyr= getAndwithData(ugyr,"education.ug.toYear","TO","");  
	                 
	              if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+ugyr+")";
	 	             }else{
	 	            	 dynamiCQuery="("+ugyr+")";
	 	             }
	              }
	             
	              
	              
	              if( dochek4Null(pgcourse)){   
	            	  pgcourse= getAndwithData(pgcourse,"education.pg.course","SPACE",""); 
	            	  if( dochek4Null(dynamiCQuery)){
	 	              dynamiCQuery=dynamiCQuery + "OR"+ "("+pgcourse+")";
	 	             }else{
	 	            	 dynamiCQuery="("+pgcourse+")";
	 	             }
	              }
	               
	               
	              if( dochek4Null(pgspe)){   
	            	  pgspe= getAndwithData(pgspe,"html.naukri.html","SPACE","");  
	            	  pgspe=pgspe.replace("\"", "\"\"");
	            	  if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+pgspe+")";
	 	             }else{
	 	            	 dynamiCQuery="("+pgspe+")";
	 	            }
	              }
	                 
	             if( dochek4Null(pginst)){   
	            	  pginst= getAndwithData(pginst,"education.pg.institute","SPACE",""); 
	            	   if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+pginst+")";
	 	             }else{
	 	            	 dynamiCQuery="("+pginst+")";
	 	             }
	              }
	              
	              if( dochek4Null(pgyr)){
	            	  pgyr= getAndwithData(pgyr,"education.pg.toYear","TO","");  
	            	  
	              if( dochek4Null(dynamiCQuery)){
	 	             dynamiCQuery=dynamiCQuery + "OR"+ "("+pgyr+")";
	 	             }else{
	 	            	 dynamiCQuery="("+pgyr+")";
	 	             }
	              }
	              
	              if( dochek4Null(ppgcourse)){   
	            	  
	            	  ppgcourse = ppgcourse.replace("\"", "").replace(",", "*\" OR \"*");
	            	  ppgcourse = "*" + ppgcourse + "*";
	            	  
	            	 
	            	  ppgcourse= getAndwithData(ppgcourse,"html.naukri.html","SPACE",""); 
	            	  if( dochek4Null(dynamiCQuery)){
		              dynamiCQuery=dynamiCQuery + "OR"+ "("+ppgcourse+")";
		             }else{
		            	 dynamiCQuery="("+ppgcourse+")";
		             }
	             }
	              
	             if( dochek4Null(ppginst)){   
	            	 ppginst = getAndwithData(ppginst,"html.naukri.html","SPACE",""); 
	            	 
	            	 if( dochek4Null(dynamiCQuery)){
		             dynamiCQuery=dynamiCQuery + "OR"+ "("+ppginst+")";
		             }else{
		            	 dynamiCQuery="("+ppginst+")";
		            }
	             }
	              
	             if( dochek4Null(ppgyr)){
	            	 ppgyr= getAndwithData(ppgyr,"html.naukri.html","TO","");  
	             
	             if( dochek4Null(dynamiCQuery)){
		             dynamiCQuery=dynamiCQuery + "OR"+ "("+ppgyr+")";
		             }else{
		            	 dynamiCQuery="("+ppgyr+")";
		             }
	             }
	              
	             
	            
	             
	           
	             if( dochek4Null(qindtyp)){
	               
	                 String naukri="";
	                 String monster="";
	                 
	                 String[] indus = qindtyp.split(",");
	      			for(int i=0;i<indus.length;i++){
	      				
	      				if(indus[i].startsWith("*N*")){
	      					naukri += indus[i].replace("*N*", "")+",";
	      				}else if(indus[i].startsWith("*M*")){
	      					monster += indus[i].replace("*M*", "")+",";
	      				}
	      				
	      			}
	      			
	      			naukri = replaceLast(naukri, ",", "");
	      			monster = replaceLast(monster, ",", "");
	                
	                 String naurkiData = "";
	                 String monsterData = "";
	                 
	                 if(!naukri.equals("")){
	                	
	                	 naurkiData= getAndwithData(naukri,"html.naukri.html","OR","");
	                	 
	                	 naurkiData = naurkiData.replace("*\" OR \"*", "</div>\") OR (html.naukri.html:\">").replace("\"*", "\">").replace("*\"", "</div>\"");
	                	 
	                	 
	                	 naurkiData = "(" + naurkiData + ")";
	                	 naurkiData = naurkiData.replace(" ", "+").replace("&", "%26");
	                	 
	                 }
	                 if(!monster.equals("")){
	                 monsterData= getAndwithData(monster,"html.monster.html","OR","");
	                	 
	                	 monsterData = monsterData.replace("*\" OR \"*", "\") OR (html.monster.html:\"Industry</span>: ").replace("\"*", "\"Industry</span>: ").replace("*\"", "\"");
	                	 monsterData = "(" + monsterData + ")";
	                	 monsterData = monsterData.replace(" ", "+").replace("&", "%26");
	                	 
	                	 
	                 }
	                 
	                 
	                 
	                 if(!naurkiData.equals("") && !monsterData.equals("")){
	                	 naurkiData = "(" + naurkiData + ")";
	                	 monsterData = "(" + monsterData + ")";
	                	 qindtyp = naurkiData +"OR"+monsterData;
	                 }
	                 else if(!naurkiData.equals("")){
	                	 qindtyp = naurkiData;
	                 }
	                 else if(!monsterData.equals("")){
	                	 qindtyp = monsterData;
	                 }
	                
	                   
	               if( dochek4Null(dynamiCQuery)){
	               dynamiCQuery=dynamiCQuery + "AND"+ "("+qindtyp+")";  //OR
	               }else{
	                 dynamiCQuery=qindtyp;
	               }
	            }
	             
	             if( dochek4Null(qcurdesig)){   
	              	qcurdesig= getAndwithData(qcurdesig,"employment.current.designation","SPACE",""); 
//	              	
	              	if(qcurdesig.contains(",")){
	              		qcurdesig=qcurdesig.replace("+,", ",").replace(",+", ",");
	              		qcurdesig =qcurdesig.replace(",", "\")+OR+(employment.current.designation:\"");
	              	   
	              		System.out.println("qcurdesig query with comma::::"+qcurdesig);
	              	}
	              
	                  if( dochek4Null(dynamiCQuery)){
	                  dynamiCQuery=dynamiCQuery + "AND"+ "("+qcurdesig+")";  //OR
	                  }else{
	                 	 dynamiCQuery="("+qcurdesig+")";
	                  }
	              }
	                              
	                        
	                          if(dochek4Null(qprdesig)){   
	                         	 qprdesig= getAndwithData(qprdesig,"previousDesig","SPACE","");   
	                         	 qprdesig=qprdesig.replace("\"", "\"\"");
	                            //System.out.println("qprdesig::::"+qprdesig);
	             	             if( dochek4Null(dynamiCQuery)){
	             	             dynamiCQuery=dynamiCQuery + "AND"+ "("+qprdesig+")";   //OR
	             	             }else{
	             	            	 dynamiCQuery="("+qprdesig+")";
	             	             }
	                          }
	                     if(dochek4Null(dynamiCQuery4Location) && dochek4Null(dynamiCQuery)){
	                    	 dynamiCQuery=dynamiCQuery+"AND"+dynamiCQuery4Location;  
	                    	 
	                   
	                     }else{
	                    	 dynamiCQuery=dynamiCQuery+dynamiCQuery4Location;
	                     }
	                     
	                     //getRurl(dynamiCQuery);
	                     System.out.println("dynamiCQuery>__________________>>>>>>>>>"+dynamiCQuery);   
	                     
	       int start = Integer.parseInt("50") *(next);
	      
	       
	       String limit = "100";
	       String noticPlimit = "20";
	       
	       String Rooturl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?default_operator=AND&q="+dynamiCQuery+"&size=50&from="+start+"&_source=id,name,email,gender,category,mobileNumber,maritalStatus,federated,createdDate,lastModified,experiencedIndustry,experiencedFunctionalArea,noticePeriod,preferredLocation,salary,employment,skillSummary,exp,experience,createdDate,lastModified,html&sort="+sort+"";
	       
	       System.out.println("Rooturl:::::::__"+Rooturl);
	       
	       //URL urll = new URL("https://ghies.globalhuntindia.com/ElasticAPI/test");
	       URL urll = new URL("http://localhost:8080/test");
	        
	       
	       
	       HttpURLConnection conn = (HttpURLConnection) urll.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			
			String input = Rooturl;
			
			OutputStream os = conn.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			
			StringBuffer response = new StringBuffer();
		
			while ((output = br.readLine()) != null) {
			
				response.append(output);
			}
	     
			jsonData = response.toString();
			
	       }catch (Exception e) {
	              e.printStackTrace();
	              String str = e.getMessage();
	              if (str.contains("400 Bad Request")) {
	                     return "{\"error\":\"please provide a valid data\"}";
	              }
	       }
	       
	       
	       return jsonData;
	}
	
	public static  boolean dochek4Null(String value) {
		boolean flag = false;
		if ( ""!=value) {
			flag = true;
		}
	
		return flag;
	}
	
	public static String getAndwithData(String data,String solrField,String Operator,String Operator4NOT){
	   	  String dataQuery="";
	   	  if(" "!=data && data.length()>1){
	   		data=data.replace("#", "%23");
	   	  if(Operator.equals("AND")){
	   		  data = "\"*" + data.replace(",", "*\" AND \"*") + "*\"";
	   		 
	   	  }
	   	  
	   	  if(Operator.equals("OR")){
	   		  data = "\"*" + data.replace(",", "*\" OR \"*") + "*\"";
	   		 
	   	  }
	   	  if(Operator.equals("SPACE")){
	   		  data=data.replace(" ", "+");  
	   		  data = "\""+data+"\"";
	   	  }
	   	  if(Operator.equals("TO")){
	   		       		               
	   		  data = data.replace(",", " TO ");
	   		  data = "[" +data+ "]";
	   	  } 	 
	   	  
	   	  }
	   	  else if( " "!=data && data.length()==1 ){
	   		  data = "\"*" +data+ "*\"";
	   	  }else{
	   		 data="*"; 
	   	  }
	         
	         if(solrField.equals("TotalExps")){
	        	
	        	data = "\"*" + data.replace(",", "*\" OR \"*") + "*\"";
	  			data = data.replace("OR", "OR TotalExps:").replaceFirst("\"", ""); 
	  			
	    	  }
	          if(solrField.equals("CurrentCTC")){
	        	 data = "\"*" + data.replace(",", "*\" OR \"*") + "*\"";
	        	 data = data.replace("OR", "OR CurrentCTC:").replaceFirst("\"", "");
	         }
	         
	       
	         
	         dataQuery=solrField+":"+data;
	       	
	        if(Operator4NOT.equals("NOT")){
	        	 data="_text_:"+data;
	 	   		 dataQuery=data;
	 	   		 
	        }
	         
	         return dataQuery;
	   			  
	     }
	
	
	 public static String getAndwithDataLocation(String data,String solrField,String Operator,String Operator4NOT){
	   	  String dataQuery="";
	   	 
	   	  if(" "!=data && data.length()>1){
	   		  
	   		
	   		data=data.replace("#", "%23");
	   	  if(Operator.equals("AND")){
	   		  
	   		  data = "\"*" + data.replace(",", "*\" AND \"*") + "*\"";
	   		
	   	  }
	   	  
	   	  if(Operator.equals("OR")){
	   		  
	   		  data = "\"*" + data.replace(",", "*\") OR ("+solrField +": \"*") + "*\"";
	   		 
	   	  }
	   	  if(Operator.equals("SPACE")){
	   		  data=data.replace(" ", "+");
	             data ="\\"+ "\"" +data + "\\" +"\"";
	   	  }
	   	  if(Operator.equals("TO")){
	   		 data = data.replace(",", " TO ");
	   		
	   		  data = "[" +data+ "]";
	   		
	   	  } 	 
	     
	   	  }else{
	   		  data="*";
	   	  }
	         
	         if(solrField.equals("TotalExps")){
	        	
	        	data = "\"*" + data.replace(",", "*\" OR \"*") + "*\"";
	  			data = data.replace("OR", "OR TotalExps:").replaceFirst("\"", "");
	  			 
	  		  }
	         
	         
	         if(solrField.equals("CurrentCTC")){
	        	 data = "\"*" + data.replace(",", "*\" OR \"*") + "*\"";
	        	 data = data.replace("OR", "OR CurrentCTC:").replaceFirst("\"", "");
	         }
	         
	        
	         dataQuery=solrField+":"+data;
	        
	        if(Operator4NOT.equals("NOT")){
	 	   		 data= " NOT (_text_:"+data+")";
	 	   		 dataQuery=data;
	        }
	         
	        dataQuery="("+dataQuery+")";
	   	  return dataQuery;
	   			  
	     }
	 
	 public static String replaceLast(String text, String regex, String replacement) {
	        return text.replaceFirst("(?s)"+regex+"(?!.*?"+regex+")", replacement);
	    }

}
