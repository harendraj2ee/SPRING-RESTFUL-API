package com.es.model;

import org.springframework.boot.context.properties.ConfigurationProperties;

//@ConfigurationProperties(prefix = "app")
public class CollectionUrl {
	private String attachUrl;
	private String candidateUrl;
	private String jobUrl;
	private String attachAuditUrl;
	private String candidateAuditUrl;
	
	
	public String getAttachUrl() {
		return attachUrl;
	}
	public void setAttachUrl(String attachUrl) {
		this.attachUrl = attachUrl;
	}
	public String getCandidateUrl() {
		return candidateUrl;
	}
	public void setCandidateUrl(String candidateUrl) {
		this.candidateUrl = candidateUrl;
	}
	public String getJobUrl() {
		return jobUrl;
	}
	public void setJobUrl(String jobUrl) {
		this.jobUrl = jobUrl;
	}
	public String getAttachAuditUrl() {
		return attachAuditUrl;
	}
	public void setAttachAuditUrl(String attachAuditUrl) {
		this.attachAuditUrl = attachAuditUrl;
	}
	public String getCandidateAuditUrl() {
		return candidateAuditUrl;
	}
	public void setCandidateAuditUrl(String candidateAuditUrl) {
		this.candidateAuditUrl = candidateAuditUrl;
	}
	
	

}
