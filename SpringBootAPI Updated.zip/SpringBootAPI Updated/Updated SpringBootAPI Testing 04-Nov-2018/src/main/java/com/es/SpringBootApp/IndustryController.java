package com.es.SpringBootApp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.restServiceImpl.RestServiceImpl;

@RestController
public class IndustryController {
	
	RestTemplate restTemplate=new RestTemplate();
	RestServiceImpl restService = new RestServiceImpl();
	@RequestMapping(value = "ElasticAPI/countindutry", method = RequestMethod.GET)
	public @ResponseBody String esResumeAttach(@RequestParam("industry")String industry, @RequestHeader HttpHeaders headers) throws JSONException, ParseException {
		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		System.out.println("ESURL Candidate1    >> " + url);
		String jsonIndustryUrl = restTemplate.getForObject(url, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
				
		JSONObject jsonObject1=(JSONObject) new JSONObject(jsonIndustryUrl).get("_shards");
		//System.out.println("jsonObject1 >> "+jsonObject1);
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonIndustryUrl).get("hits");
		//System.out.println("countttttttttttt >> "+jsonObject2);
		//System.out.println("jsonstart jsonObject2 >> "+jsonObject2.getLong("total"));
		Integer count=(Integer) jsonObject2.get("total");
		//System.out.println("count total >> "+count);
		
		array.put(count);
		jsonMain.accumulate("totalcount", count);
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		
		return jsonObjResponse.toString();
	}

	@RequestMapping(value = "/ElasticAPI/industry", method = RequestMethod.GET)
	public @ResponseBody String esIndustryCountMultiple(@RequestHeader HttpHeaders headers) throws JSONException, ParseException {
		
		 if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}
		
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
		
		String industry1="NBFCs";
		String url1 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry1+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		System.out.println("ESURL Candidate1    >> " + url1);
		String jsonIndustryUrl1 = restTemplate.getForObject(url1, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		//JSONObject jsonObject1=(JSONObject) new JSONObject(jsonIndustryUrl1).get("_shards");
		JSONObject jsonObject1= (JSONObject) new JSONObject(jsonIndustryUrl1).get("hits");
		Integer count1=(Integer) jsonObject1.get("total");
		array.put(count1);
		jsonMain.accumulate("NBFCs", count1);
		
		String industry2="EPC";
		String url2 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry2+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		//System.out.println("ESURL Candidate1    >> " + url2);
		String jsonIndustryUrl2 = restTemplate.getForObject(url2, String.class);
		//JSONObject jsonObject3=(JSONObject) new JSONObject(jsonIndustryUrl2).get("_shards");
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonIndustryUrl2).get("hits");
		Integer count2=(Integer) jsonObject2.get("total");
		array.put(count2);
		jsonMain.accumulate("EPC", count2);
		
		String industry3="CRS";
		String url3 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry3+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		//System.out.println("ESURL Candidate1    >> " + url3);
		String jsonIndustryUrl3 = restTemplate.getForObject(url3, String.class);
		//JSONObject jsonObject5=(JSONObject) new JSONObject(jsonIndustryUrl3).get("_shards");
		JSONObject jsonObject3= (JSONObject) new JSONObject(jsonIndustryUrl3).get("hits");
		Integer count3=(Integer) jsonObject3.get("total");
		array.put(count3);
		jsonMain.accumulate("CRS", count3);
		
		String industry4="FMCD";
		String url4 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry4+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		//System.out.println("ESURL Candidate1    >> " + url4);
		String jsonIndustryUrl4 = restTemplate.getForObject(url4, String.class);
		//JSONObject jsonObject7=(JSONObject) new JSONObject(jsonIndustryUrl4).get("_shards");
		JSONObject jsonObject4= (JSONObject) new JSONObject(jsonIndustryUrl4).get("hits");
		Integer count4=(Integer) jsonObject4.get("total");
		array.put(count4);
		jsonMain.accumulate("FMCD", count4);
		
		String industry5="Automobile";
		String url5 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry5+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl5 = restTemplate.getForObject(url5, String.class);
		JSONObject jsonObject5= (JSONObject) new JSONObject(jsonIndustryUrl5).get("hits");
		Integer count5=(Integer) jsonObject5.get("total");
		array.put(count5);
		jsonMain.accumulate("Automobile", count5);
		
		/*String industry6="Technology";
		String url6 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry6+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl6 = restTemplate.getForObject(url6, String.class);
		JSONObject jsonObject6= (JSONObject) new JSONObject(jsonIndustryUrl6).get("hits");
		Integer count6=(Integer) jsonObject6.get("total");
		array.put(count6);
		jsonMain.accumulate("Technology", count6);*/
		
		
		String industry7="";
		String s7="Business & Information,Manufacturing & Process";
		industry7=s7.replace("&", "");
		//System.out.println("industry7 >> "+industry7);
		
		String url7 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry7+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl7 = restTemplate.getForObject(url7, String.class);
		JSONObject jsonObject7= (JSONObject) new JSONObject(jsonIndustryUrl7).get("hits");
		Integer count7=(Integer) jsonObject7.get("total");
		array.put(count7);
		jsonMain.accumulate("Business & Information,Manufacturing & Process", count7);
		
		String industry8="Telecommunication";
		String url8 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry8+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl8 = restTemplate.getForObject(url8, String.class);
		JSONObject jsonObject8= (JSONObject) new JSONObject(jsonIndustryUrl8).get("hits");
		Integer count8=(Integer) jsonObject8.get("total");
		array.put(count8);
		jsonMain.accumulate("Telecommunication", count8);
		
		
		String industry9="";
		String s9="Technology Services";
		industry9=s9.replace("&", "");
		String url9 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry9+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl9 = restTemplate.getForObject(url9, String.class);
		JSONObject jsonObject9= (JSONObject) new JSONObject(jsonIndustryUrl9).get("hits");
		Integer count9=(Integer) jsonObject9.get("total");
		array.put(count9);
		jsonMain.accumulate("Technology Services", count9);
		
		String industry10="Shared Services";
		String url10 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry10+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl10 = restTemplate.getForObject(url10, String.class);
		JSONObject jsonObject10= (JSONObject) new JSONObject(jsonIndustryUrl10).get("hits");
		Integer count10=(Integer) jsonObject10.get("total");
		array.put(count10);
		jsonMain.accumulate("Shared Services", count10);
		
		String industry11="";
		String s11="Manufacturing & Process";
		industry11=s11.replace("&", "");
 
		String url11 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry11+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl11 = restTemplate.getForObject(url11, String.class);
		JSONObject jsonObject11= (JSONObject) new JSONObject(jsonIndustryUrl11).get("hits");
		Integer count11=(Integer) jsonObject11.get("total");
		array.put(count11);
		jsonMain.accumulate("Manufacturing & Process", count11);
		
	
		
		String industry12="Energy,Power";
		String url12 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry12+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl12 = restTemplate.getForObject(url12, String.class);
		JSONObject jsonObject12= (JSONObject) new JSONObject(jsonIndustryUrl12).get("hits");
		Integer count12=(Integer) jsonObject12.get("total");
		array.put(count12);
		jsonMain.accumulate("Energy,Power", count12);
		
		
		String industry13="Utilities";
		String url13 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry13+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl13 = restTemplate.getForObject(url13, String.class);
		JSONObject jsonObject13 = (JSONObject) new JSONObject(jsonIndustryUrl13).get("hits");
		Integer count13=(Integer) jsonObject13.get("total");
		array.put(count13);
		jsonMain.accumulate("Utilities", count13);
		
		
		String industry14="";
		String s14="Industrial Goods & Services";
		industry14=s14.replace("&", "");
		String url14 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry14+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl14 = restTemplate.getForObject(url14, String.class);
		JSONObject jsonObject14= (JSONObject) new JSONObject(jsonIndustryUrl14).get("hits");
		Integer count14=(Integer) jsonObject14.get("total");
		array.put(count14);
		jsonMain.accumulate("Industrial Goods & Services", count14);
		
		String industy15="Legal";
		String url15 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industy15+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl15 = restTemplate.getForObject(url15, String.class);
		JSONObject jsonObject15= (JSONObject) new JSONObject(jsonIndustryUrl15).get("hits");
		Integer count15=(Integer) jsonObject15.get("total");
		array.put(count15);
		jsonMain.accumulate("Legal", count15);
		
		String industry16="Shared Services/BPO/KPO";
		String url16 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry16+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl16 = restTemplate.getForObject(url16, String.class);
		JSONObject jsonObject16= (JSONObject) new JSONObject(jsonIndustryUrl16).get("hits");
		Integer count16=(Integer) jsonObject16.get("total");
		array.put(count16);
		jsonMain.accumulate("Shared Services/BPO/KPO", count16);
		
		String industry17="Pharmaceuticals";
		String url17 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry17+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl17 = restTemplate.getForObject(url17, String.class);
		JSONObject jsonObject17= (JSONObject) new JSONObject(jsonIndustryUrl17).get("hits");
		Integer count17=(Integer) jsonObject17.get("total");
		array.put(count17);
		jsonMain.accumulate("Pharmaceuticals", count17);
		
		String industry18="Management Consulting";
		String url18 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry18+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl18 = restTemplate.getForObject(url18, String.class);
		JSONObject jsonObject18= (JSONObject) new JSONObject(jsonIndustryUrl18).get("hits");
		Integer count18=(Integer) jsonObject18.get("total");
		array.put(count18);
		jsonMain.accumulate("Management Consulting", count18);
		
		String industry19="Telecom Services,Telecommunication Services";
		String url19 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry19+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl19 = restTemplate.getForObject(url19, String.class);
		JSONObject jsonObject19= (JSONObject) new JSONObject(jsonIndustryUrl19).get("hits");
		Integer count19=(Integer) jsonObject19.get("total");
		array.put(count19);
		jsonMain.accumulate("Telecom Services,Telecommunication Services", count19);
		
		
		String industry20="";
		String s20="Business & Information";
		industry20=s20.replace("&", "");
		String url20 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry20+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl20 = restTemplate.getForObject(url20, String.class);
		JSONObject jsonObject20= (JSONObject) new JSONObject(jsonIndustryUrl20).get("hits");
		Integer count20=(Integer) jsonObject20.get("total");
		array.put(count20);
		jsonMain.accumulate("Business & Information", count20);
		
		
		String industry21="";
		String s21="Logistics & Warehousing";
		industry21=s21.replace("&", "");
		String url21 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry21+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl21 = restTemplate.getForObject(url21, String.class);
		JSONObject jsonObject21= (JSONObject) new JSONObject(jsonIndustryUrl21).get("hits");
		Integer count21=(Integer) jsonObject21.get("total");
		array.put(count21);
		jsonMain.accumulate("Logistics & Warehousing", count21);
		
		String industry22="Information Technology";
		String url22 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry22+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl22 = restTemplate.getForObject(url22, String.class);
		JSONObject jsonObject22= (JSONObject) new JSONObject(jsonIndustryUrl22).get("hits");
		Integer count22=(Integer) jsonObject22.get("total");
		array.put(count22);
		jsonMain.accumulate("Information Technology", count22);
		
		String industry23="Technology Products";
		String url23 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry23+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl23 = restTemplate.getForObject(url23, String.class);
		JSONObject jsonObject23= (JSONObject) new JSONObject(jsonIndustryUrl23).get("hits");
		Integer count23=(Integer) jsonObject23.get("total");
		array.put(count23);
		jsonMain.accumulate("Technology Products", count23);
		
		
		String industry24="";
		String s24="Oil & Gas";
		industry24=s24.replace("&", "");
		String url24 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry24+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl24 = restTemplate.getForObject(url24, String.class);
		JSONObject jsonObject24= (JSONObject) new JSONObject(jsonIndustryUrl24).get("hits");
		Integer count24=(Integer) jsonObject24.get("total");
		array.put(count24);
		jsonMain.accumulate("Oil & Gas", count24);
		
		String industry25="Investment Banking";
		String url25 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry25+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl25 = restTemplate.getForObject(url25, String.class);
		JSONObject jsonObject25= (JSONObject) new JSONObject(jsonIndustryUrl25).get("hits");
		Integer count25=(Integer) jsonObject25.get("total");
		array.put(count25);
		jsonMain.accumulate("Investment Banking", count25);
		
		String industry26="Technology";
		String url26 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry26+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl26 = restTemplate.getForObject(url26, String.class);
		JSONObject jsonObject26= (JSONObject) new JSONObject(jsonIndustryUrl26).get("hits");
		Integer count26=(Integer) jsonObject26.get("total");
		array.put(count26);
		jsonMain.accumulate("Technology", count26);
		
		
		String industry27="";
		String s27="E-Commerce,Technology Ecommerce,Travel & Tours";
		industry27=s27.replace("&", "");
		String url27 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry27+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl27 = restTemplate.getForObject(url27, String.class);
		JSONObject jsonObject27= (JSONObject) new JSONObject(jsonIndustryUrl27).get("hits");
		Integer count27=(Integer) jsonObject27.get("total");
		array.put(count27);
		jsonMain.accumulate("E-Commerce,Technology Ecommerce,Travel & Tours", count27);
		
		String industry28="Consumer Goods";
		String url28 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry28+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl28 = restTemplate.getForObject(url28, String.class);
		JSONObject jsonObject28= (JSONObject) new JSONObject(jsonIndustryUrl28).get("hits");
		Integer count28=(Integer) jsonObject28.get("total");
		array.put(count28);
		jsonMain.accumulate("Consumer Goods", count28);
		
		String industry29="Construction";
		String url29 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry29+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl29 = restTemplate.getForObject(url29, String.class);
		JSONObject jsonObject29= (JSONObject) new JSONObject(jsonIndustryUrl29).get("hits");
		Integer count29=(Integer) jsonObject29.get("total");
		array.put(count29);
		jsonMain.accumulate("Construction", count29);
		
		String industry30="";
		String s30="Manufacturing & Process,FMCG";
		industry30=s30.replace("&", "");
		
		String url30 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industry:\""+industry30+"\")&size=10&from=0&pretty=true&_source=id,industry";//id,
		String jsonIndustryUrl30 = restTemplate.getForObject(url30, String.class);
		JSONObject jsonObject30= (JSONObject) new JSONObject(jsonIndustryUrl30).get("hits");
		Integer count30=(Integer) jsonObject30.get("total");
		array.put(count30);
		jsonMain.accumulate("Manufacturing & Process,FMCG", count30);
		
		
		
		
		///End
		
		
		
			
		
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		
		return jsonObjResponse.toString();
	}

	
	
}
