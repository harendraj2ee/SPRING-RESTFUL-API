package com.es.Industry;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.SpringBootApp.CognitoAuthentication;
import com.es.restServiceImpl.RestServiceImpl;

@Controller
public class IndustryController {
	RestServiceImpl restService = new RestServiceImpl();
	RestTemplate restTemplate = new RestTemplate();
	
	/* Logs APIs */
	@RequestMapping(value = "/ElasticAPI/log", method = { RequestMethod.POST })
	public @ResponseBody String auditSearch(@RequestBody String field, @RequestHeader HttpHeaders headers)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException,
			UnsupportedEncodingException {

		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		
		if (validity.equals("valid")) {

			return field;
		} else {
			return validity;
		}
	}

}
