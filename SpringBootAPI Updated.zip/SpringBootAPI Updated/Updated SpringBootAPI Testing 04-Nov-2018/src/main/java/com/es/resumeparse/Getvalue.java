package com.es.resumeparse;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Getvalue {
	static Properties prop = new Properties();
	static InputStream input = null;
	static String filepath = "/resources/searchconfig.properties";

	
	public String getSkills() {
		String skills = "";
		try {
			// load a properties file
			InputStream input = getClass().getResourceAsStream(filepath);
			prop.load(input);
			// get the property value and print it out
			skills = prop.getProperty("SkillsPath");
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return skills;
	}
	

	

}