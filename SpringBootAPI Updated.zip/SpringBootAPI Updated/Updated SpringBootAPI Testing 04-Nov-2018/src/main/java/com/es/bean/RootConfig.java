package com.es.bean;

public class RootConfig {
	
	private String resumeDataLocal;
    private String resumeDataLive;
   
    private String  fileName;
    private String  empId;
    private String  fedrated;
    
    public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFedrated() {
		return fedrated;
	}
	public void setFedrated(String fedrated) {
		this.fedrated = fedrated;
	}
	
    
    
	public String getResumeDataLocal() {
		return resumeDataLocal;
	}
	public void setResumeDataLocal(String resumeDataLocal) {
		this.resumeDataLocal = resumeDataLocal;
	}
	public String getResumeDataLive() {
		return resumeDataLive;
	}
	public void setResumeDataLive(String resumeDataLive) {
		this.resumeDataLive = resumeDataLive;
	}
     
}
