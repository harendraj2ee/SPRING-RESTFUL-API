package com.es.SpringBootApp;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

//import org.bson.Document;
//import org.bson.types.Binary;
//import org.bson.Document;
//import org.bson.types.Binary;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.dbconnection.MongoConnectionDocument;
import com.es.dbconnection.MongoConnectionTemplate;
import com.es.model.DocumentModel;
import com.es.model.TemplateModel;
import com.es.restServiceImpl.RestServiceImpl;
//import com.mongodb.BasicDBObject;
//import com.mongodb.BasicDBObject;
//import com.mongodb.BasicDBObject;
//import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;

@RestController
public class MongoController {
	RestServiceImpl restService = new RestServiceImpl();
	RestTemplate restTemplate = new RestTemplate();

	/*@RequestMapping(value = "/document")
	public @ResponseBody String document(@RequestParam("documentid") String documentId,
			@RequestHeader HttpHeaders headers) throws Exception {

		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if (validity.equals("valid")) {

			List<DocumentModel> list = new ArrayList<DocumentModel>();
			list = getDocument(documentId);
			JSONObject json = new JSONObject();
			json.put("response", list);
			return json.toString();
		} else {
			return validity;
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	public List<DocumentModel> getDocument(String documentid) {
		List<DocumentModel> al = null;
		try {
			al = new ArrayList<DocumentModel>();

			MongoCollection<Document> collection = null;
			MongoConnectionDocument mcl = new MongoConnectionDocument();
			collection = mcl.getInstanceDocument();

			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("documentId", documentid);
			
		
			for (Document doc : collection.find(whereQuery)) {
				DocumentModel document = new DocumentModel();

				if (doc.containsKey("documentId"))
					document.setDocumentId(doc.getString("documentId"));

				if (doc.containsKey("module"))
					document.setModule(doc.getString("module"));

				if (doc.containsKey("createdDate"))
					document.setCreatedDate(doc.getString("createdDate"));

				if (doc.containsKey("deleted"))
					document.setDeleted(doc.getBoolean("deleted"));

				if (doc.containsKey("createdBy"))
					document.setCreatedBy(doc.getString("createdBy"));

				if (doc.containsKey("documentType"))
					document.setDocumentType(doc.getString("documentType"));

				if (doc.containsKey("documentName"))
					document.setDocumentName(doc.getString("documentName"));

				if (doc.containsKey("modifiedBy"))
					document.setModifiedBy(doc.getString("modifiedBy"));

				if (doc.containsKey("moduleId"))
					document.setModuleId(doc.getString("moduleId"));

				if (doc.containsKey("modifiedDate"))
					document.setModifiedDate(doc.getString("modifiedDate"));

				if (doc.containsKey("doc")) {
					Binary b = (Binary) doc.get("doc");
					byte[] bytes = b.getData();
					String data = Base64.getEncoder().encodeToString(bytes);
					document.setDoc(data);
				}

				al.add(document);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}
*/
	/*@RequestMapping(value = "/Template")
	public @ResponseBody String Template(@RequestParam("rid") String rid,
			@RequestHeader HttpHeaders headers) throws Exception {

		String authString = headers.getFirst("token");
		String validity = CognitoAuthentication.getValidAuthentication(authString);
		if (validity.equals("valid")) {

			List<TemplateModel> list = new ArrayList<TemplateModel>();
			list = getTemplate(rid);
			JSONObject json = new JSONObject();
			json.put("response", list);
			return json.toString();
		} else {
			return validity;
		}
	}

	@SuppressWarnings({ "unchecked", "static-access" })
	public List<TemplateModel> getTemplate(String rid) {
		List<TemplateModel> al = null;
		try {
			al = new ArrayList<TemplateModel>();

			MongoCollection<Document> collection = null;
			MongoConnectionTemplate mcl = new MongoConnectionTemplate();
			collection = mcl.getInstanceTemplate();

			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("rid", rid);

			for (Document doc : collection.find(whereQuery)) {
				TemplateModel document = new TemplateModel();

				if (doc.containsKey("rid"))
					document.setRid(doc.getString("rid"));

				if (doc.containsKey("fileName"))
					document.setFileName(doc.getString("fileName"));

				if (doc.containsKey("extention"))
					document.setExtention(doc.getString("extention"));

				if (doc.containsKey("createdDate"))
					document.setCreatedDate(doc.getString("createdDate"));

				if (doc.containsKey("data")) {
					Binary b = (Binary) doc.get("data");
					byte[] bytes = b.getData();
					String data = Base64.getEncoder().encodeToString(bytes);
					document.setData(data);
				}

				al.add(document);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}*/
}
