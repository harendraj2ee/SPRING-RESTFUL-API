package com.es.dbconnection;
import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoConnectionAttach {    
       static MongoClientURI connectionString;
       static MongoClient mongoClient = null;   
       static MongoDatabase database ;
       static com.mongodb.client.MongoCollection<Document> collection = null;

public MongoConnectionAttach()
{
       connectionString = new MongoClientURI("mongodb+srv://cloudRouteMap:Candi123@developmentcluster-yfy2g.mongodb.net/CandidateDB");
}
       
public static MongoCollection getInstanceAttach() {
              if (mongoClient == null) {
                     //mongoCon = new MongoConnection();
                     mongoClient = new MongoClient(connectionString);
                     System.out.println("MongoClient:::::"+mongoClient.hashCode());
                     //getOpenCloseMongo();
                     database = mongoClient.getDatabase("CandidateDB");
                     //collection = database.getCollection("LinkedInCandidate");
                     collection = database.getCollection("Attached");
                     System.out.println("collection:::::"+collection);
              }
              return collection;
              
  }
}
    /*   public static void main(String...s){
              MongoCollection<Document> collection =null;
              MongoConnection connection = new MongoConnection();
              collection=   connection.getInstance();
              
              System.out.println("collection:::"+collection.getNamespace().getCollectionName());
             // FindIterable<Document> document = collection.find().limit(1);
              //System.out.println("document::::"+document.first());
              
              for (Document doc : collection.find()) {
            // for (Document doc : collection.find().sort(new
            // BasicDBObject("_id", -1))) {
            if (doc.get("_id") != null) {

                  //ObjectId _id = (ObjectId) doc.get("_id");
                String  id = (String) doc.get("_id");
                System.out.println("can id......" + id);
            }
              }
                 
              
       }
              
              */
       
       
       
      


/*import org.bson.Document;

//import org.bson.Document;
//import org.bson.types.ObjectId;

import com.es.model.CanditateResume;
//import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


public class MongoConnection {	
	static MongoClientURI connectionString;
	static MongoClient mongoClient = null;	
	static MongoDatabase database ;
	static com.mongodb.client.MongoCollection<Document> collection = null;

public MongoConnection()
{
    //connectionString = new MongoClientURI("mongodb://Candidate:tech!123@192.168.1.21:27017/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1");
	//connectionString = new MongoClientURI("mongodb://Hitech:role!123@192.168.1.21:27017/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1");
	////connectionString = new MongoClientURI("mongodb://cloudRouteMap:Candi123@mongodb+srv:27017/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1&serverSelectionTimeoutMS=15000");
	
	
	//////////connectionString = new MongoClientURI("mongodb://cloudRouteMap:Candi123@mongodb+srv:27017/?authSource=CandidateDB&serverSelectionTimeoutMS=150000");

	//connectionString = new MongoClientURI("mongodb://cloudRouteMap:Candi123@mongodb+srv://developmentcluster-yfy2g.mongodb.net/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1&serverSelectionTimeoutMS=15000");

	
	connectionString = new MongoClientURI("mongodb+srv://cloudRouteMap:Candi123@developmentcluster-yfy2g.mongodb.net/CandidateDB");


	//5b53038b3eea6f1e5cd3c227
	//client = mongoc_client_new ("mongodb+srv://kay:myRealPassword@cluster0.mongodb.net/?serverSelectionTryOnce=false&serverSelectionTimeoutMS=15000");
	//db = mongoc_client_get_database (client, "test");
	
	
	//mongoc_client_t client = mongoc_client_new ("mongodb://kay:myRealPassword@mycluster0-shard-00-00.mongodb.net:27017,mycluster0-shard-00-01.mongodb.net:27017,mycluster0-shard-00-02.mongodb.net:27017/admin?ssl=true&replicaSet=Mycluster0-shard-0&authSource=admin&serverSelectionTryOnce=false&serverSelectionTimeoutMS=15000");

}
	
	public static MongoCollection getInstance() {
		if (mongoClient == null) {
			//mongoCon = new MongoConnection();
			mongoClient = new MongoClient(connectionString);
		
			System.out.println("MongoClient:::::"+mongoClient.hashCode());
			//getOpenCloseMongo();
			 database = mongoClient.getDatabase("CandidateDB");
			
			 //collection = database.getCollection("LinkedInCandidate");
			 //collection = database.getCollection("DynamicCandidate");
			 collection = database.getCollection("Candidate");
			 System.out.println("collection:::::"+collection);
		}
		return collection;
	}
	
	public static void main(String...s){
		MongoConnection connection =  new MongoConnection();
		connection.getInstance();
		
		MongoCollection<Document> collection = null;
		MongoConnection mcl = new MongoConnection();
		collection = mcl.getInstance();
		System.out.println("collection:::::::::::::"+collection.getNamespace().getCollectionName());
		System.out.println("collection:::::::::::::"+collection.find().batchSize(1).iterator());
		
		//Document doc = collection.find().first();
		//System.out.println(doc);
		//ObjectId id = new ObjectId(objectid);

		
	}

}*/
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	private static MongoConnection mongoCon;
	MongoClientURI connectionString;
	private MongoConnection() {
		System.out.println("Mongo Constructor");
		 connectionString = new MongoClientURI("mongodb://"+Getvalue.getuserNameMongo()+":"+Getvalue.getpassMongo()+"@"+Getvalue.gethost4Mongo()+":27017/?authSource="+Getvalue.getdb4ongo()+"&authMechanism=SCRAM-SHA-1");
	}

	public static MongoConnection getInstance() {
		if (mongoCon == null) {
			mongoCon = new MongoConnection();
		}
		return mongoCon;
	}

	 public static MongoClient getOpenCloseMongo(){
			System.out.println("OpnAndclos::::");	
			MongoClient mongoClient = null;			
			if(mongoClient!=null)mongoClient.close();
			MongoClientURI connectionString = new MongoClientURI("mongodb://"+Getvalue.getuserNameMongo()+":"+Getvalue.getpassMongo()+"@"+Getvalue.gethost4Mongo()+":27017/?authSource="+Getvalue.getdb4ongo()+"&authMechanism=SCRAM-SHA-1");
					
			mongoClient = new MongoClient(connectionString);
			
			System.out.println("mongoClient>>>>"+mongoClient.hashCode());
			return mongoClient;
			
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MongoConnection.getInstance().getOpenCloseMongo();
	}

*/
