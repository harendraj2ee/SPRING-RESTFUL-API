package com.es.dbconnection;


import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


public class MongoConnection {	
	static MongoClientURI connectionString;
	static MongoClient mongoClient = null;	
	static MongoDatabase database ;
	static com.mongodb.client.MongoCollection<Document> collection = null;

public MongoConnection()
{
    //connectionString = new MongoClientURI("mongodb://Candidate:tech!123@192.168.1.21:27017/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1");
	connectionString = new MongoClientURI("mongodb://Hitech:role!123@192.168.1.21:27017/?authSource=CandidateDB&authMechanism=SCRAM-SHA-1");
}
	
	public static MongoCollection getInstance() {
		if (mongoClient == null) {
			//mongoCon = new MongoConnection();
			mongoClient = new MongoClient(connectionString);
		
			System.out.println("MongoClient:::::"+mongoClient.hashCode());
			//getOpenCloseMongo();
			 database = mongoClient.getDatabase("CandidateDB");
			
			 //collection = database.getCollection("LinkedInCandidate");
			 collection = database.getCollection("DynamicCandidate");
			 //System.out.println("collection:::::"+collection);
		}
		return collection;
	}

	
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	private static MongoConnection mongoCon;
	MongoClientURI connectionString;
	private MongoConnection() {
		System.out.println("Mongo Constructor");
		 connectionString = new MongoClientURI("mongodb://"+Getvalue.getuserNameMongo()+":"+Getvalue.getpassMongo()+"@"+Getvalue.gethost4Mongo()+":27017/?authSource="+Getvalue.getdb4ongo()+"&authMechanism=SCRAM-SHA-1");
	}

	public static MongoConnection getInstance() {
		if (mongoCon == null) {
			mongoCon = new MongoConnection();
		}
		return mongoCon;
	}

	 public static MongoClient getOpenCloseMongo(){
			System.out.println("OpnAndclos::::");	
			MongoClient mongoClient = null;			
			if(mongoClient!=null)mongoClient.close();
			MongoClientURI connectionString = new MongoClientURI("mongodb://"+Getvalue.getuserNameMongo()+":"+Getvalue.getpassMongo()+"@"+Getvalue.gethost4Mongo()+":27017/?authSource="+Getvalue.getdb4ongo()+"&authMechanism=SCRAM-SHA-1");
					
			mongoClient = new MongoClient(connectionString);
			
			System.out.println("mongoClient>>>>"+mongoClient.hashCode());
			return mongoClient;
			
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MongoConnection.getInstance().getOpenCloseMongo();
	}

*/
