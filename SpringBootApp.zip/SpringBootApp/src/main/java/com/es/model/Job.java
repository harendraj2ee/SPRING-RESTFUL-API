package com.es.model;

public class Job {
	
  private String jobid;
  private Long numFound;

public String getJobid() {
	return jobid;
}

public void setJobid(String jobid) {
	this.jobid = jobid;
}

public Long getNumFound() {
	return numFound;
}

public void setNumFound(Long numFound) {
	this.numFound = numFound;
}

}
