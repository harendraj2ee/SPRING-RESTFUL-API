package com.es.model;

import org.bson.types.Binary;

public class CanditateResume {
	
	
	private String filename="";
	
	//private int canId;
	private String objectid=""; 
	
	

	public String getObjectid() {
		return objectid;
	}

	public void setObjectid(String objectid) {
		this.objectid = objectid;
	}

	private String linkedin_html;
	
	private String resume;
	
	private Binary binaryData;
	
	private String resume_data ;


	public String getLinkedin_html() {
		return linkedin_html;
	}

	public void setLinkedin_html(String linkedin_html) {
		this.linkedin_html = linkedin_html;
	}

	public Binary getBinaryData() {
		return binaryData;
	}

	public void setBinaryData(Binary binaryData) {
		this.binaryData = binaryData;
	}

	public String getResume() {
		return resume;
	}

	public void setResume(String resume) {
		this.resume = resume;
	}

	public String getResume_data() {
		return resume_data;
	}

	public void setResume_data(String string) {
		this.resume_data = string;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

}
