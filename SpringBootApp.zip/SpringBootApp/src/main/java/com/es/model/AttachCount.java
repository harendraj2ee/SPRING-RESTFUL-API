package com.es.model;

import java.util.List;

public class AttachCount {
	
	private List<CandidateCount> candidate; 
		private Integer numFound=null;
		private String id="";
		private String objectId="";
		private String jobIdd="";
		private String drop="";
		private String dropComment="";
		private String lastModifiedBy="";
		private String createdDate="";
		private String anchor="";
		private String anchorId="";
		private String status="";
		
		
		
		
		//private String id = "";
		//private String objectId = "";
		//private String jobId:
		private String jobName = "";
		private String clientId = "";
		private String clientName = "";
		private String contactId = "";
		private String contactName ="";
		private String attachedBy = "";
		//private String lastModifiedBy = "";
		private String lastModified = "";
		//private String createdDate = "";
		//private String anchor = "";
		//private String anchorId = "";
		private String cvSentDate = "";
		private String statusChangeDate = "";
		private String statusOutcome = "";
		private String changeReason = "";
		private String clientPortalStatus = "";
		private String clientSheetStatus = "";
		private String paTestScore = "";
		private String testScore = "";
		private String avgScore = "";
		private Long pageUpId;
		private String ghStage = "";
		private String ghStatus = "";
		private Long ghStageId ;
		private Long ghStatusId;
		private Long stageId;
		private Long statusId;
		private String stage="";
		//private String status = "";
		//private String drop = "";
		//private String dropComment = "";
		private String comment = "";
		private Long withOutId;
		private String resumeName = "";
		//private String resume = "";
		private Long isClientSheet;
	
		
		public String getJobName() {
			return jobName;
		}
		public Long getPageUpId() {
			return pageUpId;
		}
		public void setPageUpId(Long pageUpId) {
			this.pageUpId = pageUpId;
		}
		public Long getGhStageId() {
			return ghStageId;
		}
		public void setGhStageId(Long ghStageId) {
			this.ghStageId = ghStageId;
		}
		public Long getGhStatusId() {
			return ghStatusId;
		}
		public void setGhStatusId(Long ghStatusId) {
			this.ghStatusId = ghStatusId;
		}
		public Long getStageId() {
			return stageId;
		}
		public void setStageId(Long stageId) {
			this.stageId = stageId;
		}
		public Long getStatusId() {
			return statusId;
		}
		public void setStatusId(Long statusId) {
			this.statusId = statusId;
		}
	
		public String getStage() {
			return stage;
		}
		public void setStage(String stage) {
			this.stage = stage;
		}
		public Long getWithOutId() {
			return withOutId;
		}
		public void setWithOutId(Long withOutId) {
			this.withOutId = withOutId;
		}
		public void setJobName(String jobName) {
			this.jobName = jobName;
		}
		public String getClientId() {
			return clientId;
		}
		public void setClientId(String clientId) {
			this.clientId = clientId;
		}
		public String getClientName() {
			return clientName;
		}
		public void setClientName(String clientName) {
			this.clientName = clientName;
		}
		public String getContactId() {
			return contactId;
		}
		public void setContactId(String contactId) {
			this.contactId = contactId;
		}
		public String getContactName() {
			return contactName;
		}
		public void setContactName(String contactName) {
			this.contactName = contactName;
		}
		public String getAttachedBy() {
			return attachedBy;
		}
		public void setAttachedBy(String attachedBy) {
			this.attachedBy = attachedBy;
		}
		public String getLastModified() {
			return lastModified;
		}
		public void setLastModified(String lastModified) {
			this.lastModified = lastModified;
		}
		public String getCvSentDate() {
			return cvSentDate;
		}
		public void setCvSentDate(String cvSentDate) {
			this.cvSentDate = cvSentDate;
		}
		public String getStatusChangeDate() {
			return statusChangeDate;
		}
		public void setStatusChangeDate(String statusChangeDate) {
			this.statusChangeDate = statusChangeDate;
		}
		public String getStatusOutcome() {
			return statusOutcome;
		}
		public void setStatusOutcome(String statusOutcome) {
			this.statusOutcome = statusOutcome;
		}
		public String getChangeReason() {
			return changeReason;
		}
		public void setChangeReason(String changeReason) {
			this.changeReason = changeReason;
		}
		public String getClientPortalStatus() {
			return clientPortalStatus;
		}
		public void setClientPortalStatus(String clientPortalStatus) {
			this.clientPortalStatus = clientPortalStatus;
		}
		public String getClientSheetStatus() {
			return clientSheetStatus;
		}
		public void setClientSheetStatus(String clientSheetStatus) {
			this.clientSheetStatus = clientSheetStatus;
		}
		public String getPaTestScore() {
			return paTestScore;
		}
		public void setPaTestScore(String paTestScore) {
			this.paTestScore = paTestScore;
		}
		public String getTestScore() {
			return testScore;
		}
		public void setTestScore(String testScore) {
			this.testScore = testScore;
		}
		public String getAvgScore() {
			return avgScore;
		}
		public void setAvgScore(String avgScore) {
			this.avgScore = avgScore;
		}
		
		public String getGhStage() {
			return ghStage;
		}
		public void setGhStage(String ghStage) {
			this.ghStage = ghStage;
		}
		public String getGhStatus() {
			return ghStatus;
		}
		public void setGhStatus(String ghStatus) {
			this.ghStatus = ghStatus;
		}
		
		
		public String getComment() {
			return comment;
		}
		public void setComment(String comment) {
			this.comment = comment;
		}
		
		public String getResumeName() {
			return resumeName;
		}
		public void setResumeName(String resumeName) {
			this.resumeName = resumeName;
		}
	
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getObjectId() {
			return objectId;
		}
		public void setObjectId(String objectId) {
			this.objectId = objectId;
		}
		public String getJobIdd() {
			return jobIdd;
		}
		public void setJobIdd(String jobIdd) {
			this.jobIdd = jobIdd;
		}
		public String getDrop() {
			return drop;
		}
		public void setDrop(String drop) {
			this.drop = drop;
		}
		public String getDropComment() {
			return dropComment;
		}
		public void setDropComment(String dropComment) {
			this.dropComment = dropComment;
		}
		public String getLastModifiedBy() {
			return lastModifiedBy;
		}
		public void setLastModifiedBy(String lastModifiedBy) {
			this.lastModifiedBy = lastModifiedBy;
		}
		public String getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}
		public String getAnchor() {
			return anchor;
		}
		public void setAnchor(String anchor) {
			this.anchor = anchor;
		}
		public String getAnchorId() {
			return anchorId;
		}
		public void setAnchorId(String anchorId) {
			this.anchorId = anchorId;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public List<CandidateCount> getCandidate() {
			return candidate;
		}
		public void setCandidate(List<CandidateCount> candidate) {
			this.candidate = candidate;
		}
		public Integer getNumFound() {
			return numFound;
		}
		public void setNumFound(Integer numFound) {
			this.numFound = numFound;
		}
		public Long getIsClientSheet() {
			return isClientSheet;
		}
		public void setIsClientSheet(Long isClientSheet) {
			this.isClientSheet = isClientSheet;
		}
		
		
		
		

}
