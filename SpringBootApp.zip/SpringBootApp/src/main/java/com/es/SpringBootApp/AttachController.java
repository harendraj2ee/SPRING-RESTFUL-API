package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
@RestController
//http://localhost:8080/ElasticAPI/objiddd?_id=5b6ea254dc38aa1f40cf086b
public class AttachController {
	@RequestMapping(value = "/ElasticAPI/objiddd", method = { RequestMethod.GET })
	public @ResponseBody String epCandidateObjectId(@RequestParam("_id") String _id
			) throws URISyntaxException, MalformedURLException {
		RestTemplate restTemplate=new RestTemplate();
		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(_id:(\""+_id+"\"))&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";
		System.out.println("ESAPI client uriCandidatedata >> " + urlCandidate);
		String jsonEsContactUrl = restTemplate.getForObject(urlCandidate, String.class);
		// System.out.println("jsonEsUrl Candidatedata >>> "+uriCandidatedata);
		return jsonEsContactUrl.toString();
	}
	

}
