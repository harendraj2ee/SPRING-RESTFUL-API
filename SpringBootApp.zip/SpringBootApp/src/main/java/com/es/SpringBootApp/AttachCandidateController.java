package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64.Encoder;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.model.Attach;
import com.es.model.Candidate;



@Controller
public class AttachCandidateController {
/*	@Autowired
	private RestTemplate restTemplate;*/
	private Long numFound;
	RestTemplate restTemplate = new RestTemplate();
	
//Solr API Start---------------------------------------------------------
	
	
	@RequestMapping(value = "/ElasticAttachAPI/attachid", method = { RequestMethod.GET })
	public @ResponseBody String esAttach(@RequestParam("jobid") String jobid, @RequestParam(value = "search", required = false) String field,
			@RequestParam("perpage") Integer perpage,@RequestParam("next") Integer next)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {
		
		 ArrayList<Attach> list = new ArrayList<Attach>();
		 list= attach(jobid,perpage,next,field);
		 org.json.JSONObject obj = new org.json.JSONObject();
		 org.json.JSONObject obj1 = new org.json.JSONObject();
		 org.json.JSONArray array = new org.json.JSONArray();
		  
		 array.put(list);
		 obj.put("attach", list);
		 obj.put("numFound", this.getNumFound());
		 obj1.put("response", obj);
		 
		 return obj1.toString();
		  
	}
	

        
 //Candidate       
  public static  ArrayList<Candidate> candidate(String objectId,Integer perpage,Integer start,String field) throws ParseException, UnsupportedEncodingException{
	  
	  //objectId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	  //int perPage=10;
	  //int start=0;
	  String name="";
	  String first_name="";
	  String last_name="";
	  String middle_name="";
	  String mobileNumber="";
	  String email="";
	 /* if(field.contains("@")){
		  field=field.replace("@", "%40");
		 // field=field.replace("(email:\"\"", "(email:"+ "\"");
		  field=field.replace("\"", "");

		  //field = URLEncoder.encode(field, "UTF-8");
		  System.out.println("Cand@"+field);
	  }*/
	  /*if(field.contains("name")) {
	      String fields="AND(name:";
		  field = field.replace(fields, "OR(name:");
		 
	  }*/
		// String anchorId="";
		 //String clientId = "";
		 //String contactId = "";
		 //Long stageId ;
		
		
	  
	  
	 if(field.contains("lastModifiedBy")||field.contains("createdDate") || field.contains("anchor") || field.contains("status") || field.contains("jobName") || field.contains("clientName") || field.contains("contactName") || field.contains("attachedBy") || field.contains("lastModified") || field.contains("cvSentDate") || field.contains("statusChangeDate") || field.contains("statusOutcome") || field.contains("changeReason") || field.contains("clientPortalStatus") || field.contains("clientSheetStatus") || field.contains("paTestScore") || field.contains("testScore") || field.contains("avgScore") || field.contains("pageUpId") || field.contains("ghStage") || field.contains("ghStatus") || field.contains("ghStageId") || field.contains("ghStatusId") || field.contains("statusId") || field.contains("stage") || field.contains("comment") || field.contains("withOutId") || field.contains("resumeName")){
		 String f1="AND(lastModifiedBy:";
		 String f2="AND(createdDate:";
		 String f3="AND(anchor:";
		 String f4="AND(status:";
		 String f5="AND(jobName:";
		 String f6="AND(clientName:";
		 String f7="AND(contactName:";
		 String f8="AND(attachedBy:";
		 String f9="AND(lastModified:";
		 String f10="AND(cvSentDate:";
		 String f11="AND(statusChangeDate:";
		 String f12="AND(statusOutcome:";
		 String f13="AND(changeReason:";
		 String f14="AND(clientPortalStatus:";
		 String f15="AND(clientSheetStatus:";
		 String f16="AND(paTestScore:";
		 String f17="AND(testScore:";
		 String f18="AND(avgScore:";
		 String f19="AND(pageUpId:";
		 String f20="AND(ghStage:";
		 String f21="AND(ghStatus:";
		 String f22="AND(ghStageId:";
		 String f23="AND(ghStatusId:";
		 String f24="AND(statusId:";
		 String f25="AND(stage:";
		 String f26="AND(comment:";
		 String f27="AND(withOutId:";
		 String f28="AND(resumeName:";
		 // String fields=f1+f2+f3;
		  
		  field = field.replace(f1, "OR(lastModifiedBy:");
		  field = field.replace(f2, "OR(createdDate:");
		  field = field.replace(f3, "OR(anchor:");
		  field = field.replace(f4, "OR(status:");
		  field = field.replace(f5, "OR(jobName:");
		  field = field.replace(f6, "OR(clientName:");
		  field = field.replace(f7, "OR(contactName:");
		  field = field.replace(f8, "OR(attachedBy:");
		  field = field.replace(f9, "OR(lastModified:");
		  field = field.replace(f10, "OR(cvSentDate:");
		  field = field.replace(f11, "OR(statusChangeDate:");
		  field = field.replace(f12, "OR(statusOutcome:");
		  field = field.replace(f13, "OR(changeReason:");
		  field = field.replace(f14, "OR(clientPortalStatus:");
		  field = field.replace(f15, "OR(clientSheetStatus:");
		  field = field.replace(f16, "OR(paTestScore:");
		  field = field.replace(f17, "OR(testScore:");
		  field = field.replace(f18, "OR(avgScore:");
		  field = field.replace(f19, "OR(pageUpId:");
		  field = field.replace(f20, "OR(ghStage:");
		  field = field.replace(f21, "OR(ghStatus:");
		  field = field.replace(f22, "OR(ghStageId:");
		  field = field.replace(f23, "OR(ghStatusId:");
		  field = field.replace(f24, "OR(statusId:");
		  field = field.replace(f25, "OR(stage:");
		  field = field.replace(f26, "OR(comment:");
		  field = field.replace(f27, "OR(withOutId:");
		  field = field.replace(f28, "OR(resumeName:");
		  field = "OR"+field;
		  field = field.replace("OROR(", "OR(");
		  System.out.println("candiif::::"+field);
		 }
	  
	  else  if(field.contains("name") ||field.contains("first_name") || field.contains("last_name")|| field.contains("middle_name")||field.contains("mobileNumber")||field.contains("email")){
		  field = "AND"+field;
		  
		  field = field.replace("ANDOR(", "AND(");
		 
		  
		  System.out.println("candielse::::"+field);
	  }else{
		  field="";
	  }
	  
	 if(field.contains("@")){
		  field=field.replaceAll("@", "%40");
		 // field=field.replace("(email:\"\"", "(email:"+ "\"");
		  field=field.replace("\"", "");

		  //field = URLEncoder.encode(field, "UTF-8");
		  System.out.println("Cand@"+field);
	  }
	  ArrayList<Candidate> list =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")"+field+"&size="+perpage+"&from="+start+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
	  System.out.println("urlCandidate >> " + urlCandidate);
	  JSONParser jsonParsercan  = new JSONParser();
	  String candidate = restTemplate.getForObject(urlCandidate, String.class);
	  JSONObject jsoncan= (JSONObject) ((JSONObject) jsonParsercan.parse(candidate)).get("hits");
			
	      //System.out.println("jsoncan::::"+jsoncan);
	        
	        JSONArray arraycan = (JSONArray) jsoncan.get("hits");
	        System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorcan = arraycan.iterator();
	        
	        while(itratorcan.hasNext()){
	        	Candidate e = new  Candidate();
	     	
	        JSONObject jsonObjectcan=(JSONObject) itratorcan.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectcan=  (JSONObject) jsonObjectcan.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);

	        
	        name=(String) jsonObjectcan.get("name");
	        e.setName(name);
	        System.out.println("candidate name::::"+name);
	        e.setName(name);
	        first_name=(String) jsonObjectcan.get("first_name");
	        e.setFirst_name(first_name);
	        last_name=(String) jsonObjectcan.get("last_name");
	        e.setLast_name(last_name);
	        middle_name=(String) jsonObjectcan.get("middle_name");
	        e.setMiddle_name(middle_name);
	        email=(String) jsonObjectcan.get("email");
	        e.setEmail(email);
	        mobileNumber=(String) jsonObjectcan.get("mobileNumber");
	        e.setMobileNumber(mobileNumber);
	      
	        list.add(e);
		
	}  
	        return list;
  }     
        

 //Attach
 public  ArrayList<Attach> attach(String jobId,Integer perpage,Integer next,String field) throws ParseException, UnsupportedEncodingException{
	  System.out.println("hello!!!");
	  //jobId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	 // int perPage=10;
	  //int start=0;
	 
		 Integer numFound=null;
		 String id="";
		 String objectId="";
		 String jobIdd="";
		 String drop="";
		 String dropComment="";
		 String lastModifiedBy="";
		 String createdDate="";
		 String anchor="";
		 String anchorId="";
		 String status="";
		 String jobName = "";
		 String clientId = "";
		 String clientName = "";
		 String contactId = "";
		 String contactName ="";
		 String attachedBy = "";
		 String lastModified = "";
		 String cvSentDate = "";
		 String statusChangeDate = "";
		 String statusOutcome = "";
		 String changeReason = "";
		 String clientPortalStatus = "";
		 String clientSheetStatus = "";
		 String paTestScore = "";
		 String testScore = "";
		 String avgScore = "";
		 Long pageUpId;
		 String ghStage = "";
		 String ghStatus = "";
		 Long ghStageId;
		 Long ghStatusId ;
		 Long stageId ;
		 Long statusId;
		 String stage ="";
		 String comment = "";
		 Long withOutId;
		 String resumeName= "";
		/* if(field.contains("@")){
			  field=field.replace("@", "%40");
			  //field=field.replace("email:\"\"", "email:");
			  field=field.replace("\"", "");

			  System.out.println("@@@atach"+field);
		  }*/
	    
	  ArrayList<Attach> list =  new ArrayList<Attach>();
	  ArrayList<Candidate> canlist =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  
	  int start = perpage*(next);

		if (field != null) {

			field = field.trim();
			/* field= field.replace(":","%3A"); */

			if (field.contains(",")) {
				String[] split = field.split(",");

				//System.out.println(Arrays.asList(split));

				List<String> list2 = Arrays.asList(split);
				String res = String.join(",", list2).replaceAll("[:]+", ":\"").replaceAll("([,]+)", "\")AND(");
				res = "(" + res + "\")";

				field = res;

				//System.out.println();

			} else {

				String ress = String.join(",", field).replaceAll("[:]+", ":\"").replaceAll("([,]+)", "\")AND(");
				ress = "(" + ress + "\")";
				field = ress;

			}

			//System.out.println();
			System.out.println("Field......." + field);
		}
	  
		String afield=field;
		String cfield=field;
		
		
		//if(!field.contains("name") ||!field.contains("first_name") || !field.contains("last_name")|| !field.contains("middle_name")||!field.contains("mobileNumber")||!field.contains("email")){
		
		/*if(field.contains("name")) {
		      String fields="AND(name:";
			  field = field.replace(fields, "OR(name:");
			 
		  }
		else if(field.contains("lastModified")||field.contains("status") || field.contains("contactName")){
			  field = "AND"+field;
			  System.out.println("field:::"+field);
		    }*/
		

		if (field.contains("name") ||field.contains("first_name") || field.contains("last_name")|| field.contains("middle_name")||field.contains("mobileNumber")||field.contains("email")){
			 String f1="AND(name:";
			 String f2="AND(first_name:";
			 String f3="AND(last_name:";
			 String f4="AND(middle_name:";
			 String f5="AND(mobileNumber:";
			 String f6="AND(email:";
			 
			  field = field.replace(f1, "OR(name:");
			  field = field.replace(f2, "OR(first_name:");
			  field = field.replace(f3, "OR(last_name:");
			  field = field.replace(f4, "OR(middle_name:");
			  field = field.replace(f5, "OR(mobileNumber:");
			  field = field.replace(f6, "OR(email:");
			  field = "OR"+field;
		}
		
		else if(field.contains("lastModifiedBy")||field.contains("createdDate") || field.contains("anchor") || field.contains("status") || field.contains("jobName") || field.contains("clientName") || field.contains("contactName") || field.contains("attachedBy") || field.contains("lastModified") || field.contains("cvSentDate") || field.contains("statusChangeDate") || field.contains("statusOutcome") || field.contains("changeReason") || field.contains("clientPortalStatus") || field.contains("clientSheetStatus") || field.contains("paTestScore") || field.contains("testScore") || field.contains("avgScore") || field.contains("pageUpId") || field.contains("ghStage") || field.contains("ghStatus") || field.contains("ghStageId") || field.contains("ghStatusId") || field.contains("statusId") || field.contains("stage") || field.contains("comment") || field.contains("withOutId") || field.contains("resumeName")){
			field = "AND"+field;
			
			field = field.replace("ORAND(", "AND(");
			
		}else {
			 field="";
		}
			
					
		 if(field.contains("@")){
			  field=field.replace("@", "%40");
			 // field=field.replace("(email:\"\"", "(email:"+ "\"");
			  field=field.replaceAll("\"", "");

			  //field = URLEncoder.encode(field, "UTF-8");
			  System.out.println("Cand@"+field);
		  }
		
	  String  urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")"+field+"&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume

	  System.out.println("urlAttach >> " + urlAttach);
	  JSONParser jsonParsercan  = new JSONParser();
	  String attach = restTemplate.getForObject(urlAttach, String.class);
	  JSONObject jsoncan= (JSONObject) ((JSONObject) jsonParsercan.parse(attach)).get("hits");
			
	        System.out.println("total:::::::"+jsoncan.get("total"));
	        Long total=  (Long) jsoncan.get("total");
	        this.setNumFound(total);
	        
	        //JSONObject total = new JSONObject();
	        //total.put("", jsoncan.get("total"));
	        JSONArray arraycan = (JSONArray) jsoncan.get("hits");
	        System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorcan = arraycan.iterator();
	       
	        while(itratorcan.hasNext()){
	        	Attach e = new  Attach();
	    
	        JSONObject jsonObjectcan=(JSONObject) itratorcan.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectcan=  (JSONObject) jsonObjectcan.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
		   
	        id= (String) jsonObjectcan.get("id");
	        e.setId(id);
	        //jsonobj.put("id", id);
			System.out.println("id value::::________"+id);
			objectId=(String) jsonObjectcan.get("objectId");
		
			canlist=candidate(objectId,perpage,next,field);
			e.setCandidate(canlist);
			
			e.setObjectId(objectId);
			System.out.println("objectId::::"+objectId);
			
		
			
			jobIdd=(String) jsonObjectcan.get("jobId");
			e.setJobIdd(jobIdd);
			drop=(String) jsonObjectcan.get("drop");
			e.setDrop(drop);
			dropComment=(String) jsonObjectcan.get("dropComment");
			e.setDropComment(dropComment);
			lastModifiedBy=(String) jsonObjectcan.get("lastModifiedBy");
			e.setLastModifiedBy(lastModifiedBy);
			createdDate=(String) jsonObjectcan.get("createdDate");
			e.setCreatedDate(createdDate);
			anchor=(String) jsonObjectcan.get("anchor");
			e.setAnchor(anchor);
			
			anchorId=(String) jsonObjectcan.get("anchorId");
			e.setAnchor(anchorId);
			e.setAnchorId(anchorId);
			status=(String) jsonObjectcan.get("status");
			e.setStatus(status);
	       
			jobName=(String) jsonObjectcan.get("jobName");
			e.setJobName(jobName);
			clientId=(String) jsonObjectcan.get("clientId");
			e.setClientId(clientId);
			clientName=(String) jsonObjectcan.get("clientName");
			e.setClientName(clientName);
			contactId=(String) jsonObjectcan.get("contactId");
			e.setContactId(contactId);
			contactName=(String) jsonObjectcan.get("contactName");
			e.setContactName(contactName);
			attachedBy=(String) jsonObjectcan.get("attachedBy");
			e.setAttachedBy(attachedBy);
			lastModified=(String) jsonObjectcan.get("lastModified");
			e.setLastModified(lastModified);
			cvSentDate=(String) jsonObjectcan.get("cvSentDate");
			e.setCvSentDate(cvSentDate);
			statusChangeDate=(String) jsonObjectcan.get("statusChangeDate");
			e.setStatusChangeDate(statusChangeDate);
			statusOutcome=(String) jsonObjectcan.get("statusOutcome");
			e.setStatusOutcome(statusOutcome);
			changeReason=(String) jsonObjectcan.get("changeReason");
			e.setChangeReason(changeReason);
			clientPortalStatus=(String) jsonObjectcan.get("clientPortalStatus");
			e.setClientPortalStatus(clientPortalStatus);
			clientSheetStatus=(String) jsonObjectcan.get("clientSheetStatus");
			e.setClientSheetStatus(clientSheetStatus);
			paTestScore=(String) jsonObjectcan.get("paTestScore");
			e.setPaTestScore(paTestScore);
			testScore=(String) jsonObjectcan.get("testScore");
			e.setTestScore(testScore);
			avgScore=(String) jsonObjectcan.get("avgScore");
			e.setAvgScore(avgScore);
			pageUpId=(Long) jsonObjectcan.get("pageUpId");
			e.setPageUpId(pageUpId);
			ghStage=(String) jsonObjectcan.get("ghStage");
			e.setGhStage(ghStage);
			ghStatus=(String) jsonObjectcan.get("ghStatus");
			e.setGhStatus(ghStatus);
			ghStageId=(Long) jsonObjectcan.get("ghStageId");
			e.setGhStageId(ghStageId);
			ghStatusId=(Long) jsonObjectcan.get("ghStatusId");
			e.setGhStatusId(ghStatusId);
			stageId=(Long) jsonObjectcan.get("stageId");
			e.setStageId(stageId);
			statusId=(Long) jsonObjectcan.get("statusId");
			e.setStatusId(statusId);
			
			stage=(String) jsonObjectcan.get("stage");
			e.setStage(stage);
			comment=(String) jsonObjectcan.get("comment");
			e.setComment(comment);
			withOutId=(Long) jsonObjectcan.get("withOutId");
			e.setWithOutId(withOutId);
			resumeName=(String) jsonObjectcan.get("resumeName");
			e.setResumeName(resumeName);

			
			
			
	        list.add(e);
		
	}  
	        return list;
  }

	
	
/*	@RequestMapping(value = "/ElasticAttachAPI/attachid", method = { RequestMethod.GET })
	public @ResponseBody String esAttach(@RequestParam("jobid") String jobid, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException {
		
		 ArrayList<Attach> list = new ArrayList<Attach>();
		 list= attach(jobid,perpage,next);
		 org.json.JSONObject obj = new org.json.JSONObject();
		 org.json.JSONObject obj1 = new org.json.JSONObject();
		 
		 
		 org.json.JSONArray array = new org.json.JSONArray();
		 array.put(list);
		 obj.put("attach", list);
		 obj.put("numFound", this.getNumFound());

		 obj1.put("response", obj);
		 System.out.println("obj1 >> "+obj1);
		 return obj1.toString();
		  
	}
	
	
	
 //Candidate       
  public static  ArrayList<Candidate> candidate(String objectId,Integer perpage,Integer start) throws ParseException{
	  
	  //objectId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	  //int perPage=10;
	  //int start=0;
	  ArrayList<Candidate> list =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
	  //System.out.println("urlCandidate >> " + urlCandidate);
	  JSONParser jsonParsercan  = new JSONParser();
	  String candidate = restTemplate.getForObject(urlCandidate, String.class);
	  JSONObject jsoncan= (JSONObject) ((JSONObject) jsonParsercan.parse(candidate)).get("hits");
			
	     // System.out.println("jsoncan::::"+jsoncan);
	        
	        JSONArray arraycan = (JSONArray) jsoncan.get("hits");
	       // System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorcan = arraycan.iterator();
	        
	        while(itratorcan.hasNext()){
	        	Candidate e = new  Candidate();
	       // e.setNumFound(arraycan.size());	
	        
	        JSONObject jsonObjectcan=(JSONObject) itratorcan.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectcan=  (JSONObject) jsonObjectcan.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
		    String name=(String) jsonObjectcan.get("name");
	        e.setName(name);
	        //System.out.println("candidate name::::"+name);
	        e.setName(name);
	        String first_name=(String) jsonObjectcan.get("first_name");
	        e.setFirst_name(first_name);
	        String last_name=(String) jsonObjectcan.get("last_name");
	        e.setLast_name(last_name);
	        String  middle_name=(String) jsonObjectcan.get("middle_name");
	        e.setMiddle_name(middle_name);
	        String  email=(String) jsonObjectcan.get("email");
	        e.setEmail(email);
	        String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
	        e.setMobileNumber(mobileNumber);
	      
	        list.add(e);
		
	}  
	        return list;
  }     
        
  
  
  
  
  
 //Attach
 //public static ArrayList<Attach> attach(String jobId,Integer perpage,Integer next) throws ParseException{
  public  ArrayList<Attach> attach(String jobId,Integer perpage,Integer next) throws ParseException{
	  //System.out.println("hello!!!");
	  //jobId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	 // int perPage=10;
	  //int start=0;
	  Integer numFound=null;
		 String id="";
		 String objectId="";
		 String jobIdd="";
		 String drop="";
		 String dropComment="";
		 String lastModifiedBy="";
		 String createdDate="";
		 String anchor="";
		 String anchorId="";
		 String status="";
				
		 String jobName = "";
		 String clientId = "";
		 String clientName = "";
		 String contactId = "";
		 String contactName ="";
		 String attachedBy = "";
		 String lastModified = "";
		 String cvSentDate = "";
		 String statusChangeDate = "";
		 String statusOutcome = "";
		 String changeReason = "";
		 String clientPortalStatus = "";
		 String clientSheetStatus = "";
		 String paTestScore = "";
		 String testScore = "";
		 String avgScore = "";
		 Long pageUpId;
		 String ghStage = "";
		 String ghStatus = "";
		 Long ghStageId;
		 Long ghStatusId ;
		 Long stageId ;
		 Long statusId;
		 String stage="" ;
		 String comment = "";
		 Long withOutId;
		 String resumeName= "";
		 Long isClientSheet;
	  
	  
	  ArrayList<Attach> list =  new ArrayList<Attach>();
	  ArrayList<Candidate> canlist =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  
	  int start = perpage*(next);
	  String  urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume

	 // System.out.println("urlCandidate >> " + urlAttach);
	  JSONParser jsonParsercan  = new JSONParser();
	  String attach = restTemplate.getForObject(urlAttach, String.class);
	  JSONObject jsoncan= (JSONObject) ((JSONObject) jsonParsercan.parse(attach)).get("hits");
			
	        //System.out.println("total:::::::"+jsoncan.get("total"));
	       // JSONObject total = new JSONObject();
	      //  total.put("", jsoncan.get("total"));
	        Long total=  (Long) jsoncan.get("total");
	        this.setNumFound(total);
	        
	        JSONArray arraycan = (JSONArray) jsoncan.get("hits");
	        //System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorcan = arraycan.iterator();
	        
	        while(itratorcan.hasNext()){
	        	Attach e = new  Attach();
	       // e.setNumFound(arraycan.size());	
	        	
	        JSONObject jsonObjectcan=(JSONObject) itratorcan.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectcan=  (JSONObject) jsonObjectcan.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
		   
	        id= (String) jsonObjectcan.get("id");
	        e.setId(id);
	        //jsonobj.put("id", id);
			//System.out.println("id value::::________"+id);
			objectId=(String) jsonObjectcan.get("objectId");
		
			canlist=candidate(objectId,perpage,next);
			e.setCandidate(canlist);
			
			e.setObjectId(objectId);
			System.out.println("objectId::::"+objectId);
			
		
			
			//jsonobj.put("objectId", objectId);
			jobIdd=(String) jsonObjectcan.get("jobId");
			e.setJobIdd(jobIdd);
			//jsonobj.put("jobId", jobId);
			drop=(String) jsonObjectcan.get("drop");
			//jsonobj.put("drop", drop);
			e.setDrop(drop);
			dropComment=(String) jsonObjectcan.get("dropComment");
			//jsonobj.put("dropComment", dropComment);
			e.setDropComment(dropComment);
			lastModifiedBy=(String) jsonObjectcan.get("lastModifiedBy");
			//jsonobj.put("lastModifiedBy", lastModifiedBy);
			e.setLastModifiedBy(lastModifiedBy);
			createdDate=(String) jsonObjectcan.get("createdDate");
			//jsonobj.put("createdDate", createdDate);
			e.setCreatedDate(createdDate);
			anchor=(String) jsonObjectcan.get("anchor");
			//jsonobj.put("anchor", anchor);
			e.setAnchor(anchor);
			
			anchorId=(String) jsonObjectcan.get("anchorId");
			e.setAnchor(anchorId);
			//jsonobj.put("anchorId", anchorId);
			e.setAnchorId(anchorId);
			status=(String) jsonObjectcan.get("status");
			//jsonobj.put("status", status);
			e.setStatus(status);
	       
			jobName=(String) jsonObjectcan.get("jobName");
			e.setJobName(jobName);
			clientId=(String) jsonObjectcan.get("clientId");
			e.setClientId(clientId);
			clientName=(String) jsonObjectcan.get("clientName");
			e.setClientName(clientName);
			contactId=(String) jsonObjectcan.get("contactId");
			e.setContactId(contactId);
			contactName=(String) jsonObjectcan.get("contactName");
			e.setContactName(contactName);
			attachedBy=(String) jsonObjectcan.get("attachedBy");
			e.setAttachedBy(attachedBy);
			lastModified=(String) jsonObjectcan.get("lastModified");
			e.setLastModified(lastModified);
			cvSentDate=(String) jsonObjectcan.get("cvSentDate");
			e.setCvSentDate(cvSentDate);
			statusChangeDate=(String) jsonObjectcan.get("statusChangeDate");
			e.setStatusChangeDate(statusChangeDate);
			statusOutcome=(String) jsonObjectcan.get("statusOutcome");
			e.setStatusOutcome(statusOutcome);
			changeReason=(String) jsonObjectcan.get("changeReason");
			e.setChangeReason(changeReason);
			clientPortalStatus=(String) jsonObjectcan.get("clientPortalStatus");
			e.setClientPortalStatus(clientPortalStatus);
			clientSheetStatus=(String) jsonObjectcan.get("clientSheetStatus");
			e.setClientSheetStatus(clientSheetStatus);
			paTestScore=(String) jsonObjectcan.get("paTestScore");
			e.setPaTestScore(paTestScore);
			testScore=(String) jsonObjectcan.get("testScore");
			e.setTestScore(testScore);
			avgScore=(String) jsonObjectcan.get("avgScore");
			e.setAvgScore(avgScore);
			pageUpId=(Long) jsonObjectcan.get("pageUpId");
			e.setPageUpId(pageUpId);
			ghStage=(String) jsonObjectcan.get("ghStage");
			e.setGhStage(ghStage);
			ghStatus=(String) jsonObjectcan.get("ghStatus");
			e.setGhStatus(ghStatus);
			ghStageId=(Long) jsonObjectcan.get("ghStageId");
			e.setGhStageId(ghStageId);
			ghStatusId=(Long) jsonObjectcan.get("ghStatusId");
			e.setGhStatusId(ghStatusId);
			stageId=(Long) jsonObjectcan.get("stageId");
			e.setStageId(stageId);
			statusId=(Long) jsonObjectcan.get("statusId");
			e.setStatusId(statusId);
			
			stage=(String) jsonObjectcan.get("stage");
			e.setStage(stage);
			comment=(String) jsonObjectcan.get("comment");
			e.setComment(comment);
			withOutId=(Long) jsonObjectcan.get("withOutId");
			e.setWithOutId(withOutId);
			resumeName=(String) jsonObjectcan.get("resumeName");
			e.setResumeName(resumeName);
			
			isClientSheet = (Long) jsonObjectcan.get("isClientSheet");
			e.setIsClientSheet(isClientSheet);

			
			
	        list.add(e);
		
	}  
	        return list;
  }
*/


public Long getNumFound() {
	return numFound;
}

public void setNumFound(Long numFound) {
	this.numFound = numFound;
} 
 
}
  
  
  
