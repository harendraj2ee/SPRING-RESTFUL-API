package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.model.Attach;
import com.es.model.Candidate;



@Controller
public class AttachCandidateListController {
/*	@Autowired
	private RestTemplate restTemplate;*/
	private Long numFound;
	RestTemplate restTemplate = new RestTemplate();
	
//Solr API Start---------------------------------------------------------

	@RequestMapping(value = "/ElasticAttachAPI/attachid", method = { RequestMethod.GET })
	public @ResponseBody String esAttach(@RequestParam("jobid") String jobid, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next)
			throws MalformedURLException, URISyntaxException, ParseException, JSONException {
		
		 ArrayList<Attach> list = new ArrayList<Attach>();
		 list= attach(jobid,perpage,next);
		 org.json.JSONObject obj = new org.json.JSONObject();
		 org.json.JSONObject obj1 = new org.json.JSONObject();
		 
		 
		 org.json.JSONArray array = new org.json.JSONArray();
		 array.put(list);
		 obj.put("attach", list);
		 obj.put("numFound", this.getNumFound());

		 obj1.put("response", obj);
		 System.out.println("obj1 >> "+obj1);
		 return obj1.toString();
		  
	}
	
	
	
 //Candidate       
  public static  ArrayList<Candidate> candidate(String objectId,Integer perpage,Integer start) throws ParseException{
	  
	  //objectId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	  //int perPage=10;
	  //int start=0;
	  ArrayList<Candidate> list =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
	  //System.out.println("urlCandidate >> " + urlCandidate);
	  JSONParser jsonParsercan  = new JSONParser();
	  String candidate = restTemplate.getForObject(urlCandidate, String.class);
	  JSONObject jsoncan= ( JSONObject) ((JSONObject) jsonParsercan.parse(candidate)).get("hits");
			
	     // System.out.println("jsoncan::::"+jsoncan);
	        
	  JSONArray arraycan = (JSONArray) jsoncan.get("hits");
	       // System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorcan = arraycan.iterator();
	        
	        while(itratorcan.hasNext()){
	        	Candidate e = new  Candidate();
	       // e.setNumFound(arraycan.size());	
	        
	        JSONObject jsonObjectcan=(JSONObject) itratorcan.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectcan=  (JSONObject) jsonObjectcan.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
	        if (jsonObjectcan.get("name")!=null ) {
	        	String name=(String) jsonObjectcan.get("name");
	 	        e.setName(name);
			}else {
	        	String name=(String) jsonObjectcan.get("name");
			}
		   if (jsonObjectcan.get("first_name")!=null) {
			   String first_name=(String) jsonObjectcan.get("first_name");
		        e.setFirst_name(first_name);
		}else {
			   String first_name=(String) jsonObjectcan.get("first_name");
		}
		   if (jsonObjectcan.get("middle_name")!=null) {
			   String  middle_name=(String) jsonObjectcan.get("middle_name");
		       e.setMiddle_name(middle_name);
		}else {
			   String  middle_name=(String) jsonObjectcan.get("middle_name");
		}
		   if (jsonObjectcan.get("last_name")!=null) {
			   String last_name=(String) jsonObjectcan.get("last_name");
		       e.setLast_name(last_name);
		}else {
			   String last_name=(String) jsonObjectcan.get("last_name");
		}
	      if (jsonObjectcan.get("email")!=null) {
	    	  String  email=(String) jsonObjectcan.get("email");
		       e.setEmail(email);
		}else {
    	  	String  email=(String) jsonObjectcan.get("email");
		}  
	     if (jsonObjectcan.get("mobileNumber")!=null) {
	    	 String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
		     e.setMobileNumber(mobileNumber);
		}else {
	    	 String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
		}
	        list.add(e);
		
	}  
	        return list;
  }     
        
  
  
  
  
  
 //Attach
 //public static ArrayList<Attach> attach(String jobId,Integer perpage,Integer next) throws ParseException{
  public  ArrayList<Attach> attach(String jobId,Integer perpage,Integer next) throws ParseException{
	  //System.out.println("hello!!!");
	  //jobId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
	 // int perPage=10;
	  //int start=0;
		 Integer numFound=null;
		 String id="";
		 String objectId="";
		 String jobIdd="";
		 String drop="";
		 String dropComment="";
		 String lastModifiedBy="";
		 String createdDate="";
		 String anchor="";
		 String anchorId="";
		 String status="";
				
		 String jobName = "";
		 String clientId = "";
		 String clientName = "";
		 String contactId = "";
		 String contactName ="";
		 String attachedBy = "";
		 String lastModified = "";
		 String cvSentDate = "";
		 String statusChangeDate = "";
		 String statusOutcome = "";
		 String changeReason = "";
		 String clientPortalStatus = "";
		 String clientSheetStatus = "";
		 String paTestScore = "";
		 String testScore = "";
		 String avgScore = "";
		 Long pageUpId = null;
		 String ghStage = "";
		 String ghStatus = "";
		 Long ghStageId = null;
		 Long ghStatusId  = null;
		 Long stageId = null;
		 Long statusId = null;
		 String stage = "";
		 String comment = "";
		 Long withOutId = null;
		 String resumeName= "";
		
	  
	  
	  
	  ArrayList<Attach> list =  new ArrayList<Attach>();
	  ArrayList<Candidate> canlist =  new ArrayList<Candidate>();
	  RestTemplate restTemplate=new RestTemplate();
	  
	  int start = perpage*(next);
	  String  urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume

	 // System.out.println("urlCandidate >> " + urlAttach);
	  JSONParser jsonParserAttach  = new JSONParser();
	  String attach = restTemplate.getForObject(urlAttach, String.class);
	  JSONObject jsonAttach= (JSONObject) ((JSONObject) jsonParserAttach.parse(attach)).get("hits");
			
	        //System.out.println("total:::::::"+jsoncan.get("total"));
	       // JSONObject total = new JSONObject();
	      //  total.put("", jsoncan.get("total"));
	        Long total=  (Long) jsonAttach.get("total");
	        this.setNumFound(total);
	        
	        JSONArray arrayAtach = (JSONArray) jsonAttach.get("hits");
	        //System.out.println("jsoncanlength::::"+arraycan.size());
	        Iterator itratorAttach = arrayAtach.iterator();
	        
	        while(itratorAttach.hasNext()){
	        	Attach e = new  Attach();
	       // e.setNumFound(arraycan.size());	
	        	
	        JSONObject jsonObjectAttach=(JSONObject) itratorAttach.next();
	        //System.out.println("jsonObject::::"+jsonObject);
	        jsonObjectAttach=  (JSONObject) jsonObjectAttach.get("_source");
	        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
			
	      
			
	        id= (String) jsonObjectAttach.get("id");
	        e.setId(id);
			
	        objectId=(String) jsonObjectAttach.get("objectId");
			e.setObjectId(objectId);
			
			jobIdd=(String) jsonObjectAttach.get("jobId");
			e.setJobIdd(jobIdd);
			
			canlist=candidate(objectId,perpage,next);
			e.setCandidate(canlist);
			
			if (jsonObjectAttach.get("drop")!=null) {
				drop=(String) jsonObjectAttach.get("drop");
				e.setDrop(drop);
			}else {
				drop=(String) jsonObjectAttach.get("drop");
			}
			if (jsonObjectAttach.get("dropComment")!=null) {
				dropComment=(String) jsonObjectAttach.get("dropComment");
				e.setDropComment(dropComment);
			}else {
				dropComment=(String) jsonObjectAttach.get("dropComment");
			}
			if (jsonObjectAttach.get("lastModifiedBy")!=null) {
				lastModifiedBy=(String) jsonObjectAttach.get("lastModifiedBy");
				e.setLastModifiedBy(lastModifiedBy);
			}else {
				lastModifiedBy=(String) jsonObjectAttach.get("lastModifiedBy");
			}
			if (jsonObjectAttach.get("createdDate")!=null) {
				createdDate=(String) jsonObjectAttach.get("createdDate");
				e.setCreatedDate(createdDate);
			}else {
				createdDate=(String) jsonObjectAttach.get("createdDate");
			}
			if (jsonObjectAttach.get("anchor")!=null) {
				anchor=(String) jsonObjectAttach.get("anchor");
				e.setAnchor(anchor);
			}else {
				anchor=(String) jsonObjectAttach.get("anchor");
			}
			if (jsonObjectAttach.get("anchorId")!=null) {
				anchorId=(String) jsonObjectAttach.get("anchorId");
				e.setAnchorId(anchorId);
			}else {
				anchorId=(String) jsonObjectAttach.get("anchorId");
			}
			if (jsonObjectAttach.get("status")!=null) {
				status=(String) jsonObjectAttach.get("status");
				e.setStatus(status);
			}else {
				status=(String) jsonObjectAttach.get("status");
			}
			if (jsonObjectAttach.get("jobName")!=null) {
				jobName=(String) jsonObjectAttach.get("jobName");
				e.setJobName(jobName);
			}else {
				jobName=(String) jsonObjectAttach.get("jobName");
			}
			if (jsonObjectAttach.get("clientId")!=null) {
				clientId=(String) jsonObjectAttach.get("clientId");
				e.setClientId(clientId);
			}else {
				clientId=(String) jsonObjectAttach.get("clientId");
			}
			if (jsonObjectAttach.get("clientName")!=null) {
				clientName=(String) jsonObjectAttach.get("clientName");
				e.setClientName(clientName);
			}else {
				clientName=(String) jsonObjectAttach.get("clientName");
			}
			if (jsonObjectAttach.get("contactId")!=null) {
				contactId=(String) jsonObjectAttach.get("contactId");
				e.setContactId(contactId);
			}else {
				contactId=(String) jsonObjectAttach.get("contactId");
			}
	       if (jsonObjectAttach.get("contactName")!=null) {
	   		   contactName=(String) jsonObjectAttach.get("contactName");
			   e.setContactName(contactName);
	       }else {
	    	   contactName=(String) jsonObjectAttach.get("contactName");
	       }
			if (jsonObjectAttach.get("attachedBy")!=null) {
				attachedBy=(String) jsonObjectAttach.get("attachedBy");
				e.setAttachedBy(attachedBy);
			}else {
				attachedBy=(String) jsonObjectAttach.get("attachedBy");
			}
			if (jsonObjectAttach.get("lastModified")!=null) {
				lastModified=(String) jsonObjectAttach.get("lastModified");
				e.setLastModified(lastModified);
			}else {
				lastModified=(String) jsonObjectAttach.get("lastModified");
			}
			if (jsonObjectAttach.get("cvSentDate")!=null) {
				cvSentDate=(String) jsonObjectAttach.get("cvSentDate");
				e.setCvSentDate(cvSentDate);
			}else {
				cvSentDate=(String) jsonObjectAttach.get("cvSentDate");
			}
			if (jsonObjectAttach.get("statusChangeDate")!=null) {
				statusChangeDate=(String) jsonObjectAttach.get("statusChangeDate");
				e.setStatusChangeDate(statusChangeDate);
			}else {
				statusChangeDate=(String) jsonObjectAttach.get("statusChangeDate");
			}
			if (jsonObjectAttach.get("statusOutcome")!=null) {
				statusOutcome=(String) jsonObjectAttach.get("statusOutcome");
				e.setStatusOutcome(statusOutcome);
			}else {
				statusOutcome=(String) jsonObjectAttach.get("statusOutcome");
			}
			if (jsonObjectAttach.get("changeReason")!=null) {
				changeReason=(String) jsonObjectAttach.get("changeReason");
				e.setChangeReason(changeReason);
			}else {
				changeReason=(String) jsonObjectAttach.get("changeReason");
			}
			if (jsonObjectAttach.get("clientPortalStatus")!=null) {
				clientPortalStatus=(String) jsonObjectAttach.get("clientPortalStatus");
				e.setClientPortalStatus(clientPortalStatus);
			}else {
				clientPortalStatus=(String) jsonObjectAttach.get("clientPortalStatus");
			}
			if (jsonObjectAttach.get("paTestScore")!=null) {
				paTestScore=(String) jsonObjectAttach.get("paTestScore");
				e.setPaTestScore(paTestScore);
			}else {
				paTestScore=(String) jsonObjectAttach.get("paTestScore");
			}
			if (jsonObjectAttach.get("testScore")!=null) {
				testScore=(String) jsonObjectAttach.get("testScore");
				e.setTestScore(testScore);
			}else {
				testScore=(String) jsonObjectAttach.get("testScore");
			}
			if (jsonObjectAttach.get("avgScore")!=null) {
				avgScore=(String) jsonObjectAttach.get("avgScore");
				e.setAvgScore(avgScore);
			}else {
				avgScore=(String) jsonObjectAttach.get("avgScore");
			}
			if (jsonObjectAttach.get("pageUpId")!=null) {
				pageUpId=(Long) jsonObjectAttach.get("pageUpId");
				e.setPageUpId(pageUpId);
			}else {
				pageUpId=(Long) jsonObjectAttach.get("pageUpId");
			}
			if (jsonObjectAttach.get("ghStage")!=null) {
				ghStage=(String) jsonObjectAttach.get("ghStage");
				e.setGhStatus(ghStage);
			}else {
				ghStage=(String) jsonObjectAttach.get("ghStage");
			}
			if (jsonObjectAttach.get("ghStatus")!=null) {
				ghStatus=(String) jsonObjectAttach.get("ghStatus");
				e.setGhStatus(ghStatus);
			}else {
				ghStatus=(String) jsonObjectAttach.get("ghStatus");
			}
			if (jsonObjectAttach.get("ghStageId")!=null) {
				ghStageId=(Long) jsonObjectAttach.get("ghStageId");
				e.setGhStageId(ghStageId);
			}else {
				ghStageId=(Long) jsonObjectAttach.get("ghStageId");
			}
			if (jsonObjectAttach.get("ghStatusId")!=null) {
				ghStatusId=(Long) jsonObjectAttach.get("ghStatusId");
				e.setGhStatusId(ghStatusId);
			}else {
				ghStatusId=(Long) jsonObjectAttach.get("ghStatusId");
			}
			if (jsonObjectAttach.get("stageId")!=null) {
				stageId=(Long) jsonObjectAttach.get("stageId");
				e.setStageId(stageId);
			}else {
				stageId=(Long) jsonObjectAttach.get("stageId");
			}
			if (jsonObjectAttach.get("statusId")!=null) {
				statusId=(Long) jsonObjectAttach.get("statusId");
				e.setStatusId(statusId);
			}else {
				statusId=(Long) jsonObjectAttach.get("statusId");
			}
			if (jsonObjectAttach.get("stage")!=null) {
				stage=(String) jsonObjectAttach.get("stage");
				e.setStage(stage);
			}else {
				stage=(String) jsonObjectAttach.get("stage");
			}
			if (jsonObjectAttach.get("comment")!=null) {
				comment=(String) jsonObjectAttach.get("comment");
				e.setComment(comment);
			}else {
				jsonObjectAttach.get("comment");
			}
			if (jsonObjectAttach.get("withOutId")!=null) {
				withOutId=(Long) jsonObjectAttach.get("withOutId");
				e.setWithOutId(withOutId);
			}else {
				withOutId=(Long) jsonObjectAttach.get("withOutId");
			}
			if (jsonObjectAttach.get("resumeName")!=null) {
				resumeName=(String) jsonObjectAttach.get("resumeName");
				e.setResumeName(resumeName);
			}else {
				resumeName=(String) jsonObjectAttach.get("resumeName");
			}

			
	        list.add(e);
		
	}  
	        return list;
  }



public Long getNumFound() {
	return numFound;
}

public void setNumFound(Long numFound) {
	this.numFound = numFound;
} 
 
}
  
  
  
