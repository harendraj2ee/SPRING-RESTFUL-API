package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.es.model.AttachCount;
import com.es.model.CandidateCount;
@Controller
public class HitechCRMController {
	/*@Autowired
	private RestTemplate restTemplate;*/
	RestTemplate restTemplate = new RestTemplate();
	
	private Long numFound;
	
	@RequestMapping(value = "/ElasticAPI/jobcount", method = RequestMethod.GET)
	public @ResponseBody String esJobCount(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate) throws JSONException, ParseException {
		
		/*String dquery = "";
		
		if (postedby.length() >= 1) {
			postedby = "(postedby:(\"" + postedby + "\"))";
			if (dquery.equals("")) {
				dquery = postedby;
			} else {
				dquery = dquery + " AND " + postedby;
			}
		}
		if (fromdate.length() >= 1) {
			fromdate = "(postedDate:(\"" + fromdate + "\"))";
			if (dquery.equals("")) {
				dquery = fromdate;
			} else {
				dquery = dquery + " AND " + fromdate;
			}
		}

		if (todate.length() >= 1) {
			todate = "(postedDate:(\"" + todate + "\"))";
			if (dquery.equals("")) {
				dquery = todate;
			} else {
				dquery = dquery + " AND " + todate;
			}
		}*/
		
		
		//job1=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId
		String joburl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(postedBy:\""+postedby+"\")AND(postedDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,modifiedDate,postedBy,postedDate";//id,
		System.out.println("ESURL job1    >> " + joburl);
		String jsonjobUrl = restTemplate.getForObject(joburl, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
				
		JSONObject jsonObject1=(JSONObject) new JSONObject(jsonjobUrl).get("_shards");
		System.out.println("jsonObject1 >> "+jsonObject1);
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonjobUrl).get("hits");
		
		
		/*JSONObject jsonObject2=new JSONObject(jsonIndustryUrl);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);*/
		/*JSONArray array2 = (JSONArray) jsonObject2.get("hits");
		JSONObject jsonObject3 = (JSONObject) array2.get(0);
		System.out.println("json value::::"+jsonObject3);
		JSONObject jsonObject4=(JSONObject) jsonObject3.get("_source");
		System.out.println("jsonObject4 >>> "+jsonObject4);*/
		
		/*String jobId="";
		String postedBy="";
		String postedDate="";
		if (jsonObject4.has(jobId) && !jsonObject4.get(jobId).equals("null")) {
			jobId=(String) jsonObject4.get("jobId");
			System.out.println("jobId >> "+jobId);
		}
		if (jsonObject4.has("postedBy")) {
			postedBy=(String) jsonObject4.get("postedBy");
			System.out.println("postedBy >> "+postedBy);
		}
		if (jsonObject4.has(postedDate)) {
			postedDate=(String) jsonObject4.get("postedDate");
			System.out.println("postedDate >> "+postedDate);
		}
		String attachurl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach2/_search?q=(jobId:\""+jobId+"\")&size=10&from=0&pretty=true&_source=id,modifiedDate,postedBy,postedDate";//id,
		System.out.println("ESURL attach2    >> " + attachurl);
		String jsonAttachUrl = restTemplate.getForObject(attachurl, String.class);
		System.out.println("jsonAttachUrl >> "+jsonAttachUrl);*/
		
		
		Integer count=(Integer) jsonObject2.get("total");
		System.out.println("count total >> "+count);
		array.put(count);
		jsonMain.accumulate("job", count);
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		
		return jsonObjResponse.toString();
	}
	
	//AttachCandidate
	
	@RequestMapping(value = "/ElasticAPI/attachcount", method = RequestMethod.GET)
	public @ResponseBody String esAttachJobCount(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate) throws JSONException, ParseException {
		//job1=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId,
		String attachurl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,jobId,objectId,attachedBy,createdDate";//id,
		System.out.println("ESURL job1    >> " + attachurl);
		String jsonAttachUrl = restTemplate.getForObject(attachurl, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
				
		JSONObject jsonObject1=(JSONObject) new JSONObject(jsonAttachUrl).get("_shards");
		System.out.println("jsonObject1 >> "+jsonObject1);
		JSONObject jsonObject2= (JSONObject) new JSONObject(jsonAttachUrl).get("hits");
		

		/*JSONObject jsonObject2=new JSONObject(jsonIndustryUrl);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);*/
		
		/*JSONArray array2 = (JSONArray) jsonObject2.get("hits");
		JSONObject jsonObject3 = (JSONObject) array2.get(0);
		System.out.println("json value::::"+jsonObject3);
		JSONObject jsonObject4=(JSONObject) jsonObject3.get("_source");
		System.out.println("jsonObject4 >>> "+jsonObject4);*/
		
	
		Integer count=(Integer) jsonObject2.get("total");
		System.out.println("count total >> "+count);
		array.put(count);
		jsonMain.accumulate("attach", count);
		System.out.println("jsonMain >> "+jsonMain);
		array1.put(jsonMain);
		jsonObjDocs.put("docs", array1);
		jsonObjResponse.put("response", jsonObjDocs);
		System.out.println("jsonObjResponse >> " + jsonObjResponse);
		
		return jsonObjResponse.toString();
	}
	
//joblist
	@RequestMapping(value = "/ElasticAPI/joblist", method = { RequestMethod.GET })
	public @ResponseBody String esJobList(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
			@RequestParam("todate")String todate,@RequestParam("sort")String sort,@RequestParam("next")Integer next,
			@RequestParam("perpage")Integer perpage)throws URISyntaxException, MalformedURLException, JSONException {
		String joburl ="";
		String jsonEsJobUrl ="";
		
		if (sort.equals("postedDatea")) {
			sort="postedDate:" + " asc";
		}else if(sort.equals("postedDated")) {
			sort="postedDate:" + " desc";
		}
		//		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&sort=" + sort + "&_source=name,skills,role,ctc,experience,location,postedby,id,description,industry,@timestamp,industrytype,education,funtionalarea,posteddate,noofopenings,expireddate,modifieddate,modifiedby";
 
		joburl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(postedBy:\""+postedby+"\")AND(postedDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+next+"&pretty=true&_source=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId&sort="+sort+"";//id,
		System.out.println("ESAPI job  :>> "+joburl);
		URL urlCandidatedata = new URL(joburl);
		String nullFragment = null;
		URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(), urlCandidatedata.getHost(),
				urlCandidatedata.getPort(), urlCandidatedata.getPath(), urlCandidatedata.getQuery(), nullFragment);
		
		jsonEsJobUrl = restTemplate.getForObject(uriCandidatedata, String.class);
		return jsonEsJobUrl.toString();
	}

	//atachlist
		@RequestMapping(value = "/ElasticAPI/attachlist2", method = { RequestMethod.GET })
		public @ResponseBody String esAttachList(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
				@RequestParam("todate")String todate)throws URISyntaxException, MalformedURLException, JSONException {
			
			String attahurl="";
			String jsonEsAttachUrl ="";
			//id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName
			attahurl  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume
			System.out.println("ESAPI Attach :>> "+attahurl);
			jsonEsAttachUrl = restTemplate.getForObject(attahurl, String.class);
			
			JSONObject jsonObject1=(JSONObject) new JSONObject(jsonEsAttachUrl).get("_shards");
			System.out.println("jsonObject1 >> "+jsonObject1);
			JSONObject jsonObject2= (JSONObject) new JSONObject(jsonEsAttachUrl).get("hits");

			return jsonEsAttachUrl;
		}
		
		@RequestMapping(value = "/ElasticAPI/attachlist", method = { RequestMethod.GET })
		public @ResponseBody String esAttachCRM(@RequestParam("postedby")String postedby, @RequestParam("fromdate")String fromdate,
				@RequestParam("todate")String todate,@RequestParam("perpage") Integer perpage,@RequestParam("next")Integer next,
				@RequestParam("sort")String sort)throws URISyntaxException, MalformedURLException, JSONException, ParseException {
			
			 ArrayList<AttachCount> list = new ArrayList<AttachCount>();
			 list= attach(postedby,fromdate,todate,perpage,next,sort);
			 org.json.JSONObject obj = new org.json.JSONObject();
			 org.json.JSONObject obj1 = new org.json.JSONObject();
			 
			 
			 org.json.JSONArray array = new org.json.JSONArray();
			 array.put(list);
			 obj.put("attach", list);
			 obj.put("numFound", this.getNumFound());

			 obj1.put("response", obj);
			 System.out.println("obj1 >> "+obj1);
			 return obj1.toString();
			  
		}
		

		//////////////////////
		
		
		//Candidate       
		  public static  ArrayList<CandidateCount> candidate(String objectId,Integer perpage,Integer start,String sort) throws ParseException, JSONException{
				
				if (sort.equals("postedDatea")) {
					sort="createdDate:" + " asc";
				}else if(sort.equals("postedDated")) {
					sort="createdDate:" + " desc";
				}
			  
			  //objectId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
			  //int perPage=10;
			  //int start=0;
			  ArrayList<CandidateCount> list =  new ArrayList<CandidateCount>();
			  RestTemplate restTemplate=new RestTemplate();
			  String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+objectId+"\")&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
			  System.out.println("urlCandidate >> " + urlCandidate);
			  JSONParser jsonParsercan  = new JSONParser();
			  
			
			  
			  String candidate = restTemplate.getForObject(urlCandidate, String.class);
			  org.json.simple.JSONObject jsoncan= (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan.parse(candidate)).get("hits");
					
			      System.out.println("jsoncan::::"+jsoncan);
			        
			        org.json.simple.JSONArray arraycan = ( org.json.simple.JSONArray) jsoncan.get("hits");
			        System.out.println("jsoncanlength::::"+arraycan.size());
			        Iterator itratorcan = arraycan.iterator();
			        
			        while(itratorcan.hasNext()){
			        	CandidateCount e = new  CandidateCount();
			     	
			        	org.json.simple.JSONObject jsonObjectcan=(org.json.simple.JSONObject) itratorcan.next();
			        //System.out.println("jsonObject::::"+jsonObject);
			        jsonObjectcan=  (org.json.simple.JSONObject) jsonObjectcan.get("_source");
			        System.out.println("jsonObjectcan:::"+jsonObjectcan);
			        
			        String name=(String) jsonObjectcan.get("name");
			        e.setName(name);
			        System.out.println("candidate name::::"+name);
			        e.setName(name);
			        String first_name=(String) jsonObjectcan.get("first_name");
			        e.setFirst_name(first_name);
			        String last_name=(String) jsonObjectcan.get("last_name");
			        e.setLast_name(last_name);
			        String  middle_name=(String) jsonObjectcan.get("middle_name");
			        e.setMiddle_name(middle_name);
			         String  email=(String) jsonObjectcan.get("email");
			        e.setEmail(email);
			        String   mobileNumber=(String) jsonObjectcan.get("mobileNumber");
			        e.setMobileNumber(mobileNumber);
			      
			        list.add(e);
				
			}  
			        return list;
		  }     
		        

		 //Attach
		 public    ArrayList<AttachCount> attach(String postedby,String fromdate,String todate,Integer perpage,Integer next,String sort) throws ParseException, JSONException{
			  System.out.println("hello!!!");
			  //jobId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
			 // int perPage=10;
			  //int start=0;
			 
				 Integer numFound=null;
				 String id="";
				 String objectId="";
				 String jobIdd="";
				 String drop="";
				 String dropComment="";
				 String lastModifiedBy="";
				 String createdDate="";
				 String anchor="";
				 String anchorId="";
				 String status="";
						
				 String jobName = "";
				 String clientId = "";
				 String clientName = "";
				 String contactId = "";
				 String contactName ="";
				 String attachedBy = "";
				 String lastModified = "";
				 String cvSentDate = "";
				 String statusChangeDate = "";
				 String statusOutcome = "";
				 String changeReason = "";
				 String clientPortalStatus = "";
				 String clientSheetStatus = "";
				 String paTestScore = "";
				 String testScore = "";
				 String avgScore = "";
				 Long pageUpId;
				 String ghStage = "";
				 String ghStatus = "";
				 Long ghStageId;
				 Long ghStatusId ;
				 Long stageId ;
				 Long statusId;
				 String stage ="";
				 String comment = "";
				 Long withOutId;
				 String resumeName= "";
				
				 Long isClientSheet;
				
			
			  ArrayList<AttachCount> list =  new ArrayList<AttachCount>();
			  ArrayList<CandidateCount> canlist =  new ArrayList<CandidateCount>();
			  RestTemplate restTemplate=new RestTemplate();
			  
				if (sort.equals("postedDatea")) {
					sort="createdDate:" + " asc";
				}else if(sort.equals("postedDated")) {
					sort="createdDate:" + " desc";
				}
			  int start = perpage*(next);
			  
			  String urlAttach  = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(attachedBy:\""+postedby+"\")AND(createdDate:[\""+fromdate+"\" TO \""+todate+"\"])&size="+perpage+"&from="+start+"&sort="+sort+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,lastModifiedBy,lastModified,createdDate,anchor,anchorId,cvSentDate,statusChangeDate,statusOutcome,changeReason,clientPortalStatus,clientSheetStatus,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";//resume

			  
			  //String  urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume

			  System.out.println("urlCandidate >> " + urlAttach);
			  JSONParser jsonParsercan  = new JSONParser();
			  String attach = restTemplate.getForObject(urlAttach, String.class);
			  org.json.simple.JSONObject jsoncan= ( org.json.simple.JSONObject) (( org.json.simple.JSONObject) jsonParsercan.parse(attach)).get("hits");
					
			        System.out.println("total:::::::"+jsoncan.get("total"));
			        Long total=  (Long) jsoncan.get("total");
			        this.setNumFound(total);
			        
			        //JSONObject total = new JSONObject();
			        //total.put("", jsoncan.get("total"));
			        org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
			        System.out.println("jsoncanlength::::"+arraycan.size());
			        Iterator itratorcan = arraycan.iterator();
			       
			        while(itratorcan.hasNext()){
			        	AttachCount e = new  AttachCount();
			    
			        org.json.simple.JSONObject jsonObjectcan=( org.json.simple.JSONObject) itratorcan.next();
			        //System.out.println("jsonObject::::"+jsonObject);
			        jsonObjectcan=  ( org.json.simple.JSONObject) jsonObjectcan.get("_source");
			        System.out.println("jsonObjectcan:::"+jsonObjectcan);
				   
			        id= (String) jsonObjectcan.get("id");
			        e.setId(id);
			        //jsonobj.put("id", id);
					System.out.println("id value::::________"+id);
					objectId=(String) jsonObjectcan.get("objectId");
				
					canlist=candidate(objectId,perpage,next,sort);
					e.setCandidate(canlist);
					
					e.setObjectId(objectId);
					System.out.println("objectId::::"+objectId);
					
				
					
					//jsonobj.put("objectId", objectId);
					jobIdd=(String) jsonObjectcan.get("jobId");
					e.setJobIdd(jobIdd);
					//jsonobj.put("jobId", jobId);
					drop=(String) jsonObjectcan.get("drop");
					//jsonobj.put("drop", drop);
					e.setDrop(drop);
					dropComment=(String) jsonObjectcan.get("dropComment");
					//jsonobj.put("dropComment", dropComment);
					e.setDropComment(dropComment);
					lastModifiedBy=(String) jsonObjectcan.get("lastModifiedBy");
					//jsonobj.put("lastModifiedBy", lastModifiedBy);
					e.setLastModifiedBy(lastModifiedBy);
					createdDate=(String) jsonObjectcan.get("createdDate");
					//jsonobj.put("createdDate", createdDate);
					e.setCreatedDate(createdDate);
					anchor=(String) jsonObjectcan.get("anchor");
					//jsonobj.put("anchor", anchor);
					e.setAnchor(anchor);
					
					anchorId=(String) jsonObjectcan.get("anchorId");
					e.setAnchor(anchorId);
					//jsonobj.put("anchorId", anchorId);
					e.setAnchorId(anchorId);
					status=(String) jsonObjectcan.get("status");
					//jsonobj.put("status", status);
					e.setStatus(status);
			       
					jobName=(String) jsonObjectcan.get("jobName");
					e.setJobName(jobName);
					clientId=(String) jsonObjectcan.get("clientId");
					e.setClientId(clientId);
					clientName=(String) jsonObjectcan.get("clientName");
					e.setClientName(clientName);
					contactId=(String) jsonObjectcan.get("contactId");
					e.setContactId(contactId);
					contactName=(String) jsonObjectcan.get("contactName");
					e.setContactName(contactName);
					attachedBy=(String) jsonObjectcan.get("attachedBy");
					e.setAttachedBy(attachedBy);
					lastModified=(String) jsonObjectcan.get("lastModified");
					e.setLastModified(lastModified);
					cvSentDate=(String) jsonObjectcan.get("cvSentDate");
					e.setCvSentDate(cvSentDate);
					statusChangeDate=(String) jsonObjectcan.get("statusChangeDate");
					e.setStatusChangeDate(statusChangeDate);
					statusOutcome=(String) jsonObjectcan.get("statusOutcome");
					e.setStatusOutcome(statusOutcome);
					changeReason=(String) jsonObjectcan.get("changeReason");
					e.setChangeReason(changeReason);
					clientPortalStatus=(String) jsonObjectcan.get("clientPortalStatus");
					e.setClientPortalStatus(clientPortalStatus);
					clientSheetStatus=(String) jsonObjectcan.get("clientSheetStatus");
					e.setClientSheetStatus(clientSheetStatus);
					paTestScore=(String) jsonObjectcan.get("paTestScore");
					e.setPaTestScore(paTestScore);
					testScore=(String) jsonObjectcan.get("testScore");
					e.setTestScore(testScore);
					avgScore=(String) jsonObjectcan.get("avgScore");
					e.setAvgScore(avgScore);
					pageUpId=(Long) jsonObjectcan.get("pageUpId");
					e.setPageUpId(pageUpId);
					ghStage=(String) jsonObjectcan.get("ghStage");
					e.setGhStage(ghStage);
					ghStatus=(String) jsonObjectcan.get("ghStatus");
					e.setGhStatus(ghStatus);
					ghStageId=(Long) jsonObjectcan.get("ghStageId");
					e.setGhStageId(ghStageId);
					ghStatusId=(Long) jsonObjectcan.get("ghStatusId");
					e.setGhStatusId(ghStatusId);
					stageId=(Long) jsonObjectcan.get("stageId");
					e.setStageId(stageId);
					statusId=(Long) jsonObjectcan.get("statusId");
					e.setStatusId(statusId);
					
					stage=(String) jsonObjectcan.get("stage");
					e.setStage(stage);
					comment=(String) jsonObjectcan.get("comment");
					e.setComment(comment);
					withOutId=(Long) jsonObjectcan.get("withOutId");
					e.setWithOutId(withOutId);
					resumeName=(String) jsonObjectcan.get("resumeName");
					e.setResumeName(resumeName);
					
					isClientSheet = (Long) jsonObjectcan.get("isClientSheet");
					e.setIsClientSheet(isClientSheet);
                    list.add(e);
				
			}  
			        return list;
		  }

		public Long getNumFound() {
			return numFound;
		}

		public void setNumFound(Long numFound) {
			this.numFound = numFound;
		} 
		
		
		
		
	
}
