package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.model.JobDetail;

@RestController
public class MobileController {
	RestTemplate restTemplate = new RestTemplate();
	
	///////JOB API
// 1.  Mobile API behalf of industry and functionalarea
	
	@RequestMapping(value = "/ElasticAPI/job", method = { RequestMethod.GET })
	public @ResponseBody String esJob1(@RequestParam("industrytype") String industrytype,
			@RequestParam("funtionalarea") String funtionalarea)
			throws URISyntaxException, MalformedURLException, JSONException {

		String dquery = "";

		String Jobid = "";
		String Jobname = "";
		String Jobctc = "";
		String Jobdescription = "";
		String Joblocation = "";
		String JobindustryType = "";
		String JobfuntionalArea = "";

		String Jobexperience = "";

		String JobspostedDate = "";
		String JobsmodifiedDate = "";
		String AttachStatus = "";
		Integer AttachStatusId = null;

		if (funtionalarea.length() >= 1) {
			// location = "location:*" + location + "*";
			funtionalarea = "(funtionalArea:(\"" + funtionalarea + "\"))";
			// location = "\"" + location + "\"";
			if (dquery.equals("")) {
				dquery = funtionalarea;
			} else {
				dquery = dquery + " AND " + funtionalarea;
			}
		}

		if (industrytype.length() >= 1) {
			// industrytype = "(industryType:(\"" + industrytype + "\"))";
			industrytype = "(industry:(\"" + industrytype + "\"))";
			// industry = "\"" + industry + "\"";
			if (dquery.equals("")) {
				dquery = industrytype;
			} else {
				dquery = dquery + " AND " + industrytype;
			}
		}

		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="
				+ dquery
				+ "&size=10&from=0&pretty=true&_source=id,name,ctc,description,location,industryType,funtionalArea,experience,modifiedDate,postedDate";

		System.out.println("ESAPI job Industrytype & functionalArea :>> " + urljob);

		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);

		JSONArray jobsarrat = new JSONArray();
		JSONObject mainjson = new JSONObject();

		// System.out.println("data......." + jsonEsJobUrl);

		Map jobsMap = new HashMap();
		JSONObject jsonObject = new JSONObject(jsonEsJobUrl);
		jsonObject = (JSONObject) jsonObject.get("_shards");
		System.out.println("shards........" + jsonObject);

		JSONObject jsonObject2 = new JSONObject(jsonEsJobUrl);
		jsonObject2 = (JSONObject) jsonObject2.get("hits");

		System.out.println("hits,,,,,,,,," + jsonObject2);

		JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");

		System.out.println("Hits...........??????? >> " + jsonarray);
		for (int i = 0; i < jsonarray.length(); i++) {

			JSONObject jsonObject3 = (JSONObject) jsonarray.get(i);

			JSONObject jsonObject4 = (JSONObject) jsonObject3.get("_source");
			System.out.println(" Source .........." + jsonObject4);

			if (jsonObject4.has("id")) {
				Jobid = jsonObject4.getString("id");
			}

			if (jsonObject4.has("name")) {
				Jobname = jsonObject4.getString("name");
			}

			if (jsonObject4.has("ctc")) {
				Jobctc = jsonObject4.getString("ctc");
			}

			if (jsonObject4.has("description")) {
				Jobdescription = jsonObject4.getString("description");
			}

			if (jsonObject4.has("location")) {
				Joblocation = jsonObject4.getString("location");
			}

			if (jsonObject4.has("industryType")) {
				JobindustryType = jsonObject4.getString("industryType");
			}

			if (jsonObject4.has("funtionalArea")) {
				JobfuntionalArea = jsonObject4.getString("funtionalArea");
			}

			if (jsonObject4.has("experience")) {
				Jobexperience = jsonObject4.getString("experience");
			}

			if (jsonObject4.has("postedDate")) {
				JobspostedDate = jsonObject4.getString("postedDate");
			}

			if (jsonObject4.has("modifiedDate")) {
				JobsmodifiedDate = jsonObject4.getString("modifiedDate");
			}

			String attachUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=jobName:\""
					+ Jobname + "\"";

			System.out.println(attachUrl);

			URL urlAttach = new URL(attachUrl);

			URI uriAttach = new URI(urlAttach.getProtocol(), urlAttach.getUserInfo(), urlAttach.getHost(),
					urlAttach.getPort(), urlAttach.getPath(), urlAttach.getQuery(), attachUrl);

			String attachData = restTemplate.getForObject(uriAttach, String.class);

			JSONObject jsonAttach = new JSONObject(attachData);

			JSONObject hits1 = jsonAttach.getJSONObject("hits");
			JSONArray hitsArr1 = hits1.getJSONArray("hits");

			for (int j = 0; j < hitsArr1.length(); j++) {

				JSONObject arrObj1 = ((JSONObject) hitsArr1.get(j)).getJSONObject("_source");

				if (arrObj1.has("status")) {
					AttachStatus = arrObj1.getString("status");
				}

				if (arrObj1.has("statusId")) {
					AttachStatusId = arrObj1.getInt("statusId");
				}

				jobsMap.put("postedDate", JobspostedDate);
				jobsMap.put("modifiedDate", JobsmodifiedDate);
				jobsMap.put("experience", Jobexperience);

				jobsMap.put("funtionalArea", JobfuntionalArea);
				jobsMap.put("industryType", JobindustryType);
				jobsMap.put("location", Joblocation);
				jobsMap.put("description", Jobdescription);
				jobsMap.put("ctc", Jobctc);
				jobsMap.put("id", Jobid);
				jobsMap.put("name", Jobname);
				jobsMap.put("status", AttachStatus);
				jobsMap.put("statusId", AttachStatusId);

				jobsarrat.put(jobsMap);

			}

			if (hitsArr1.isNull(0)) {
				jobsMap.put("postedDate", JobspostedDate);
				jobsMap.put("modifiedDate", JobsmodifiedDate);
				jobsMap.put("experience", Jobexperience);
				jobsMap.put("funtionalArea", JobfuntionalArea);
				jobsMap.put("industryType", JobindustryType);
				jobsMap.put("location", Joblocation);
				jobsMap.put("description", Jobdescription);
				jobsMap.put("ctc", Jobctc);
				jobsMap.put("id", Jobid);
				jobsMap.put("name", Jobname);
				jobsMap.put("status", AttachStatus);
				jobsMap.put("statusId", JSONObject.NULL);

				jobsarrat.put(jobsMap);
			}
		}

		mainjson.put("response", jobsarrat);

		return mainjson.toString();
	}

	
	
	/*@RequestMapping(value = "/ElasticAPI/job", method = { RequestMethod.GET })
    public @ResponseBody String esJob1(@RequestParam("industrytype") String industrytype,
                                    @RequestParam("funtionalarea") String funtionalarea)
                                    throws URISyntaxException, MalformedURLException, JSONException {

                    String dquery = "";

                    String Jobid = "";
                    String Jobname = "";
                    String Jobctc = "";
                    String Jobdescription = "";
                    String Joblocation = "";
                    String JobindustryType = "";
                    String JobfuntionalArea = "";

                    String Jobexperience = "";

                    String JobspostedDate = "";
                    String JobsmodifiedDate = "";

                    if (funtionalarea.length() >= 1) {
                                    // location = "location:*" + location + "*";
                                    funtionalarea = "(funtionalArea:(\"" + funtionalarea + "\"))";
                                    // location = "\"" + location + "\"";
                                    if (dquery.equals("")) {
                                                    dquery = funtionalarea;
                                    } else {
                                                    dquery = dquery + " AND " + funtionalarea;
                                    }
                    }

                    if (industrytype.length() >= 1) {
                                    industrytype = "(industryType:(\"" + industrytype + "\"))";
                                    // industry = "\"" + industry + "\"";
                                    if (dquery.equals("")) {
                                                    dquery = industrytype;
                                    } else {
                                                    dquery = dquery + " AND " + industrytype;
                                    }
                    }

                    String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="
                                                    + dquery
                                                    + "&size=10&from=0&pretty=true&_source=id,name,ctc,description,location,industryType,funtionalArea,experience,modifiedDate,postedDate";

                    System.out.println("ESAPI job Industrytype & functionalArea :>> " + urljob);

                    String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);

                    JSONObject jobsObj = new JSONObject();
                    JSONArray jobsarrat = new JSONArray();
                    JSONObject mainjson = new JSONObject();

                    //System.out.println("data......." + jsonEsJobUrl);

                    Map<String, String> jobsMap = new HashMap<String, String>();
                    JSONObject jsonObject = new JSONObject(jsonEsJobUrl);
                    jsonObject = (JSONObject) jsonObject.get("_shards");
                    System.out.println("shards........" + jsonObject);

                    JSONObject jsonObject2 = new JSONObject(jsonEsJobUrl);
                    jsonObject2 = (JSONObject) jsonObject2.get("hits");
                    
                    System.out.println("hits,,,,,,,,," + jsonObject2);

                    JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");

                    System.out.println("Hits...........??????? >> " + jsonarray);
                    for (int i = 0; i < jsonarray.length(); i++) {

                                    JSONObject jsonObject3 = (JSONObject) jsonarray.get(i);

                                    JSONObject jsonObject4 = (JSONObject) jsonObject3.get("_source");
                                    System.out.println(" Source .........." + jsonObject4);

                                    if (jsonObject4.has("id")) {
                                                    Jobid = jsonObject4.getString("id");
                                    }

                                    if (jsonObject4.has("name")) {
                                                    Jobname = jsonObject4.getString("name");
                                    }

                                    if (jsonObject4.has("ctc")) {
                                                    Jobctc = jsonObject4.getString("ctc");
                                    }

                                    if (jsonObject4.has("description")) {
                                                    Jobdescription = jsonObject4.getString("description");
                                    }

                                    if (jsonObject4.has("location")) {
                                                    Joblocation = jsonObject4.getString("location");
                                    }

                                    if (jsonObject4.has("industryType")) {
                                                    JobindustryType = jsonObject4.getString("industryType");
                                    }

                                    if (jsonObject4.has("funtionalArea")) {
                                                    JobfuntionalArea = jsonObject4.getString("funtionalArea");
                                    }

                                    if (jsonObject4.has("experience")) {
                                                    Jobexperience = jsonObject4.getString("experience");
                                    }

                                    if (jsonObject4.has("postedDate")) {
                                                    JobspostedDate = jsonObject4.getString("postedDate");
                                    }

                                    if (jsonObject4.has("modifiedDate")) {
                                                    JobsmodifiedDate = jsonObject4.getString("modifiedDate");
                                    }

                                    jobsMap.put("postedDate", JobspostedDate);
                                    jobsMap.put("modifiedDate", JobsmodifiedDate);
                                    jobsMap.put("experience", Jobexperience);

                                    jobsMap.put("funtionalArea", JobfuntionalArea);
                                    jobsMap.put("industryType", JobindustryType);
                                    jobsMap.put("location", Joblocation);
                                    jobsMap.put("description", Jobdescription);
                                    jobsMap.put("ctc", Jobctc);
                                    jobsMap.put("id", Jobid);
                                    jobsMap.put("name", Jobname);

                                    jobsarrat.put(jobsMap);

                    }

                    if (jsonarray.isNull(0)) {
                                    jobsMap.put("postedDate", JobspostedDate);
                                    jobsMap.put("modifiedDate", JobsmodifiedDate);
                                    jobsMap.put("experience", Jobexperience);

                                    jobsMap.put("funtionalArea", JobfuntionalArea);
                                    jobsMap.put("industryType", JobindustryType);
                                    jobsMap.put("location", Joblocation);
                                    jobsMap.put("description", Jobdescription);
                                    jobsMap.put("ctc", Jobctc);
                                    jobsMap.put("id", Jobid);
                                    jobsMap.put("name", Jobname);

                                    jobsarrat.put(jobsMap);
                    }

                    mainjson.put("response", jobsarrat);

                    return mainjson.toString();
    }*/
	
	
	
	//InProgress..
    /// mobile 2 API 12. Recent Search  
	//Parameter- skill,industry type,location,experience ,UserObjectID
//	Returned value- JobName ,Functional Area ,Experience ,CTC ,Location ,Apply Status , Job Freshness(e.g. Today,3 days Ago), 
//	CompanyName ,jobID status,status id, Job Count.


    @RequestMapping(value = "/ElasticAPI/jobs", method = { RequestMethod.GET })
    public @ResponseBody String esJob2(@RequestParam("name") String name, @RequestParam("skills") String skills,
                                    @RequestParam("company") String company, @RequestParam("location") String location,
                                    @RequestParam("experience") String experience)
                                    throws URISyntaxException, MalformedURLException, JSONException {

                    // RestTemplate restTemplate=new RestTemplate();
                    String Jobsid = "";
                    String Jobsname = "";
                    String Jobsctc = "";
                    String Jobsdescription = "";
                    String Jobslocation = "";
                    String JobsindustryType = "";
                    String JobsfuntionalArea = "";
                    String Jobsskills = "";
                    String Jobsexperience = "";

                    String JobspostedDate = "";
                    String JobsmodifiedDate = "";
                    if (name.length() >= 0) {
                                    name = "\"" + name + "\"";
                                    // System.out.println("name >> "+name);
                    }
                    if (skills.length() >= 0) {
                                    skills = "\"" + skills + "\"";
                                    // System.out.println("skills >> "+skills);
                    }
                    if (company.length() >= 0) {
                                    company = "\"" + company + "\"";
                                    // System.out.println("company >> "+company);
                    }
                    if (location.length() > 0) {
                                    location = "\"" + location + "\"";
                                    // System.out.println("location >> "+location);
                    }
                    if (experience.length() > 0) {
                                    experience = "\"" + experience + "\"";
                                    // System.out.println("experience >> "+experience);
                    }

                    String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(name:("
                                                    + name + ")) OR (company:(" + company + ")) OR (skills:(" + skills + ")) AND (location:(" + location
                                                    + ")) AND (experience:(" + experience
                                                    + "))&size=10&from=0&pretty=true&_source=id,name,ctc,description,location,industryType,funtionalArea,skills,experience,postedDate,modifiedDate";
                    System.out.println("ES API.........:>> " + urljob);

                    JSONObject jobsObj = new JSONObject();
                    JSONArray jobsarrat = new JSONArray();
                    JSONObject mainjson = new JSONObject();
                    String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
                   // System.out.println("data......." + jsonEsJobUrl);

                    Map<String, String> jobsMap = new HashMap<String, String>();
                    JSONObject jsonObject = new JSONObject(jsonEsJobUrl);
                    jsonObject = (JSONObject) jsonObject.get("_shards");
                    System.out.println("shards........" + jsonObject);

                    JSONObject jsonObject2 = new JSONObject(jsonEsJobUrl);
                    jsonObject2 = (JSONObject) jsonObject2.get("hits");
                    System.out.println("hits,,,,,,,,," + jsonObject2);

                    JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");

                    System.out.println("Hits...........??????? >> " + jsonarray);
                    for (int i = 0; i < jsonarray.length(); i++) {

                                    JSONObject jsonObject3 = (JSONObject) jsonarray.get(i);

                                    JSONObject jsonObject4 = (JSONObject) jsonObject3.get("_source");
                                    System.out.println(" Source .........." + jsonObject4);

                                    if (jsonObject4.has("id")) {
                                                    Jobsid = jsonObject4.getString("id");
                                    }

                                    if (jsonObject4.has("name")) {
                                                    Jobsname = jsonObject4.getString("name");
                                    }

                                    if (jsonObject4.has("ctc")) {
                                                    Jobsctc = jsonObject4.getString("ctc");
                                    }

                                    if (jsonObject4.has("description")) {
                                                    Jobsdescription = jsonObject4.getString("description");
                                    }

                                    if (jsonObject4.has("location")) {
                                                    Jobslocation = jsonObject4.getString("location");
                                    }

                                    if (jsonObject4.has("industryType")) {
                                                    JobsindustryType = jsonObject4.getString("industryType");
                                    }

                                    if (jsonObject4.has("funtionalArea")) {
                                                    JobsfuntionalArea = jsonObject4.getString("funtionalArea");
                                    }
                                    if (jsonObject4.has("skills")) {
                                                    Jobsskills = jsonObject4.getString("skills");
                                    }

                                    if (jsonObject4.has("experience")) {
                                                    Jobsexperience = jsonObject4.getString("experience");
                                    }

                                    if (jsonObject4.has("postedDate")) {
                                                    JobspostedDate = jsonObject4.getString("postedDate");
                                    }

                                    if (jsonObject4.has("modifiedDate")) {
                                                    JobsmodifiedDate = jsonObject4.getString("modifiedDate");
                                    }

                                    jobsMap.put("postedDate", JobspostedDate);
                                    jobsMap.put("modifiedDate", JobsmodifiedDate);
                                    jobsMap.put("experience", Jobsexperience);
                                    jobsMap.put("skills", Jobsskills);
                                    jobsMap.put("funtionalArea", JobsfuntionalArea);
                                    jobsMap.put("industryType", JobsindustryType);
                                    jobsMap.put("location", Jobslocation);
                                    jobsMap.put("description", Jobsdescription);
                                    jobsMap.put("ctc", Jobsctc);
                                    jobsMap.put("id", Jobsid);
                                    jobsMap.put("name", Jobsname);

                                    jobsarrat.put(jobsMap);

                    }

                    if (jsonarray.isNull(0)) {
                                    jobsMap.put("postedDate", JobspostedDate);
                                    jobsMap.put("modifiedDate", JobsmodifiedDate);
                                    jobsMap.put("experience", Jobsexperience);
                                    jobsMap.put("skills", Jobsskills);
                                    jobsMap.put("funtionalArea", JobsfuntionalArea);
                                    jobsMap.put("industryType", JobsindustryType);
                                    jobsMap.put("location", Jobslocation);
                                    jobsMap.put("description", Jobsdescription);
                                    jobsMap.put("ctc", Jobsctc);
                                    jobsMap.put("id", Jobsid);
                                    jobsMap.put("name", Jobsname);

                                    jobsarrat.put(jobsMap);
                    }

                    mainjson.put("response", jobsarrat);

                    return mainjson.toString();
    }

	///mobile 3 API
	@RequestMapping(value = "/ElasticAPI/jobex", method = { RequestMethod.GET })
	public @ResponseBody String esJob3(@RequestParam("skills")String skills,@RequestParam("experience")String experience) throws URISyntaxException, MalformedURLException, JSONException {
		String id = "";
		String ctc = "";
		String description = "";
		String location = "";
		String industryType = "";
		String funtionalArea = "";
		String skill = "";
		String company = "";
		String experience1 = "";
		/*if (skills.length()>=0) {
			 skills="\""+skills+"\"";
			 //System.out.println("skills >> "+skills);
		}
		 if (experience.length()>0) {
			experience="\""+experience+"\"";
			//System.out.println("experience >> "+experience);
		}*/
		String dquery ="";
		  if (skills.length() >= 1) {
              // location = "location:*" + location + "*";
			  skills = "(skills:(\"" + skills + "\"))";
              // location = "\"" + location + "\"";
              if (dquery.equals("")) {
                              dquery = skills;
              } else {
                              dquery = dquery + " AND " + skills;
              }
		  }

		  if (experience.length() >= 1) {
			  experience = "(experience:(\"" + experience + "\"))";
              // industry = "\"" + industry + "\"";
              if (dquery.equals("")) {
                              dquery = experience;
              } else {
                              dquery = dquery + " AND " + experience;
              }
		  }
		 
		  	JSONObject jsonMain=new JSONObject();
			JSONObject jsonObjDocs = new JSONObject();
			JSONObject jsonObjResponse = new JSONObject();
			JSONArray array = new JSONArray();
			JSONArray array1 = new JSONArray();
		//String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(skills:("+skills+")) AND (experience:("+experience+"))&size=10&from=0&pretty=true&_source=id,name,ctc,description,location,industryType,funtionalArea,skills,company,experience";
		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&_source=id,name,ctc,description,location,industryType,funtionalArea,skills,company,experience";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		URL urljobdata = new URL(urljob);
		String nullFragment = null;
		URI uriJob = new URI(urljobdata.getProtocol(), urljobdata.getUserInfo(), urljobdata.getHost(),
				urljobdata.getPort(), urljobdata.getPath(), urljobdata.getQuery(), nullFragment);
		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		// System.out.println("jsonEsUrl job >>> "+jsonEsJobUrl);
		org.json.JSONObject hits = new org.json.JSONObject(jsonEsJobUrl).getJSONObject("hits");

		org.json.JSONArray hitsArr = hits.getJSONArray("hits");

		for (int i = 0; i < hitsArr.length(); i++) {
			JobDetail jd = new JobDetail();
			System.out.println("Array length >> "+hitsArr.length());
			org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
			org.json.JSONObject _source = arrobj.getJSONObject("_source");
			if (_source.has("id")) {
				 id= _source.getString("id");
				 //String jobids= "4986f9b7-f872-4b4b-bdd0-6ce9fef4d6a0";s
				 jd.setId(id);
				 //jobIds = jobIds + "+" + _source.getString("jobId");
			} 
			else {
				_source.accumulate("id", "");
			}
			if (_source.has("ctc")) {
				ctc = _source.getString("ctc");
				jd.setCtc(ctc);
			}
			else {
				_source.accumulate("ctc", "");
			}
			if (_source.has("description") && !_source.get("description").equals(null)) {
				description = _source.getString("description");
				jd.setDescription(description);
			}
			else /*if (!_source.has("description"))*/ {
				description ="";
				_source.accumulate("description", "");
				//System.out.println("description... >> "+description);
			}
			if (_source.has("location")) {
				location = _source.getString("location");
				jd.setLocation(location);
			}else {
				_source.accumulate("location", location);
			}
			if (_source.has("industryType")) {
				industryType = _source.getString("industryType");
				jd.setIndustryType(industryType);
			}
			else {
				_source.accumulate("industryType", "");
			}
			if (_source.has("funtionalArea")) {
				funtionalArea = _source.getString("funtionalArea");
				jd.setFuntionalArea(funtionalArea);
			}
			else {
				_source.accumulate("funtionalArea", "");
			}
			if (_source.has("skills")) {
				skill = _source.getString("skills");
				jd.setSkills(skill);
			}else {
				_source.accumulate("skills", "");
			}
			if (_source.has("company")) {
				company = _source.getString("company");
				jd.setCompany(company);
			}
			else {
				//_source.append("company", "");
				
			}
			if (_source.has("experience")) {
				experience1 = _source.getString("experience");
				jd.setExperience(experience1);
			}
			else {
				_source.accumulate("experience", "");
			}
			
			//	array.put(count);
			//jsonMain.accumulate("totalcount", count);
			//System.out.println("jsonMain >> "+jsonMain);
			array1.put(_source);
			//jsonObjDocs.put("docs", array1);
			jsonObjResponse.put("response", array1);
			System.out.println("jsonObjResponse >> " + jsonObjResponse);
			return jsonObjResponse.toString();
		}
		
		return "";
	}
	
	///mobile 4 API 04-Aug-2018 behalf of jobid similar data
	@RequestMapping(value = "/ElasticAPI/jid", method = { RequestMethod.GET })
	public @ResponseBody String esJobId4(@RequestParam("id")String id) throws URISyntaxException, MalformedURLException, JSONException {
		//RestTemplate restTemplate=new RestTemplate();
		String urljob ="";
		String jsonEsJobUrl ="";
		 if (id.length()>=0) {
			 id="\""+id+"\"";
			 //System.out.println("skills >> "+skills);
		}
		 urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(id:"+id+")&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		///System.out.println("jsonEsJobUrl  Only Job ID >> "+jsonEsJobUrl);
		 
		 JSONObject jsonObject= new JSONObject(jsonEsJobUrl);
		 jsonObject=(JSONObject) jsonObject.get("_shards");
		 System.out.println("jsonEsUrl job >>>>>>> "+jsonObject);
		
		JSONObject jsonObject2=new JSONObject(jsonEsJobUrl);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);
		
		JSONArray array = (JSONArray) jsonObject2.get("hits");
		System.out.println("array:::"+array.length());
		
		JSONObject jsonObject3 = (JSONObject) array.get(0);
		System.out.println("json value::::"+jsonObject3);
		
		JSONObject jsonObject4=(JSONObject) jsonObject3.get("_source");
		System.out.println("jsonObject4 >>> "+jsonObject4);
		
		//"clientId": 1508,
		//"contactId": 10650,
		//"noOfOpenings": 0,
		//"deleted": 0,
		
		String jobcode="";
		String funtionalarea="";
		String skills="";
		String modifieddate="";
		String description="";
		String experience="";
		String  clientId="";
		String education="";
		String role="";
		String modifiedby="";
		String industrytype="";
		String industry="";
		String expireddate="";
		String  contactId="";
		String version="";//@version
		String ids="";//id
		String name="";
		String postedby="";
		int deleted = 0;
		String location="";
		String ctc="";
		String posteddate="";
		Long noofopenings = null;
	
		if (jsonObject4.has("id")) {
			ids=(String) jsonObject4.get("id");
		}
		if (jsonObject4.has("name")) {
			name=(String) jsonObject4.get("name");
		}
		if (jsonObject4.has("location")) {
			location=(String) jsonObject4.get("location");

		}

		String  urljob1 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(name:\""+name+"\")AND(location:\""+location+"\")&size=100&from=0&pretty=true&_source=funtionalArea,role,education,clientId,contactId,jobCode,description,industry,experience,noOfOpenings,postedDate,skills,postedBy,jobId,ctc,deleted,industryType,name,modifiedDate,location,modifiedBy,id";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob1);
		jsonEsJobUrl = restTemplate.getForObject(urljob1, String.class);
		//System.out.println("jsonEsJobUrl:::::::::::::::::::::____________"+jsonEsJobUrl);
		
		   JSONObject jobsObj = new JSONObject();
           JSONArray jobsarrat = new JSONArray();
           JSONObject mainjson = new JSONObject();
           jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
           //System.out.println("data......." + jsonEsJobUrl);

          // Map<String, String> jobsMap = new HashMap<String, String>();
           Map jobsMap = new HashMap<>();
           JSONObject jsonObjec = new JSONObject(jsonEsJobUrl);
           jsonObjec = (JSONObject) jsonObjec.get("_shards");
           JSONObject jsonObject22 = new JSONObject(jsonEsJobUrl);
           jsonObject22 = (JSONObject) jsonObject22.get("hits");
           JSONArray jsonarray = (JSONArray) jsonObject22.get("hits");

          // System.out.println("Hits...........??????? >> " + jsonarray);
           for (int i = 0; i < jsonarray.length(); i++) {

                           JSONObject jsonObject33 = (JSONObject) jsonarray.get(i);
                           JSONObject jsonObject44 = (JSONObject) jsonObject33.get("_source");
                          // System.out.println(" Source .........." + jsonObject44);

                           if (jsonObject44.has("id")) {
                               id = jsonObject44.getString("id");
                           }
                           if (jsonObject44.has("name")) {
                                name = jsonObject44.getString("name");
                           }
                           if (jsonObject44.has("ctc")) {
                                ctc = jsonObject44.getString("ctc");
                           }
                           if (jsonObject44.has("description")) {
                                description = jsonObject44.getString("description");
                           }
                           if (jsonObject44.has("location")) {
                               location = jsonObject44.getString("location");
                           }
                           if (jsonObject44.has("industryType")) {
                        	   industrytype = jsonObject44.getString("industryType");
                           }
                           if (jsonObject44.has("funtionalArea")) {
                               funtionalarea = jsonObject44.getString("funtionalArea");
                           }
                           if (jsonObject44.has("skills")) {
                               skills = jsonObject44.getString("skills");
                           }
                           if (jsonObject44.has("postedDate")) {
                               posteddate = jsonObject44.getString("postedDate");
                           }
                           if (jsonObject44.has("modifiedDate")) {
                               modifieddate = jsonObject44.getString("modifiedDate");
                           }
                           if(jsonObject44.has("clientId")){
                           		clientId = jsonObject44.getString("clientId");
                           	}
                           if(jsonObject44.has("contactId")){
                        	   contactId = jsonObject44.getString("contactId");
                           	}
                           if(jsonObject44.has("jobCode")){
                        	   jobcode = jsonObject44.getString("jobCode");
                          	}
                           if(jsonObject44.has("noOfOpenings")){
                        	   noofopenings = jsonObject44.getLong("noOfOpenings");
                          	}
                           if(jsonObject44.has("experience")){
                        	   experience = jsonObject44.getString("experience");
                          	} 
                           if(jsonObject44.has("industry")){
                        	   industry = jsonObject44.getString("industry");
                           	}
                           if(jsonObject44.has("role")){
                        	   role = jsonObject44.getString("role");
                          	}
                           if(jsonObject44.has("expiredDate")){
                        	   expireddate = jsonObject44.getString("expiredDate");
                          	}
                           if(jsonObject44.has("postedBy")){
                        	   postedby = jsonObject44.getString("postedBy");
                          	}
                           if(jsonObject44.has("modifiedBy")){
                        	   modifiedby = jsonObject44.getString("modifiedBy");
                          	}
                           if(jsonObject44.has("deleted")){
                        	   deleted = jsonObject44.getInt("deleted");
                          	}
                           jobsMap.put("clientId", clientId);
                           jobsMap.put("contactId", contactId);
                           jobsMap.put("jobCode", jobcode);
                           jobsMap.put("noOfOpenings", noofopenings);
                           jobsMap.put("jobCode", jobcode);
                           jobsMap.put("experience", experience);
                           jobsMap.put("industry", industry);
                           jobsMap.put("role", role);
                           jobsMap.put("expiredDate", expireddate);
                           jobsMap.put("postedBy", postedby);
                           jobsMap.put("modifiedBy", modifiedby);
                           jobsMap.put("deleted", deleted);
                           jobsMap.put("postedDate", posteddate);
                           jobsMap.put("modifiedDate", modifieddate);
                           jobsMap.put("experience", experience);
                           jobsMap.put("skills", skills);
                           jobsMap.put("funtionalArea", funtionalarea);
                           jobsMap.put("industryType", industrytype);
                           jobsMap.put("location", location);
                           jobsMap.put("description", description);
                           jobsMap.put("ctc", ctc);
                           jobsMap.put("id", id);
                           jobsMap.put("name", name);

                           jobsarrat.put(jobsMap);

           }

           if (jsonarray.isNull(0)) {
        	   jobsMap.put("clientId", clientId);
               jobsMap.put("contactId", contactId);
               jobsMap.put("jobCode", jobcode);
               jobsMap.put("noOfOpenings", noofopenings);
               jobsMap.put("jobCode", jobcode);
               jobsMap.put("experience", experience);
               jobsMap.put("industry", industry);
               jobsMap.put("role", role);
               jobsMap.put("expiredDate", expireddate);
               jobsMap.put("postedBy", postedby);
               jobsMap.put("modifiedBy", modifiedby);
               jobsMap.put("deleted", deleted);
               jobsMap.put("postedDate", posteddate);
               jobsMap.put("modifiedDate", modifieddate);
               jobsMap.put("experience", experience);
               jobsMap.put("skills", skills);
               jobsMap.put("funtionalArea", funtionalarea);
               jobsMap.put("industryType", industrytype);
               jobsMap.put("location", location);
               jobsMap.put("description", description);
               jobsMap.put("ctc", ctc);
               jobsMap.put("id", id);
               jobsMap.put("name", name);

                           jobsarrat.put(jobsMap);
           }

           mainjson.put("response", jobsarrat);

           return mainjson.toString();
}
		
		
		
		//return jsonEsJobUrl.toString();
	//}
	
	
	///mobile 4 API 04-Aug-2018 behalf of jobid similar job only for me testing
	@RequestMapping(value = "/ElasticAPI/jidd", method = { RequestMethod.GET })
	public @ResponseBody String esJobId44(@RequestParam("id")String id,@RequestParam("location")String location,@RequestParam("industrytype")String industrytype) throws URISyntaxException, MalformedURLException {
			String dquery = "";
					if (id.length() >= 1) {
						id = "(id:(\"" + id + "\"))";
						//skills = "\"" + skills + "\"";
						if (dquery.equals("")) {
							dquery = id;
						} else {
							dquery = dquery + " AND " + id;
						}
					}
					if (location.length() >= 1) {
						//location = "location:*" + location + "*";
						location = "(location:(\"" + location + "\"))";
						//location = "\"" + location + "\"";
						if (dquery.equals("")) {
							dquery = location;
						} else {
							dquery = dquery + " AND " + location;
						}
					}

					if (industrytype.length() >= 1) {
						industrytype = "(industryType:(\"" + industrytype + "\"))";
						//industry = "\"" + industry + "\"";
						if (dquery.equals("")) {
							dquery = industrytype;
						} else {
							dquery = dquery + " AND " + industrytype;
						}
					}
																																						  
		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		return jsonEsJobUrl.toString();
	}

	//mobile api similar type data.
	@RequestMapping(value = "/ElasticAPI/jiddd", method = { RequestMethod.GET })
	public @ResponseBody String esJobId44(@RequestParam("id")String id,@RequestParam("industrytype")String industrytype) throws URISyntaxException, MalformedURLException {
		 if (id.length()>=1) {
				id = "(id:(\"" + id + "\"))";
		}
		 if (industrytype.length()>=0) {
			 //industrytype = "(industrytype:(\"" + industrytype + "\"))";
			 industrytype = "(industrytype:(" + industrytype + "))";
		}
		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+id+"OR"+industrytype+"&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		return jsonEsJobUrl.toString();
	}


	///mobile 5 API 04-Aug-2018 behalf of : preferred Location ,Salary range(e.g. 10k- 52k) ,Job Freshness(PostDate) (e.g. 7 days Ago),Job Type
	@RequestMapping(value = "/ElasticAPI/jobdata", method = { RequestMethod.GET })
	public @ResponseBody String esJobSort5(@RequestParam("industrytype")String industrytype,@RequestParam("ctc")String ctc,
			@RequestParam("posteddate")String posteddate,@RequestParam("location")String location) throws URISyntaxException, MalformedURLException, JSONException {
		// String company = "";
			
		 String id="";
		 String clientId="";
		 String contactId="";
		 String name="";
		 String jobCode ="";
		 Long noOfOpenings= null;
		 String experience ="";
		 String ctcs="";
		 String locations="";
		 String industryType="";
		 String industry="";
		 String funtionalArea="";
		 String role="";
		 String skills="";
		 String education="";
		 String description="";
		 String postedDate="";
		 String modifiedDate="";
		 String expiredDate="";
		 String postedBy="";
		 String modifiedBy="";
		 int deleted =0;

	
		/*if (industrytype.length()>=0) {
			industrytype="\""+industrytype+"\"";
		}
		 if (ctc.length()>=0) {
			 ctc="\""+ctc+"\"";
		}
		 if (posteddate.length()>=0){
			 posteddate="\""+posteddate+"\"";
		}
		 if (location.length()>0) {
			 location="\""+location+"\"";
		}*/
		 
			String dquery = "";
			if (ctc.length() >= 1) {
				ctc = "(ctc:(\"" + ctc + "\"))";
				//skills = "\"" + skills + "\"";
				if (dquery.equals("")) {
					dquery = ctc;
				} else {
					dquery = dquery + " AND " + ctc;
				}
			}
			if (location.length() >= 1) {
				//location = "location:*" + location + "*";
				location = "(location:(\"" + location + "\"))";
				//location = "\"" + location + "\"";
				if (dquery.equals("")) {
					dquery = location;
				} else {
					dquery = dquery + " AND " + location;
				}
			}

			if (industrytype.length() >= 1) {
				industrytype = "(industryType:(\"" + industrytype + "\"))";
				//industry = "\"" + industry + "\"";
				if (dquery.equals("")) {
					dquery = industrytype;
				} else {
					dquery = dquery + " AND " + industrytype;
				}
			}
			if (posteddate.length() >= 1) {
				posteddate = "(postedDate:(\"" + posteddate + "\"))";
				//industry = "\"" + industry + "\"";
				if (dquery.equals("")) {
					dquery = posteddate;
				} else {
					dquery = dquery + " AND " + posteddate;
				}
			}
		 
		 String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted"; 
	
		//String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(industryType:("+industrytype+")) AND (ctc:("+ctc+")) AND (postedDate:("+posteddate+")) AND (location:("+location+"))&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);

	    JSONObject jobsObj = new JSONObject();
        JSONArray jobsarrat = new JSONArray();
        JSONObject mainjson = new JSONObject();
       // jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
        //System.out.println("data......." + jsonEsJobUrl);

       // Map<String, String> jobsMap = new HashMap<String, String>();
        Map jobsMap = new HashMap<>();
        JSONObject jsonObjec = new JSONObject(jsonEsJobUrl);
        jsonObjec = (JSONObject) jsonObjec.get("_shards");
        JSONObject jsonObject22 = new JSONObject(jsonEsJobUrl);
        jsonObject22 = (JSONObject) jsonObject22.get("hits");
        JSONArray jsonarray = (JSONArray) jsonObject22.get("hits");

       // System.out.println("Hits...........??????? >> " + jsonarray);
        for (int i = 0; i < jsonarray.length(); i++) {

                        JSONObject jsonObject33 = (JSONObject) jsonarray.get(i);
                        JSONObject jsonObject44 = (JSONObject) jsonObject33.get("_source");
                       // System.out.println(" Source .........." + jsonObject44);

                        if (jsonObject44.has("id")) {
                            id = jsonObject44.getString("id");
                        }
                        if (jsonObject44.has("name")) {
                             name = jsonObject44.getString("name");
                        }
                        if (jsonObject44.has("ctc")) {
                             ctc = jsonObject44.getString("ctc");
                        }
                        if (jsonObject44.has("description")) {
                             description = jsonObject44.getString("description");
                        }
                        if (jsonObject44.has("location")) {
                            location = jsonObject44.getString("location");
                        }
                        if (jsonObject44.has("industryType")) {
                     	   industrytype = jsonObject44.getString("industryType");
                        }
                        if (jsonObject44.has("funtionalArea")) {
                            funtionalArea = jsonObject44.getString("funtionalArea");
                        }
                        if (jsonObject44.has("skills")) {
                            skills = jsonObject44.getString("skills");
                        }
                        if (jsonObject44.has("postedDate")) {
                            posteddate = jsonObject44.getString("postedDate");
                        }
                        if (jsonObject44.has("modifiedDate")) {
                            modifiedDate = jsonObject44.getString("modifiedDate");
                        }
                        if(jsonObject44.has("clientId")){
                        		clientId = jsonObject44.getString("clientId");
                        	}
                        if(jsonObject44.has("contactId")){
                     	   contactId = jsonObject44.getString("contactId");
                        	}
                        if(jsonObject44.has("jobCode")){
                     	   jobCode = jsonObject44.getString("jobCode");
                       	}
                        if(jsonObject44.has("noOfOpenings")){
                     	   noOfOpenings = jsonObject44.getLong("noOfOpenings");
                       	}
                        if(jsonObject44.has("experience")){
                     	   experience = jsonObject44.getString("experience");
                       	} 
                        if(jsonObject44.has("industry")){
                     	   industry = jsonObject44.getString("industry");
                        	}
                        if(jsonObject44.has("role")){
                     	   role = jsonObject44.getString("role");
                       	}
                        if(jsonObject44.has("expiredDate")){
                     	   expiredDate = jsonObject44.getString("expiredDate");
                       	}
                        if(jsonObject44.has("postedBy")){
                     	   postedBy = jsonObject44.getString("postedBy");
                       	}
                        if(jsonObject44.has("modifiedBy")){
                     	   modifiedBy = jsonObject44.getString("modifiedBy");
                       	}
                        if(jsonObject44.has("deleted")){
                     	   deleted = jsonObject44.getInt("deleted");
                       	}
                        jobsMap.put("clientId", clientId);
                        jobsMap.put("contactId", contactId);
                        jobsMap.put("jobCode", jobCode);
                        jobsMap.put("noOfOpenings", noOfOpenings);
                        jobsMap.put("jobCode", jobCode);
                        jobsMap.put("experience", experience);
                        jobsMap.put("industry", industry);
                        jobsMap.put("role", role);
                        jobsMap.put("expiredDate", expiredDate);
                        jobsMap.put("postedBy", postedBy);
                        jobsMap.put("modifiedBy", modifiedBy);
                        jobsMap.put("deleted", deleted);
                        jobsMap.put("postedDate", posteddate);
                        jobsMap.put("modifiedDate", modifiedDate);
                        jobsMap.put("experience", experience);
                        jobsMap.put("skills", skills);
                        jobsMap.put("funtionalArea", funtionalArea);
                        jobsMap.put("industryType", industrytype);
                        jobsMap.put("location", location);
                        jobsMap.put("description", description);
                        jobsMap.put("ctc", ctc);
                        jobsMap.put("id", id);
                        jobsMap.put("name", name);

                        jobsarrat.put(jobsMap);

        }

        if (jsonarray.isNull(0)) {
     	   jobsMap.put("clientId", clientId);
            jobsMap.put("contactId", contactId);
            jobsMap.put("jobCode", jobCode);
            jobsMap.put("noOfOpenings", noOfOpenings);
            jobsMap.put("experience", experience);
            jobsMap.put("industry", industry);
            jobsMap.put("role", role);
            jobsMap.put("expiredDate", expiredDate);
            jobsMap.put("postedBy", postedBy);
            jobsMap.put("modifiedBy", modifiedBy);
            jobsMap.put("deleted", deleted);
            jobsMap.put("postedDate", posteddate);
            jobsMap.put("modifiedDate", modifiedDate);
            jobsMap.put("experience", experience);
            jobsMap.put("skills", skills);
            jobsMap.put("funtionalArea", funtionalArea);
            jobsMap.put("industryType", industrytype);
            jobsMap.put("location", location);
            jobsMap.put("description", description);
            jobsMap.put("ctc", ctc);
            jobsMap.put("id", id);
            jobsMap.put("name", name);

                        jobsarrat.put(jobsMap);
        }

        mainjson.put("response", jobsarrat);

        return mainjson.toString();
}
		
		

	
	//Mobile API 6 no param get data..18-Aug-2018
	
	@RequestMapping(value = "/ElasticAPI/jdata", method = { RequestMethod.GET })
	public @ResponseBody String esJobId6() throws URISyntaxException, MalformedURLException, JSONException, ParseException {
		//RestTemplate restTemplate=new RestTemplate();
		String urljob ="";
		String jsonEsJobUrl ="";
		 String id="";
		 String clientId="";
		 String contactId="";
		 String name="";
		 String jobCode ="";
		 Long noOfOpenings= null;
		 String experience ="";
		 String ctc="";
		 String location="";
		 String industryType="";
		 String industry="";
		 String funtionalArea="";
		 String role="";
		 String skills="";
		 String education="";
		 String description="";
		 String postedDate="";
		 String modifiedDate="";
		 String expiredDate="";
		 String postedBy="";
		 String modifiedBy="";
		 int deleted =0;
		
		//urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=\"\"&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		System.out.println("ESAPI job Industrytype & functionalArea :>> "+urljob);
		jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		
		//JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		JSONArray array1 = new JSONArray();
		
		
		  JSONObject jobsObj = new JSONObject();
            JSONArray jobsarrat = new JSONArray();
            JSONObject mainjson = new JSONObject();
           // jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
            //System.out.println("data......." + jsonEsJobUrl);

           // Map<String, String> jobsMap = new HashMap<String, String>();
            Map jobsMap = new HashMap<>();
            JSONObject jsonObjec = new JSONObject(jsonEsJobUrl);
            jsonObjec = (JSONObject) jsonObjec.get("_shards");
            JSONObject jsonObject22 = new JSONObject(jsonEsJobUrl);
            jsonObject22 = (JSONObject) jsonObject22.get("hits");
            JSONArray jsonarray = (JSONArray) jsonObject22.get("hits");

          //  System.out.println("Hits...........??????? >> " + jsonarray);
            for (int i = 0; i < jsonarray.length(); i++) {

                            JSONObject jsonObject33 = (JSONObject) jsonarray.get(i);
                            JSONObject jsonObject44 = (JSONObject) jsonObject33.get("_source");
                           // System.out.println(" Source .........." + jsonObject44);

                            if (jsonObject44.has("id")) {
                                id = jsonObject44.getString("id");
                            }
                            if (jsonObject44.has("name")) {
                                 name = jsonObject44.getString("name");
                            }
                            if (jsonObject44.has("ctc")) {
                                 ctc = jsonObject44.getString("ctc");
                            }
                            if (jsonObject44.has("description")) {
                                 description = jsonObject44.getString("description");
                            }
                            if (jsonObject44.has("location")) {
                                location = jsonObject44.getString("location");
                            }
                            if (jsonObject44.has("industryType")) {
                         	   industryType = jsonObject44.getString("industryType");
                            }
                            if (jsonObject44.has("funtionalArea")) {
                                funtionalArea = jsonObject44.getString("funtionalArea");
                            }
                            if (jsonObject44.has("skills")) {
                                skills = jsonObject44.getString("skills");
                            }
                            if (jsonObject44.has("postedDate")) {
                                postedDate = jsonObject44.getString("postedDate");
                            }
                            if (jsonObject44.has("modifiedDate")) {
                                modifiedDate = jsonObject44.getString("modifiedDate");
                            }
                            if(jsonObject44.has("clientId")){
                            		clientId = jsonObject44.getString("clientId");
                            	}
                            if(jsonObject44.has("contactId")){
                         	   contactId = jsonObject44.getString("contactId");
                            	}
                            if(jsonObject44.has("jobCode")){
                         	   jobCode = jsonObject44.getString("jobCode");
                           	}
                            if(jsonObject44.has("noOfOpenings")){
                         	   noOfOpenings = jsonObject44.getLong("noOfOpenings");
                           	}
                            if(jsonObject44.has("experience")){
                         	   experience = jsonObject44.getString("experience");
                           	} 
                            if(jsonObject44.has("industry")){
                         	   industry = jsonObject44.getString("industry");
                            	}
                            if(jsonObject44.has("role")){
                         	   role = jsonObject44.getString("role");
                           	}
                            if(jsonObject44.has("expiredDate")){
                         	   expiredDate = jsonObject44.getString("expiredDate");
                           	}
                            if(jsonObject44.has("postedBy")){
                         	   postedBy = jsonObject44.getString("postedBy");
                           	}
                            if(jsonObject44.has("modifiedBy")){
                         	   modifiedBy = jsonObject44.getString("modifiedBy");
                           	}
                            if(jsonObject44.has("deleted")){
                         	   deleted = jsonObject44.getInt("deleted");
                           	}
                            jobsMap.put("clientId", clientId);
                            jobsMap.put("contactId", contactId);
                            jobsMap.put("jobCode", jobCode);
                            jobsMap.put("noOfOpenings", noOfOpenings);
                            jobsMap.put("jobCode", jobCode);
                            jobsMap.put("experience", experience);
                            jobsMap.put("industry", industry);
                            jobsMap.put("role", role);
                            jobsMap.put("expiredDate", expiredDate);
                            jobsMap.put("postedBy", postedBy);
                            jobsMap.put("modifiedBy", modifiedBy);
                            jobsMap.put("deleted", deleted);
                            jobsMap.put("postedDate", postedDate);
                            jobsMap.put("modifiedDate", modifiedDate);
                            jobsMap.put("experience", experience);
                            jobsMap.put("skills", skills);
                            jobsMap.put("funtionalArea", funtionalArea);
                            jobsMap.put("industryType", industryType);
                            jobsMap.put("location", location);
                            jobsMap.put("description", description);
                            jobsMap.put("ctc", ctc);
                            jobsMap.put("id", id);
                            jobsMap.put("name", name);

                            jobsarrat.put(jobsMap);

            }

            if (jsonarray.isNull(0)) {
         	   jobsMap.put("clientId", clientId);
                jobsMap.put("contactId", contactId);
                jobsMap.put("jobCode", jobCode);
                jobsMap.put("noOfOpenings", noOfOpenings);
                jobsMap.put("experience", experience);
                jobsMap.put("industry", industry);
                jobsMap.put("role", role);
                jobsMap.put("expiredDate", expiredDate);
                jobsMap.put("postedBy", postedBy);
                jobsMap.put("modifiedBy", modifiedBy);
                jobsMap.put("deleted", deleted);
                jobsMap.put("postedDate", postedDate);
                jobsMap.put("modifiedDate", modifiedDate);
                jobsMap.put("experience", experience);
                jobsMap.put("skills", skills);
                jobsMap.put("funtionalArea", funtionalArea);
                jobsMap.put("industryType", industryType);
                jobsMap.put("location", location);
                jobsMap.put("description", description);
                jobsMap.put("ctc", ctc);
                jobsMap.put("id", id);
                jobsMap.put("name", name);

                            jobsarrat.put(jobsMap);
            	            //array1.put(jobsMap);

            }
            
            mainjson.put("response", jobsarrat);
           return mainjson.toString();
            
            //array1.put(_source);
			/*jsonObjDocs.put("docs", jobsarrat);
			mainjson.put("response", jsonObjDocs);
			System.out.println("jsonObjResponse >> " + jsonObjResponse);
			return mainjson.toString();*/
}
			
			
	
//till date now

	// Mobile API 7 :--behalf of status  to check attach return data  jobs 29-Aug-2018
		
	@RequestMapping(value = "/ElasticAPI/attachstatus", method = { RequestMethod.GET })
    public @ResponseBody String jobAPI(@RequestParam("id") String objectId, @RequestParam("status") String status)
                  throws JSONException, URISyntaxException, MalformedURLException {

           JSONObject mainjson = new JSONObject();
           JSONArray jsonArray = new JSONArray();

           String urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:"
                        + objectId + ")AND(status:\"" + status + "\")&_source=objectId,jobId,jobName";

           URL urlattach = new URL(urlAttach);

           URI uriAttach = new URI(urlattach.getProtocol(), urlattach.getUserInfo(), urlattach.getHost(),
                        urlattach.getPort(), urlattach.getPath(), urlattach.getQuery(), urlAttach);

//         System.out.println("attach query..." + urlAttach);

           String jsonAttachData = restTemplate.getForObject(uriAttach, String.class);

           JSONObject hits = new JSONObject(jsonAttachData).getJSONObject("hits");
           JSONArray hitsArr = hits.getJSONArray("hits");

           for (int i = 0; i < hitsArr.length(); i++) {

                  String jobId = "";
                  String jobName = "";

                  JSONObject arrobj = (JSONObject) hitsArr.get(i);
                  JSONObject _source = arrobj.getJSONObject("_source");

                  jobId = _source.getString("jobId");
                  jobName = _source.getString("jobName");

                  String urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=id:"
                               + jobId;

                  URL Joburl = new URL(urlJob);

                  URI uriJob = new URI(Joburl.getProtocol(), Joburl.getUserInfo(), Joburl.getHost(), Joburl.getPort(),
                               Joburl.getPath(), Joburl.getQuery(), urlJob);

//                System.out.println("urlJob .." + urlJob);

                  String jsonJobData = restTemplate.getForObject(uriJob, String.class);

                  JSONObject jobHits = new JSONObject(jsonJobData).getJSONObject("hits");
                  JSONArray jobHitsArr = jobHits.getJSONArray("hits");

                  for (int j = 0; j < jobHitsArr.length(); j++) {

                        JSONObject arrobj1 = (JSONObject) jobHitsArr.get(j);
                        JSONObject _source1 = arrobj1.getJSONObject("_source");

                        JSONObject subJson = new JSONObject();

                        subJson.put("jobId", jobId);
                        subJson.put("jobName", jobName);

                        if (_source1.has("name"))
                               subJson.put("name", _source1.get("name"));
                        else
                               subJson.put("name", JSONObject.NULL);

                        if (_source1.has("experience"))
                               subJson.put("experience", _source1.get("experience"));
                        else
                               subJson.put("experience", JSONObject.NULL);

                        if (_source1.has("ctc"))
                               subJson.put("ctc", _source1.get("ctc"));
                        else
                               subJson.put("ctc", JSONObject.NULL);

                        if (_source1.has("industryType"))
                               subJson.put("industryType", _source1.get("industryType"));
                        else
                               subJson.put("industryType", JSONObject.NULL);

                        if (_source1.has("jobType"))
                               subJson.put("jobType", _source1.get("jobType"));
                        else
                               subJson.put("jobType", JSONObject.NULL);

                        if (_source1.has("funtionalArea"))
                               subJson.put("funtionalArea", _source1.get("funtionalArea"));
                        else
                               subJson.put("funtionalArea", JSONObject.NULL);

                        if (_source1.has("role"))
                               subJson.put("role", _source1.get("role"));
                        else
                               subJson.put("role", JSONObject.NULL);

                        if (_source1.has("description"))
                               subJson.put("description", _source1.get("description"));
                        else
                               subJson.put("description", JSONObject.NULL);

                        if (_source1.has("status"))
                               subJson.put("status", _source1.get("status"));
                        else
                               subJson.put("status", JSONObject.NULL);

                        jsonArray.put(subJson);

                  }
           }
           mainjson.put("response", jsonArray);

           return mainjson.toString();
    }

	
	/*@RequestMapping(value = "/ElasticAPI/attachstatus", method = { RequestMethod.GET })
    public @ResponseBody String esAttachstatus(@RequestParam("status") String statusParam,
                                    @RequestParam("jobid") String jobIds,
                                    @RequestParam(value = "search", required = false) String field,
                                    @RequestParam(value = "sort", required = false) String sort,
                                    @RequestParam(value = ("sortType"), required = false) String sortType)
                                    throws MalformedURLException, URISyntaxException, JSONException {

                    JSONObject Mainjson = new JSONObject();
                    JSONArray obj = new JSONArray();
                    // int start = perpage * (next);
                    String objectId = "";
                    String urlAttach = "";
                    String jsonAttachData = "";
                    String urlCandidate = "";
                    String jsonCandidateData = "";

                    JSONObject JobHits = new JSONObject();
                    JSONObject CandidateHits = new JSONObject();
                    JSONObject mainjson = new JSONObject();

                    urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(status:\""
                                                    + statusParam + "\")"+"(jobId:\""+ jobIds + "\")"+"&pretty=true&_source_includes=status,clientName,jobId";
                    URL urlAttachdata = new URL(urlAttach);
                    String nullFragment = null;
                    // System.out.println("urlJobdata >> "+urlJobdata);
                    URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
                                                    urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);

                    System.out.println("urlAttach >> " + urlAttach);
                    jsonAttachData = restTemplate.getForObject(uriAttach, String.class);

                    System.out.println("Json Attach Data.............. " + jsonAttachData);

                    JSONObject jsonObject = new JSONObject(jsonAttachData);
                    jsonObject = (JSONObject) jsonObject.get("_shards");

                    JSONObject jsonObject2 = new JSONObject(jsonAttachData);
                    jsonObject2 = (JSONObject) jsonObject2.get("hits");

                    JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");

                    JobHits.put("Hits", jsonarray.length());

                    JSONObject jsonObject4 = new JSONObject();
                    JSONObject jsonObject3 = new JSONObject();

                    JSONObject Hits = new JSONObject();
                    JSONObject object = new JSONObject();
                    Hits.put("hits", jsonarray.length());

                    List<String> objectIdList = new ArrayList<String>();

                    for (int n = 0; n < jsonarray.length(); n++) {

                                    Map<String, String> map = new HashMap<String, String>();

                                    jsonObject3 = (JSONObject) jsonarray.get(n);

                                    jsonObject4 = (JSONObject) jsonObject3.get("_source");
                                    System.out.println(" Source .........." + jsonObject4);

                                    if (jsonObject4.has("jobId")) {
                                                    objectId = jsonObject4.getString("jobId");
                                                    objectIdList.add(objectId);
                                    }

                    }

                    Set<String> s = new LinkedHashSet<String>(objectIdList);

                    objectIdList.clear();

                    objectIdList.addAll(s);

                    System.out.println("total Size....." + objectIdList.size());

                    for (int c = 0; c < objectIdList.size(); c++) {

                                    urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(id:\""
                                                                    + objectIdList.get(c)
                                                                    + "\")&pretty=true&_source_includes=ctc,name,funtionalArea,description,industry,role,experience,id";

                                    Map<String, JSONObject> Response = new HashMap<String, JSONObject>();

                                    String ctc = "";
                                    String name = "";
                                    String funtionalArea = "";
                                    String description = "";
                                    String industry = "";
                                    String role = "";
                                    String experience = "";
                                    String jobId = "";

                                    URL urlcandidatehdata = new URL(urlCandidate);
                                    URI uricandidates = new URI(urlcandidatehdata.getProtocol(), urlcandidatehdata.getUserInfo(),
                                                                    urlcandidatehdata.getHost(), urlcandidatehdata.getPort(), urlcandidatehdata.getPath(),
                                                                    urlcandidatehdata.getQuery(), urlCandidate);

                                    System.out.println("urlCandidate:::::::: " + urlCandidate);
                                    jsonCandidateData = restTemplate.getForObject(uricandidates, String.class);

                                    JSONObject jsonCand = new JSONObject(jsonCandidateData);
                                    jsonCand = (JSONObject) jsonCand.get("_shards");

                                    JSONObject jsonCand2 = new JSONObject(jsonCandidateData);
                                    jsonCand2 = (JSONObject) jsonCand2.get("hits");

                                    JSONArray jsonarrayCand = (JSONArray) jsonCand2.get("hits");

                                    CandidateHits.put("Hits", objectIdList.size());
                                    mainjson.put("candidate", CandidateHits);

                                    System.out.println("candidate Array Size...." + jsonarrayCand.length());
                                    if (jsonarrayCand.isNull(0) == false) {
                                                    JSONObject jsonCand3 = (JSONObject) jsonarrayCand.get(0);
                                                    System.out.println("Getting Object From Candiate Array.... >> " + jsonCand3);

                                                    // JSONObject jsonCand4=new JSONObject(jsonCandidateData);
                                                    JSONObject jsonCand4 = (JSONObject) jsonCand3.get("_source");
                                                    System.out.println("jsonCand4 >> " + jsonCand4);

                                                    if (jsonCand4.has("ctc")) {
                                                                    ctc = jsonCand4.getString("ctc");
                                                    } else {
                                                                    ctc = "";
                                                    }

                                                    if (jsonCand4.has("name")) {
                                                                    name = jsonCand4.getString("name");
                                                    } else {
                                                                    name = "";
                                                    }
                                                    if (jsonCand4.has("funtionalArea")) {
                                                                    funtionalArea = jsonCand4.getString("funtionalArea");
                                                    } else {
                                                                    funtionalArea = "";
                                                    }

                                                    if (jsonCand4.has("description")) {
                                                                    description = jsonCand4.getString("description");
                                                    } else {
                                                                    description = "";
                                                    }

                                                    if (jsonCand4.has("industry")) {
                                                                    industry = jsonCand4.getString("industry");
                                                    } else {
                                                                    industry = "";
                                                    }
                                                    if (jsonCand4.has("role")) {
                                                                    role = jsonCand4.getString("role");
                                                    } else {
                                                                    role = "";
                                                    }

                                                    if (jsonCand4.has("experience")) {
                                                                    experience = jsonCand4.getString("experience");
                                                    } else {
                                                                    experience = "";
                                                    }
                                                    if (jsonCand4.has("jobId")) {
                                                                    jobId = jsonCand4.getString("jobId");
                                                    } else {
                                                                    jobId = "";
                                                    }
                                                    jsonCand4.put("ctc", ctc);
                                                    jsonCand4.put("name", name);
                                                    jsonCand4.put("funtionalArea", funtionalArea);
                                                    jsonCand4.put("description", description);
                                                    jsonCand4.put("industry", industry);
                                                    jsonCand4.put("jobId", jobId);
                                                    jsonCand4.put("experience", experience);
                                                    jsonCand4.put("role", role);
                                                    jsonCand4.accumulate("JobTypeStatus", statusParam);
                                                    Response.put("data", jsonCand4);
                                                    
                                                    * JobTypeStatus.put("JobTypeStatus", statusParam);
                                                    * 
                                                     * Response.put("JobTypeStatus", JobTypeStatus);
                                                    

                                                    obj.put(jsonCand4);

                                    }

                    }
                    Mainjson.put("response", obj);

                    return Mainjson.toString();
    }
*/
	
	
	

	//8. Mobile API Resumeview details
		
		@RequestMapping(value = "/ElasticAPI/resumeview", method = { RequestMethod.GET })
	    public @ResponseBody String resumeView(@RequestParam("companyName") String comapany,
	                                    @RequestParam("Companyid") String comapanyId,

	                                    @RequestParam(value = "search", required = false) String field,
	                                    @RequestParam(value = "sort", required = false) String sort,
	                                    @RequestParam(value = ("sortType"), required = false) String sortType)
	                                    throws MalformedURLException, URISyntaxException, JSONException {
	                    JSONObject jsonsource = new JSONObject();
	                    JSONObject Mainjson = new JSONObject();
	                    JSONArray obj = new JSONArray();
	                    // int start = perpage * (next);
	                    String objectId = "";
	                    String jobNames = "";
	                    String status = "";
	                    String anchor = "";
	                    String urlAttach = "";
	                    String jsonAttachData = "";
	                    String urlCandidate = "";
	                    String jsonCandidateData = "";

	                    String JsonSimilardata = "";

	                    JSONObject JobHits = new JSONObject();
	                    JSONObject CandidateHits = new JSONObject();
	                    JSONObject mainjson = new JSONObject();

	                    urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(clientName:\""
	                                                    + comapany + "\")AND(clientId:\"" + comapanyId
	                                                    + "\")&pretty=true&_source_includes=status,clientName,jobId,anchor";
	                    URL urlAttachdata = new URL(urlAttach);
	                    String nullFragment = null;
	                    // System.out.println("urlJobdata >> "+urlJobdata);
	                    URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
	                                                    urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);

	                    System.out.println("urlAttach >> " + urlAttach);
	                    jsonAttachData = restTemplate.getForObject(uriAttach, String.class);

	                   // System.out.println("Json Attach Data.............. " + jsonAttachData);

	                    JSONObject jsonObject = new JSONObject(jsonAttachData);
	                    jsonObject = (JSONObject) jsonObject.get("_shards");

	                    JSONObject jsonObject2 = new JSONObject(jsonAttachData);
	                    jsonObject2 = (JSONObject) jsonObject2.get("hits");

	                    JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");

	                    JobHits.put("Hits", jsonarray.length());

	                    JSONObject jsonObject4 = new JSONObject();
	                    JSONObject jsonObject3 = new JSONObject();

	                    JSONObject Hits = new JSONObject();
	                    JSONObject object = new JSONObject();
	                    Hits.put("hits", jsonarray.length());

	                    List<String> objectIdList = new ArrayList<String>();

	                    for (int n = 0; n < jsonarray.length(); n++) {

	                                    Map<String, String> map = new HashMap<String, String>();

	                                    jsonObject3 = (JSONObject) jsonarray.get(n);

	                                    jsonObject4 = (JSONObject) jsonObject3.get("_source");
	                                    System.out.println(" Source .........." + jsonObject4);

	                                    if (jsonObject4.has("jobId")) {
	                                                    objectId = jsonObject4.getString("jobId");
	                                                    objectIdList.add(objectId);
	                                    }

	                                    if (jsonObject4.has("status")) {
	                                                    status = jsonObject4.getString("status");

	                                    }

	                                    if (jsonObject4.has("anchor")) {
	                                                    anchor = jsonObject4.getString("anchor");

	                                    }

	                    }

	                    Set<String> s = new LinkedHashSet<String>(objectIdList);

	                    objectIdList.clear();

	                    objectIdList.addAll(s);

	                    System.out.println("total Size....." + objectIdList.size());

	                    urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(id:\""
	                                                    + objectIdList.get(0)
	                                                    + "\")&pretty=true&_source_includes=ctc,name,funtionalArea,description,industry,role,experience,jobCode,location,education,postedDate,modifiedDate,skills,noOfOpenings";

	                    Map<String, JSONObject> Response = new HashMap<String, JSONObject>();
	                    String funtionalArea = "";
	                    String ctc = "";
	                    String description = "";
	                    String industry = "";
	                    String role = "";
	                    String experience = "";
	                    String jobCode = "";
	                    String location = "";
	                    String education = "";
	                    String postedDate = "";
	                    String modifiedDate = "";
	                    String skills = "";
	                    String noOfOpenings = "";

	                    URL urlcandidatehdata = new URL(urlCandidate);
	                    URI uricandidates = new URI(urlcandidatehdata.getProtocol(), urlcandidatehdata.getUserInfo(),
	                                                    urlcandidatehdata.getHost(), urlcandidatehdata.getPort(), urlcandidatehdata.getPath(),
	                                                    urlcandidatehdata.getQuery(), urlCandidate);

	                    System.out.println("urlCandidate:::::::: " + urlCandidate);
	                    jsonCandidateData = restTemplate.getForObject(uricandidates, String.class);

	                    JSONObject jsonCand = new JSONObject(jsonCandidateData);
	                    jsonCand = (JSONObject) jsonCand.get("_shards");

	                    JSONObject jsonCand2 = new JSONObject(jsonCandidateData);
	                    jsonCand2 = (JSONObject) jsonCand2.get("hits");

	                    JSONArray jsonarrayCand = (JSONArray) jsonCand2.get("hits");

	                    CandidateHits.put("Hits", objectIdList.size());
	                    mainjson.put("candidate", CandidateHits);

	                    System.out.println("candidate Array Size...." + jsonarrayCand.length());

	                    if (jsonarrayCand.isNull(0) == false) {
	                                    JSONObject jsonCand3 = (JSONObject) jsonarrayCand.get(0);
	                                    //System.out.println("Getting Object From Candiate Array.... >> " + jsonCand3);

	                                    jsonsource = (JSONObject) jsonCand3.get("_source");

	                                    if (jsonsource.has("name")) {

	                                                    jobNames = jsonsource.getString("name");

	                                                    System.out.println("job name......." + jobNames);

	                                    }

	                                    if (jsonsource.has("funtionalArea")) {

	                                                    funtionalArea = jsonsource.getString("funtionalArea");

	                                    } else {
	                                                    funtionalArea = "";
	                                    }

	                                    if (jsonsource.has("ctc")) {

	                                                    ctc = jsonsource.getString("ctc");

	                                    } else {
	                                                    ctc = "";
	                                    }

	                                    if (jsonsource.has("description")) {

	                                                    description = jsonsource.getString("description");

	                                    } else {
	                                                    description = "";
	                                    }

	                                    if (jsonsource.has("industry")) {

	                                                    industry = jsonsource.getString("industry");

	                                    } else {
	                                                    industry = "";
	                                    }

	                                    if (jsonsource.has("role")) {

	                                                    role = jsonsource.getString("role");

	                                    } else {
	                                                    role = "";
	                                    }

	                                    if (jsonsource.has("experience")) {

	                                                    experience = jsonsource.getString("experience");

	                                    } else {
	                                                    experience = "";
	                                    }
	                                    if (jsonsource.has("jobCode")) {

	                                                    jobCode = jsonsource.getString("jobCode");

	                                    } else {
	                                                    jobCode = "";
	                                    }

	                                    if (jsonsource.has("location")) {

	                                                    location = jsonsource.getString("location");

	                                    } else {
	                                                    location = "";
	                                    }

	                                    if (jsonsource.has("education")) {

	                                                    education = jsonsource.getString("education");

	                                    } else {
	                                                    education = "";
	                                    }
	                                    if (jsonsource.has("postedDate")) {

	                                                    postedDate = jsonsource.getString("postedDate");

	                                    } else {
	                                                    postedDate = "";
	                                    }

	                                    if (jsonsource.has("modifiedDate")) {

	                                                    modifiedDate = jsonsource.getString("modifiedDate");

	                                    } else {
	                                                    modifiedDate = "";
	                                    }

	                                    if (jsonsource.has("skills")) {

	                                                    skills = jsonsource.getString("skills");

	                                    } else {
	                                                    skills = "";
	                                    }

	                                    if (jsonsource.has("noOfOpenings")) {

	                                                    noOfOpenings = jsonsource.getString("noOfOpenings");

	                                    } else {
	                                                    noOfOpenings = "";
	                                    }

	                                   // System.out.println("jsonCand4 >> " + jsonsource);
	                                    jsonsource.put("status", status);

	                                    jsonsource.put("ctc", ctc);
	                                    jsonsource.put("description", description);
	                                    jsonsource.put("industry", industry);
	                                    jsonsource.put("role", role);
	                                    jsonsource.put("experience", experience);

	                                    jsonsource.put("jobCode", jobCode);
	                                    jsonsource.put("location", location);
	                                    jsonsource.put("education", education);

	                                    jsonsource.put("postedDate", postedDate);
	                                    jsonsource.put("modifiedDate", modifiedDate);
	                                    jsonsource.put("skills", skills);
	                                    jsonsource.put("noOfOpenings", noOfOpenings);

	                                    Response.put("data", jsonsource);

	                                    obj.put(jsonsource);

	                    }

	                    if (jobNames.contains("&")) {
	                                    jobNames = jobNames.replace("&", "");
	                    }

	                    if (jobNames != null) {
	                                    String urlSimiliar = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(name:\""
	                                                                    + jobNames + "\")&pretty=true&_source_includes=id,location,name";

	                                    JSONObject jsonsource1 = new JSONObject();
	                                    URL urlsimiliar = new URL(urlSimiliar);
	                                    URI urisimiliar = new URI(urlsimiliar.getProtocol(), urlsimiliar.getUserInfo(), urlsimiliar.getHost(),
	                                                                    urlsimiliar.getPort(), urlsimiliar.getPath(), urlsimiliar.getQuery(), urlSimiliar);

	                                    String similarid = "";
	                                    String similarlocation = "";
	                                    String similarname = "";
	                                    System.out.println("urlsimilar:::::::: " + urlSimiliar);

	                                    JsonSimilardata = restTemplate.getForObject(urlSimiliar, String.class);

	                                    JSONObject jsonSimilar = new JSONObject(JsonSimilardata);
	                                    jsonCand = (JSONObject) jsonSimilar.get("_shards");

	                                    JSONObject jsonCand23 = new JSONObject(JsonSimilardata);
	                                    jsonCand2 = (JSONObject) jsonCand23.get("hits");

	                                    JSONArray jsonarrayCand1 = (JSONArray) jsonCand2.get("hits");

	                                    Map<String, JSONArray> similarMap1 = new HashMap<String, JSONArray>();
	                                    JSONObject similarMap = new JSONObject();

	                                    JSONArray similarJobArray1 = new JSONArray();
	                                    if (jsonarrayCand1.isNull(0) == false) {

	                                                    for (int i = 0; i < jsonarrayCand1.length(); i++) {
	                                                                    JSONObject jsonCand3 = (JSONObject) jsonarrayCand1.get(i);

	                                                                    jsonsource1 = (JSONObject) jsonCand3.get("_source");
	                                                                    System.out.println("Similar jobs......" + jsonsource1);
	                                                                    if (jsonsource1.has("similarid")) {

	                                                                                    similarid = jsonsource1.getString("similarid");

	                                                                    } else {
	                                                                                    similarid = "";
	                                                                    }

	                                                                    if (jsonsource1.has("similarlocation")) {

	                                                                                    similarlocation = jsonsource1.getString("similarlocation");

	                                                                    } else {
	                                                                                    similarlocation = "";
	                                                                    }

	                                                                    if (jsonsource1.has("similarname")) {

	                                                                                    similarname = jsonsource1.getString("similarname");

	                                                                    } else {
	                                                                                    similarname = "";
	                                                                    }
	                                                                    jsonsource1.put("similarname", similarname);
	                                                                    jsonsource1.put("similarlocation", similarlocation);
	                                                                    jsonsource1.put("similarid", similarid);
	                                                                    similarJobArray1.put(jsonsource1);
	                                                                    similarMap1.put("SimilarJobs", similarJobArray1);

	                                                    }

	                                                    obj.put(similarMap1);
	                                    }

	                    }
	                    Mainjson.put("response", obj);

	                    return Mainjson.toString();
	    }

		
		
	
	
	
	// 9. API Mobile Candidate Profile.
  
		@RequestMapping(value = "/ElasticAPI/candprofile1", method = { RequestMethod.GET })
	       public @ResponseBody String test(@RequestParam("id") String UserId,
	                     @RequestParam(value = ("sortType"), required = false) String sortType)
	                     throws MalformedURLException, URISyntaxException, JSONException {
	              String ids = "";
	              String name = "";
	              String email = "";
	              JSONArray alternateEmail = new JSONArray();
	              String birthdate = "";
	              String mobileNumber = "";
	              String lastModified = "";
	              // String education = "";
	              String ug = "";
	              String degree = "";
	              String degreeType = "";
	              String course = "";
	              String institute = "";
	              String universityOrBoard = "";
	              String city = "";
	              String fromMonth = "";
	              String fromYear = "";
	              String toMonth = "";
	              String toYear = "";
	              String percentage = "";
	              String pg = "";
	              String doctorate = "";
	              String diploma = "";
	              String twelveth = "";
	              String tenth = "";
	              String address = "";
	              String permanentAddress = "";
	              String country = "";
	              String state = "";
	              String street = "";
	              String pincode = "";
	              String location = "";
	              String currentAddress = "";
	              String preferredLocation = "";
	              String ResumeName = "";
	              String Resume = "";
	              String salary = "";
	              String currentCTCType = "";
	              String currentCTC = "";
	              String negotiableCTC = "";
	              String expectedCTCType = "";
	              String expectedCTC = "";
	              String takeHome = "";
	              String fixed = "";
	              String employment = "";
	              String current = "";
	              String companyName = "";
	              String designation = "";
	              String first_name = "";
	              String middle_name = "";
	              String last_name = "";
	              Integer age = null;
	              String gender = "";
	              String picture = "";
	              String profile = "";
	              String website = "";
	              String jobType = "";
	              String employmentType = "";
	              boolean immediateJoiningAvailabilityOrNegotiable = false;
	              String minimumDaysRequired = "";
	              String salutation = "";
	              boolean visibility = false;

	              JSONArray alternateMobileNumber = new JSONArray();

	              String telePhone = "";
	              String officePhone = "";
	              String religion = "";
	              JSONArray family = new JSONArray();
	              String maritalStatus = "";
	              JSONArray connectSocialNetwork = new JSONArray();
	              String createdDate = "";
	              String lastModifiedBy = "";
	              String aadharCardNo = "";
	              String passportNo = "";
	              String passportValidity = "";
	              String panNo = "";
	              String areaOfSpecialization = "";
	              String otherInterest = "";
	              String category = "";
	              boolean confidential = false;
	              String employmentStatus = "";
	              String nationality = "";
	              String exNationality = "";
	              String experiencedIndustry = "";
	              String preferredIndustry = "";
	              String experiencedFunctionalArea = "";
	              String preferredFunctionalArea = "";
	              String language = "";
	              String notes = "";
	              String noticePeriod = "";
	              String reasonForRelocate = "";
	              String preferredDistance = "";
	              String physicallyChallenged = "";
	              String reasonForLeaving = "";
	              String willingToRelocate = "";
	              String willingToChangeJob = "";
	              String resumeHeadLine = "";
	              boolean experienced = false;
	              boolean fresher = false;
	              String shiftWork = "";
	              String skillSummary = "";
	              String summary = "";
	              String federated = "";
	              String officePhoneExtention = "";
	              boolean isMobileNumberVerified = false;
	              String locale = "";
	              String isCurrent = "";
	              String desc = "";
	              String workLocation = "";
	              String role = "";
	              String level = "";
	              String teamSize = "";
	              // String previous = "";
	              String experience = "";
	              Integer months;
	              String TotalExp = "";
	              Integer years;
	              String createdBy = "";
	              String username = "";
	              JSONObject Mainjson = new JSONObject();
	              JSONArray obj = new JSONArray();
	              // int start = perpage * (next);
	              String objectId = "";
	              String jobNames = "";
	              String status = "";
	              String anchor = "";
	              String urlAttach = "";
	              String jsonAttachData = "";
	              String urlCandidate = "";
	              String jsonCandidateData = "";

	              String JsonSimilardata = "";

	              JSONObject JobHits = new JSONObject();
	              JSONObject CandidateHits = new JSONObject();
	              JSONObject mainjson = new JSONObject();
	              Map<String, String> SkillsMap = new HashMap<String, String>();

	              JSONArray SkillsObj = new JSONArray();
	              JSONArray achievementObj = new JSONArray();
	              JSONArray familyObj = new JSONArray();
	              JSONArray connectSocialObj = new JSONArray();
	              JSONArray refralObj = new JSONArray();
	              JSONArray certificateObj = new JSONArray();
	              JSONArray projectObj = new JSONArray();
	              urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""
	                           + UserId + "\")&pretty=true&_source=status";// ,resumeName,resume

	              URL urlAttachdata = new URL(urlAttach);
	              String nullFragment = null;
	              // System.out.println("urlJobdata >> "+urlJobdata);
	              URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
	                           urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);

	              System.out.println("urlAttachssssss >> " + urlAttach);
	              jsonAttachData = restTemplate.getForObject(urlAttach, String.class);

	              System.out.println("Json Attach Data.............. " + jsonAttachData);

	              JSONObject jsonObject = new JSONObject(jsonAttachData);
	              jsonObject = (JSONObject) jsonObject.get("_shards");
	              System.out.println("shards........" + jsonObject);

	              JSONObject jsonObject2 = new JSONObject(jsonAttachData);
	              jsonObject2 = (JSONObject) jsonObject2.get("hits");
	              System.out.println("hits,,,,,,,,," + jsonObject2);

	              JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");
	              System.out.println("Hits...........??????? >> " + jsonarray);

	              int appliedcount = 0;
	              int shortlistcount = 0;
	              int Sheduledcount = 0;
	              int Gotselectedcount = 0;
	              for (int n = 0; n < jsonarray.length(); n++) {

	                     Map<String, String> map = new HashMap<String, String>();

	                     JSONObject jsonObject3 = (JSONObject) jsonarray.get(n);

	                     JSONObject jsonObject4 = (JSONObject) jsonObject3.get("_source");

	                     if (jsonObject4.has("status")) {

	                           if (jsonObject4.getString("status").equals("Applied")) {

	                                  appliedcount = appliedcount + 1;
	                           }

	                           if (jsonObject4.getString("status").equals("Shortlisted")) {

	                                  shortlistcount = shortlistcount + 1;

	                           }

	                           if (jsonObject4.getString("status").equals("Scheduled")) {

	                                  Sheduledcount = Sheduledcount + 1;

	                           }

	                           if (jsonObject4.getString("status").equals("GotSelect")) {

	                                  Gotselectedcount = Gotselectedcount + 1;

	                           }

	                     }

	              }

	              String candidateProfileUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
	                           + UserId + "\")&pretty=true";
	              JSONArray skillList = new JSONArray();
	              JSONArray project = new JSONArray();
	              JSONArray achievement = new JSONArray();
	              JSONArray referal = new JSONArray();

	              JSONArray previouss = new JSONArray();
	              JSONArray certificates = new JSONArray();

	              Map<String, String> candijson = new HashMap<String, String>();

	              Map<String, JSONArray> Skills = new HashMap<String, JSONArray>();
	              Map<String, JSONArray> refral = new HashMap<String, JSONArray>();
	              Map<String, JSONArray> projects = new HashMap<String, JSONArray>();
	              Map<String, JSONArray> map = new HashMap<String, JSONArray>();
	              Map<String, JSONObject> map1 = new HashMap<String, JSONObject>();
	              Map<String, JSONArray> achievements = new HashMap<String, JSONArray>();
	              Map<String, JSONArray> alternateEmailmap = new HashMap<String, JSONArray>();

	              Map<String, JSONArray> previous = new HashMap<String, JSONArray>();
	              Map<String, JSONArray> certificatess = new HashMap<String, JSONArray>();

	              URL urlcandiateProfile = new URL(candidateProfileUrl);

	              // System.out.println("urlJobdata >> "+urlJobdata);
	              URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                           urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                           urlcandiateProfile.getQuery(), candidateProfileUrl);

	              System.out.println("urlcandidateProfileUrl >> " + candidateProfileUrl);

	              jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	              JSONObject jsonCand = new JSONObject(jsonCandidateData);
	              jsonCand = (JSONObject) jsonCand.get("_shards");

	              JSONObject jsonCand2 = new JSONObject(jsonCandidateData);
	              jsonCand2 = (JSONObject) jsonCand2.get("hits");

	              JSONArray jsonarrayCand = (JSONArray) jsonCand2.get("hits");
	              System.out.println("Candidate Hits Array..... >> " + jsonarrayCand);

	              mainjson.put("candidate", CandidateHits);

	              if (jsonarrayCand.isNull(0) == false) {
	                     JSONObject jsonCand3 = (JSONObject) jsonarrayCand.get(0);
	                     System.out.println("Getting Object From Candiate Array.... >> " + jsonCand3);

	                     // JSONObject jsonCand4=new JSONObject(jsonCandidateData);
	                     JSONObject jsonCand4 = (JSONObject) jsonCand3.get("_source");
	                     System.out.println("jsonCand4 >> " + jsonCand4);

	                     if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
	                           preferredLocation = jsonCand4.getString("preferredLocation");
	                     }

	                     if (jsonCand4.has("resumeName") && !jsonCand4.get("resumeName").equals(null)) {
	                           ResumeName = jsonCand4.getString("resumeName");
	                     }

	                     if (jsonCand4.has("resume") && !jsonCand4.get("resume").equals(null)) {
	                           Resume = jsonCand4.getString("resume");
	                     }

	                     if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
	                           createdBy = jsonCand4.getString("createdBy");
	                     }
	                     if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
	                           username = jsonCand4.getString("username");
	                     }
	                     if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
	                           ids = jsonCand4.getString("id");
	                     }
	                     if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
	                           name = jsonCand4.getString("name");

	                     }
	                     if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
	                           email = jsonCand4.getString("email");
	                     }
	                     if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
	                           birthdate = jsonCand4.getString("birthdate");
	                     }
	                     if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
	                           mobileNumber = jsonCand4.getString("mobileNumber");
	                     }
	                     // ...................

	                     if (jsonCand4.has("first_name") && !jsonCand4.get("first_name").equals(null)) {
	                           first_name = jsonCand4.getString("first_name");

	                     }

	                     if (jsonCand4.has("middle_name") && !jsonCand4.get("middle_name").equals(null)) {
	                           middle_name = (String) jsonCand4.get("middle_name");
	                     }

	                     if (jsonCand4.has("last_name") && !jsonCand4.get("last_name").equals(null)) {
	                           last_name = jsonCand4.getString("last_name");

	                     }

	                     if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
	                           alternateEmail = (JSONArray) jsonCand4.get("alternateEmail");

	                     }

	                     if (jsonCand4.has("age") && !jsonCand4.get("age").equals(null)) {

	                           age = (Integer) jsonCand4.get("age");
	                     }

	                     if (jsonCand4.has("gender") && !jsonCand4.get("gender").equals(null)) {
	                           gender = jsonCand4.getString("gender");
	                     }

	                     if (jsonCand4.has("picture") && !jsonCand4.get("picture").equals(null)) {
	                           picture = jsonCand4.getString("picture");
	                     }

	                     if (jsonCand4.has("profile") && !jsonCand4.get("profile").equals(null)) {
	                           profile = jsonCand4.getString("profile");
	                     }

	                     if (jsonCand4.has("website") && !jsonCand4.get("website").equals(null)) {
	                           website = jsonCand4.getString("website");
	                     }

	                     if (jsonCand4.has("jobType") && !jsonCand4.get("jobType").equals(null)) {
	                           jobType = jsonCand4.getString("jobType");
	                     }

	                     if (jsonCand4.has("employmentType") && !jsonCand4.get("employmentType").equals(null)) {
	                           employmentType = jsonCand4.getString("employmentType");
	                     }

	                     if (jsonCand4.has("immediateJoiningAvailabilityOrNegotiable")
	                                  && !jsonCand4.get("immediateJoiningAvailabilityOrNegotiable").equals(null)) {
	                           immediateJoiningAvailabilityOrNegotiable = (boolean) jsonCand4
	                                         .get("immediateJoiningAvailabilityOrNegotiable");

	                     }

	                     if (jsonCand4.has("minimumDaysRequired") && !jsonCand4.get("minimumDaysRequired").equals(null)) {
	                           minimumDaysRequired = jsonCand4.getString("minimumDaysRequired");
	                     }

	                     if (jsonCand4.has("salutation") && !jsonCand4.get("salutation").equals(null)) {
	                           salutation = jsonCand4.getString("salutation");
	                     }

	                     if (jsonCand4.has("visibility") && !jsonCand4.get("visibility").equals(null)) {
	                           visibility = (boolean) jsonCand4.get("visibility");
	                     }

	                     if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
	                           mobileNumber = jsonCand4.getString("mobileNumber");
	                     }

	                     if (jsonCand4.has("alternateMobileNumber") && !jsonCand4.get("alternateMobileNumber").equals(null)) {
	                           alternateMobileNumber = (JSONArray) jsonCand4.get("alternateMobileNumber");
	                     }

	                     if (jsonCand4.has("telePhone") && !jsonCand4.get("telePhone").equals(null)) {
	                           telePhone = jsonCand4.getString("telePhone");
	                     }

	                     if (jsonCand4.has("officePhone") && !jsonCand4.get("officePhone").equals(null)) {
	                           officePhone = jsonCand4.getString("officePhone");
	                     }

	                     if (jsonCand4.has("officePhoneExtention") && !jsonCand4.get("officePhoneExtention").equals(null)) {
	                           officePhoneExtention = jsonCand4.getString("officePhoneExtention");
	                     }

	                     if (jsonCand4.has("isMobileNumberVerified") && !jsonCand4.get("isMobileNumberVerified").equals(null)) {
	                           isMobileNumberVerified = (boolean) jsonCand4.get("isMobileNumberVerified");
	                     }

	                     if (jsonCand4.has("locale") && !jsonCand4.get("locale").equals(null)) {
	                           locale = jsonCand4.getString("locale");
	                     }

	                     if (jsonCand4.has("religion") && !jsonCand4.get("religion").equals(null)) {
	                           religion = jsonCand4.getString("religion");
	                     }

	                     if (jsonCand4.has("maritalStatus") && !jsonCand4.get("maritalStatus").equals(null)) {
	                           maritalStatus = jsonCand4.getString("maritalStatus");
	                     }

	                     if (jsonCand4.has("createdDate") && !jsonCand4.get("createdDate").equals(null)) {
	                           createdDate = jsonCand4.getString("createdDate");
	                     }

	                     if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
	                           lastModified = jsonCand4.getString("lastModified");
	                     }

	                     if (jsonCand4.has("aadharCardNo") && !jsonCand4.get("aadharCardNo").equals(null)) {
	                           aadharCardNo = jsonCand4.getString("aadharCardNo");
	                     }

	                     if (jsonCand4.has("passportNo") && !jsonCand4.get("passportNo").equals(null)) {
	                           passportNo = jsonCand4.getString("passportNo");
	                     }
	                     if (jsonCand4.has("passportValidity") && !jsonCand4.get("passportValidity").equals(null)) {
	                           passportValidity = jsonCand4.getString("passportValidity");
	                     }
	                     if (jsonCand4.has("panNo") && !jsonCand4.get("panNo").equals(null)) {
	                           panNo = jsonCand4.getString("panNo");
	                     }

	                     if (jsonCand4.has("areaOfSpecialization") && !jsonCand4.get("areaOfSpecialization").equals(null)) {
	                           areaOfSpecialization = jsonCand4.getString("areaOfSpecialization");
	                     }

	                     if (jsonCand4.has("otherInterest") && !jsonCand4.get("otherInterest").equals(null)) {
	                           otherInterest = jsonCand4.getString("otherInterest");
	                     }

	                     if (jsonCand4.has("category") && !jsonCand4.get("category").equals(null)) {
	                           category = jsonCand4.getString("category");
	                     }

	                     if (jsonCand4.has("confidential") && !jsonCand4.get("confidential").equals(null)) {
	                           confidential = (boolean) jsonCand4.get("confidential");
	                     }

	                     if (jsonCand4.has("employmentStatus") && !jsonCand4.get("employmentStatus").equals(null)) {
	                           employmentStatus = jsonCand4.getString("employmentStatus");
	                     }

	                     if (jsonCand4.has("nationality") && !jsonCand4.get("nationality").equals(null)) {
	                           nationality = jsonCand4.getString("nationality");
	                     }

	                     if (jsonCand4.has("exNationality") && !jsonCand4.get("exNationality").equals(null)) {
	                           exNationality = jsonCand4.getString("exNationality");
	                     }

	                     if (jsonCand4.has("experiencedIndustry") && !jsonCand4.get("experiencedIndustry").equals(null)) {
	                           experiencedIndustry = jsonCand4.getString("experiencedIndustry");

	                     }

	                     if (jsonCand4.has("preferredIndustry") && !jsonCand4.get("preferredIndustry").equals(null)) {
	                           preferredIndustry = jsonCand4.getString("preferredIndustry");
	                     }

	                     if (jsonCand4.has("experiencedFunctionalArea")
	                                  && !jsonCand4.get("experiencedFunctionalArea").equals(null)) {
	                           experiencedFunctionalArea = jsonCand4.getString("experiencedFunctionalArea");
	                     }

	                     if (jsonCand4.has("preferredFunctionalArea") && !jsonCand4.get("preferredFunctionalArea").equals(null)) {
	                           preferredFunctionalArea = jsonCand4.getString("preferredFunctionalArea");
	                     }

	                     if (jsonCand4.has("language") && !jsonCand4.get("language").equals(null)) {
	                           language = jsonCand4.getString("language");
	                     }

	                     if (jsonCand4.has("notes") && !jsonCand4.get("notes").equals(null)) {
	                           notes = jsonCand4.getString("notes");
	                     }

	                     if (jsonCand4.has("noticePeriod") && !jsonCand4.get("noticePeriod").equals(null)) {
	                           noticePeriod = jsonCand4.getString("noticePeriod");
	                     }

	                     if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
	                           preferredLocation = jsonCand4.getString("preferredLocation");
	                     }

	                     if (jsonCand4.has("preferredDistance") && !jsonCand4.get("preferredDistance").equals(null)) {
	                           preferredDistance = jsonCand4.getString("preferredDistance");
	                     }

	                     if (jsonCand4.has("physicallyChallenged") && !jsonCand4.get("physicallyChallenged").equals(null)) {
	                           physicallyChallenged = jsonCand4.getString("physicallyChallenged");
	                     }

	                     if (jsonCand4.has("reasonForLeaving") && !jsonCand4.get("reasonForLeaving").equals(null)) {
	                           reasonForLeaving = jsonCand4.getString("reasonForLeaving");
	                     }

	                     if (jsonCand4.has("reasonForRelocate") && !jsonCand4.get("reasonForRelocate").equals(null)) {
	                           reasonForRelocate = jsonCand4.getString("reasonForRelocate");
	                     }

	                     if (jsonCand4.has("willingToRelocate") && !jsonCand4.get("willingToRelocate").equals(null)) {
	                           willingToRelocate = jsonCand4.getString("willingToRelocate");
	                     }

	                     if (jsonCand4.has("willingToChangeJob") && !jsonCand4.get("willingToChangeJob").equals(null)) {
	                           willingToChangeJob = jsonCand4.getString("willingToChangeJob");
	                     }
	                     if (jsonCand4.has("resumeHeadLine") && !jsonCand4.get("resumeHeadLine").equals(null)) {
	                           resumeHeadLine = jsonCand4.getString("resumeHeadLine");
	                     }
	                     if (jsonCand4.has("experienced") && !jsonCand4.get("experienced").equals(null)) {
	                           experienced = (boolean) jsonCand4.get("experienced");
	                     }

	                     if (jsonCand4.has("fresher") && !jsonCand4.get("fresher").equals(null)) {
	                           fresher = (boolean) jsonCand4.get("fresher");
	                     }

	                     if (jsonCand4.has("shiftWork") && !jsonCand4.get("shiftWork").equals(null)) {
	                           shiftWork = jsonCand4.getString("shiftWork");
	                     }
	                     if (jsonCand4.has("skillSummary") && !jsonCand4.get("skillSummary").equals(null)) {
	                           skillSummary = jsonCand4.getString("skillSummary");
	                     }
	                     if (jsonCand4.has("summary") && !jsonCand4.get("summary").equals(null)) {
	                           summary = jsonCand4.getString("summary");
	                     }
	                     if (jsonCand4.has("federated") && !jsonCand4.get("federated").equals(null)) {
	                           federated = jsonCand4.getString("federated");
	                     }
	                     // ...............................................................................................
	                     String skillTest = "";
	                     String skillfromYear = "";
	                     String skillEXP = "";
	                     String skillfromMonth = "";
	                     String skilltoYear = "";
	                     String skilltoMonth = "";
	                     if (jsonCand4.has("skills")) {
	                           JSONObject skillobject = new JSONObject();

	                           skillList = (JSONArray) jsonCand4.get("skills");

	                           for (int i = 0; i < skillList.length(); i++) {

	                                  skillobject = (JSONObject) skillList.get(i);

	                                  if (skillobject.has("text")) {
	                                         skillTest = (String) skillobject.get("text");
	                                  }

	                                  if (skillobject.has("experience")) {
	                                         skillEXP = (String) skillobject.get("experience");
	                                  }

	                                  if (skillobject.has("fromMonth")) {
	                                         skillfromMonth = (String) skillobject.get("fromMonth");
	                                  }

	                                  if (skillobject.has("fromYear")) {
	                                         skillfromYear = (String) skillobject.get("fromYear");
	                                  }
	                                  if (skillobject.has("toMonth")) {
	                                         skilltoMonth = (String) skillobject.get("toMonth");
	                                  }
	                                  if (skillobject.has("toYear")) {
	                                         skilltoYear = (String) skillobject.get("toYear");
	                                  }

	                                  SkillsMap.put("text", skillTest);

	                                  SkillsMap.put("experience", skillEXP);

	                                  SkillsMap.put("fromMonth", skillfromMonth);

	                                  SkillsMap.put("fromYear", skillfromYear);

	                                  SkillsMap.put("toMonth", skilltoMonth);
	                                  SkillsMap.put("toYear", skilltoYear);

	                                  SkillsObj.put(SkillsMap);
	                           }

	                           System.out.println("skill......" + skillList);
	                     }

	                     else {
	                           SkillsMap.put("text", skillTest);

	                           SkillsMap.put("experience", skillEXP);

	                           SkillsMap.put("fromMonth", skillfromMonth);

	                           SkillsMap.put("fromYear", skillfromYear);

	                           SkillsMap.put("toMonth", skilltoMonth);
	                           SkillsMap.put("toYear", skilltoYear);

	                            SkillsObj.put(SkillsMap);
	                     }

	                     String connectSocialNetworkname = "";
	                     String connectSocialNetworkurl = "";

	                     Map<String, String> connectSocialNetworkMap = new HashMap<String, String>();

	                     if (jsonCand4.has("connectSocialNetwork")) {
	                           connectSocialNetwork = (JSONArray) jsonCand4.get("connectSocialNetwork");

	                           JSONObject connectSocialNetworkject = new JSONObject();

	                           for (int i = 0; i < connectSocialNetwork.length(); i++) {

	                                  connectSocialNetworkject = (JSONObject) connectSocialNetwork.get(i);

	                                  if (connectSocialNetworkject.has("name")) {
	                                         connectSocialNetworkname = (String) connectSocialNetworkject.get("name");
	                                  }

	                                  if (connectSocialNetworkject.has("url")) {
	                                         connectSocialNetworkurl = (String) connectSocialNetworkject.get("url");
	                                  }

	                                  connectSocialNetworkMap.put("name", connectSocialNetworkname);

	                                  connectSocialNetworkMap.put("url", connectSocialNetworkurl);

	                                  connectSocialObj.put(connectSocialNetworkMap);

	                           }

	                     } else {

	                           connectSocialNetworkMap.put("name", connectSocialNetworkname);

	                           connectSocialNetworkMap.put("url", connectSocialNetworkurl);

	                           connectSocialObj.put(connectSocialNetworkMap);
	                     }

	                     String familyoccupation = "";
	                     String familyname = "";
	                     String familylocation = "";
	                     String familyrelationship = "";

	                     Map<String, String> familyMap = new HashMap<String, String>();

	                     if (jsonCand4.has("family")) {

	                           family = (JSONArray) jsonCand4.get("family");

	                           JSONObject familyobject = new JSONObject();

	                           for (int i = 0; i < family.length(); i++) {

	                                  familyobject = (JSONObject) family.get(i);

	                                  if (familyobject.has("occupation")) {
	                                         familyoccupation = (String) familyobject.get("occupation");
	                                  }

	                                  if (familyobject.has("name")) {
	                                         familyname = (String) familyobject.get("name");
	                                  }

	                                  if (familyobject.has("location")) {
	                                         familylocation = (String) familyobject.get("location");
	                                  }
	                                  if (familyobject.has("relationship")) {
	                                         familyrelationship = (String) familyobject.get("relationship");
	                                  }

	                                  familyMap.put("occupation", familyoccupation);

	                                  familyMap.put("name", familyname);

	                                  familyMap.put("location", familylocation);

	                                  familyMap.put("relationship", familyrelationship);

	                                  familyObj.put(familyMap);

	                           }

	                     } else {
	                           familyMap.put("occupation", familyoccupation);

	                           familyMap.put("name", familyname);

	                           familyMap.put("location", familylocation);

	                           familyMap.put("relationship", familyrelationship);

	                           familyObj.put(familyMap);
	                     }

	                     String achievementTitle = "";
	                     String achievementRole = "";
	                     String achievementDescription = "";
	                     Map<String, String> achievementMap = new HashMap<String, String>();
	                     if (jsonCand4.has("achievement")) {

	                           achievement = (JSONArray) jsonCand4.get("achievement");
	                           JSONObject Achievementobject = new JSONObject();

	                           for (int i = 0; i < achievement.length(); i++) {

	                                  Achievementobject = (JSONObject) achievement.get(i);

	                                  if (Achievementobject.has("achievementTitle")) {
	                                         achievementTitle = (String) Achievementobject.get("achievementTitle");
	                                  }

	                                  if (Achievementobject.has("achievementRole")) {
	                                         achievementRole = (String) Achievementobject.get("achievementRole");
	                                  }

	                                  if (Achievementobject.has("achievementDescription")) {
	                                         achievementDescription = (String) Achievementobject.get("achievementDescription");
	                                  }

	                                  achievementMap.put("achievementTitle", achievementTitle);

	                                  achievementMap.put("achievementRole", achievementRole);

	                                  achievementMap.put("achievementDescription", achievementDescription);

	                                  achievementObj.put(achievementMap);

	                           }

	                     } else {
	                           achievementMap.put("achievementTitle", achievementTitle);

	                           achievementMap.put("achievementRole", achievementRole);

	                           achievementMap.put("achievementDescription", achievementDescription);

	                           achievementObj.put(achievementMap);
	                     }

	                     String referralname = "";
	                     String referralofficeEmail = "";
	                     String referralofficePhone = "";

	                     String referralcompany = "";
	                     String referraltitle = "";
	                     String referraldescription = "";

	                     Map<String, String> referalMap = new HashMap<String, String>();
	                     if (jsonCand4.has("referral")) {

	                           referal = (JSONArray) jsonCand4.get("referral");
	                           JSONObject referralobject = new JSONObject();

	                           for (int i = 0; i < achievement.length(); i++) {

	                                  referralobject = (JSONObject) achievement.get(i);

	                                  if (referralobject.has("name")) {
	                                         referralname = (String) referralobject.get("name");
	                                  }

	                                  if (referralobject.has("officeEmail")) {
	                                         referralofficeEmail = (String) referralobject.get("officeEmail");
	                                  }

	                                  if (referralobject.has("officePhone")) {
	                                         referralofficePhone = (String) referralobject.get("officePhone");
	                                  }

	                                  if (referralobject.has("company")) {
	                                         referralcompany = (String) referralobject.get("company");
	                                  }

	                                  if (referralobject.has("title")) {
	                                         referraltitle = (String) referralobject.get("title");
	                                  }

	                                  if (referralobject.has("description")) {
	                                         referraldescription = (String) referralobject.get("description");
	                                  }

	                                  referalMap.put("achievementTitle", referralname);

	                                  referalMap.put("achievementRole", referralofficeEmail);

	                                  referalMap.put("achievementDescription", referralofficePhone);

	                                  referalMap.put("achievementDescription", referralcompany);

	                                  referalMap.put("achievementDescription", referraltitle);

	                                  referalMap.put("achievementDescription", referraldescription);

	                                  refralObj.put(referalMap);

	                           }

	                     } else {
	                           referalMap.put("achievementTitle", referralname);

	                           referalMap.put("achievementRole", referralofficeEmail);

	                           referalMap.put("achievementDescription", referralofficePhone);

	                           referalMap.put("achievementDescription", referralcompany);

	                           referalMap.put("achievementDescription", referraltitle);

	                           referalMap.put("achievementDescription", referraldescription);

	                           refralObj.put(referalMap);

	                     }

	                     String certificatesTitle = "";
	                     String certificatesmonth = "";
	                     String certificateyear = "";
	                     String certificatesDescription = "";

	                     Map<String, String> certificateMap = new HashMap<String, String>();

	                     if (jsonCand4.has("certificates")) {
	                           certificates = (JSONArray) jsonCand4.get("certificates");
	                           JSONObject certificatesobject = new JSONObject();

	                           for (int i = 0; i < achievement.length(); i++) {

	                                  certificatesobject = (JSONObject) certificates.get(i);

	                                  if (certificatesobject.has("certificatesTitle")) {
	                                         certificatesTitle = (String) certificatesobject.get("certificatesTitle");
	                                  }

	                                  if (certificatesobject.has("month")) {
	                                         certificatesmonth = (String) certificatesobject.get("month");
	                                  }

	                                  if (certificatesobject.has("year")) {
	                                         certificateyear = (String) certificatesobject.get("year");
	                                  }

	                                  if (certificatesobject.has("certificatesDescription")) {
	                                         certificatesDescription = (String) certificatesobject.get("certificatesDescription");
	                                  }

	                                  certificateMap.put("certificatesTitle", certificatesTitle);

	                                  certificateMap.put("month", certificatesmonth);
	                                  certificateMap.put("year", certificateyear);
	                                  certificateMap.put("certificatesDescription", certificatesDescription);

	                                  certificateObj.put(certificateMap);

	                           }

	                     } else {
	                           certificateMap.put("certificatesTitle", certificatesTitle);

	                           certificateMap.put("month", certificatesmonth);
	                           certificateMap.put("year", certificateyear);
	                           certificateMap.put("certificatesDescription", certificatesDescription);

	                           certificateObj.put(certificateMap);
	                     }

	                     String projectTitle = "";
	                     String projectRole = "";
	                     String projectfromMonth = "";
	                     String projectfromYear = "";

	                     String projecttoMonth = "";
	                     String projecttoYear = "";
	                     String projecturl = "";
	                     String projectDescription = "";

	                     Map<String, String> projectMap = new HashMap<String, String>();

	                     if (jsonCand4.has("project")) {

	                           project = (JSONArray) jsonCand4.get("project");

	                           JSONObject projectobject = new JSONObject();

	                           for (int i = 0; i < project.length(); i++) {

	                                  projectobject = (JSONObject) project.get(i);

	                                  if (projectobject.has("projectTitle")) {
	                                         projectTitle = (String) projectobject.get("projectTitle");
	                                  }

	                                  if (projectobject.has("projectRole")) {
	                                         projectRole = (String) projectobject.get("projectRole");
	                                  }

	                                  if (projectobject.has("fromMonth")) {
	                                         projectfromMonth = (String) projectobject.get("fromMonth");
	                                  }

	                                  if (projectobject.has("fromYear")) {
	                                         projectfromYear = (String) projectobject.get("fromYear");
	                                  }

	                                  if (projectobject.has("toMonth")) {
	                                         projecttoMonth = (String) projectobject.get("toMonth");
	                                  }
	                                  if (projectobject.has("toYear")) {
	                                         projecttoYear = (String) projectobject.get("toYear");
	                                  }
	                                  if (projectobject.has("url")) {
	                                         projecturl = (String) projectobject.get("url");
	                                  }
	                                  if (projectobject.has("projectDescription")) {
	                                         projectDescription = (String) projectobject.get("projectDescription");
	                                  }

	                                  projectMap.put("projectTitle", projectTitle);

	                                  projectMap.put("projectRole", projectRole);
	                                  projectMap.put("fromMonth", projectfromMonth);
	                                  projectMap.put("fromYear", projectfromYear);

	                                  projectMap.put("toMonth", projecttoMonth);
	                                  projectMap.put("toYear", projecttoYear);
	                                  projectMap.put("url", projecturl);
	                                  projectMap.put("projectDescription", projectDescription);

	                                  projectObj.put(projectMap);

	                           }

	                     }

	                     else {
	                           projectMap.put("projectTitle", projectTitle);

	                           projectMap.put("projectRole", projectRole);
	                           projectMap.put("fromMonth", projectfromMonth);
	                           projectMap.put("fromYear", projectfromYear);

	                           projectMap.put("toMonth", projecttoMonth);
	                           projectMap.put("toYear", projecttoYear);
	                           projectMap.put("url", projecturl);
	                           projectMap.put("projectDescription", projectDescription);

	                           projectObj.put(projectMap);

	                     }
	                     if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
	                           preferredLocation = (String) jsonCand4.get("preferredLocation");
	                           System.out.println("preferredLocation >> " + preferredLocation);
	                     } else {
	                           preferredLocation = "";
	                           System.out.println("preferredLocation >> " + preferredLocation);
	                     }
	                     if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
	                           createdBy = (String) jsonCand4.get("createdBy");
	                     } else {
	                           createdBy = "";
	                           System.out.println("createdBy >> " + createdBy);
	                     }
	                     if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
	                           username = (String) jsonCand4.get("username");
	                     } else {
	                           username = "";
	                           System.out.println("username >> " + username);
	                     }
	                     if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
	                           ids = (String) jsonCand4.get("id");
	                     } else {
	                           String id = "";
	                           System.out.println("id >> " + id);
	                     }
	                     if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
	                           name = (String) jsonCand4.get("name");
	                     } else {
	                           name = "";
	                           System.out.println("name >> " + name);
	                     }
	                     if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
	                           email = (String) jsonCand4.get("email");
	                     } else {
	                           email = "";
	                           System.out.println("email >> " + email);
	                     }
	                     if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
	                           birthdate = (String) jsonCand4.get("birthdate");
	                     } else {
	                           birthdate = "";
	                           System.out.println("birthdate >> " + birthdate);
	                     }
	                     if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
	                           mobileNumber = (String) jsonCand4.get("mobileNumber");
	                     } else {
	                           mobileNumber = "";
	                           System.out.println("mobileNumber >> " + mobileNumber);
	                     }

	                     if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
	                           lastModified = (String) jsonCand4.get("lastModified");
	                           System.out.println("lastModified dfs>> " + lastModified);
	                     } else {
	                           lastModified = "";
	                           System.out.println("lastModified fsdss >> " + lastModified);
	                     }

	                     //// experience....

	                     JSONObject experience1 = null;
	                     if (jsonCand4.has("experience") && !jsonCand4.get("experience").equals(null)) {
	                           experience1 = (JSONObject) jsonCand4.get("experience");
	                           System.out.println("experience1 >> " + experience1);
	                           if (experience1.has("months") && !experience1.get("months").equals(null)) {
	                                  months = (Integer) experience1.get("months");
	                                  System.out.println("months >> " + months);
	                           } else {
	                                  months = null;
	                                  System.out.println("months >> " + months);
	                           }
	                           if (experience1.has("TotalExp") && !experience1.get("TotalExp").equals(null)) {
	                                  TotalExp = (String) experience1.get("TotalExp");
	                                  System.out.println("TotalExp >> " + TotalExp);
	                           } else {
	                                  TotalExp = "";
	                                  System.out.println("TotalExp >> " + TotalExp);
	                           }
	                           if (experience1.has("years") && !experience1.get("years").equals(null)) {
	                                  years = (Integer) experience1.get("years");
	                                  System.out.println("years >> " + years);
	                           } else {
	                                  years = null;
	                                  System.out.println("years >>> " + years);
	                           }
	                     } else {
	                           experience = "";
	                           System.out.println("experience >> " + experience);
	                     }

	                     // salary......
	                     JSONObject salary1 = null;

	                     if (jsonCand4.has("salary") && !jsonCand4.get("salary").equals(null)) {
	                           salary1 = (JSONObject) jsonCand4.get("salary");
	                           System.out.println("salry1 >> " + salary1);
	                           if (salary1.has("currentCTCType") && !salary1.get("currentCTCType").equals(null)) {
	                                  currentCTCType = (String) salary1.get("currentCTCType");
	                                  System.out.println("currentCTCType >> " + currentCTCType);
	                           } else {
	                                  currentCTCType = "";
	                                  System.out.println("currentCTCType >> " + currentCTCType);
	                           }
	                           if (salary1.has("currentCTC") && !salary1.get("currentCTC").equals(null)) {
	                                  currentCTC = (String) salary1.get("currentCTC");
	                                  System.out.println("currentCTC >> " + currentCTC);
	                           } else {
	                                  currentCTC = "";
	                                  System.out.println("currentCTC >> " + currentCTC);
	                           }
	                           if (salary1.has("negotiableCTC") && !salary1.get("negotiableCTC").equals(null)) {
	                                  negotiableCTC = (String) salary1.get("negotiableCTC");
	                                  System.out.println("negotiableCTC >> " + negotiableCTC);
	                           } else {
	                                  negotiableCTC = "";
	                                  System.out.println("negotiableCTC >> " + negotiableCTC);
	                           }
	                           if (salary1.has("expectedCTCType") && !salary1.get("expectedCTCType").equals(null)) {
	                                  expectedCTCType = (String) salary1.get("expectedCTCType");
	                                  System.out.println("expectedCTCType >> " + expectedCTCType);
	                           } else {
	                                  expectedCTCType = "";
	                                  System.out.println("expectedCTCType >> " + expectedCTCType);
	                           }
	                           if (salary1.has("expectedCTC") && !salary1.get("expectedCTC").equals(null)) {
	                                  expectedCTC = (String) salary1.get("expectedCTC");
	                                  System.out.println("expectedCTC >> " + expectedCTC);
	                           } else {
	                                  expectedCTC = "";
	                                  System.out.println("expectedCTC >> " + expectedCTC);
	                           }
	                           if (salary1.has("takeHome") && !salary1.get("takeHome").equals(null)) {
	                                  takeHome = (String) salary1.get("takeHome");
	                                  System.out.println("takeHome >> " + takeHome);
	                           } else {
	                                  takeHome = "";
	                                  System.out.println("takeHome >> " + takeHome);
	                           }
	                           if (salary1.has("fixed") && !salary1.get("fixed").equals(null)) {
	                                  fixed = (String) salary1.get("fixed");
	                                  System.out.println("fixed >> " + fixed);
	                           } else {
	                                  fixed = "";
	                                  System.out.println("fixed >> " + fixed);
	                           }

	                     } else {
	                           salary = "";
	                           System.out.println("salary >> " + salary);
	                     }

	                     /// address......permanent
	                     JSONObject permanentAddressJson = null;
	                     JSONObject permanentAddress1 = null;
	                     JSONObject currentAddressJson = null;
	                     JSONObject currentAddress1 = null;
	                     JSONObject addressJson = null;
	                     JSONObject addressJson1 = null;

	                     if (jsonCand4.has("address") && !jsonCand4.get("address").equals(null)) {
	                           addressJson = (JSONObject) jsonCand4.get("address");
	                           if (addressJson.has("permanentAddress") && !addressJson.get("permanentAddress").equals(null)) {
	                                  System.out.println("permanentAddress >> " + addressJson.get("permanentAddress"));
	                                  // permanentAddress1=new JSONObject();
	                                  addressJson1 = (JSONObject) addressJson.get("permanentAddress");
	                                  // addressJson1=(JSONObject)
	                                  // addressJson1.get("permanentAddress");
	                                  System.out.println("permanentAddress1 >>> " + addressJson1);
	                                  if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
	                                         country = (String) addressJson1.get("country");
	                                         System.out.println("country >> " + country);
	                                  } else {
	                                         country = "";
	                                         System.out.println("country >> " + country);
	                                  }
	                                  if (addressJson1.has("state") && !addressJson1.get("state").equals(null)) {
	                                         state = (String) addressJson1.get("state");
	                                         System.out.println("state >> " + state);
	                                  } else {
	                                         state = "";
	                                         System.out.println("state >> " + state);
	                                  }
	                                  if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
	                                         city = (String) addressJson1.get("city");
	                                  } else {
	                                         city = "";
	                                         System.out.println("city >> " + city);
	                                  }
	                                  if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
	                                         street = (String) addressJson1.get("street");
	                                         System.out.println("street >> " + street);
	                                  } else {
	                                         street = "";
	                                         System.out.println("street >> " + street);
	                                  }
	                                  if (addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)) {
	                                         pincode = (String) addressJson1.get("pincode");
	                                         System.out.println("pincode >> " + pincode);
	                                  } else {
	                                         pincode = "";
	                                         System.out.println("pincode >> " + pincode);
	                                  }
	                                  if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
	                                         location = (String) addressJson1.get("location");
	                                         System.out.println("location >> " + location);
	                                  } else {
	                                         location = "";
	                                         System.out.println("location >> " + location);
	                                  }
	                           } else {
	                                  permanentAddress = "";
	                                  System.out.println("permanentAddress >> " + permanentAddress);
	                           }
	                           /// current address write code.. START

	                           // currentAddressJson=(JSONObject) jsonCand4.get("address");
	                           addressJson = (JSONObject) jsonCand4.get("address");

	                           if (addressJson.has("currentAddress") && !addressJson.get("currentAddress").equals(null)) {
	                                  System.out.println("currentAddress >> " + addressJson.get("currentAddress"));
	                                  // currentAddress1=new JSONObject();
	                                  addressJson1 = (JSONObject) addressJson.get("currentAddress");
	                                  System.out.println("currentAddress1 >>> " + addressJson1);
	                                  if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
	                                         country = (String) addressJson1.get("country");
	                                         System.out.println("country >> " + country);
	                                  } else {
	                                         country = "";
	                                         System.out.println("country current >> " + country);
	                                  }
	                                  if (addressJson1.has("state") && !addressJson1.get("state").equals(null)) {
	                                         state = (String) addressJson1.get("state");
	                                         System.out.println("state  current>> " + state);
	                                  } else {
	                                         state = "";
	                                         System.out.println("state current>> " + state);
	                                  }
	                                  if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
	                                         city = (String) addressJson1.get("city");
	                                  } else {
	                                         city = "";
	                                         System.out.println("city current>> " + city);
	                                  }
	                                  if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
	                                         street = (String) addressJson1.get("street");
	                                         System.out.println("street current>> " + street);
	                                  } else {
	                                         street = "";
	                                         System.out.println("street current>> " + street);
	                                  }
	                                  if (addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)) {
	                                         pincode = (String) addressJson1.get("pincode");
	                                         System.out.println("pincode current>> " + pincode);
	                                  } else {
	                                         pincode = "";
	                                         System.out.println("pincode current >> " + pincode);
	                                  }
	                                  if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
	                                         location = (String) addressJson1.get("location");
	                                         System.out.println("location current >> " + location);
	                                  } else {
	                                         location = "";
	                                         System.out.println("location current >> " + location);
	                                  }
	                           } else {
	                                  currentAddress = "";
	                                  System.out.println("currentAddress current >> " + currentAddress);
	                           }
	                     } else {
	                           address = "";
	                           System.out.println("address >> " + address);
	                     }

	                     /// Education..
	                     JSONObject ugjson = null;
	                     JSONObject ug1 = null;
	                     JSONObject pgjson = null;
	                     JSONObject pg1 = null;
	                     JSONObject twelvethjson = null;
	                     JSONObject twelveth1 = null;
	                     JSONObject tenthjson = null;
	                     JSONObject tenth1 = null;

	                     JSONObject educationjson = null;
	                     JSONObject educationjson1 = null;

	                     // if (jsonCand4.has("education") &&
	                     // !jsonCand4.get("education").equals(null)) {
	                     //
	                     //
	                     //
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("ug") &&
	                     // !educationjson.get("ug").equals(null)) {
	                     // System.out.println("ug >>> " + educationjson.get("ug"));
	                     // // ug1=new JSONObject();
	                     // // ug1=(JSONObject) ugjson.get("ug");
	                     //
	                     // educationjson1 = (JSONObject) educationjson.get("ug");
	                     // System.out.println("ug1 >> " + educationjson1);
	                     // if (educationjson1.has("degree") &&
	                     // !educationjson1.get("degree").equals(null)) {
	                     // degree = (String) educationjson1.get("degree");
	                     // System.out.println("degree >>> " + educationjson1.get("degree"));
	                     // } else {
	                     // degree = "";
	                     // System.out.println("degree >> " + degree);
	                     // }
	                     //
	                     //
	                     // if (educationjson1.has("degreeType") &&
	                     // !educationjson1.get("degreeType").equals(null)) {
	                     // degreeType = (String) educationjson1.get("degreeType");
	                     // System.out.println("degreeType >>> " +
	                     // educationjson1.get("degreeType"));
	                     // } else {
	                     // degreeType = "";
	                     // System.out.println("degreeType >> " + degreeType);
	                     // }
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     //
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     //
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     //
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     //
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     //
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     //
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     //
	                     // } else {
	                     // toYear = "";
	                     //
	                     // }
	                     // if (educationjson1.has("percentage") &&
	                     // !educationjson1.get("percentage").equals(null)) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     //
	                     // } else {
	                     // percentage = "";
	                     //
	                     // }
	                     //
	                     // } else {
	                     // ug = "";
	                     // System.out.println("ug >> " + ug);
	                     // }
	                     //
	                     //
	                     // System.out.println("Hiiiiiiiiiiiii");
	                     //
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("pg") &&
	                     // !educationjson.get("pg").equals(null)) {
	                     //
	                     //
	                     //
	                     // educationjson1 = (JSONObject) educationjson.get("pg");
	                     // System.out.println("pg1 >> " + educationjson1);
	                     //
	                     // if (educationjson1.has("degree") &&
	                     // !educationjson1.get("degree").equals(null)) {
	                     // degree = (String) educationjson1.get("degree");
	                     // System.out.println("degree >>> " + educationjson1.get("degree"));
	                     // } else {
	                     // degree = "";
	                     // System.out.println("degree >> " + degree);
	                     // }
	                     // if (educationjson1.has("degreeType") &&
	                     // !educationjson1.get("degreeType").equals(null)) {
	                     // degreeType = (String) educationjson1.get("degreeType");
	                     // System.out.println("degreeType >>> " +
	                     // educationjson1.get("degreeType"));
	                     // } else {
	                     // degreeType = "";
	                     // System.out.println("degreeType >> " + degreeType);
	                     // }
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     // System.out.println("institute >>> " +
	                     // educationjson1.get("institute"));
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     // System.out.println("universityOrBoard >>> " +
	                     // educationjson1.get("universityOrBoard"));
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     // System.out.println("city >>> " + educationjson1.get("city"));
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     // System.out.println("fromMonth >>> " +
	                     // educationjson1.get("fromMonth"));
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     // System.out.println("fromYear >>> " +
	                     // educationjson1.get("fromYear"));
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     // System.out.println("toMonth >> " + toMonth);
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     //
	                     // else {
	                     // toYear = "";
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     // if (educationjson1.has("percentage") &&
	                     // !educationjson1.get("percentage").equals(null)) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // System.out.println("percentage >> " + percentage);
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     //
	                     // } else {
	                     // pg = "";
	                     // System.out.println("pg >>" + pg);
	                     // } // end pg
	                     //
	                     // //// doctrate start
	                     //
	                     // System.out.println("Hiiiiiiiiiiiii");
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("doctorate") &&
	                     // !educationjson.get("doctorate").equals(null)) {
	                     // System.out.println("doctorate Json >>> " +
	                     // educationjson.get("doctorate"));
	                     //
	                     // // JSONObject doctorate1=new JSONObject();
	                     // // System.out.println("doctorate1 >> "+doctorate1);
	                     // educationjson1 = (JSONObject) educationjson.get("twelveth");
	                     // System.out.println("doctorate1 >>> " + educationjson1);
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     // System.out.println("institute >>> " +
	                     // educationjson1.get("institute"));
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     // System.out.println("universityOrBoard >>> " +
	                     // educationjson1.get("universityOrBoard"));
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     // System.out.println("city >>> " + educationjson1.get("city"));
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     // System.out.println("fromMonth >>> " +
	                     // educationjson1.get("fromMonth"));
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     // System.out.println("fromYear >>> " +
	                     // educationjson1.get("fromYear"));
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     // System.out.println("toMonth >> " + toMonth);
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     // System.out.println("toYear >> " + toYear);
	                     // } else {
	                     // toYear = "";
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     // if (educationjson1.has("percentage") &&
	                     // !educationjson1.get("percentage").equals(null)) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // System.out.println("percentage >> " + percentage);
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     //
	                     // } else {
	                     // doctorate = "";
	                     // System.out.println("doctorate >>" + doctorate);
	                     // }
	                     //
	                     // /// start Diploma
	                     //
	                     // System.out.println("Hiiiiiiiiiiiii");
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("diploma") &&
	                     // !educationjson.get("diploma").equals(null)) {
	                     // System.out.println("diploma Json >>> " +
	                     // educationjson.get("diploma"));
	                     //
	                     // // JSONObject diploma1=new JSONObject();
	                     // // System.out.println("diploma1 >> "+diploma1);
	                     // educationjson1 = (JSONObject) educationjson.get("diploma");
	                     // System.out.println("diploma1 >>> " + educationjson1);
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     // System.out.println("institute >>> " +
	                     // educationjson1.get("institute"));
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     // System.out.println("universityOrBoard >>> " +
	                     // educationjson1.get("universityOrBoard"));
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     // System.out.println("city >>> " + educationjson1.get("city"));
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     // System.out.println("fromMonth >>> " +
	                     // educationjson1.get("fromMonth"));
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     // System.out.println("fromYear >>> " +
	                     // educationjson1.get("fromYear"));
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     // System.out.println("toMonth >> " + toMonth);
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     // System.out.println("toYear >> " + toYear);
	                     // } else {
	                     // toYear = "";
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     // if (educationjson1.has("percentage") &&
	                     // !educationjson1.get("percentage").equals(null)) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // System.out.println("percentage >> " + percentage);
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     //
	                     // } else {
	                     // diploma = "";
	                     // System.out.println("diploma >>" + diploma);
	                     // }
	                     //
	                     // //////// start 12th
	                     // System.out.println("Hiiiiiiiiiiiii");
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("twelveth") &&
	                     // !educationjson.get("twelveth").equals(null)) {
	                     // System.out.println("pg1 Json >>> " +
	                     // educationjson.get("twelveth"));
	                     //
	                     // // twelveth1=new JSONObject();
	                     // // System.out.println("twelveth1 >> "+twelveth1);
	                     // educationjson1 = (JSONObject) educationjson.get("twelveth");
	                     // System.out.println("twelveth1 >>> " + educationjson1);
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     // System.out.println("institute >>> " +
	                     // educationjson1.get("institute"));
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     // System.out.println("universityOrBoard >>> " +
	                     // educationjson1.get("universityOrBoard"));
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     // System.out.println("city >>> " + educationjson1.get("city"));
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     // System.out.println("fromMonth >>> " +
	                     // educationjson1.get("fromMonth"));
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     // System.out.println("fromYear >>> " +
	                     // educationjson1.get("fromYear"));
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     // System.out.println("toMonth >> " + toMonth);
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     // System.out.println("toYear >> " + toYear);
	                     // } else {
	                     // toYear = "";
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     // if (!educationjson1.get("percentage").equals(null)) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // System.out.println("percentage >> " + percentage);
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     //
	                     // System.out.println("educationjson1 >> " + educationjson1);
	                     // if (educationjson1.has("percentage")) {
	                     // if (!educationjson1.get("percentage").equals(null)) {
	                     // if (educationjson1.has("percentage")) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     // }
	                     // }
	                     //
	                     // } else {
	                     // twelveth = "";
	                     // System.out.println("twelveth >>" + twelveth);
	                     // }
	                     //
	                     // // end twelveth
	                     //
	                     // // Start tenth
	                     // System.out.println("Hiiiiiiiiiiiii");
	                     // educationjson = (JSONObject) jsonCand4.get("education");
	                     // if (educationjson.has("tenth") &&
	                     // !educationjson.get("tenth").equals(null)) {
	                     // System.out.println("tetnth Json >>> " +
	                     // educationjson.get("tenth"));
	                     //
	                     // // tenth1=new JSONObject();
	                     // // System.out.println("tenth1 >> "+tenth1);
	                     // educationjson1 = (JSONObject) educationjson.get("tenth");
	                     // System.out.println("tenth1 >>> " + educationjson1);
	                     //
	                     // if (educationjson1.has("degree") &&
	                     // !educationjson1.get("degree").equals(null)) {
	                     // degree = (String) educationjson1.get("degree");
	                     // System.out.println("degree >>> " + educationjson1.get("degree"));
	                     // } else {
	                     // degree = "";
	                     // System.out.println("degree >> " + degree);
	                     // }
	                     // if (educationjson1.has("degreeType") &&
	                     // !educationjson1.get("degreeType").equals(null)) {
	                     // degreeType = (String) educationjson1.get("degreeType");
	                     // System.out.println("degreeType >>> " +
	                     // educationjson1.get("degreeType"));
	                     // } else {
	                     // degreeType = "";
	                     // System.out.println("degreeType >> " + degreeType);
	                     // }
	                     //
	                     // if (educationjson1.has("course") &&
	                     // !educationjson1.get("course").equals(null)) {
	                     // course = (String) educationjson1.get("course");
	                     // System.out.println("course >>> " + educationjson1.get("course"));
	                     // } else {
	                     // course = "";
	                     // System.out.println("course >> " + course);
	                     // }
	                     // if (educationjson1.has("institute") &&
	                     // !educationjson1.get("institute").equals(null)) {
	                     // institute = (String) educationjson1.get("institute");
	                     // System.out.println("institute >>> " +
	                     // educationjson1.get("institute"));
	                     // } else {
	                     // institute = "";
	                     // System.out.println("institute >> " + institute);
	                     // }
	                     // if (educationjson1.has("universityOrBoard")
	                     // && !educationjson1.get("universityOrBoard").equals(null)) {
	                     // universityOrBoard = (String)
	                     // educationjson1.get("universityOrBoard");
	                     // System.out.println("universityOrBoard >>> " +
	                     // educationjson1.get("universityOrBoard"));
	                     // } else {
	                     // universityOrBoard = "";
	                     // System.out.println("universityOrBoard >> " + universityOrBoard);
	                     // }
	                     // if (educationjson1.has("city") &&
	                     // !educationjson1.get("city").equals(null)) {
	                     // city = (String) educationjson1.get("city");
	                     // System.out.println("city >>> " + educationjson1.get("city"));
	                     // } else {
	                     // city = "";
	                     // System.out.println("city >> " + city);
	                     // }
	                     // if (educationjson1.has("fromMonth") &&
	                     // !educationjson1.get("fromMonth").equals(null)) {
	                     // fromMonth = (String) educationjson1.get("fromMonth");
	                     // System.out.println("fromMonth >>> " +
	                     // educationjson1.get("fromMonth"));
	                     // } else {
	                     // fromMonth = "";
	                     // System.out.println("fromMonth >> " + fromMonth);
	                     // }
	                     // if (educationjson1.has("fromYear") &&
	                     // !educationjson1.get("fromYear").equals(null)) {
	                     // fromYear = (String) educationjson1.get("fromYear");
	                     // System.out.println("fromYear >>> " +
	                     // educationjson1.get("fromYear"));
	                     // } else {
	                     // fromYear = "";
	                     // System.out.println("fromYear >> " + fromYear);
	                     // }
	                     // if (educationjson1.has("toMonth") &&
	                     // !educationjson1.get("toMonth").equals(null)) {
	                     // toMonth = (String) educationjson1.get("toMonth");
	                     // System.out.println("toMonth >> " + toMonth);
	                     // } else {
	                     // toMonth = "";
	                     // System.out.println("toMonth >> " + toMonth);
	                     // }
	                     // if (educationjson1.has("toYear") &&
	                     // !educationjson1.get("toYear").equals(null)) {
	                     // toYear = (String) educationjson1.get("toYear");
	                     // System.out.println("toYear >> " + toYear);
	                     // } else {
	                     // toYear = "";
	                     // System.out.println("toYear >> " + toYear);
	                     // }
	                     //
	                     // System.out.println("educationjson1 >> " + educationjson1);
	                     // if (educationjson1.has("percentage")) {
	                     // if (!educationjson1.get("percentage").equals(null)) {
	                     // if (educationjson1.has("percentage")) {
	                     // percentage = (String) educationjson1.get("percentage");
	                     // } else {
	                     // percentage = "";
	                     // System.out.println("percentage >> " + percentage);
	                     // }
	                     // }
	                     // }
	                     //
	                     // } else {
	                     // tenth = "";
	                     // System.out.println("twelveth >>" + tenth);
	                     // }
	                     //
	                     // // end tenth
	                     // //////////
	                     //
	                     // } else {
	                     // education = "";
	                     // System.out.println("education >> " + education);
	                     // }

	                     JSONObject education = new JSONObject();

	                     educationjson = (JSONObject) jsonCand4.get("education");

	                     JSONObject blankEdu = new JSONObject();
	                     
	                     blankEdu.put("degree", "");
	                     blankEdu.put("degreeType", "");
	                     blankEdu.put("course", "");
	                     blankEdu.put("institute", "");
	                     blankEdu.put("universityOrBoard", "");
	                     blankEdu.put("city", "");
	                     blankEdu.put("fromMonth", "");
	                     blankEdu.put("fromYear", "");
	                     blankEdu.put("toMonth", "");
	                     blankEdu.put("toYear", "");
	                     blankEdu.put("percentage", "");
	                     
	                     if (educationjson.has("ug")) {
	                           JSONObject subEdu = new JSONObject();

	                           educationjson1 = (JSONObject) educationjson.get("ug");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                           else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                           if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("ug", subEdu);
	                     } else
	                           education.put("ug", blankEdu);

	                     if (educationjson.has("pg")) {

	                           JSONObject subEdu = new JSONObject();

	                           educationjson1 = (JSONObject) educationjson.get("pg");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                           else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                            if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("pg", subEdu);

	                     } else
	                           education.put("pg", blankEdu); // end pg

	                     if (educationjson.has("doctorate")) {

	                           JSONObject subEdu = new JSONObject();

	                           educationjson1 = (JSONObject) educationjson.get("doctorate");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                           else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                           if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("doctorate", subEdu);

	                     } else
	                           education.put("doctorate", blankEdu);

	                     if (educationjson.has("diploma")) {

	                           JSONObject subEdu = new JSONObject();

	                           educationjson1 = (JSONObject) educationjson.get("diploma");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                           else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                           if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("diploma", subEdu);

	                     } else
	                           education.put("diploma", blankEdu);

	                     if (educationjson.has("twelveth")) {

	                           JSONObject subEdu = new JSONObject();

	                           educationjson1 = (JSONObject) educationjson.get("twelveth");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                            else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                           if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("twelveth", subEdu);

	                     } else
	                           education.put("twelveth", blankEdu);
	                     JSONObject subEdu = new JSONObject();

	                     
	                     if (educationjson.has("tenth")) {

	                           educationjson1 = (JSONObject) educationjson.get("tenth");

	                           if (educationjson1.has("degree"))
	                                  subEdu.put("degree", educationjson1.getString("degree"));
	                           else
	                                  subEdu.put("degree", "");

	                           if (educationjson1.has("degreeType"))
	                                  subEdu.put("degreeType", educationjson1.getString("degreeType"));
	                           else
	                                  subEdu.put("degreeType", "");

	                           if (educationjson1.has("course"))
	                                  subEdu.put("course", educationjson1.getString("course"));
	                           else
	                                  subEdu.put("course", "");

	                           if (educationjson1.has("institute"))
	                                  subEdu.put("institute", educationjson1.getString("institute"));
	                           else
	                                  subEdu.put("institute", "");

	                           if (educationjson1.has("universityOrBoard"))
	                                  subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
	                           else
	                                  subEdu.put("universityOrBoard", "");

	                           if (educationjson1.has("city"))
	                                  subEdu.put("city", educationjson1.getString("city"));
	                           else
	                                  subEdu.put("city", "");

	                           if (educationjson1.has("fromMonth"))
	                                  subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
	                           else
	                                  subEdu.put("fromMonth", "");

	                           if (educationjson1.has("fromYear"))
	                                  subEdu.put("fromYear", educationjson1.getString("fromYear"));
	                           else
	                                  subEdu.put("fromYear", "");

	                           if (educationjson1.has("toMonth"))
	                                  subEdu.put("toMonth", educationjson1.getString("toMonth"));
	                           else
	                                  subEdu.put("toMonth", "");

	                           if (educationjson1.has("toYear"))
	                                  subEdu.put("toYear", educationjson1.getString("toYear"));
	                           else
	                                  subEdu.put("toYear", "");

	                           if (educationjson1.has("percentage"))
	                                  subEdu.put("percentage", educationjson1.getString("percentage"));
	                           else
	                                  subEdu.put("percentage", "");

	                           education.put("tenth", subEdu);

	                     } else
	                           education.put("tenth", blankEdu);

	                     // candijson.put("education", education);

	                     JSONObject employment1 = null;
	                     JSONObject current1 = null;
	                     JSONArray previous1 = null;
	                     String previousOrganization = "";
	                     String previousDesignation = "";
	                     String previousLevel = "";
	                     String previousCity = "";
	                     String previousFromMonth = "";
	                     String previousFromYear = "";
	                     String previousToMonth = "";
	                     String previousToYear = "";
	                     String previousDescription = "";

	                     if (jsonCand4.has("employement") && !jsonCand4.get("employement").equals(null)) {
	                           employment1 = jsonCand4.getJSONObject("employement");
	                           if (employment1.has("current") && !employment1.get("current").equals(null)) {
	                                  current1 = employment1.getJSONObject("current");
	                                  System.out.println("current jsonObject >>" + current);
	                                  if (current1.has("companyName") && !current1.get("companyName").equals(null)) {
	                                         companyName = current1.getString("companyName");
	                                         System.out.println("companyName >> " + companyName);
	                                  } else {
	                                         companyName = "";
	                                  }
	                                  if (current1.has("designation") && !current1.get("designation").equals(null)) {
	                                         designation = current1.getString("designation");
	                                         System.out.println("desidnation >> " + designation);
	                                  } else {
	                                         designation = "";
	                                  }
	                                  if (current1.has("isCurrent") && !current1.get("isCurrent").equals(null)) {
	                                         isCurrent = current1.getString("isCurrent");
	                                         System.out.println("isCurrent >>" + isCurrent);
	                                  } else {
	                                         isCurrent = "";
	                                  }
	                                  if (current1.has("desc") && !current1.get("desc").equals(null)) {
	                                         desc = current1.getString("desc");
	                                         System.out.println("desc >> " + desc);
	                                  } else {
	                                         desc = "";
	                                  }
	                                  if (current1.has("workLocation") && !current1.get("workLocation").equals(null)) {
	                                         workLocation = current1.getString("workLocation");
	                                         System.out.println("workLocation >>" + workLocation);
	                                  } else {
	                                         workLocation = "";
	                                  }
	                                  if (current1.has("role") && !current1.get("role").equals(null)) {
	                                         role = current1.getString("role");
	                                         System.out.println("role >> " + role);
	                                  } else {
	                                         role = "";
	                                  }
	                                  if (current1.has("level") && !current1.get("level").equals(null)) {
	                                         level = current1.getString("level");
	                                         System.out.println("level >> " + level);
	                                  } else {
	                                         level = "";
	                                  }
	                                  if (current1.has("teamSize") && !current1.get("teamSize").equals(null)) {
	                                         teamSize = current1.getString("teamSize");
	                                         System.out.println("teamSize >> " + teamSize);
	                                  } else {
	                                         teamSize = "";
	                                  }

	                           }

	                           if (employment1.has("previous") && !employment1.get("previous").equals(null)
	                                         || !employment1.isNull("previous")) {
	                                  previous1 = employment1.getJSONArray("previous");
	                                  System.out.println("previous1 >> " + previous1);
	                                  int i = 0;
	                                  for (i = 0; i < previous1.length(); i++) {
	                                         JSONObject jsonprevious = previous1.getJSONObject(i);
	                                         if (jsonprevious.has("organization") && !jsonprevious.get("organization").equals(null)) {
	                                                previousOrganization = jsonprevious.getString("organization");
	                                                System.out.println("previousOrganization >>" + previousOrganization);
	                                         } else {
	                                                previousOrganization = "";
	                                         }
	                                         if (jsonprevious.has("designation") && !jsonprevious.get("designation").equals(null)) {
	                                                previousDesignation = jsonprevious.getString("designation");
	                                                System.out.println("previousDesignation >>" + previousDesignation);
	                                         } else {
	                                                previousDesignation = "";
	                                         }
	                                         if (jsonprevious.has("level") && !jsonprevious.get("level").equals(null)) {
	                                                previousLevel = jsonprevious.getString("level");

	                                         } else {
	                                                previousLevel = "";
	                                         }
	                                         if (jsonprevious.has("city") && !jsonprevious.get("city").equals(null)) {
	                                                previousCity = jsonprevious.getString("city");
	                                         } else {
	                                                previousCity = "";
	                                         }
	                                         if (jsonprevious.has("fromMonth") && !jsonprevious.get("fromMonth").equals(null)) {
	                                                previousFromMonth = jsonprevious.getString("fromMonth");
	                                         } else {
	                                                previousFromMonth = "";
	                                         }
	                                         if (jsonprevious.has("fromYear") && !jsonprevious.get("fromYear").equals(null)) {
	                                                previousFromYear = jsonprevious.getString("fromYear");
	                                         } else {
	                                                previousFromYear = "";
	                                         }
	                                         if (jsonprevious.has("toMonth") && !jsonprevious.get("toMonth").equals(null)) {
	                                                previousToMonth = jsonprevious.getString("toMonth");
	                                         } else {
	                                                previousToMonth = "";
	                                         }
	                                         if (jsonprevious.has("toYear") && !jsonprevious.get("toYear").equals(null)) {
	                                                previousToYear = jsonprevious.getString("toYear");
	                                         } else {
	                                                previousToYear = "";
	                                         }
	                                         if (jsonprevious.has("description") && !jsonprevious.get("description").equals(null)) {
	                                                previousDescription = jsonprevious.getString("description");
	                                         } else {
	                                                previousDescription = "";
	                                         }
	                                  }

	                           }
	                     }

	                     JSONArray altenaiteEmail1 = new JSONArray();
	                     int m = 0;
	                     if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
	                           altenaiteEmail1 = (JSONArray) jsonCand4.get("alternateEmail");
	                           System.out.println("altenail:::" + altenaiteEmail1);
	                           for (m = 0; m < altenaiteEmail1.length(); m++) {
	                                  altenaiteEmail1.get(m);
	                                  System.out.println("AlernateEmail ::" + altenaiteEmail1.get(m));
	                           }
	                           System.out.println("alternateEmail:::" + alternateEmail);
	                     }
	                     candijson.put("AppliedCount", String.valueOf(appliedcount));

	                     candijson.put("ResumeName", ResumeName);
	                     candijson.put("Resume", Resume);

	                     candijson.put("SheduledCount", String.valueOf(Sheduledcount));
	                     candijson.put("GotSelectedCount", String.valueOf(Gotselectedcount));
	                     candijson.put("ShortListedCount", String.valueOf(shortlistcount));
	                     candijson.put("preferredLocation", preferredLocation);
	                     candijson.put("createdBy", createdBy);
	                     candijson.put("username", username);
	                     candijson.put("id", ids);
	                     candijson.put("name", name);
	                     candijson.put("email", email);
	                     candijson.put("birthdate", birthdate);
	                     candijson.put("mobileNumber", mobileNumber);
	                     candijson.put("lastModified", lastModified);
	                     candijson.put("first_name", first_name);
	                     candijson.put("middle_name", middle_name);
	                     candijson.put("last_name", last_name);

	                     // candijson.put("alternateEmail", alternateEmail1);

	                     candijson.put("age", String.valueOf(age));

	                     candijson.put("gender", gender);

	                     candijson.put("picture", picture);

	                     candijson.put("profile", profile);

	                     candijson.put("website", website);

	                     candijson.put("jobType", jobType);

	                     candijson.put("employmentType", employmentType);

	                     // candijson.put("immediateJoiningAvailabilityOrNegotiable",
	                     // immediateJoiningAvailabilityOrNegotiable);

	                     candijson.put("employmentType", employmentType);

	                     candijson.put("immediateJoiningAvailabilityOrNegotiable",
	                                  String.valueOf(immediateJoiningAvailabilityOrNegotiable));

	                     candijson.put("minimumDaysRequired", minimumDaysRequired);

	                     candijson.put("salutation", salutation);

	                     candijson.put("visibility", String.valueOf(visibility));

	                     candijson.put("mobileNumber", mobileNumber);

	                     candijson.put("telePhone", telePhone);

	                     candijson.put("officePhone", officePhone);

	                     candijson.put("officePhoneExtention", officePhoneExtention);

	                     candijson.put("isMobileNumberVerified", String.valueOf(isMobileNumberVerified));

	                     candijson.put("locale", locale);

	                     candijson.put("religion", religion);

	                     candijson.put("maritalStatus", maritalStatus);

	                     candijson.put("createdDate", createdDate);
	                     candijson.put("lastModified", lastModified);
	                     candijson.put("aadharCardNo", aadharCardNo);

	                     candijson.put("passportNo", passportNo);

	                     candijson.put("passportValidity", passportValidity);

	                     candijson.put("panNo", panNo);

	                     candijson.put("areaOfSpecialization", areaOfSpecialization);

	                     candijson.put("otherInterest", otherInterest);

	                     candijson.put("category", category);

	                     candijson.put("confidential", String.valueOf(confidential));

	                     candijson.put("employmentStatus", employmentStatus);

	                     candijson.put("nationality", nationality);
	                     candijson.put("exNationality", exNationality);
	                     candijson.put("experiencedIndustry", experiencedIndustry);
	                     candijson.put("preferredIndustry", preferredIndustry);
	                     candijson.put("experiencedFunctionalArea", experiencedFunctionalArea);
	                     candijson.put("preferredFunctionalArea", preferredFunctionalArea);
	                     candijson.put("language", language);
	                     candijson.put("notes", notes);
	                     candijson.put("noticePeriod", noticePeriod);
	                     candijson.put("preferredLocation", preferredLocation);

	                     candijson.put("preferredDistance", preferredDistance);
	                     candijson.put("physicallyChallenged", physicallyChallenged);
	                     candijson.put("reasonForLeaving", reasonForLeaving);
	                     candijson.put("reasonForRelocate", reasonForRelocate);

	                     candijson.put("willingToRelocate", willingToRelocate);
	                     candijson.put("willingToChangeJob", willingToChangeJob);
	                     candijson.put("resumeHeadLine", resumeHeadLine);
	                     candijson.put("experienced", String.valueOf(experienced));

	                     candijson.put("fresher", String.valueOf(fresher));

	                     candijson.put("shiftWork", shiftWork);

	                     candijson.put("skillSummary", skillSummary);

	                     candijson.put("summary", summary);

	                     candijson.put("federated", federated);

	                     System.out.println("candidate Json......" + candijson);
	                     achievements.put("achievement", achievementObj);
	                     certificatess.put("certificate", certificateObj);
	                     previous.put("previous", previouss);
	                     projects.put("project", projectObj);
	                     Skills.put("skills", SkillsObj);
	                     refral.put("referral", refralObj);
	                     map.put("alternateEmail", altenaiteEmail1);
	                     map.put("alternateMobile", alternateMobileNumber);
	                     map.put("family", familyObj);
	                     map.put("connectSocialNetwork", connectSocialObj);
	                     map1.put("experience", experience1);
	                     map1.put("salary", salary1);
	                     map1.put("address", addressJson);

	                     map1.put("education", education);
	                     map1.put("employment", employment1);

	                     obj.put(candijson);
	                     obj.put(map1);
	                     obj.put(map);
	                     obj.put(Skills);
	                     obj.put(refral);
	                     obj.put(projects);
	                     obj.put(achievements);
	                     obj.put(certificatess);

	              }

	              Mainjson.put("response", obj);

	              return Mainjson.toString();
	       }

		//10. Mobile API new requirment.
		 // Return job data on behalf of deleted and status
		 

		/*@RequestMapping(value = "/ElasticAPI/job_Deleted_Status", method = { RequestMethod.GET })
		public @ResponseBody String job_Deleted_Status(@RequestParam("deleted") String deleted,
				@RequestParam("status") String status) throws JSONException, URISyntaxException, MalformedURLException {

			String urlJob = "";
			String jobData = "";

			if (deleted.length() > 0 && status.trim().length() > 0)
				urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(deleted:"
						+ deleted + ")AND(status:\"" + status + "\")";
			else if (deleted.length() > 0)
				urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(deleted:"
						+ deleted + ")";
			else if (status.trim().length() > 0)
				urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(status:\""
						+ status + "\")";
			else
				urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search";

			System.out.println(urlJob);

			URL urlJobs = new URL(urlJob);

			URI uriJobs = new URI(urlJobs.getProtocol(), urlJobs.getUserInfo(), urlJobs.getHost(), urlJobs.getPort(),
					urlJobs.getPath(), urlJobs.getQuery(), urlJob);

			jobData = restTemplate.getForObject(uriJobs, String.class);

			JSONObject mainjson = new JSONObject();

			JSONArray jsonArray = new JSONArray();

			JSONObject jsonAttach = new JSONObject(jobData);
			JSONObject jobhits = jsonAttach.getJSONObject("hits");

			JSONArray jobhitsArr = jobhits.getJSONArray("hits");

			for (int i = 0; i < jobhitsArr.length(); i++) {

				JSONObject subJson = new JSONObject();

				JSONObject arrobj = (JSONObject) jobhitsArr.get(i);
				JSONObject arrobj1 = arrobj.getJSONObject("_source");

				if (arrobj1.has("id"))
					subJson.put("id", arrobj1.get("id"));
				else
					subJson.put("id", JSONObject.NULL);

				if (arrobj1.has("clientId"))
					subJson.put("clientId", arrobj1.get("clientId"));
				else
					subJson.put("clientId", JSONObject.NULL);

				if (arrobj1.has("contactId"))
					subJson.put("contactId", arrobj1.get("contactId"));
				else
					subJson.put("contactId", JSONObject.NULL);

				if (arrobj1.has("name"))
					subJson.put("name", arrobj1.get("name"));
				else
					subJson.put("name", JSONObject.NULL);

				if (arrobj1.has("jobCode"))
					subJson.put("jobCode", arrobj1.get("jobCode"));
				else
					subJson.put("jobCode", JSONObject.NULL);

				if (arrobj1.has("noOfOpenings"))
					subJson.put("noOfOpenings", arrobj1.get("noOfOpenings"));
				else
					subJson.put("noOfOpenings", JSONObject.NULL);

				if (arrobj1.has("experience"))
					subJson.put("experience", arrobj1.get("experience"));
				else
					subJson.put("experience", JSONObject.NULL);

				if (arrobj1.has("ctc"))
					subJson.put("ctc", arrobj1.get("ctc"));
				else
					subJson.put("ctc", JSONObject.NULL);

				if (arrobj1.has("location"))
					subJson.put("location", arrobj1.get("location"));
				else
					subJson.put("location", JSONObject.NULL);

				if (arrobj1.has("industryType"))
					subJson.put("industryType", arrobj1.get("industryType"));
				else
					subJson.put("industryType", JSONObject.NULL);

				if (arrobj1.has("jobType"))
					subJson.put("jobType", arrobj1.get("jobType"));
				else
					subJson.put("jobType", JSONObject.NULL);

				if (arrobj1.has("industry"))
					subJson.put("industry", arrobj1.get("industry"));
				else
					subJson.put("industry", JSONObject.NULL);

				if (arrobj1.has("funtionalArea"))
					subJson.put("funtionalArea", arrobj1.get("funtionalArea"));
				else
					subJson.put("funtionalArea", JSONObject.NULL);

				if (arrobj1.has("role"))
					subJson.put("role", arrobj1.get("role"));
				else
					subJson.put("role", JSONObject.NULL);

				if (arrobj1.has("skills"))
					subJson.put("skills", arrobj1.get("skills"));
				else
					subJson.put("skills", JSONObject.NULL);

				if (arrobj1.has("education"))
					subJson.put("education", arrobj1.get("education"));
				else
					subJson.put("education", JSONObject.NULL);

				if (arrobj1.has("description"))
					subJson.put("description", arrobj1.get("description"));
				else
					subJson.put("description", JSONObject.NULL);

				if (arrobj1.has("postedDate"))
					subJson.put("postedDate", arrobj1.get("postedDate"));
				else
					subJson.put("postedDate", JSONObject.NULL);

				if (arrobj1.has("modifiedDate"))
					subJson.put("modifiedDate", arrobj1.get("modifiedDate"));
				else
					subJson.put("modifiedDate", JSONObject.NULL);

				if (arrobj1.has("postedBy"))
					subJson.put("postedBy", arrobj1.get("postedBy"));
				else
					subJson.put("postedBy", JSONObject.NULL);

				if (arrobj1.has("modifiedBy"))
					subJson.put("modifiedBy", arrobj1.get("modifiedBy"));
				else
					subJson.put("modifiedBy", JSONObject.NULL);

				if (arrobj1.has("deleted"))
					subJson.put("deleted", arrobj1.get("deleted"));
				else
					subJson.put("deleted", JSONObject.NULL);

				if (arrobj1.has("expiredDate"))
					subJson.put("expiredDate", arrobj1.get("expiredDate"));
				else
					subJson.put("expiredDate", JSONObject.NULL);

				if (arrobj1.has("status"))
					subJson.put("status", arrobj1.get("status"));
				else
					subJson.put("status", JSONObject.NULL);

				jsonArray.put(subJson);

			}

			mainjson.put("total", jobhits.get("total"));
			mainjson.put("response", jsonArray);

			return mainjson.toString();
		}*/
		
		
		//11. Mobile API  * Few Candidate details(for Android team) new Requirement		
		 
		@RequestMapping(value = "candidateid", method = { RequestMethod.GET })
		public @ResponseBody String candidateDataObjectId(@RequestParam("id") String objectId)
				throws JSONException, URISyntaxException, MalformedURLException {

			JSONObject candijson = new JSONObject();
			JSONArray jsonarray = new JSONArray();
			JSONObject jsonmain = new JSONObject();
			String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=id:\""
					+ objectId + "\"";

			System.out.println("url :: " + candidateUrl);

			URL urlcandiateProfile = new URL(candidateUrl);

			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";

			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");

			JSONArray hitsArr = hits.getJSONArray("hits");

			for (int k = 0; k < hitsArr.length(); k++) {

				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");

				if (arrObj1.has("name"))
					candijson.put("name", arrObj1.getString("name"));
				else
					candijson.put("name", JSONObject.NULL);

				if (arrObj1.has("first_name"))
					candijson.put("first_name", arrObj1.getString("first_name"));
				else
					candijson.put("first_name", JSONObject.NULL);

				if (arrObj1.has("middle_name"))
					candijson.put("middle_name", arrObj1.getString("middle_name"));
				else
					candijson.put("middle_name", JSONObject.NULL);

				if (arrObj1.has("last_name"))
					candijson.put("last_name", arrObj1.getString("last_name"));
				else
					candijson.put("last_name", JSONObject.NULL);

				if (arrObj1.has("picture"))
					candijson.put("picture", arrObj1.get("picture"));
				else
					candijson.put("picture", JSONObject.NULL);

				/*
				 * Employment
				 */
				if (arrObj1.has("employment")) {

					JSONObject getemployment = arrObj1.getJSONObject("employment");

					if (getemployment.has("current")) {
						JSONObject getcurrent = getemployment.getJSONObject("current");

						if (getcurrent.has("organization"))
							candijson.put("organization", getcurrent.getString("organization"));
						else
							candijson.put("organization", JSONObject.NULL);

						if (getcurrent.has("designation"))
							candijson.put("designation", getcurrent.getString("designation"));
						else
							candijson.put("designation", JSONObject.NULL);
					}

				} else {
					candijson.put("employment", JSONObject.NULL);
				}
				
				jsonarray.put(candijson);
				jsonmain.put("response", jsonarray);
			}

			return jsonmain.toString();
		}


		//12. Mobile API 
//		Recent Search
//		Parameter- skill,industry type,location,experience ,UserObjectID
//		Returned value- JobName ,Functional Area ,Experience ,CTC ,Location ,Apply Status , Job Freshness(e.g. Today,3 days Ago), CompanyName ,jobID status,status id, Job Count.

	       @RequestMapping(value = "/ElasticAPI/recentSearch", method = { RequestMethod.GET })
	       public @ResponseBody String recentSearch(@RequestParam("skills") String skills,
	                     @RequestParam("industryType") String industryType, @RequestParam("experience") String experience,
	                     @RequestParam("location") String location) throws JSONException, URISyntaxException, MalformedURLException {

	              JSONObject mainjson = new JSONObject();
	              JSONArray jsonArray = new JSONArray();

	              String search = "";

	              if (skills.length() > 0)
	                     search = search + "AND(skills:\"" + skills + "\")";
	              if (industryType.length() > 0)
	                     search = search + "AND(industryType:\"" + industryType + "\")";
	              if (experience.length() > 0)
	                     search = search + "AND(experience:\"" + experience + "\")";
	              if (location.length() > 0)
	                     search = search + "AND(location:\"" + location + "\")";

	              search = search.replaceFirst("AND", "");

	              System.out.println(search);
	              
	              String urlJob = "";
	              
	              if(search.length()>0)
	              urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="
	                           + search;
	              else
	                     urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search";

	              URL Joburl = new URL(urlJob);

	              URI uriJob = new URI(Joburl.getProtocol(), Joburl.getUserInfo(), Joburl.getHost(), Joburl.getPort(),
	                           Joburl.getPath(), Joburl.getQuery(), urlJob);

	              System.out.println("urlJob .." + urlJob);

	              String jsonJobData = restTemplate.getForObject(uriJob, String.class);

	              JSONObject jobHits = new JSONObject(jsonJobData).getJSONObject("hits");
	              JSONArray jobHitsArr = jobHits.getJSONArray("hits");

	              for (int i = 0; i < jobHitsArr.length(); i++) {

	                     String jobId = "";

	                     JSONObject arrobj = (JSONObject) jobHitsArr.get(i);
	                     JSONObject _source = arrobj.getJSONObject("_source");

	                     JSONObject subJson = new JSONObject();

	                     jobId = _source.getString("id");

	                     String urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=jobId:"
	                                  + jobId;

	                     URL urlattach = new URL(urlAttach);

	                     URI uriAttach = new URI(urlattach.getProtocol(), urlattach.getUserInfo(), urlattach.getHost(),
	                                  urlattach.getPort(), urlattach.getPath(), urlattach.getQuery(), urlAttach);

	                     System.out.println("attach query..." + urlAttach);

	                     String jsonAttachData = restTemplate.getForObject(uriAttach, String.class);

	                     JSONObject hits = new JSONObject(jsonAttachData).getJSONObject("hits");
	                     JSONArray hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0) {
	                           JSONObject _source1 = ((JSONObject) hitsArr.get(0)).getJSONObject("_source");

	                           if (_source1.has("jobName"))
	                                  subJson.put("jobName", _source1.get("jobName"));
	                           else
	                                  subJson.put("jobName", JSONObject.NULL);

	                           if (_source1.has("clientName"))
	                                  subJson.put("clientName", _source1.get("clientName"));
	                           else
	                                  subJson.put("clientName", JSONObject.NULL);

	                           if (_source1.has("statusId"))
	                                  subJson.put("statusId", _source1.get("statusId"));
	                           else
	                                  subJson.put("statusId", JSONObject.NULL);

	                           if (_source1.has("status"))
	                                  subJson.put("status", _source1.get("status"));
	                           else
	                                  subJson.put("status", JSONObject.NULL);

	                     }

	                     if (_source.has("funtionalArea"))
	                           subJson.put("funtionalArea", _source.get("funtionalArea"));
	                     else
	                           subJson.put("funtionalArea", JSONObject.NULL);

	                     if (_source.has("location"))
	                           subJson.put("location", _source.get("location"));
	                     else
	                           subJson.put("location", JSONObject.NULL);

	                     if (_source.has("experience"))
	                           subJson.put("experience", _source.get("experience"));
	                     else
	                           subJson.put("experience", JSONObject.NULL);

	                     if (_source.has("ctc"))
	                           subJson.put("ctc", _source.get("ctc"));
	                     else
	                           subJson.put("ctc", JSONObject.NULL);

	                     if (_source.has("id"))
	                           subJson.put("id", _source.get("id"));
	                     else
	                           subJson.put("id", JSONObject.NULL);

	                     if (_source.has("industryType"))
	                           subJson.put("industryType", _source.get("industryType"));
	                     else
	                           subJson.put("industryType", JSONObject.NULL);

	                     if (_source.has("skills"))
	                           subJson.put("skills", _source.get("skills"));
	                     else
	                           subJson.put("skills", JSONObject.NULL);

	                     jsonArray.put(subJson);

	              }
	              
	              mainjson.put("total" , jobHits.get("total"));
	              mainjson.put("response", jsonArray);

	              return mainjson.toString();
	       }



		
}
