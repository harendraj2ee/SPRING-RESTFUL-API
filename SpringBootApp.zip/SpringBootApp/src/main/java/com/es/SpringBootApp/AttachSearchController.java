package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class AttachSearchController {
	
	RestTemplate restTemplate = new RestTemplate();
	String ids = "";
	String name = "";
	String email = "";
	String alternateEmail = "";
	String birthdate = "";
	String mobileNumber = "";
	String lastModified = "";
	String education = "";
	String ug = "";
	String degree = "";
	String degreeType = "";
	String course = "";
	String institute = "";
	String universityOrBoard = "";
	String city = "";
	String fromMonth = "";
	String fromYear = "";
	String toMonth = "";
	String toYear = "";
	String percentage = "";
	String pg = "";

	String doctorate = "";
	String diploma = "";

	String twelveth = "";
	String tenth = "";

	String address = "";
	String permanentAddress = "";
	String country = "";
	String state = "";
	String street = "";
	String pincode = "";
	String location = "";
	String currentAddress = "";

	String preferredLocation = "";
	String salary = "";
	String currentCTCType = "";
	String currentCTC = "";
	String negotiableCTC = "";
	String expectedCTCType = "";
	String expectedCTC = "";
	String takeHome = "";
	String fixed = "";
	String employment = "";
	String current = "";
	String companyName = "";
	String designation = "";
	String first_name = "";
	String middle_name = "";

	String last_name = "";

	Integer age;
	String gender = "";

	String picture = "";
	String profile = "";
	String website = "";
	String jobType = "";
	String employmentType = "";

	String immediateJoiningAvailabilityOrNegotiable = "";
	String minimumDaysRequired = "";

	String salutation = "";

	boolean visibility = false;

	String alternateMobileNumber = "";

	String telePhone = "";

	String officePhone = "";

	String religion = "";

	String family = "";

	String maritalStatus = "";
	String connectSocialNetwork = "";

	String createdDate = "";
	String lastModifiedBy = "";

	String aadharCardNo = "";
	String passportNo = "";
	String passportValidity = "";
	String panNo = "";

	String areaOfSpecialization = "";
	String otherInterest = "";
	String category = "";
	String confidential = "";

	String employmentStatus = "";
	String nationality = "";
	String exNationality = "";
	String experiencedIndustry = "";
	String preferredIndustry = "";

	String experiencedFunctionalArea = "";
	String preferredFunctionalArea = "";
	String language = "";
	String notes = "";
	String noticePeriod = "";

	String reasonForRelocate = "";
	String preferredDistance = "";
	String physicallyChallenged = "";
	String reasonForLeaving = "";
	String willingToRelocate = "";

	String willingToChangeJob = "";
	String resumeHeadLine = "";
	boolean experienced = false;
	boolean fresher = false;
	String shiftWork = "";

	String skillSummary = "";
	String summary = "";
	String federated = "";

	String officePhoneExtention = "";
	boolean isMobileNumberVerified = false;
	String locale = "";
	String isCurrent = "";
	String desc = "";
	String workLocation = "";
	String role = "";
	String level = "";
	String teamSize = "";
	String previous = "";

	String experience = "";
	String months = "";
	String TotalExp = "";
	String years = "";

	String createdBy = "";
	String username = "";

	@RequestMapping(value = "/ElasticAPI/attachsearch", method = { RequestMethod.GET })
	public @ResponseBody String esAttachJobid(@RequestParam("jobid") String jobid,
			@RequestParam("perpage") Integer perpage, @RequestParam(value = "search", required = false) String field,
			@RequestParam("next") Integer next, @RequestParam(value = "sort", required = false) String sort,
			@RequestParam(value = ("sortType"), required = false) String sortType)
			throws MalformedURLException, URISyntaxException, JSONException {
		// int start = 50 * (next);
		int start = perpage * (next);
		// RestTemplate restTemplate=new RestTemplate();
		String urlAttach = "";
		String jsonAttachData = "";
		String urlCandidate = "";
		String jsonCandidateData = "";

		
		if (field != null) {

			field = field.trim();
			/* field= field.replace(":","%3A"); */

			if (field.contains(",")) {
				String[] split = field.split(",");

				System.out.println(Arrays.asList(split));

				List<String> list = Arrays.asList(split);
				String res = String.join(",", list).replaceAll("[:]+", ":\"").replaceAll("([,]+)", "\")AND(");
				res = "(" + res + "\")";

				field = res;

				System.out.println();

			} else {

				String ress = String.join(",", field).replaceAll("[:]+", ":\"").replaceAll("([,]+)", "\")AND(");
				ress = "(" + ress + "\")";
				field = ress;

			}

			System.out.println();
			System.out.println("Field......." + field);
		}

		JSONObject JobHits = new JSONObject();
		JSONObject CandidateHits = new JSONObject();
		JSONObject mainjson = new JSONObject();

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
				+ jobid + "\")&size=" + perpage + "&from=" + start
				+ "&pretty=true&_source=id,objectId,jobId,jobName,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId";// ,resumeName,resume

		URL urlAttachdata = new URL(urlAttach);
		String nullFragment = null;
		// System.out.println("urlJobdata >> "+urlJobdata);
		URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
				urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);

		System.out.println("urlAttach >> " + urlAttach);
		jsonAttachData = restTemplate.getForObject(urlAttach, String.class);

		//System.out.println("Json Attach Data.............. " + jsonAttachData);

		JSONObject jsonObject = new JSONObject(jsonAttachData);
		jsonObject = (JSONObject) jsonObject.get("_shards");
		//System.out.println("shards........" + jsonObject);

		JSONObject jsonObject2 = new JSONObject(jsonAttachData);
		jsonObject2 = (JSONObject) jsonObject2.get("hits");
		//System.out.println("hits,,,,,,,,," + jsonObject2);

		JSONArray jsonarray = (JSONArray) jsonObject2.get("hits");
		//System.out.println("Hits...........??????? >> " + jsonarray);

		String id = "";
		String objectId = "";
		String drop = "";
		String dropComment = "";
		String lastModifiedBy = "";
		String createdDate = "";
		String anchor = "";
		String lastModified = "";
		String anchorId = "";
		String status = "";
		String jobIdd = "";
		String jobName = "";
		String clientId = "";
		String clientName = "";
		String stage = "";
		String attachedBy = "";

		String contactId = "";
		String contactName = "";
		Integer pageUpId = null;
		Integer ghStageId = null;
		Integer ghStatusId = null;
		Integer stageId = null;
		Integer statusId = null;
		Integer withOutId = null;
		String clientPortalStatus = "";
		String statusChangeDate = "";

		String avgScore = "";
		String testScore = "";
		String ghStatus = "";
		String paTestScore = "";
		String changeReason = "";
		String cvSentDate = "";
		String comment = "";
		String clientSheetStatus = "";
		String statusOutcome = "";
		String ghStage = "";

		JobHits.put("Hits", jsonarray.length());

		JSONObject jsonObject4 = new JSONObject();
		JSONObject jsonObject3 = new JSONObject();
		JSONObject attachjson = new JSONObject();
		JSONObject Hits = new JSONObject();
		JSONArray arr = new JSONArray();
		JSONArray skillList = new JSONArray();
		JSONArray project = new JSONArray();
		JSONArray achievement = new JSONArray();
		JSONArray previouss = new JSONArray();
		JSONArray certificates = new JSONArray();
		Hits.put("hits", jsonarray.length());

		List<String> objectIdList = new ArrayList<String>();
		System.out.println("Hits Array size::::::::::::" + jsonarray.length());

		for (int n = 0; n < jsonarray.length(); n++) {

			Map<String, String> map = new HashMap<String, String>();

			jsonObject3 = (JSONObject) jsonarray.get(n);
			//System.out.println("Getting Array Object......." + jsonObject3);

			jsonObject4 = (JSONObject) jsonObject3.get("_source");
			//System.out.println(" Source .........." + jsonObject4);

			if (jsonObject4.has("id")) {
				id = jsonObject4.getString("id");
			}
			if (jsonObject4.has("jobId")) {
				jobIdd = jsonObject4.getString("jobId");
			}
			if (jsonObject4.has("jobName")) {
				jobName = jsonObject4.getString("jobName");
			}
			if (jsonObject4.has("clientId")) {
				clientId = jsonObject4.getString("clientId");
			}
			if (jsonObject4.has("clientName")) {
				clientName = jsonObject4.getString("clientName");
			}
			if (jsonObject4.has("contactId")) {
				contactId = jsonObject4.getString("contactId");
			}
			if (jsonObject4.has("contactName")) {
				contactName = jsonObject4.getString("contactName");
			}
			if (jsonObject4.has("attachedBy")) {
				attachedBy = jsonObject4.getString("attachedBy");
			}
			if (jsonObject4.has("stage")) {
				stage = (String) jsonObject4.get("stage");
			}

			//System.out.println("id value::::________" + id);
			if (jsonObject4.has("objectId")) {
				objectId = jsonObject4.getString("objectId");
				objectIdList.add(objectId);
			}

			//System.out.println("Object value::::" + id);
			if (jsonObject4.has("jobId")) {
				jobIdd = jsonObject4.getString("jobId");
			}
			if (jsonObject4.has("drop")) {
				drop = jsonObject4.getString("drop");
			}
			if (jsonObject4.has("dropComment")) {
				dropComment = jsonObject4.getString("dropComment");
			}
			if (jsonObject4.has("lastModifiedBy")) {
				lastModifiedBy = jsonObject4.getString("lastModifiedBy");
			}
			if (jsonObject4.has("createdDate")) {
				createdDate = jsonObject4.getString("createdDate");
			}
			if (jsonObject4.has("anchor")) {
				anchor = jsonObject4.getString("anchor");
			}
			if (jsonObject4.has("anchorId")) {
				anchorId = jsonObject4.getString("anchorId");
			}
			if (jsonObject4.has("status")) {
				status = jsonObject4.getString("status");
			}

			if (jsonObject4.has("ghStage")) {
				ghStage = jsonObject4.getString("ghStage");
			}

			if (jsonObject4.has("statusOutcome")) {
				statusOutcome = jsonObject4.getString("statusOutcome");
			}

			if (jsonObject4.has("clientSheetStatus")) {
				clientSheetStatus = jsonObject4.getString("clientSheetStatus");
			}

			if (jsonObject4.has("comment")) {
				comment = jsonObject4.getString("comment");
			}

			if (jsonObject4.has("cvSentDate")) {
				cvSentDate = jsonObject4.getString("cvSentDate");
			}

			if (jsonObject4.has("changeReason")) {
				changeReason = jsonObject4.getString("changeReason");
			}

			if (jsonObject4.has("paTestScore")) {
				paTestScore = jsonObject4.getString("paTestScore");
			}

			if (jsonObject4.has("ghStatus")) {
				ghStatus = jsonObject4.getString("ghStatus");
			}

			if (jsonObject4.has("testScore")) {
				testScore = jsonObject4.getString("testScore");
			}

			if (jsonObject4.has("avgScore")) {
				avgScore = jsonObject4.getString("avgScore");
			}

			if (jsonObject4.has("statusChangeDate")) {
				statusChangeDate = jsonObject4.getString("statusChangeDate");
			}

			if (jsonObject4.has("clientPortalStatus")) {
				clientPortalStatus = jsonObject4.getString("clientPortalStatus");
			}

			if (jsonObject4.has("withOutId")) {
				withOutId = (Integer) jsonObject4.get("withOutId");
			}

			if (jsonObject4.has("statusId")) {
				statusId = (Integer) jsonObject4.get("statusId");
			}

			if (jsonObject4.has("stageId")) {
				stageId = (Integer) jsonObject4.get("stageId");
			}

			if (jsonObject4.has("ghStatusId")) {
				ghStatusId = (Integer) jsonObject4.get("ghStatusId");
			}

			if (jsonObject4.has("ghStageId")) {
				ghStageId = (Integer) jsonObject4.get("ghStageId");
			}

			if (jsonObject4.has("pageUpId")) {
				pageUpId = (Integer) jsonObject4.get("pageUpId");
			}

			if (jsonObject4.has("contactId")) {
				contactId = jsonObject4.getString("contactId");
			}

			if (jsonObject4.has("contactName")) {
				contactName = jsonObject4.getString("contactName");
			}

			map.put("id", id);
			map.put("objectId", objectId);
			map.put("jobId", jobid);
			map.put("drop", drop);
			map.put("dropComment", dropComment);
			map.put("lastModifiedBy", lastModifiedBy);
			map.put("createdDate", createdDate);
			map.put("anchor", anchor);
			map.put("anchorId", anchorId);
			map.put("status", status);
			map.put("jobId", jobIdd);
			map.put("jobName", jobName);
			map.put("clientId", clientId);
			map.put("clientName", clientName);
			map.put("ghStage", ghStage);
			map.put("statusOutcome", statusOutcome);
			map.put("clientSheetStatus", clientSheetStatus);
			map.put("comment", comment);
			map.put("cvSentDate", cvSentDate);
			map.put("changeReason", changeReason);
			map.put("paTestScore", paTestScore);
			map.put("ghStatus", ghStatus);
			map.put("testScore", testScore);
			map.put("avgScore", avgScore);

			map.put("contactId", contactId);
			map.put("contactName", contactName);
			map.put("pageUpId", pageUpId.toString());
			map.put("ghStageId", ghStageId.toString());
			map.put("ghStatusId", ghStatusId.toString());
			map.put("stageId", stageId.toString());
			map.put("statusId", statusId.toString());
			map.put("withOutId", withOutId.toString());

			map.put("clientPortalStatus", clientPortalStatus);

			map.put("statusChangeDate", statusChangeDate);

			map.put("attachedBy", attachedBy);
			map.put("stage", stage.toString());

			//System.out.println("attachJson >>>________ " + attachjson);

			// attachjson.accumulate("attach", map);
			mainjson.accumulate("attach", map);
			//System.out.println("Attach Json" + attachjson);

		}

		//System.out.println("main Json.............." + mainjson);
		//System.out.println("arr............." + attachjson);
		// candidate
		JSONArray obj = new JSONArray();
		for (int c = 0; c < objectIdList.size(); c++) {

			if (field == null) {
				urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?sort=name:desc&q=(id:\""
						+ objectIdList.get(c) + "\")&size=" + perpage + "&from=" + start
						+ "&pretty=true&_source=id,name,firstName,last_name,userName,email,birthdate,age,gender,picture,profile,mobileNumber,isMobileNumberVerified,maritalStatus,fedrated,address,notification,visibility,jobType,employmentType,createdDate,lastModified,createdBy,lastModifiedBy,employmentStatus,experiencedIndustry,experiencedFunctionalArea,noticePeriod,preferredLocation,physicallychallenged,experienced,fresher,skillSummary,skills,salary,education,employement,experiences&sort=";
			}

			if (field != null) {
				urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
						+ objectIdList.get(c) + "\")AND" + field + "&size=" + perpage + "&from=" + start
						+ "&pretty=true&_source=id,name,firstName,last_name,userName,email,birthdate,age,gender,picture,profile,mobileNumber,isMobileNumberVerified,maritalStatus,fedrated,address,notification,visibility,jobType,employmentType,createdDate,lastModified,createdBy,lastModifiedBy,employmentStatus,experiencedIndustry,experiencedFunctionalArea,noticePeriod,preferredLocation,physicallychallenged,experienced,fresher,skillSummary,skills,salary,education,employement,experiences";
			}

			/*
			 * if (field.contains("%20")) { urlCandidate =
			 * "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
			 * + objectIdList.get(c) + "\")AND(\"" + ss + "\")&size=" + perpage
			 * + "&from=" + start + "&pretty=true";
			 * 
			 * }
			 */

			Map<String, String> candijson = new HashMap<String, String>();
			Map<String, JSONArray> Skills = new HashMap<String, JSONArray>();
			Map<String, JSONArray> projects = new HashMap<String, JSONArray>();
			Map<String, JSONArray> map = new HashMap<String, JSONArray>();
			Map<String, JSONObject> map1 = new HashMap<String, JSONObject>();
			Map<String, JSONArray> achievements = new HashMap<String, JSONArray>();
			Map<String, JSONArray> previous = new HashMap<String, JSONArray>();
			Map<String, JSONArray> certificatess = new HashMap<String, JSONArray>();

			URL urlcandidatehdata = new URL(urlCandidate);
			URI uricandidates = new URI(urlcandidatehdata.getProtocol(), urlcandidatehdata.getUserInfo(),
					urlcandidatehdata.getHost(), urlcandidatehdata.getPort(), urlcandidatehdata.getPath(),
					urlcandidatehdata.getQuery(), urlCandidate);

			System.out.println("urlCandidate:::::::: " + urlCandidate);
			jsonCandidateData = restTemplate.getForObject(uricandidates, String.class);
			//System.out.println("jsonCandidateData >> " + jsonCandidateData);

			JSONObject jsonCand = new JSONObject(jsonCandidateData);
			jsonCand = (JSONObject) jsonCand.get("_shards");
			//System.out.println(" Candiate Shards...... " + jsonObject);

			JSONObject jsonCand2 = new JSONObject(jsonCandidateData);
			jsonCand2 = (JSONObject) jsonCand2.get("hits");
			//System.out.println("Candidate Hits....... " + jsonCand2);

			JSONArray jsonarrayCand = (JSONArray) jsonCand2.get("hits");
			//System.out.println("Candidate Hits Array..... >> " + jsonarrayCand);
			CandidateHits.put("Hits", objectIdList.size());
			mainjson.put("candidate", CandidateHits);

			//System.out.println("candidate Array Size...." + jsonarrayCand.length());
			if (jsonarrayCand.isNull(0) == false) {
				JSONObject jsonCand3 = (JSONObject) jsonarrayCand.get(0);
				//System.out.println("Getting Object From Candiate Array.... >> " + jsonCand3);

				// JSONObject jsonCand4=new JSONObject(jsonCandidateData);
				JSONObject jsonCand4 = (JSONObject) jsonCand3.get("_source");
				//System.out.println("jsonCand4 >> " + jsonCand4);
				if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
					preferredLocation = jsonCand4.getString("preferredLocation");
				}
				if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
					createdBy = jsonCand4.getString("createdBy");
				}
				if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
					username = jsonCand4.getString("username");
				}
				if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
					ids = jsonCand4.getString("id");
				}
				if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
					name = jsonCand4.getString("name");

				}
				if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
					email = jsonCand4.getString("email");
				}
				if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
					birthdate = jsonCand4.getString("birthdate");
				}
				if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
					mobileNumber = jsonCand4.getString("mobileNumber");
				}
				// ...................

				if (jsonCand4.has("first_name") && !jsonCand4.get("first_name").equals(null)) {
					first_name = jsonCand4.getString("first_name");

				}

				if (jsonCand4.has("middle_name") && !jsonCand4.get("middle_name").equals(null)) {
					middle_name = (String) jsonCand4.get("middle_name");
				}

				if (jsonCand4.has("last_name") && !jsonCand4.get("last_name").equals(null)) {
					last_name = jsonCand4.getString("last_name");

				}

				if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
					alternateEmail = jsonCand4.getString("alternateEmail");

				}

				if (jsonCand4.has("age") && !jsonCand4.get("age").equals(null)) {
					age = (Integer) jsonCand4.get("age");
				}

				if (jsonCand4.has("gender") && !jsonCand4.get("gender").equals(null)) {
					gender = jsonCand4.getString("gender");
				}

				if (jsonCand4.has("picture") && !jsonCand4.get("picture").equals(null)) {
					picture = jsonCand4.getString("picture");
				}

				if (jsonCand4.has("profile") && !jsonCand4.get("profile").equals(null)) {
					profile = jsonCand4.getString("profile");
				}

				if (jsonCand4.has("website") && !jsonCand4.get("website").equals(null)) {
					website = jsonCand4.getString("website");
				}

				if (jsonCand4.has("jobType") && !jsonCand4.get("jobType").equals(null)) {
					jobType = jsonCand4.getString("jobType");
				}

				if (jsonCand4.has("employmentType") && !jsonCand4.get("employmentType").equals(null)) {
					employmentType = jsonCand4.getString("employmentType");
				}

				if (jsonCand4.has("immediateJoiningAvailabilityOrNegotiable")
						&& !jsonCand4.get("immediateJoiningAvailabilityOrNegotiable").equals(null)) {
					immediateJoiningAvailabilityOrNegotiable = jsonCand4
							.getString("immediateJoiningAvailabilityOrNegotiable");

				}

				if (jsonCand4.has("minimumDaysRequired") && !jsonCand4.get("minimumDaysRequired").equals(null)) {
					minimumDaysRequired = jsonCand4.getString("minimumDaysRequired");
				}

				if (jsonCand4.has("salutation") && !jsonCand4.get("salutation").equals(null)) {
					salutation = jsonCand4.getString("salutation");
				}

				if (jsonCand4.has("visibility") && !jsonCand4.get("visibility").equals(null)) {
					visibility = (boolean) jsonCand4.get("visibility");
				}

				if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
					mobileNumber = jsonCand4.getString("mobileNumber");
				}

				if (jsonCand4.has("alternateMobileNumber") && !jsonCand4.get("alternateMobileNumber").equals(null)) {
					alternateMobileNumber = jsonCand4.getString("alternateMobileNumber");
				}

				if (jsonCand4.has("telePhone") && !jsonCand4.get("telePhone").equals(null)) {
					telePhone = jsonCand4.getString("telePhone");
				}

				if (jsonCand4.has("officePhone") && !jsonCand4.get("officePhone").equals(null)) {
					officePhone = jsonCand4.getString("officePhone");
				}

				if (jsonCand4.has("officePhoneExtention") && !jsonCand4.get("officePhoneExtention").equals(null)) {
					officePhoneExtention = jsonCand4.getString("officePhoneExtention");
				}

				if (jsonCand4.has("isMobileNumberVerified") && !jsonCand4.get("isMobileNumberVerified").equals(null)) {
					isMobileNumberVerified = (boolean) jsonCand4.get("isMobileNumberVerified");
				}

				if (jsonCand4.has("locale") && !jsonCand4.get("locale").equals(null)) {
					locale = jsonCand4.getString("locale");
				}

				if (jsonCand4.has("religion") && !jsonCand4.get("religion").equals(null)) {
					religion = jsonCand4.getString("religion");
				}

				if (jsonCand4.has("family") && !jsonCand4.get("family").equals(null)) {
					family = jsonCand4.getString("family");
				}
				if (jsonCand4.has("maritalStatus") && !jsonCand4.get("maritalStatus").equals(null)) {
					maritalStatus = jsonCand4.getString("maritalStatus");
				}

				if (jsonCand4.has("connectSocialNetwork") && !jsonCand4.get("connectSocialNetwork").equals(null)) {
					connectSocialNetwork = jsonCand4.getString("connectSocialNetwork");
				}

				if (jsonCand4.has("createdDate") && !jsonCand4.get("createdDate").equals(null)) {
					createdDate = jsonCand4.getString("createdDate");
				}

				if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
					lastModified = jsonCand4.getString("lastModified");
				}

				if (jsonCand4.has("aadharCardNo") && !jsonCand4.get("aadharCardNo").equals(null)) {
					aadharCardNo = jsonCand4.getString("aadharCardNo");
				}

				if (jsonCand4.has("passportNo") && !jsonCand4.get("passportNo").equals(null)) {
					passportNo = jsonCand4.getString("passportNo");
				}
				if (jsonCand4.has("passportValidity") && !jsonCand4.get("passportValidity").equals(null)) {
					passportValidity = jsonCand4.getString("passportValidity");
				}
				if (jsonCand4.has("panNo") && !jsonCand4.get("panNo").equals(null)) {
					panNo = jsonCand4.getString("panNo");
				}

				if (jsonCand4.has("areaOfSpecialization") && !jsonCand4.get("areaOfSpecialization").equals(null)) {
					areaOfSpecialization = jsonCand4.getString("areaOfSpecialization");
				}

				if (jsonCand4.has("otherInterest") && !jsonCand4.get("otherInterest").equals(null)) {
					otherInterest = jsonCand4.getString("otherInterest");
				}

				if (jsonCand4.has("category") && !jsonCand4.get("category").equals(null)) {
					category = jsonCand4.getString("category");
				}

				if (jsonCand4.has("confidential") && !jsonCand4.get("confidential").equals(null)) {
					confidential = jsonCand4.getString("confidential");
				}

				if (jsonCand4.has("employmentStatus") && !jsonCand4.get("employmentStatus").equals(null)) {
					employmentStatus = jsonCand4.getString("employmentStatus");
				}

				if (jsonCand4.has("nationality") && !jsonCand4.get("nationality").equals(null)) {
					nationality = jsonCand4.getString("nationality");
				}

				if (jsonCand4.has("exNationality") && !jsonCand4.get("exNationality").equals(null)) {
					exNationality = jsonCand4.getString("exNationality");
				}

				if (jsonCand4.has("experiencedIndustry") && !jsonCand4.get("experiencedIndustry").equals(null)) {
					experiencedIndustry = jsonCand4.getString("experiencedIndustry");

				}

				if (jsonCand4.has("preferredIndustry") && !jsonCand4.get("preferredIndustry").equals(null)) {
					preferredIndustry = jsonCand4.getString("preferredIndustry");
				}

				if (jsonCand4.has("experiencedFunctionalArea")
						&& !jsonCand4.get("experiencedFunctionalArea").equals(null)) {
					experiencedFunctionalArea = jsonCand4.getString("experiencedFunctionalArea");
				}

				if (jsonCand4.has("preferredFunctionalArea")
						&& !jsonCand4.get("preferredFunctionalArea").equals(null)) {
					preferredFunctionalArea = jsonCand4.getString("preferredFunctionalArea");
				}

				if (jsonCand4.has("language") && !jsonCand4.get("language").equals(null)) {
					language = jsonCand4.getString("language");
				}

				if (jsonCand4.has("notes") && !jsonCand4.get("notes").equals(null)) {
					notes = jsonCand4.getString("notes");
				}

				if (jsonCand4.has("noticePeriod") && !jsonCand4.get("noticePeriod").equals(null)) {
					noticePeriod = jsonCand4.getString("noticePeriod");
				}

				if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
					preferredLocation = jsonCand4.getString("preferredLocation");
				}

				if (jsonCand4.has("preferredDistance") && !jsonCand4.get("preferredDistance").equals(null)) {
					preferredDistance = jsonCand4.getString("preferredDistance");
				}

				if (jsonCand4.has("physicallyChallenged") && !jsonCand4.get("physicallyChallenged").equals(null)) {
					physicallyChallenged = jsonCand4.getString("physicallyChallenged");
				}

				if (jsonCand4.has("reasonForLeaving") && !jsonCand4.get("reasonForLeaving").equals(null)) {
					reasonForLeaving = jsonCand4.getString("reasonForLeaving");
				}

				if (jsonCand4.has("reasonForRelocate") && !jsonCand4.get("reasonForRelocate").equals(null)) {
					reasonForRelocate = jsonCand4.getString("reasonForRelocate");
				}

				if (jsonCand4.has("willingToRelocate") && !jsonCand4.get("willingToRelocate").equals(null)) {
					willingToRelocate = jsonCand4.getString("willingToRelocate");
				}

				if (jsonCand4.has("willingToChangeJob") && !jsonCand4.get("willingToChangeJob").equals(null)) {
					willingToChangeJob = jsonCand4.getString("willingToChangeJob");
				}
				if (jsonCand4.has("resumeHeadLine") && !jsonCand4.get("resumeHeadLine").equals(null)) {
					resumeHeadLine = jsonCand4.getString("resumeHeadLine");
				}
				if (jsonCand4.has("experienced") && !jsonCand4.get("experienced").equals(null)) {
					experienced = (boolean) jsonCand4.get("experienced");
				}

				if (jsonCand4.has("fresher") && !jsonCand4.get("fresher").equals(null)) {
					fresher = (boolean) jsonCand4.get("fresher");
				}

				if (jsonCand4.has("shiftWork") && !jsonCand4.get("shiftWork").equals(null)) {
					shiftWork = jsonCand4.getString("shiftWork");
				}
				if (jsonCand4.has("skillSummary") && !jsonCand4.get("skillSummary").equals(null)) {
					skillSummary = jsonCand4.getString("skillSummary");
				}
				if (jsonCand4.has("summary") && !jsonCand4.get("summary").equals(null)) {
					summary = jsonCand4.getString("summary");
				}
				if (jsonCand4.has("federated") && !jsonCand4.get("federated").equals(null)) {
					federated = jsonCand4.getString("federated");
				}
				// ...............................................................................................
				if (jsonCand4.has("skills") && !jsonCand4.get("skills").equals(null)) {
					skillList = (JSONArray) jsonCand4.get("skills");
					//System.out.println("skill" + skillList);
				}

				if (jsonCand4.has("achievement") && !jsonCand4.get("achievement").equals(null)) {
					achievement = (JSONArray) jsonCand4.get("achievement");

				}

				if (jsonCand4.has("certificates") && !jsonCand4.get("certificates").equals(null)) {
					certificates = (JSONArray) jsonCand4.get("certificates");

				}
				if (jsonCand4.has("project") && !jsonCand4.get("project").equals(null)) {

					JSONObject json = new JSONObject();

					json = jsonCand4.getJSONObject("project");

					project = (JSONArray) json.get("project");

				}
				if (jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)) {
					preferredLocation = (String) jsonCand4.get("preferredLocation");
					//System.out.println("preferredLocation >> " + preferredLocation);
				} else {
					preferredLocation = "";
					//System.out.println("preferredLocation >> " + preferredLocation);
				}
				if (jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)) {
					createdBy = (String) jsonCand4.get("createdBy");
				} else {
					createdBy = "";
					//System.out.println("createdBy >> " + createdBy);
				}
				if (jsonCand4.has("username") && !jsonCand4.get("username").equals(null)) {
					username = (String) jsonCand4.get("username");
				} else {
					username = "";
					//System.out.println("username >> " + username);
				}
				if (jsonCand4.has("id") && !jsonCand4.get("id").equals(null)) {
					ids = (String) jsonCand4.get("id");
				} else {
					id = "";
					System.out.println("id >> " + id);
				}
				if (jsonCand4.has("name") && !jsonCand4.get("name").equals(null)) {
					name = (String) jsonCand4.get("name");
				} else {
					name = "";
					//System.out.println("name >> " + name);
				}
				if (jsonCand4.has("email") && !jsonCand4.get("email").equals(null)) {
					email = (String) jsonCand4.get("email");
				} else {
					email = "";
					//System.out.println("email >> " + email);
				}
				if (jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)) {
					birthdate = (String) jsonCand4.get("birthdate");
				} else {
					birthdate = "";
					//System.out.println("birthdate >> " + birthdate);
				}
				if (jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)) {
					mobileNumber = (String) jsonCand4.get("mobileNumber");
				} else {
					mobileNumber = "";
					//System.out.println("mobileNumber >> " + mobileNumber);
				}

				if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
					lastModified = (String) jsonCand4.get("lastModified");
					//System.out.println("lastModified dfs>> " + lastModified);
				} else {
					lastModified = "";
					//System.out.println("lastModified fsdss >> " + lastModified);
				}

				//// experience....

				JSONObject experience1 = null;
				if (jsonCand4.has("experience") && !jsonCand4.get("experience").equals(null)) {
					experience1 = (JSONObject) jsonCand4.get("experience");
					//System.out.println("experience1 >> " + experience1);
					if (experience1.has("months") && !experience1.get("months").equals(null)) {
						months = (String) experience1.get("months");
						//System.out.println("months >> " + months);
					} else {
						months = "";
						//System.out.println("months >> " + months);
					}
					if (experience1.has("TotalExp") && !experience1.get("TotalExp").equals(null)) {
						TotalExp = (String) experience1.get("TotalExp");
						//System.out.println("TotalExp >> " + TotalExp);
					} else {
						TotalExp = "";
						//System.out.println("TotalExp >> " + TotalExp);
					}
					if (experience1.has("years") && !experience1.get("years").equals(null)) {
						years = (String) experience1.get("years");
						//System.out.println("years >> " + years);
					} else {
						years = "";
					}
				} else {
					experience = "";
					//System.out.println("experience >> " + experience);
				}

				// salary......
				JSONObject salary1 = null;

				if (jsonCand4.has("salary") && !jsonCand4.get("salary").equals(null)) {
					salary1 = (JSONObject) jsonCand4.get("salary");
					//System.out.println("salry1 >> " + salary1);
					if (salary1.has("currentCTCType") && !salary1.get("currentCTCType").equals(null)) {
						currentCTCType = (String) salary1.get("currentCTCType");
					} else {
						currentCTCType = "";
						System.out.println("currentCTCType >> " + currentCTCType);
					}
					if (salary1.has("currentCTC") && !salary1.get("currentCTC").equals(null)) {
						currentCTC = (String) salary1.get("currentCTC");
						//System.out.println("currentCTC >> " + currentCTC);
					} else {
						currentCTC = "";
						//System.out.println("currentCTC >> " + currentCTC);
					}
					if (salary1.has("negotiableCTC") && !salary1.get("negotiableCTC").equals(null)) {
						negotiableCTC = (String) salary1.get("negotiableCTC");
						//System.out.println("negotiableCTC >> " + negotiableCTC);
					} else {
						negotiableCTC = "";
						//System.out.println("negotiableCTC >> " + negotiableCTC);
					}
					if (salary1.has("expectedCTCType") && !salary1.get("expectedCTCType").equals(null)) {
						expectedCTCType = (String) salary1.get("expectedCTCType");
						System.out.println("expectedCTCType >> " + expectedCTCType);
					} else {
						expectedCTCType = "";
						//System.out.println("expectedCTCType >> " + expectedCTCType);
					}
					if (salary1.has("expectedCTC") && !salary1.get("expectedCTC").equals(null)) {
						expectedCTC = (String) salary1.get("expectedCTC");
						//System.out.println("expectedCTC >> " + expectedCTC);
					} else {
						expectedCTC = "";
						//System.out.println("expectedCTC >> " + expectedCTC);
					}
					if (salary1.has("takeHome") && !salary1.get("takeHome").equals(null)) {
						takeHome = (String) salary1.get("takeHome");
						//System.out.println("takeHome >> " + takeHome);
					} else {
						takeHome = "";
						//System.out.println("takeHome >> " + takeHome);
					}
					if (salary1.has("fixed") && !salary1.get("fixed").equals(null)) {
						fixed = (String) salary1.get("fixed");
						//System.out.println("fixed >> " + fixed);
					} else {
						fixed = "";
						//System.out.println("fixed >> " + fixed);
					}

				} else {
					salary = "";
					//System.out.println("salary >> " + salary);
				}

				/// address......permanent
				JSONObject permanentAddressJson = null;
				JSONObject permanentAddress1 = null;
				JSONObject currentAddressJson = null;
				JSONObject currentAddress1 = null;
				JSONObject addressJson = null;
				JSONObject addressJson1 = null;

				if (jsonCand4.has("address") && !jsonCand4.get("address").equals(null)) {
					addressJson = (JSONObject) jsonCand4.get("address");
					if (addressJson.has("permanentAddress") && !addressJson.get("permanentAddress").equals(null)) {
						//System.out.println("permanentAddress >> " + addressJson.get("permanentAddress"));
						// permanentAddress1=new JSONObject();
						addressJson1 = (JSONObject) addressJson.get("permanentAddress");
						// addressJson1=(JSONObject)
						// addressJson1.get("permanentAddress");
						//System.out.println("permanentAddress1 >>> " + addressJson1);
						if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
							country = (String) addressJson1.get("country");
							System.out.println("country >> " + country);
						} else {
							country = "";
							//System.out.println("country >> " + country);
						}
						if (addressJson1.has("state") && !addressJson1.get("state").equals(null)) {
							state = (String) addressJson1.get("state");
							//System.out.println("state >> " + state);
						} else {
							state = "";
							//System.out.println("state >> " + state);
						}
						if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
							city = (String) addressJson1.get("city");
						} else {
							city = "";
							//System.out.println("city >> " + city);
						}
						if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
							street = (String) addressJson1.get("street");
							//System.out.println("street >> " + street);
						} else {
							street = "";
							//System.out.println("street >> " + street);
						}
						if (addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)) {
							pincode = (String) addressJson1.get("pincode");
							//System.out.println("pincode >> " + pincode);
						} else {
							pincode = "";
							//System.out.println("pincode >> " + pincode);
						}
						if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
							location = (String) addressJson1.get("location");
							//System.out.println("location >> " + location);
						} else {
							location = "";
							//System.out.println("location >> " + location);
						}
					} else {
						permanentAddress = "";
						//System.out.println("permanentAddress >> " + permanentAddress);
					}
					/// current address write code.. START

					// currentAddressJson=(JSONObject) jsonCand4.get("address");
					addressJson = (JSONObject) jsonCand4.get("address");

					if (addressJson.has("currentAddress") && !addressJson.get("currentAddress").equals(null)) {
						//System.out.println("currentAddress >> " + addressJson.get("currentAddress"));
						// currentAddress1=new JSONObject();
						addressJson1 = (JSONObject) addressJson.get("currentAddress");
						//System.out.println("currentAddress1 >>> " + addressJson1);
						if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
							country = (String) addressJson1.get("country");
							//System.out.println("country >> " + country);
						} else {
							country = "";
							//System.out.println("country current >> " + country);
						}
						if (addressJson1.has("state") && !addressJson1.get("state").equals(null)) {
							state = (String) addressJson1.get("state");
							//System.out.println("state  current>> " + state);
						} else {
							state = "";
							//System.out.println("state current>> " + state);
						}
						if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
							city = (String) addressJson1.get("city");
						} else {
							city = "";
							//System.out.println("city current>> " + city);
						}
						if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
							street = (String) addressJson1.get("street");
							System.out.println("street current>> " + street);
						} else {
							street = "";
							//System.out.println("street current>> " + street);
						}
						if (addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)) {
							pincode = (String) addressJson1.get("pincode");
							//System.out.println("pincode current>> " + pincode);
						} else {
							pincode = "";
							
						}
						if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
							location = (String) addressJson1.get("location");
							//System.out.println("location current >> " + location);
						} else {
							location = "";
							//System.out.println("location current >> " + location);
						}
					} else {
						currentAddress = "";
						//System.out.println("currentAddress current >> " + currentAddress);
					}
				} else {
					address = "";
					//System.out.println("address >> " + address);
				}

				/// Education..
				JSONObject ugjson = null;
				JSONObject ug1 = null;
				JSONObject pgjson = null;
				JSONObject pg1 = null;
				JSONObject twelvethjson = null;
				JSONObject twelveth1 = null;
				JSONObject tenthjson = null;
				JSONObject tenth1 = null;

				JSONObject educationjson = null;
				JSONObject educationjson1 = null;

				if (jsonCand4.has("education") && !jsonCand4.get("education").equals(null)) {
					// education=(String) jsonCand4.get("education");
					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("ug") && !educationjson.get("ug").equals(null)) {
						//System.out.println("ug >>> " + educationjson.get("ug"));
						// ug1=new JSONObject();
						// ug1=(JSONObject) ugjson.get("ug");

						educationjson1 = (JSONObject) educationjson.get("ug");
					//	System.out.println("ug1 >> " + educationjson1);
						if (educationjson1.has("degree") && !educationjson1.get("degree").equals(null)) {
							degree = (String) educationjson1.get("degree");
						//	System.out.println("degree >>> " + educationjson1.get("degree"));
						} else {
							degree = "";
						//	System.out.println("degree >> " + degree);
						}

						// has means json field have or not proper work has key
						// in
						// json
						if (educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)) {
							degreeType = (String) educationjson1.get("degreeType");
						} else {
							degreeType = "";
						}

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
						} else {
							course = "";
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
						} else {
							institute = "";
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
							//System.out.println("universityOrBoard >>> " + educationjson1.get("universityOrBoard"));
						} else {
							universityOrBoard = "";
						//	System.out.println("universityOrBoard >> " + universityOrBoard);
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
						} else {
							city = "";
							//System.out.println("city >> " + city);
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
							//System.out.println("fromMonth >>> " + educationjson1.get("fromMonth"));
						} else {
							fromMonth = "";
							//System.out.println("fromMonth >> " + fromMonth);
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
							System.out.println("fromYear >>> " + educationjson1.get("fromYear"));
						} else {
							fromYear = "";
							//System.out.println("fromYear >> " + fromYear);
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
							System.out.println("toMonth >> " + toMonth);
						} else {
							toMonth = "";
						//	System.out.println("toMonth >> " + toMonth);
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
							//System.out.println("toYear >> " + toYear);
						} else {
							toYear = "";
							//System.out.println("toYear >> " + toYear);
						}
						if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
							percentage = (String) educationjson1.get("percentage");
							//System.out.println("percentage >> " + percentage);
						} else {
							percentage = "";
						//	System.out.println("percentage >> " + percentage);
						}

					} else {
						ug = "";
						//System.out.println("ug >> " + ug);
					}
					// for pg

				//	System.out.println("Hiiiiiiiiiiiii");
					// pgjson = (JSONObject) jsonCand4.get("education");
					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("pg") && !educationjson.get("pg").equals(null)) {
						//System.out.println("pg1 Json >>> " + educationjson.get("pg"));

						// pg1=new JSONObject();
						// System.out.println("pg1 >> "+pg1);
						// pg1=(JSONObject) pgjson.get("pg");
						educationjson1 = (JSONObject) educationjson.get("pg");
						//System.out.println("pg1 >> " + educationjson1);

						if (educationjson1.has("degree") && !educationjson1.get("degree").equals(null)) {
							degree = (String) educationjson1.get("degree");
							//System.out.println("degree >>> " + educationjson1.get("degree"));
						} else {
							degree = "";
							//System.out.println("degree >> " + degree);
						}
						if (educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)) {
							degreeType = (String) educationjson1.get("degreeType");
							//System.out.println("degreeType >>> " + educationjson1.get("degreeType"));
						} else {
							degreeType = "";
							//System.out.println("degreeType >> " + degreeType);
						}

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
							//System.out.println("course >>> " + educationjson1.get("course"));
						} else {
							course = "";
							System.out.println("course >> " + course);
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
							//System.out.println("institute >>> " + educationjson1.get("institute"));
						} else {
							institute = "";
							//System.out.println("institute >> " + institute);
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
							//System.out.println("universityOrBoard >>> " + educationjson1.get("universityOrBoard"));
						} else {
							universityOrBoard = "";
							//System.out.println("universityOrBoard >> " + universityOrBoard);
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
							//System.out.println("city >>> " + educationjson1.get("city"));
						} else {
							city = "";
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
							//System.out.println("fromMonth >>> " + educationjson1.get("fromMonth"));
						} else {
							fromMonth = "";
							//System.out.println("fromMonth >> " + fromMonth);
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
							//System.out.println("fromYear >>> " + educationjson1.get("fromYear"));
						} else {
							fromYear = "";
							//System.out.println("fromYear >> " + fromYear);
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
							//System.out.println("toMonth >> " + toMonth);
						} else {
							toMonth = "";
							//System.out.println("toMonth >> " + toMonth);
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
							//System.out.println("toYear >> " + toYear);
						} else {
							toYear = "";
							//System.out.println("toYear >> " + toYear);
						}
						if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
							percentage = (String) educationjson1.get("percentage");
							//System.out.println("percentage >> " + percentage);
						} else {
							percentage = "";
							//System.out.println("percentage >> " + percentage);
						}

					} else {
						pg = "";
						//System.out.println("pg >>" + pg);
					} // end pg

					//// doctrate start

					//System.out.println("Hiiiiiiiiiiiii");
					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("doctorate") && !educationjson.get("doctorate").equals(null)) {
						//System.out.println("doctorate Json >>> " + educationjson.get("doctorate"));

						// JSONObject doctorate1=new JSONObject();
						// System.out.println("doctorate1 >> "+doctorate1);
						educationjson1 = (JSONObject) educationjson.get("twelveth");
						//System.out.println("doctorate1 >>> " + educationjson1);

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
							//System.out.println("course >>> " + educationjson1.get("course"));
						} else {
							course = "";
							//System.out.println("course >> " + course);
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
							//System.out.println("institute >>> " + educationjson1.get("institute"));
						} else {
							institute = "";
							//System.out.println("institute >> " + institute);
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
							//System.out.println("universityOrBoard >>> " + educationjson1.get("universityOrBoard"));
						} else {
							universityOrBoard = "";
							//System.out.println("universityOrBoard >> " + universityOrBoard);
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
						} else {
							city = "";
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
						} else {
							fromMonth = "";
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
						} else {
							fromYear = "";
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
						} else {
							toMonth = "";
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
						} else {
							toYear = "";
							System.out.println("toYear >> " + toYear);
						}
						if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
							percentage = (String) educationjson1.get("percentage");
						} else {
							percentage = "";
						}

					} else {
						doctorate = "";
					}

					/// start Diploma

					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("diploma") && !educationjson.get("diploma").equals(null)) {

						// JSONObject diploma1=new JSONObject();
						// System.out.println("diploma1 >> "+diploma1);
						educationjson1 = (JSONObject) educationjson.get("diploma");

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
						} else {
							course = "";
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
						} else {
							institute = "";
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
						} else {
							universityOrBoard = "";
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
						} else {
							city = "";
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
						} else {
							fromMonth = "";
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
						} else {
							fromYear = "";
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
						} else {
							toMonth = "";
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
						} else {
							toYear = "";
						}
						if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
							percentage = (String) educationjson1.get("percentage");
							System.out.println("percentage >> " + percentage);
						} else {
							percentage = "";
						}

					} else {
						diploma = "";
					}

					//////// start 12th
					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("twelveth") && !educationjson.get("twelveth").equals(null)) {

						// twelveth1=new JSONObject();
						// System.out.println("twelveth1 >> "+twelveth1);
						educationjson1 = (JSONObject) educationjson.get("twelveth");

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
							System.out.println("course >>> " + educationjson1.get("course"));
						} else {
							course = "";
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
						} else {
							institute = "";
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
						} else {
							universityOrBoard = "";
							System.out.println("universityOrBoard >> " + universityOrBoard);
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
						} else {
							city = "";
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
							System.out.println("fromMonth >>> " + educationjson1.get("fromMonth"));
						} else {
							fromMonth = "";
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
						} else {
							fromYear = "";
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
						} else {
							toMonth = "";
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
						} else {
							toYear = "";
						}
						if (!educationjson1.get("percentage").equals(null)) {
							percentage = (String) educationjson1.get("percentage");
						} else {
							percentage = "";
						}

						System.out.println("educationjson1 >> " + educationjson1);
						if (educationjson1.has("percentage")) {
							if (!educationjson1.get("percentage").equals(null)) {
								if (educationjson1.has("percentage")) {
									percentage = (String) educationjson1.get("percentage");
								} else {
									percentage = "";
								}
							}
						}

					} else {
						twelveth = "";
					}

					// end twelveth

					// Start tenth
					educationjson = (JSONObject) jsonCand4.get("education");
					if (educationjson.has("tenth") && !educationjson.get("tenth").equals(null)) {

						// tenth1=new JSONObject();
						// System.out.println("tenth1 >> "+tenth1);
						educationjson1 = (JSONObject) educationjson.get("tenth");

						if (educationjson1.has("degree") && !educationjson1.get("degree").equals(null)) {
							degree = (String) educationjson1.get("degree");
						} else {
							degree = "";
						}
						if (educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)) {
							degreeType = (String) educationjson1.get("degreeType");
						} else {
							degreeType = "";
						}

						if (educationjson1.has("course") && !educationjson1.get("course").equals(null)) {
							course = (String) educationjson1.get("course");
						} else {
							course = "";
						}
						if (educationjson1.has("institute") && !educationjson1.get("institute").equals(null)) {
							institute = (String) educationjson1.get("institute");
						} else {
							institute = "";
						}
						if (educationjson1.has("universityOrBoard")
								&& !educationjson1.get("universityOrBoard").equals(null)) {
							universityOrBoard = (String) educationjson1.get("universityOrBoard");
						} else {
							universityOrBoard = "";
						}
						if (educationjson1.has("city") && !educationjson1.get("city").equals(null)) {
							city = (String) educationjson1.get("city");
						} else {
							city = "";
						}
						if (educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)) {
							fromMonth = (String) educationjson1.get("fromMonth");
						} else {
							fromMonth = "";
						}
						if (educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)) {
							fromYear = (String) educationjson1.get("fromYear");
						} else {
							fromYear = "";
						}
						if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
							toMonth = (String) educationjson1.get("toMonth");
						} else {
							toMonth = "";
						}
						if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
							toYear = (String) educationjson1.get("toYear");
						} else {
							toYear = "";
						}

						System.out.println("educationjson1 >> " + educationjson1);
						if (educationjson1.has("percentage")) {
							if (!educationjson1.get("percentage").equals(null)) {
								if (educationjson1.has("percentage")) {
									percentage = (String) educationjson1.get("percentage");
								} else {
									percentage = "";
								}
							}
						}

					} else {
						tenth = "";
					}

					// end tenth
					//////////

				} else {
					education = "";
				}

				JSONObject employment1 = null;
				JSONObject current1 = null;
				JSONArray previous1 = null;
				String previousOrganization = "";
				String previousDesignation = "";
				String previousLevel = "";
				String previousCity = "";
				String previousFromMonth = "";
				String previousFromYear = "";
				String previousToMonth = "";
				String previousToYear = "";
				String previousDescription = "";

				if (jsonCand4.has("employement") && !jsonCand4.get("employement").equals(null)) {
					employment1 = jsonCand4.getJSONObject("employement");
					if (employment1.has("current") && !employment1.get("current").equals(null)) {
						current1 = employment1.getJSONObject("current");
						if (current1.has("companyName") && !current1.get("companyName").equals(null)) {
							companyName = current1.getString("companyName");
						} else {
							companyName = "";
						}
						if (current1.has("designation") && !current1.get("designation").equals(null)) {
							designation = current1.getString("designation");
						} else {
							designation = "";
						}
						if (current1.has("isCurrent") && !current1.get("isCurrent").equals(null)) {
							isCurrent = current1.getString("isCurrent");
						} else {
							isCurrent = "";
						}
						if (current1.has("desc") && !current1.get("desc").equals(null)) {
							desc = current1.getString("desc");
							System.out.println("desc >> " + desc);
						} else {
							desc = "";
						}
						if (current1.has("workLocation") && !current1.get("workLocation").equals(null)) {
							workLocation = current1.getString("workLocation");
						} else {
							workLocation = "";
						}
						if (current1.has("role") && !current1.get("role").equals(null)) {
							role = current1.getString("role");
						} else {
							role = "";
						}
						if (current1.has("level") && !current1.get("level").equals(null)) {
							level = current1.getString("level");
						} else {
							level = "";
						}
						if (current1.has("teamSize") && !current1.get("teamSize").equals(null)) {
							teamSize = current1.getString("teamSize");
						} else {
							teamSize = "";
						}

					}

					if (employment1.has("previous") && !employment1.get("previous").equals(null)
							|| !employment1.isNull("previous")) {
						previous1 = employment1.getJSONArray("previous");
						int i = 0;
						for (i = 0; i < previous1.length(); i++) {
							JSONObject jsonprevious = previous1.getJSONObject(i);
							if (jsonprevious.has("organization") && !jsonprevious.get("organization").equals(null)) {
								previousOrganization = jsonprevious.getString("organization");
							//	System.out.println("previousOrganization >>" + previousOrganization);
							} else {
								previousOrganization = "";
							}
							if (jsonprevious.has("designation") && !jsonprevious.get("designation").equals(null)) {
								previousDesignation = jsonprevious.getString("designation");
							} else {
								previousDesignation = "";
							}
							if (jsonprevious.has("level") && !jsonprevious.get("level").equals(null)) {
								previousLevel = jsonprevious.getString("level");
								;
							} else {
								previousLevel = "";
							}
							if (jsonprevious.has("city") && !jsonprevious.get("city").equals(null)) {
								previousCity = jsonprevious.getString("city");
							} else {
								previousCity = "";
							}
							if (jsonprevious.has("fromMonth") && !jsonprevious.get("fromMonth").equals(null)) {
								previousFromMonth = jsonprevious.getString("fromMonth");
							} else {
								previousFromMonth = "";
							}
							if (jsonprevious.has("fromYear") && !jsonprevious.get("fromYear").equals(null)) {
								previousFromYear = jsonprevious.getString("fromYear");
							} else {
								previousFromYear = "";
							}
							if (jsonprevious.has("toMonth") && !jsonprevious.get("toMonth").equals(null)) {
								previousToMonth = jsonprevious.getString("toMonth");
							} else {
								previousToMonth = "";
							}
							if (jsonprevious.has("toYear") && !jsonprevious.get("toYear").equals(null)) {
								previousToYear = jsonprevious.getString("toYear");
							} else {
								previousToYear = "";
							}
							if (jsonprevious.has("description") && !jsonprevious.get("description").equals(null)) {
								previousDescription = jsonprevious.getString("description");
							} else {
								previousDescription = "";
							}
						}

					}
				}
				// JSONArray alternateEmailArray = null;
				if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
					alternateEmail = (String) jsonCand4.get("alternateEmail");
				} else {

					alternateEmail = "";
				}
				JSONArray altenaiteEmail1 = null;
				int m = 0;
				if (jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)) {
					altenaiteEmail1 = (JSONArray) jsonCand4.get("alternateEmail");
					for (m = 0; m < altenaiteEmail1.length(); m++) {
						altenaiteEmail1.get(m);
					}
				} else {
					alternateEmail = "";
				}

				candijson.put("preferredLocation", preferredLocation);
				candijson.put("createdBy", createdBy);
				candijson.put("username", username);
				candijson.put("id", ids);
				candijson.put("name", name);
				candijson.put("email", email);
				candijson.put("birthdate", birthdate);
				candijson.put("mobileNumber", mobileNumber);
				candijson.put("lastModified", lastModified);
				candijson.put("first_name", first_name);
				candijson.put("middle_name", middle_name);
				candijson.put("last_name", last_name);

				candijson.put("alternateEmail", alternateEmail);
				candijson.put("age", age.toString());
				candijson.put("gender", gender);
				candijson.put("picture", picture);

				candijson.put("profile", profile);
				candijson.put("website", website);
				candijson.put("jobType", jobType);

				candijson.put("employmentType", employmentType);
				candijson.put("immediateJoiningAvailabilityOrNegotiable", immediateJoiningAvailabilityOrNegotiable);

				candijson.put("employmentType", employmentType);

				candijson.put("immediateJoiningAvailabilityOrNegotiable", immediateJoiningAvailabilityOrNegotiable);
				candijson.put("minimumDaysRequired", minimumDaysRequired);
				candijson.put("salutation", salutation);

				candijson.put("visibility", String.valueOf(visibility));
				candijson.put("mobileNumber", mobileNumber);
				candijson.put("alternateMobileNumber", alternateMobileNumber);
				candijson.put("telePhone", telePhone);
				candijson.put("officePhone", officePhone);
				candijson.put("officePhoneExtention", officePhoneExtention);
				candijson.put("isMobileNumberVerified", String.valueOf(isMobileNumberVerified));

				candijson.put("locale", locale);
				candijson.put("religion", religion);
				candijson.put("family", family);
				candijson.put("maritalStatus", maritalStatus);

				candijson.put("connectSocialNetwork", connectSocialNetwork);
				candijson.put("createdDate", createdDate);
				candijson.put("lastModified", lastModified);
				candijson.put("aadharCardNo", aadharCardNo);

				candijson.put("passportNo", passportNo);

				candijson.put("passportValidity", passportValidity);

				candijson.put("panNo", panNo);

				candijson.put("areaOfSpecialization", areaOfSpecialization);

				candijson.put("otherInterest", otherInterest);

				candijson.put("category", category);

				candijson.put("confidential", confidential);

				candijson.put("employmentStatus", employmentStatus);

				candijson.put("nationality", nationality);
				candijson.put("exNationality", exNationality);
				candijson.put("experiencedIndustry", experiencedIndustry);
				candijson.put("preferredIndustry", preferredIndustry);
				candijson.put("experiencedFunctionalArea", experiencedFunctionalArea);
				candijson.put("preferredFunctionalArea", preferredFunctionalArea);
				candijson.put("language", language);
				candijson.put("notes", notes);
				candijson.put("noticePeriod", noticePeriod);
				candijson.put("preferredLocation", preferredLocation);

				candijson.put("preferredDistance", preferredDistance);
				candijson.put("physicallyChallenged", physicallyChallenged);
				candijson.put("reasonForLeaving", reasonForLeaving);
				candijson.put("reasonForRelocate", reasonForRelocate);

				candijson.put("willingToRelocate", willingToRelocate);
				candijson.put("willingToChangeJob", willingToChangeJob);
				candijson.put("resumeHeadLine", resumeHeadLine);
				candijson.put("experienced", String.valueOf(experienced));

				candijson.put("fresher", String.valueOf(fresher));

				candijson.put("shiftWork", shiftWork);

				candijson.put("skillSummary", skillSummary);

				candijson.put("summary", summary);

				candijson.put("federated", federated);

				//System.out.println("candidate Json......" + candijson);
				achievements.put("achievement", achievement);
				certificatess.put("certificate", certificates);
				previous.put("previous", previouss);
				projects.put("project", project);
				Skills.put("skills", skillList);
				map.put("alternateEmail", altenaiteEmail1);
				map1.put("experience", experience1);
				map1.put("salary", salary1);
				map1.put("address", addressJson);

				map1.put("education", educationjson);
				map1.put("employment", employment1);

				obj.put(candijson);
				obj.put(map1);
				obj.put(map);
				obj.put(Skills);
				obj.put(projects);
				obj.put(achievements);
				obj.put(certificatess);

			}
		}

		mainjson.put("candidate", obj);

		System.out.println("Main Json........22222" + mainjson);

		//
		JSONObject object = new JSONObject();

		object.accumulate("response", Hits);
		object.accumulate("response", mainjson);

		

		return object.toString();

	}

}
