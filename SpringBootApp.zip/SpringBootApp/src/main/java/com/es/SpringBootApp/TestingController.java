package com.es.SpringBootApp;



import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.model.Attach;
import com.es.model.Candidate;

@RestController
public class TestingController {
/*	@Autowired
	private RestTemplate restTemplate;*/
	RestTemplate restTemplate = new RestTemplate();
	private Integer numFound = 0;
	static String Jsonkey = "";

	static String checkcontains = "none";
	// Attach return data candidate & attach

	@RequestMapping(value = "/ElasticAPI/f@ck", method = { RequestMethod.POST })
	public @ResponseBody String esAttach(@RequestBody String field, @RequestParam("jobid") String jobid,
			@RequestParam(value = "perpage", required = false) Integer perpage,
			@RequestParam(value = "next", required = false) Integer next) throws MalformedURLException,
			URISyntaxException, ParseException, JSONException, UnsupportedEncodingException {

		ArrayList<Attach> list = new ArrayList<Attach>();
		list = attach(jobid, perpage, next, field);
		org.json.JSONObject obj = new org.json.JSONObject();
		org.json.JSONObject obj1 = new org.json.JSONObject();
		org.json.JSONArray array = new org.json.JSONArray();

		array.put(list);
		obj.put("attach", list);
		obj.put("numFound", this.getNumFound());
		obj1.put("response", obj);

		return obj1.toString();

	}

	// Candidate
	public static ArrayList<Candidate> candidate(String objectId, Integer perpage, Integer start, String field)
			throws ParseException, UnsupportedEncodingException {

		// objectId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
		// int perPage=10;
		// int start=0;
		String name = "";
		String first_name = "";
		String last_name = "";
		String middle_name = "";
		String mobileNumber = "";
		String email = "";

		field = field.replace("{", "}").replace("}", "").replace("\"", "").trim();

		System.out.println("Field Before......." + field);

		if (field != null) {

			field = field.trim();
			/* field= field.replace(":","%3A"); */

			if (field.contains(",")) {
				String[] split = field.split(",");

				// System.out.println(Arrays.asList(split));

				List<String> list2 = Arrays.asList(split);
				String res = String.join(",", list2).replaceAll("[:]+", ":\"").replaceAll("([,]+)",
						"\")" + Jsonkey + "(");
				res = "(" + res + "\")";

				field = res;

				// System.out.println();

			} else {

				String ress = String.join(",", field).replaceAll("[:]+", ":\"").replaceAll("([,]+)",
						"\")" + Jsonkey + "(");
				ress = "(" + ress + "\")";
				field = ress;

			}

		}
		System.out.println("candidate field after......." + field);

		if (field.contains("@")) {
			field = field.replaceAll("@", "%40");
			// field=field.replace("(email:\"\"", "(email:"+ "\"");
			field = field.replace("\"", "");

			// field = URLEncoder.encode(field, "UTF-8");
			System.out.println("Cand@" + field);
		}
		ArrayList<Candidate> list = new ArrayList<Candidate>();
		RestTemplate restTemplate = new RestTemplate();
		String urlCandidate = "";

		System.out.println("check contains ,,,,,," + checkcontains);

		if (checkcontains.equals("none") && !field.equals("(\")")) {
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""

					+ objectId + "\")" + Jsonkey + field
					+ "&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";// ,resumeName,resume
		}

		else if (checkcontains.equals("Begins with") && !field.equals("(\")")) {

			System.out.println("Contains URL..........");
			field = field.replace(":\"", ":").replace("\")", "*)");
			System.out.println("Field after Contains ......." + field);
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""

					+ objectId + "\")" + Jsonkey + field
					+ "&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";// ,resumeName,resume
		}

		else if (checkcontains.equals("Not Contains") && !field.equals("(\")")) {

			System.out.println("Not Contains URL..........");

			field = "(NOT(" + field + "))";

			System.out.println("Field after Not  Contains ......." + field);
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""

					+ objectId + "\")" + Jsonkey+field
					+ "&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";// ,resumeName,resume
		}

		else if (field.equals("(\")")) {
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
					+ objectId
					+ "\")&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";// ,resumeName,resume
		}

		System.out.println("urlCandidate >> " + urlCandidate);
		JSONParser jsonParsercan = new JSONParser();
		String candidate = restTemplate.getForObject(urlCandidate, String.class);
		JSONObject jsoncan = (JSONObject) ((JSONObject) jsonParsercan.parse(candidate)).get("hits");

		// System.out.println("jsoncan::::"+jsoncan);

		JSONArray arraycan = (JSONArray) jsoncan.get("hits");
		System.out.println("jsoncanlength::::" + arraycan.size());
		Iterator itratorcan = arraycan.iterator();

		while (itratorcan.hasNext()) {
			Candidate e = new Candidate();

			JSONObject jsonObjectcan = (JSONObject) itratorcan.next();
			// System.out.println("jsonObject::::"+jsonObject);
			jsonObjectcan = (JSONObject) jsonObjectcan.get("_source");
			System.out.println("J:::" + jsonObjectcan);

			name = (String) jsonObjectcan.get("name");
			e.setName(name);
			System.out.println("candidate name::::" + name);
			e.setName(name);
			first_name = (String) jsonObjectcan.get("first_name");
			e.setFirst_name(first_name);
			last_name = (String) jsonObjectcan.get("last_name");
			e.setLast_name(last_name);
			middle_name = (String) jsonObjectcan.get("middle_name");
			e.setMiddle_name(middle_name);
			email = (String) jsonObjectcan.get("email");
			e.setEmail(email);
			mobileNumber = (String) jsonObjectcan.get("mobileNumber");
			e.setMobileNumber(mobileNumber);

			list.add(e);

		}
		return list;
	}

	// Attach
	public ArrayList<Attach> attach(String jobId, Integer perpage, Integer next, String field)
			throws ParseException, UnsupportedEncodingException {
		System.out.println("hello!!!");
		// jobId="0996c1b6-fd4f-41a4-b8bb-bc46130c64aa";
		// int perPage=10;
		// int start=0;

		Integer numFound = 0;
		String id = "";
		String objectId = "";
		String jobIdd = "";
		String drop = "";
		String dropComment = "";
		String lastModifiedBy = "";
		String createdDate = "";
		String anchor = "";
		String anchorId = "";
		String status = "";
		String jobName = "";
		String clientId = "";
		String clientName = "";
		String contactId = "";
		String contactName = "";
		String attachedBy = "";
		String lastModified = "";
		String cvSentDate = "";
		String statusChangeDate = "";
		String statusOutcome = "";
		String changeReason = "";
		String clientPortalStatus = "";
		String clientSheetStatus = "";
		String paTestScore = "";
		String testScore = "";
		String avgScore = "";
		Long pageUpId;
		String ghStage = "";
		String ghStatus = "";
		Long ghStageId;
		Long ghStatusId;
		Long stageId;
		Long statusId;
		String stage = "";
		String comment = "";
		Long withOutId;
		String resumeName = "";
		/*
		 * if(field.contains("@")){ field=field.replace("@", "%40");
		 * //field=field.replace("email:\"\"", "email:");
		 * field=field.replace("\"", "");
		 * 
		 * System.out.println("@@@atach"+field); }
		 */

		ArrayList<Attach> list = new ArrayList<Attach>();
		ArrayList<Candidate> canlist = new ArrayList<Candidate>();
		RestTemplate restTemplate = new RestTemplate();

		/* int start = perpage*(next); */

		System.out.println("field......" + field);

		JSONParser parser = new JSONParser();

		JSONArray jsonArray = (JSONArray) parser.parse(field);

		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject json = (JSONObject) jsonArray.get(i);

			System.out.println("JsonArray........." + json);

			// JSONObject json = (JSONObject) parser.parse(field);
			String attachField = "";
			String Jsondrop = "";
			String JsondropComment = "";
			String JsonlastModifiedBy = "";
			String JsoncreatedDate = "";
			String Jsonanchor = "";
			String JsonanchorId = "";
			String Jsonstatus = "";

			String JsonjobName = "";
			String JsonclientId = "";
			String JsonclientName = "";
			String JsoncontactId = "";
			String JsoncontactName = "";
			String JsonattachedBy = "";

			String JsonlastModified = "";

			String JsoncvSentDate = "";
			String JsonstatusChangeDate = "";
			String JsonstatusOutcome = "";
			String JsonchangeReason = "";
			String JsonclientPortalStatus = "";
			String JsonclientSheetStatus = "";
			String JsonpaTestScore = "";
			String JsontestScore = "";
			String JsonJsonavgScore = "";
			String JsonpageUpId = "";
			String JsonghStage = "";
			String JsonghStatus = "";
			Long JsonghStageId;
			String JsonghStatusId = "";
			String JsonstageId = "";
			String JsonstatusId = "";
			String Jsonstage = "";
			String JsonavgScore = "";
			String Jsoncomment = "";
			String JsonwithOutId = "";
			String JsonresumeName = "";

			if (json.get("jobName") != null) {
				JsonjobName = (String) json.get("jobName");

				JsonjobName = "," + "jobName:" + JsonjobName;
				attachField += JsonjobName;
				json.remove("jobName");

			}

			if (json.get("key") != null) {
				Jsonkey = (String) json.get("key");

				if (Jsonkey.equals("Contains")) {
					Jsonkey = "OR";
				}
				if (Jsonkey.equals("Equal")) {
					Jsonkey = "AND";
				}

				if (Jsonkey.equals("Begins with")) {
					checkcontains = "Begins with";
					Jsonkey = "AND";
				}

				if (Jsonkey.equals("Not Contains")) {
					checkcontains = "Not Contains";
					Jsonkey = "AND";
				}

				json.remove("key");
			}

			if (json.get("clientId") != null) {
				JsonclientId = (String) json.get("clientId");

				JsonclientId = "," + "clientId:" + JsonclientId;
				attachField += JsonclientId;
				json.remove("clientId");

			}

			if (json.get("clientName") != null) {
				JsonclientName = (String) json.get("clientName");

				JsonclientName = "," + "clientName:" + JsonclientName;
				attachField += JsonclientName;

				json.remove("clientName");

			}

			if (json.get("contactId") != null) {
				JsoncontactId = (String) json.get("contactId");

				JsoncontactId = "," + "contactId:" + JsoncontactId;
				attachField += JsoncontactId;
				json.remove("contactId");

			}

			if (json.get("contactName") != null) {
				JsoncontactName = (String) json.get("contactName");

				JsoncontactName = "," + "contactName:" + JsoncontactName;
				attachField += JsoncontactName;
				json.remove("contactName");

			}

			if (json.get("attachedBy") != null) {
				JsonattachedBy = (String) json.get("attachedBy");

				JsonattachedBy = "," + "attachedBy:" + JsonattachedBy;

				attachField += JsonattachedBy;
				json.remove("attachedBy");

			}

			if (json.get("lastModifiedBy") != null) {
				JsonlastModifiedBy = (String) json.get("lastModifiedBy");

				JsonlastModifiedBy = "," + "lastModifiedBy:" + JsonlastModifiedBy;

				attachField += JsonlastModifiedBy;

				json.remove("lastModifiedBy");

			}

			if (json.get("lastModified") != null) {
				JsonlastModified = (String) json.get("lastModified");

				JsonlastModified = "," + "lastModified:" + JsonlastModified;
				attachField += JsonlastModifiedBy;
				json.remove("lastModified");

			}
			if (json.get("createdDate") != null) {
				JsoncreatedDate = (String) json.get("createdDate");

				JsoncreatedDate = "," + "createdDate:" + JsoncreatedDate;
				attachField += JsoncreatedDate;
				json.remove("createdDate");

			}
			if (json.get("anchor") != null) {
				Jsonanchor = (String) json.get("anchor");

				Jsonanchor = "," + "anchor:" + Jsonanchor;
				attachField += Jsonanchor;
				json.remove("anchor");

			}

			if (json.get("cvSentDate") != null) {
				JsoncvSentDate = (String) json.get("cvSentDate");

				JsoncvSentDate = "," + "cvSentDate:" + JsoncvSentDate;
				attachField += JsoncvSentDate;
				json.remove("cvSentDate");

			}
			if (json.get("statusChangeDate") != null) {
				JsonstatusChangeDate = (String) json.get("statusChangeDate");

				JsonstatusChangeDate = "," + "statusChangeDate:" + JsonstatusChangeDate;
				attachField += JsonstatusChangeDate;
				json.remove("statusChangeDate");

			}

			if (json.get("statusOutcome") != null) {
				JsonstatusOutcome = (String) json.get("statusOutcome");

				JsonstatusOutcome = "," + "statusOutcome:" + JsonstatusOutcome;
				attachField += JsonstatusOutcome;
				json.remove("statusOutcome");

			}

			if (json.get("changeReason") != null) {
				JsonchangeReason = (String) json.get("changeReason");

				JsonchangeReason = "," + "changeReason:" + JsonchangeReason;
				attachField += JsonchangeReason;
				json.remove("JsonchangeReason");

			}

			if (json.get("clientPortalStatus") != null) {
				JsonclientPortalStatus = (String) json.get("clientPortalStatus");

				JsonclientPortalStatus = "," + "clientPortalStatus:" + JsonclientPortalStatus;
				attachField += JsonclientPortalStatus;
				json.remove("JsonclientPortalStatus");

			}

			if (json.get("clientSheetStatus") != null) {
				JsonclientSheetStatus = (String) json.get("clientSheetStatus");

				JsonclientSheetStatus = "," + "clientSheetStatus:" + JsonclientSheetStatus;
				attachField += JsonclientSheetStatus;
				json.remove("clientSheetStatus");

			}
			if (json.get("paTestScore") != null) {
				JsonpaTestScore = (String) json.get("paTestScore");

				JsonpaTestScore = "," + "paTestScore:" + JsonpaTestScore;
				attachField += JsonpaTestScore;
				json.remove("paTestScore");

			}

			if (json.get("testScore") != null) {
				JsontestScore = (String) json.get("testScore");

				JsontestScore = "," + "testScore:" + JsontestScore;
				attachField += JsontestScore;
				json.remove("testScore");

			}
			if (json.get("avgScore") != null) {
				JsonavgScore = (String) json.get("avgScore");

				JsonavgScore = "," + "avgScore:" + JsonavgScore;
				attachField += JsonavgScore;
				json.remove("avgScore");

			}
			if (json.get("avgScore") != null) {
				JsonavgScore = (String) json.get("avgScore");

				JsonavgScore = "," + "avgScore:" + JsonavgScore;
				attachField += JsonavgScore;
				json.remove("avgScore");

			}

			if (json.get("status") != null) {
				Jsonstatus = (String) json.get("status");

				Jsonstatus = "," + "status:" + Jsonstatus;
				attachField += Jsonstatus;
				json.remove("status");

			}

			if (json.get("dropComment") != null) {
				JsondropComment = (String) json.get("dropComment");

				JsondropComment = "," + "dropComment:" + JsondropComment;
				attachField += JsondropComment;
				json.remove("dropComment");

			}

			if (json.get("comment") != null) {
				Jsoncomment = (String) json.get("comment");

				Jsoncomment = "," + "comment:" + Jsoncomment;
				attachField += Jsoncomment;
				json.remove("comment");

			}

			if (json.get("resumeName") != null) {
				JsonresumeName = (String) json.get("resumeName");

				JsonresumeName = "," + "resumeName:" + JsonresumeName;
				attachField += JsonresumeName;
				json.remove("resumeName");

			}

			System.out.println("attach field........" + attachField);
			attachField = attachField.replaceFirst(",", "");

			if (!attachField.equals("")) {
				field = attachField;
			} else {
				field = "none";
			}
			if (field != null) {

				field = field.trim();
				/* field= field.replace(":","%3A"); */

				if (field.contains(",")) {
					String[] split = field.split(",");

					// System.out.println(Arrays.asList(split));

					List<String> list2 = Arrays.asList(split);
					String res = String.join(",", list2).replaceAll("[:]+", ":\"").replaceAll("([,]+)",
							"\")" + Jsonkey + "(");
					res = "(" + res + "\")";

					field = res;

					// System.out.println();

				} else {

					String ress = String.join(",", field).replaceAll("[:]+", ":\"").replaceAll("([,]+)",
							"\")" + Jsonkey + "(");
					ress = "(" + ress + "\")";
					field = ress;

				}

			}

			System.out.println("final field......" + field);

			if (field.contains("@")) {
				field = field.replace("@", "%40");
				// field=field.replace("(email:\"\"", "(email:"+ "\"");
				field = field.replaceAll("\"", "");

				// field = URLEncoder.encode(field, "UTF-8");
				System.out.println("Cand@" + field);
			}
			String urlAttach = "";
			if (checkcontains.equals("none") && !field.contains("none")) {
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
						+ jobId + "\")" + Jsonkey + field

						+ "&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";// ,resumeName,resume
			}

			else if (checkcontains.equals("Begins with") && !field.contains("none")) {

				System.out.println("Contains URL..........");
				field = field.replace(":\"", ":").replace("\")", "*)");
				System.out.println("Field after Contains ......." + field);
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
						+ jobId + "\")" + Jsonkey + field
						+ "&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";// ,resumeName,resume
			}

			else if (checkcontains.equals("Not Contains") && !field.contains("none")) {

				System.out.println("Not Contains URL..........");
				field = "(NOT(" + field + "))";
				System.out.println("Field after NOT  Contains ......." + field);
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
						+ jobId + "\")" + Jsonkey+field
						+ "&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";// ,resumeName,resume
			}

			else if (field.contains("none")) {
				urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""
						+ jobId
						+ "\")&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";// ,resumeName,resume
			}
			System.out.println("urlAttach >> " + urlAttach);
			JSONParser jsonParsercan = new JSONParser();
			String attach = restTemplate.getForObject(urlAttach, String.class);
			JSONObject jsoncan = (JSONObject) ((JSONObject) jsonParsercan.parse(attach)).get("hits");

			System.out.println("total:::::::" + jsoncan.get("total"));

			// JSONObject total = new JSONObject();
			// total.put("", jsoncan.get("total"));
			JSONArray arraycan = (JSONArray) jsoncan.get("hits");
			System.out.println("jsoncanlength::::" + arraycan.size());
			Iterator itratorcan = arraycan.iterator();

			while (itratorcan.hasNext()) {
				Attach e = new Attach();

				JSONObject jsonObjectcan = (JSONObject) itratorcan.next();
				// System.out.println("jsonObject::::"+jsonObject);
				jsonObjectcan = (JSONObject) jsonObjectcan.get("_source");
				System.out.println("jsonAttach.....:::" + jsonObjectcan);

				id = (String) jsonObjectcan.get("id");
				e.setId(id);
				// jsonobj.put("id", id);
				System.out.println("id value::::________" + id);
				objectId = (String) jsonObjectcan.get("objectId");

				canlist = candidate(objectId, perpage, next, json.toString());
				e.setCandidate(canlist);

				e.setObjectId(objectId);
				System.out.println("objectId::::" + objectId);

				jobIdd = (String) jsonObjectcan.get("jobId");
				e.setJobIdd(jobIdd);
				drop = (String) jsonObjectcan.get("drop");
				e.setDrop(drop);
				dropComment = (String) jsonObjectcan.get("dropComment");
				e.setDropComment(dropComment);
				lastModifiedBy = (String) jsonObjectcan.get("lastModifiedBy");
				e.setLastModifiedBy(lastModifiedBy);
				createdDate = (String) jsonObjectcan.get("createdDate");
				e.setCreatedDate(createdDate);
				anchor = (String) jsonObjectcan.get("anchor");
				e.setAnchor(anchor);

				anchorId = (String) jsonObjectcan.get("anchorId");
				e.setAnchor(anchorId);
				e.setAnchorId(anchorId);
				status = (String) jsonObjectcan.get("status");
				e.setStatus(status);

				jobName = (String) jsonObjectcan.get("jobName");
				e.setJobName(jobName);
				clientId = (String) jsonObjectcan.get("clientId");
				e.setClientId(clientId);
				clientName = (String) jsonObjectcan.get("clientName");
				e.setClientName(clientName);
				contactId = (String) jsonObjectcan.get("contactId");
				e.setContactId(contactId);
				contactName = (String) jsonObjectcan.get("contactName");
				e.setContactName(contactName);
				attachedBy = (String) jsonObjectcan.get("attachedBy");
				e.setAttachedBy(attachedBy);
				lastModified = (String) jsonObjectcan.get("lastModified");
				e.setLastModified(lastModified);
				cvSentDate = (String) jsonObjectcan.get("cvSentDate");
				e.setCvSentDate(cvSentDate);
				statusChangeDate = (String) jsonObjectcan.get("statusChangeDate");
				e.setStatusChangeDate(statusChangeDate);
				statusOutcome = (String) jsonObjectcan.get("statusOutcome");
				e.setStatusOutcome(statusOutcome);
				changeReason = (String) jsonObjectcan.get("changeReason");
				e.setChangeReason(changeReason);
				clientPortalStatus = (String) jsonObjectcan.get("clientPortalStatus");
				e.setClientPortalStatus(clientPortalStatus);
				clientSheetStatus = (String) jsonObjectcan.get("clientSheetStatus");
				e.setClientSheetStatus(clientSheetStatus);
				paTestScore = (String) jsonObjectcan.get("paTestScore");
				e.setPaTestScore(paTestScore);
				testScore = (String) jsonObjectcan.get("testScore");
				e.setTestScore(testScore);
				avgScore = (String) jsonObjectcan.get("avgScore");
				e.setAvgScore(avgScore);
				pageUpId = (Long) jsonObjectcan.get("pageUpId");

				stage = (String) jsonObjectcan.get("stage");
				e.setStage(stage);
				comment = (String) jsonObjectcan.get("comment");
				e.setComment(comment);
				/*
				 * withOutId=(Long) jsonObjectcan.get("withOutId");
				 * e.setWithOutId(withOutId);
				 */
				resumeName = (String) jsonObjectcan.get("resumeName");
				e.setResumeName(resumeName);

				if (!canlist.isEmpty()) {
					numFound = numFound + 1;
					this.setNumFound(numFound);
					list.add(e);
				} else {
					list.add(null);
				}
			}

		}
		return list;

	}

	public Integer getNumFound() {
		return numFound;
	}

	public void setNumFound(Integer numFound2) {
		this.numFound = numFound2;
	}

}
