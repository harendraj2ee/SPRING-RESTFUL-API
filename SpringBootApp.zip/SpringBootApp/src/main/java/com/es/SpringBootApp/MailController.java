package com.es.SpringBootApp;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.es.model.CanditateResume;
import com.es.model.Job;
import com.es.model.JobDetail;
import com.es.service.ResumeService;

@RestController
public class MailController {
	ResumeService resumeService = new ResumeService();
	RestTemplate restTemplate=new RestTemplate();
	@RequestMapping(value="/ElasticAPI/test")
	public String mailModule(){
		return "Hello this is the simeple test result for es api..... TESt";
	}
	//Returning data REsume Behalf of objectid DynamicCandidate
	@RequestMapping(value = "/ElasticAPI/resume")
	public @ResponseBody String resumeElasticAPIMongo(@RequestParam("objectid") String objectid) throws Exception {

		List<CanditateResume> list = new ArrayList<CanditateResume>();
		list = resumeService.getResumeDataElasticAPIMongo(objectid);
		//System.out.println("list >> "+list);
		JSONObject json = new JSONObject();
		json.put("response", list);
		// System.out.println("json data:::"+json);
		return json.toString();
	}
	
	/*@RequestMapping(value = "/ElasticAPI/candresume", method = RequestMethod.GET)
	public @ResponseBody String esCandidateResume(@RequestParam("id")String id) {
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+id+"\")&size=10&from=0&pretty=true&_source=resume";//id,
		System.out.println("ESURL Candidate1    >> " + url);
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);
		
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		return jsonElasticUrl;
	}

	@RequestMapping(value = "/ElasticAPI/attachresume", method = RequestMethod.GET)
	public @ResponseBody String esAttachResume(@RequestParam("id")String id) {
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach2/_search?q=(id:\""+id+"\")&size=10&from=0&pretty=true&_source=resume";//id,
		System.out.println("ESURL Candidate1    >> " + url);
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);
		
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		return jsonElasticUrl;
	}*/
	
	
	/*@RequestMapping(value="/MailAPI/data")
	public String getDataMthod(){
		return "It is a test for mail API welcom to Springboot API 1st time.......";
		
	}
	@RequestMapping(value="/")
	public String jspMethodTest(){
		return "index.jsp";
		
	}
	
	//@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	@RequestMapping(value ="/aa", method = RequestMethod.GET)
    public @ResponseBody String index(Model model) {
        String message = "Hello Spring Boot + JSP";
        model.addAttribute("message", message);
        //return model.toString();
        return "index";
    }*/
	

	
	
	@RequestMapping(value = "/ElasticAPI/candresume", method = RequestMethod.GET)
	public @ResponseBody String esCandidateResume(@RequestParam("id") String id) throws JSONException, ParseException {
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
				+ id + "\")&size=10&from=0&pretty=true&_source=resume,first_name,last_name,name,resumeName";// id,
		System.out.println("ESURL Candidate1    >> " + url);
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);

		//System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		
		JSONParser jsonParsercan  = new JSONParser();
		
		// String candidate = restTemplate.getForObject(jsonElasticUrl, String.class);
		 
		     org.json.simple.JSONObject jsoncan= (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan.parse(jsonElasticUrl)).get("hits");
			 	
		      // System.out.println("jsoncan::::"+jsoncan);
		        
		     org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
		       // System.out.println("jsoncanlength::::"+arraycan.size());
		        Iterator itratorcan = arraycan.iterator();
		        org.json.simple.JSONObject jsonObject = new org.json.simple.JSONObject();
		        org.json.simple.JSONObject jsonresponse = new org.json.simple.JSONObject();
		        //System.out.println("jsonObject_________________:::"+jsonObject);
		        while(itratorcan.hasNext()){
		        
		         org.json.simple.JSONObject jsonObjectcan=(org.json.simple.JSONObject) itratorcan.next();
		        //System.out.println("jsonObject::::"+jsonObject);
		        jsonObjectcan=  (org.json.simple.JSONObject) jsonObjectcan.get("_source");
		        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
			    String name=(String) jsonObjectcan.get("name");
		        jsonObject.put("name", name);
		        String first_name=(String) jsonObjectcan.get("first_name");
		        jsonObject.put("first_name", first_name);
		        String last_name=(String) jsonObjectcan.get("last_name");
		        jsonObject.put("last_name", last_name);
		        String  resume=(String) jsonObjectcan.get("resume");
		        jsonObject.put("resume", resume);
		        String  resumeName=(String) jsonObjectcan.get("resumeName");
		        jsonObject.put("resumeName", resumeName);
		        jsonresponse.put("response", jsonObject);
		     
		}  
		
		//System.out.println("::::::::_______"+jsonObject);
		
		return jsonresponse.toString();
	}
	
	//Attach Resume
	@RequestMapping(value = "/ElasticAPI/attachresume", method = RequestMethod.GET)
	public @ResponseBody String esAttachResume(@RequestParam("id") String id) throws ParseException {
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(id:\""
				+ id + "\")&size=10&from=0&pretty=true&_source=resume,resumeName";// id,
		System.out.println("ESURL Candidate1    >> " + url);
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);

	     JSONParser jsonParsercan  = new JSONParser();
		
		// String candidate = restTemplate.getForObject(jsonElasticUrl, String.class);
		 
		     org.json.simple.JSONObject jsoncan= (org.json.simple.JSONObject) ((org.json.simple.JSONObject) jsonParsercan.parse(jsonElasticUrl)).get("hits");
			 	
		      // System.out.println("jsoncan::::"+jsoncan);
		        
		     org.json.simple.JSONArray arraycan = (org.json.simple.JSONArray) jsoncan.get("hits");
		       // System.out.println("jsoncanlength::::"+arraycan.size());
		        Iterator itratorcan = arraycan.iterator();
		        org.json.simple.JSONObject jsonObject = new org.json.simple.JSONObject();
		        org.json.simple.JSONObject jsonresponse = new org.json.simple.JSONObject();
		        //System.out.println("jsonObject_________________:::"+jsonObject);
		        while(itratorcan.hasNext()){
		        
		         org.json.simple.JSONObject jsonObjectcan=(org.json.simple.JSONObject) itratorcan.next();
		        //System.out.println("jsonObject::::"+jsonObject);
		        jsonObjectcan=  (org.json.simple.JSONObject) jsonObjectcan.get("_source");
		        //System.out.println("jsonObjectcan:::"+jsonObjectcan);
		        
			    String resume=(String) jsonObjectcan.get("resume");
			    String resumeName=(String) jsonObjectcan.get("resumeName");
		        jsonObject.put("resume", resume);
		        jsonObject.put("resumeName", resumeName);
		       
		        jsonresponse.put("response", jsonObject);
		     
		}  
		
		//System.out.println("::::::::_______"+jsonObject);
		
			
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		return jsonresponse.toString();
	}

	//Attach Details behalf of attach id.
	@RequestMapping(value = "ElasticAPI/attid")
	public @ResponseBody String attachDataOnly(@RequestParam("id")String id) throws JSONException{
		String urlAttach ="";
		
		
		 String ids="";
		 String objectId="";
		 String jobId="";
		 String drop="";
		 String dropComment="";
		 String lastModifiedBy="";
		 String createdDate="";
		 String anchor="";
		 String anchorId="";
		 String status="";
		 String jobName = "";
		 String clientId = "";
		 String clientName = "";
		 String contactId = "";
		 String contactName ="";
		 String attachedBy = "";
		 String lastModified = "";
		 String cvSentDate = "";
		 String statusChangeDate = "";
		 String statusOutcome = "";
		 String changeReason = "";
		 String clientPortalStatus = "";
		 String clientSheetStatus = "";
		 String paTestScore = "";
		 String testScore = "";
		 String avgScore = "";
		 Long pageUpId;
		 String ghStage = "";
		 String ghStatus = "";
		 Long ghStageId ;
		 Long ghStatusId;
		 Long stageId;
		 Long statusId;
		 String stage="";
		 String comment = "";
		 Long withOutId;
		 String resumeName = "";	
		 
		 
		JSONObject jsonMain=new JSONObject();
		JSONObject jsonObjDocs = new JSONObject();
		JSONObject jsonObjResponse = new JSONObject();
		JSONArray array = new JSONArray();
		org.json.JSONArray array1 = new org.json.JSONArray();
		//urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(id:\""+ id + "\")&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,paTestScore,testScore,avgScore,pageUpId,ghStage,ghStatus,ghStageId,ghStatusId,stageId,statusId,stage,status,drop,dropComment,comment,withOutId,resumeName";// ,resumeName,resume
		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(id:\""+ id + "\")&size=10&from=0&pretty=true&_source_excludes=resume";// ,resumeName,resume

		String jsonAttach = restTemplate.getForObject(urlAttach, String.class);
        
        org.json.JSONObject hits = new org.json.JSONObject(jsonAttach).getJSONObject("hits");
		org.json.JSONArray hitsArr = hits.getJSONArray("hits");

		for (int i = 0; i < hitsArr.length(); i++) {
			JobDetail jd = new JobDetail();
			System.out.println("Array length >> "+hitsArr.length());
			org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
			org.json.JSONObject _source = arrobj.getJSONObject("_source");
			if (_source.has("id")) {
				 ids= _source.getString("id");
				 //String jobids= "4986f9b7-f872-4b4b-bdd0-6ce9fef4d6a0";s
				 jd.setId(id);
				 //jobIds = jobIds + "+" + _source.getString("jobId");
			} 
			else {
				_source.accumulate("id", "");
			}
			if (_source.has("objectId")) {
				objectId = _source.getString("objectId");
			}else {
				_source.accumulate("objectId", "");
			}
			if (_source.has("jobId")) {
				jobId = _source.getString("jobId");
			}else {
				_source.accumulate("jobId", "");
			}
			if (_source.has("drop")) {
				drop = _source.getString("drop");
			}else {
				_source.accumulate("drop", "");
			}
			if (_source.has("attachedBy")) {
				attachedBy = _source.getString("attachedBy");
			}else {
				_source.accumulate("attachedBy", "");
			}
			if (_source.has("clientName")) {
				clientName = _source.getString("clientName");
			}else {
				_source.accumulate("clientName", "");
			}
			if (_source.has("contactId")) {
				contactId = _source.getString("contactId");
			}else {
				_source.accumulate("contactId", "");
			}
			if (_source.has("contactName")) {
				contactName = _source.getString("contactName");
			}else {
				_source.accumulate("contactName", "");
			}
			if (_source.has("lastModifiedBy")) {
				lastModifiedBy = _source.getString("lastModifiedBy");
			}else {
				_source.accumulate("lastModifiedBy", "");
			}
			if (_source.has("lastModified")) {
				lastModified = _source.getString("lastModified");
			}else {
				_source.accumulate("lastModified", "");
			}
			if (_source.has("anchor")) {
				anchor = _source.getString("anchor");
			}else {
				_source.accumulate("anchor", "");
			}
			if (_source.has("anchorId")) {
				anchorId = _source.getString("anchorId");
			}else {
				_source.accumulate("anchorId", "");
			}
			if (_source.has("paTestScore")) {
				paTestScore = _source.getString("paTestScore");
			}else {
				_source.accumulate("paTestScore", "");
			}
			if (_source.has("testScore")) {
				testScore = _source.getString("testScore");
			}else {
				_source.accumulate("testScore", "");
			}
			if (_source.has("avgScore")) {
				avgScore = _source.getString("avgScore");
			}else {
				_source.accumulate("avgScore", "");
			}
			if (_source.has("pageUpId")) {
				pageUpId = _source.getLong("pageUpId");
			}else {
				_source.accumulate("pageUpId", "");
			}
			if (_source.has("ghStatus")) {
				ghStatus = _source.getString("ghStatus");
			}else {
				_source.accumulate("ghStatus", "");
			}
			if (_source.has("ghStageId")) {
				ghStageId = _source.getLong("ghStageId");
			}else {
				_source.accumulate("ghStageId", "");
			}
			if (_source.has("ghStatusId")) {
				ghStatusId = _source.getLong("ghStatusId");
			}else {
				_source.accumulate("ghStatusId", "");
			}
			if (_source.has("stageId")) {
				stageId = _source.getLong("stageId");
			}else {
				_source.accumulate("stageId", "");
			}
			if (_source.has("statusId")) {
				statusId = _source.getLong("statusId");
			}else {
				_source.accumulate("statusId", "");
			}
			if (_source.has("stage")) {
				stage = _source.getString("stage");
			}else {
				_source.accumulate("stage", "");
			}
			if (_source.has("dropComment")) {
				dropComment = _source.getString("dropComment");
			}else {
				_source.accumulate("dropComment", "");
			}
			if (_source.has("comment")) {
				comment = _source.getString("comment");
			}else {
				_source.accumulate("comment", "");
			}
			if (_source.has("withOutId")) {
				withOutId = _source.getLong("withOutId");
			}else {
				_source.accumulate("withOutId", "");
			}
			if (_source.has("resumeName")) {
				resumeName = _source.getString("resumeName");
			}else {
				_source.accumulate("resumeName", "");
			}
			if (_source.has("status")) {
				status= _source.getString("status");
			}else {
				_source.accumulate("status", "");
			}
		
			array1.put(_source);
			jsonObjDocs.put("docs", array1);
			jsonObjResponse.put("response", jsonObjDocs);
			System.out.println("jsonObjResponse >> " + jsonObjResponse);
			return jsonObjResponse.toString();
		}
	return "";	
	}
	
	
	
	
	//candidate behalf of empid & fedrated value show html working....
	
	
	@RequestMapping(value = "/ElasticAPI/candihtml", method = RequestMethod.GET)
    public @ResponseBody String esCandidateResume(@RequestParam("id")String id, @RequestParam("fedrated")String fedrated) {
           String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""+id+"\")AND(fedrated:\""+fedrated+"\")&size=10&from=0&pretty=true&_source=id,fedrated,html,naukriHtml,naukriGulf,monster,monsterus,indeed,linkedin,careerBuilder,jobserve,other";//id,
           System.out.println("ESURL Candidates    >> " + url);
           String jsonElasticUrl = restTemplate.getForObject(url, String.class);
           
           // System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
           return jsonElasticUrl;
    }


	@RequestMapping(value="/ElasticAPI/industrydata")
	public @ResponseBody String industrydata() throws Exception {
	       
	       String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/industrydata/_search?default_operator=AND&q=(_id:\"1\")&size=200&from=0&_source=industry.id,industry.name";
	       
	       System.out.println("url IndustryDaa ::::::"+url);
	       
	       URL url1 = new URL(url);
	       String nullFragment1 = null;

	       URI UOrig1 = new URI(url1.getProtocol(), url1.getUserInfo(), url1.getHost(), url1.getPort(), url1.getPath(),url1.getQuery(), nullFragment1);
	       
	       //System.out.println("url for htmlData without cmpny::: "+Rooturl);
	          
	       // jsonData=restTemplate.getForObject(UOrig1, String.class);
	       String json  = restTemplate.getForObject(UOrig1, String.class);
	       return json;
	}

	@RequestMapping(value="/ElasticAPI/fareadata")
	public @ResponseBody String fareadata() throws Exception {
	       
	       String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/functionalarea/_search?default_operator=AND&q=(_id:\"1\")&size=200&from=0&_source=f_area.id,f_area.name";
	       
	       System.out.println("url FunctinalAREa ::::::"+url);
	       
	       URL url1 = new URL(url);
	       String nullFragment1 = null;

	       URI UOrig1 = new URI(url1.getProtocol(), url1.getUserInfo(), url1.getHost(), url1.getPort(), url1.getPath(),url1.getQuery(), nullFragment1);
	       
	       //System.out.println("url for htmlData without cmpny::: "+Rooturl);
	          
	       // jsonData=restTemplate.getForObject(UOrig1, String.class);
	       String json  = restTemplate.getForObject(UOrig1, String.class);
	       return json;
	}

	
	
	
	
	@RequestMapping(value = "/ElasticAPI/esjob", method = RequestMethod.GET)
	public @ResponseBody String esDataIndexJob(@RequestHeader HttpHeaders headers) {
		/*if (!headers.containsKey("authorization")) {
			System.out.println("No Authentication");
			return "{\"error\":\"Please Provide The Authentication\"}";
		}
		String authString = headers.getFirst("authorization");
		if (!restService.isUserAuthenticated(authString)) {
			System.out.println("Wrong Authentication.....");
			return "{\"error\":\"User not authenticated\"}";
		}*/
		RestTemplate restTemplate=new RestTemplate();
		// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?default_operator=AND&q=fromMail:"+name+"&size=50&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/dataindexjob/_search?size=10&from=0&pretty=true&_source=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId";
		System.out.println("ESURL dataindexjob  Data NonParam  >> " + url);
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);
		// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		return jsonElasticUrl;
	}


	@RequestMapping(value = "/ElasticAPI/jobid", method = { RequestMethod.GET })
	public @ResponseBody String esDataIndexjobId(@RequestParam("id") String id)
			throws MalformedURLException, URISyntaxException {
		
		RestTemplate restTemplate=new RestTemplate();
		String urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/dataindexjob/_search?q=jobId:"+id+"&size=10&from=0&pretty=true&_source=id,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted,clientId,contactId,jobId";
		URL urlJobdata = new URL(urlJob);
		String nullFragment = null;
		// System.out.println("urlJobdata >> "+urlJobdata);
		URI uriJob = new URI(urlJobdata.getProtocol(), urlJobdata.getUserInfo(), urlJobdata.getHost(),
				urlJobdata.getPort(), urlJobdata.getPath(), urlJobdata.getQuery(), nullFragment);
		System.out.println("uriJob >> " + uriJob);
		String jsonJobData = restTemplate.getForObject(uriJob, String.class);
		return jsonJobData;

	}
	
	//Attach behalf of objId 13-Aug-2018 
	
	@RequestMapping(value = "/ElasticAPI/attachid", method = { RequestMethod.GET })
	public @ResponseBody String esAttachJobid(@RequestParam("jobid") String jobid, @RequestParam("perpage") Integer perpage,
			@RequestParam("next") Integer next/*, @RequestParam("sort") String sort*/)
			throws MalformedURLException, URISyntaxException, JSONException {
		//int start = 50 * (next);
		int start = perpage * (next);
		RestTemplate restTemplate=new RestTemplate();
		String urlAttach = "";
		String jsonAttachData = "";
		String urlCandidate = "";
		String jsonCandidateData = "";
		 urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobid+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume
		/*URL urlAttachdata = new URL(urlAttach);
		String nullFragment = null;
		// System.out.println("urlJobdata >> "+urlJobdata);
		URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
				urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);*/
		System.out.println("urlAttach >> " + urlAttach);
		jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
		System.out.println("jsonAttachData >> "+jsonAttachData);
		
	
		JSONObject jsonObject=new JSONObject(jsonAttachData);
		jsonObject=(JSONObject) jsonObject.get("_shards");
		System.out.println("jsonObject >> "+jsonObject);
		
		JSONObject jsonObject2=new JSONObject(jsonAttachData);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);
		
		JSONArray jsonarray=(JSONArray) jsonObject2.get("hits");
		System.out.println("jsonArray >> "+jsonarray);
		
		
		
		JSONObject candijson = new JSONObject();
		JSONObject attachjson = new JSONObject();
		JSONObject mainjson = new JSONObject();
		
		String id="";
		String objectId="";
		String jobIdd="";
		String drop="";
		String dropComment="";
		String lastModifiedBy="";
		String createdDate="";
		String anchor="";
		String anchorId="";
		String status="";
		
	
		
		/*for(int n=0; n<jsonarray.length(); n++){
			System.out.println("n value:::"+n);
			System.out.println(jsonarray.length());
			JSONObject jsonObjectn=(JSONObject) jsonarray.get(n);

			System.out.println("jsonObjectn >> "+jsonObjectn);
		}
		*/
		
		for(int n=0; n<jsonarray.length(); n++){
		
			System.out.println(jsonarray.length());
			JSONObject jsonObject3=(JSONObject) jsonarray.get(n);
			
			
			System.out.println("jsonObject3 >> "+jsonObject3);
			
			
			JSONObject jsonObject4=new JSONObject(jsonAttachData);
			jsonObject4=(JSONObject) jsonObject3.get("_source");
			System.out.println("jsonObject4 >> "+jsonObject4);
			
			
			id= jsonObject4.getString("id");
			
			System.out.println("id value::::________"+id);
			objectId=jsonObject4.getString("objectId");
			jobIdd=jsonObject4.getString("jobId");
			drop=jsonObject4.getString("drop");
			dropComment=jsonObject4.getString("dropComment");
			lastModifiedBy=jsonObject4.getString("lastModifiedBy");
			createdDate=jsonObject4.getString("createdDate");
			anchor=jsonObject4.getString("anchor");
			anchorId=jsonObject4.getString("anchorId");
			status=jsonObject4.getString("status");
			
			attachjson.put("id", id);
			attachjson.put("objectId", objectId);
			attachjson.put("jobId", jobid);
			attachjson.put("drop", drop);
			attachjson.put("dropComment", dropComment);
			attachjson.put("lastModifiedBy", lastModifiedBy);
			attachjson.put("createdDate", createdDate);
			attachjson.put("anchor", anchor);
			attachjson.put("anchorId", anchorId);
			attachjson.put("status", status);
			System.out.println("attachJson >>>________ "+attachjson);
			
			mainjson.put("attach", attachjson);
			
			System.out.println("mainjson:::"+mainjson);
			
			//return mainjson.toString();
		}
			// candidate
			
			urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size="+perpage+"&from="+start+"&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
			System.out.println("urlCandidate >> " + urlCandidate);
			jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
			System.out.println("jsonCandidateData >> "+jsonCandidateData);
			
			JSONObject jsonCand=new JSONObject(jsonCandidateData);
			jsonCand=(JSONObject) jsonCand.get("_shards");
			System.out.println("jsonCand >> "+jsonObject);
			
			JSONObject jsonCand2=new JSONObject(jsonCandidateData);
			jsonCand2=(JSONObject) jsonCand2.get("hits");
			System.out.println("jsonCand2 >> "+jsonCand2);
			
			JSONArray jsonarrayCand=(JSONArray) jsonCand2.get("hits");
			System.out.println("jsonArrayCand >> "+jsonarrayCand);
			
			JSONObject jsonCand3=(JSONObject) jsonarrayCand.get(0);
			System.out.println("jsonCand3 >> "+jsonCand3);
			
			//JSONObject jsonCand4=new JSONObject(jsonCandidateData);
			JSONObject jsonCand4=(JSONObject) jsonCand3.get("_source");
			System.out.println("jsonCand4 >> "+jsonCand4);
			
			String ids="";
			String name="";
			String email="";
			String alternateEmail="";
			String birthdate="";
			String mobileNumber="";
			String lastModified="";
			String education="";
			String ug="";
			String degree="";
			String degreeType="";
			String course="";
			String institute="";
			String universityOrBoard="";
			String city="";
			String fromMonth="";
			String fromYear="";
			String toMonth="";
			String toYear="";
			String percentage="";
			String pg="";
			
		    String doctorate="";
			String diploma="";
			
			String twelveth="";
			String tenth="";
			
			String address="";
			String permanentAddress="";
			String country="";
			String state="";
			String street="";
			String pincode="";
			String location="";
			String currentAddress="";
			
			String preferredLocation="";
			String salary="";
			String currentCTCType="";
			String currentCTC="";
			String negotiableCTC="";
			String expectedCTCType="";
			String expectedCTC="";
			String takeHome="";
			String fixed="";
			String employment="";
			String current="";
			String companyName="";
			String designation="";
			
			String isCurrent="";
			String desc="";
			String workLocation="";
			String role="";
			String level="";
			String teamSize="";
			String previous="";
			
			String experience="";
			String months="";
			String TotalExp="";
			String years="";
		
			String createdBy="";
			String username="";
	         
			 /*preferredLocation=jsonCand4.getString("preferredLocation");
			 createdBy=jsonCand4.getString("createdBy");
			 username=jsonCand4.getString("username");
			 ids=jsonCand4.getString("id");
			 name=jsonCand4.getString("name");
			 email=jsonCand4.getString("email");
			 birthdate=jsonCand4.getString("birthdate");
			 mobileNumber=jsonCand4.getString("mobileNumber");*/
			 if(jsonCand4.has("preferredLocation") && !jsonCand4.get("preferredLocation").equals(null)){
				 preferredLocation=(String) jsonCand4.get("preferredLocation");
				 System.out.println("preferredLocation >> "+preferredLocation);
			 }else {
				 preferredLocation="";
				 System.out.println("preferredLocation >> "+preferredLocation);
			}if(jsonCand4.has("createdBy") && !jsonCand4.get("createdBy").equals(null)){
				createdBy=(String) jsonCand4.get("createdBy");
			 }else {
				 createdBy="";
				 System.out.println("createdBy >> "+createdBy);
			}if(jsonCand4.has("username") && !jsonCand4.get("username").equals(null)){
				username=(String) jsonCand4.get("username");
			 }else {
				 username="";
				 System.out.println("username >> "+username);
			}if(jsonCand4.has("id") && !jsonCand4.get("id").equals(null)){
				ids=(String) jsonCand4.get("id");
			 }else {
				 id="";
				 System.out.println("id >> "+id);
			}if(jsonCand4.has("name") && !jsonCand4.get("name").equals(null)){
				name=(String) jsonCand4.get("name");
			 }else {
				 name="";
				 System.out.println("name >> "+name);
			}if(jsonCand4.has("email") && !jsonCand4.get("email").equals(null)){
				email=(String) jsonCand4.get("email");
			 }else {
				 email="";
				 System.out.println("email >> "+email);
			}if(jsonCand4.has("birthdate") && !jsonCand4.get("birthdate").equals(null)){
				birthdate=(String) jsonCand4.get("birthdate");
			 }else {
				 birthdate="";
				 System.out.println("birthdate >> "+birthdate);
			}if(jsonCand4.has("mobileNumber") && !jsonCand4.get("mobileNumber").equals(null)){
				mobileNumber=(String) jsonCand4.get("mobileNumber");
			 }else {
				 mobileNumber="";
				 System.out.println("mobileNumber >> "+mobileNumber);
			}
			 
				 

			 if (jsonCand4.has("lastModified") && !jsonCand4.get("lastModified").equals(null)) {
				 lastModified=(String) jsonCand4.get("lastModified");
				 System.out.println("lastModified dfs>> "+lastModified);
			}else {
				lastModified="";
				System.out.println("lastModified fsdss >> "+lastModified);
			}
			
			/* experience=jsonCand4.getString("experience");
			 months=jsonCand4.getString("months");
			 TotalExp=jsonCand4.getString("TotalExp");
			 years=jsonCand4.getString("years");*/
			 ////experience....
			 
			 JSONObject experience1=null;
			 if (jsonCand4.has("experience") && !jsonCand4.get("experience").equals(null)) {
				experience1=(JSONObject) jsonCand4.get("experience");
				System.out.println("experience1 >> "+experience1);
				if (experience1.has("months") && !experience1.get("months").equals(null)) {
					months=(String) experience1.get("months");
					System.out.println("months >> "+months);
				}else {
					months="";
					System.out.println("months >> "+months);
				}if (experience1.has("TotalExp") && !experience1.get("TotalExp").equals(null)) {
					TotalExp=(String) experience1.get("TotalExp");
					System.out.println("TotalExp >> "+TotalExp);
				}else {
					TotalExp="";
					System.out.println("TotalExp >> "+TotalExp);
				}if (experience1.has("years") && !experience1.get("years").equals(null)) {
					years=(String) experience1.get("years");
					System.out.println("years >> "+years);
				}else {
					years="";
					System.out.println("years >>> "+years);
				}
			}else {
				experience="";
				System.out.println("experience >> "+experience);
			}
			 
			//salary......
			 JSONObject salary1=null;
			 
			 if(jsonCand4.has("salary") && !jsonCand4.get("salary").equals(null)){
				 salary1=(JSONObject) jsonCand4.get("salary");
				 System.out.println("salry1 >> "+salary1);
				 if (salary1.has("currentCTCType") && !salary1.get("currentCTCType").equals(null)) {
					 currentCTCType=(String) salary1.get("currentCTCType");
					 System.out.println("currentCTCType >> "+currentCTCType);
				}else {
					currentCTCType="";
					System.out.println("currentCTCType >> "+currentCTCType);
				}if(salary1.has("currentCTC") && !salary1.get("currentCTC").equals(null)){
					currentCTC=(String) salary1.get("currentCTC");
					System.out.println("currentCTC >> "+currentCTC);
				}else {
					currentCTC="";
					System.out.println("currentCTC >> "+currentCTC);
				}if (salary1.has("negotiableCTC") && !salary1.get("negotiableCTC").equals(null)) {
					negotiableCTC=(String) salary1.get("negotiableCTC");
					System.out.println("negotiableCTC >> "+negotiableCTC);
				}else {
					negotiableCTC="";
					System.out.println("negotiableCTC >> "+negotiableCTC);
				}if (salary1.has("expectedCTCType") && !salary1.get("expectedCTCType").equals(null)) {
					expectedCTCType=(String) salary1.get("expectedCTCType");
					System.out.println("expectedCTCType >> "+expectedCTCType);
				}else {
					expectedCTCType="";
					System.out.println("expectedCTCType >> "+expectedCTCType);
				}if (salary1.has("expectedCTC") && !salary1.get("expectedCTC").equals(null)) {
					expectedCTC=(String) salary1.get("expectedCTC");
					System.out.println("expectedCTC >> "+expectedCTC);
				}else {
					expectedCTC="";
					System.out.println("expectedCTC >> "+expectedCTC);
				}if (salary1.has("takeHome") && !salary1.get("takeHome").equals(null)) {
					takeHome=(String) salary1.get("takeHome");
					System.out.println("takeHome >> "+takeHome);
				}else {
					takeHome="";
					System.out.println("takeHome >> "+takeHome);
				}if (salary1.has("fixed") && !salary1.get("fixed").equals(null)) {
					fixed=(String) salary1.get("fixed");
					System.out.println("fixed >> "+fixed);
				}else {
					fixed="";
					System.out.println("fixed >> "+fixed);
				}
				 
			 }else {
				salary="";
				System.out.println("salary >> "+salary);
			}
			 
			 
			 
			 ///address......permanent
			/* JSONObject permanentAddressJson=null;
			 JSONObject permanentAddress1=null;
			 JSONObject currentAddressJson=null;
			 JSONObject currentAddress1=null;*/
			 JSONObject addressJson=null;
			 JSONObject addressJson1=null;
			
			 
			 if(jsonCand4.has("address") && !jsonCand4.get("address").equals(null)){
				 addressJson=(JSONObject) jsonCand4.get("address");
				 if(addressJson.has("permanentAddress") && !addressJson.get("permanentAddress").equals(null)){
					System.out.println("permanentAddress >> "+addressJson.get("permanentAddress"));
					//permanentAddress1=new JSONObject();
					addressJson1=(JSONObject) addressJson.get("permanentAddress");
					//addressJson1=(JSONObject) addressJson1.get("permanentAddress");
					System.out.println("permanentAddress1 >>> "+addressJson1);
					if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
						country=(String) addressJson1.get("country");
						System.out.println("country >> "+country);
					}else {
						country="";
						System.out.println("country >> "+country);
					}
					if(addressJson1.has("state") && !addressJson1.get("state").equals(null)){
						state=(String) addressJson1.get("state");
						System.out.println("state >> "+state);
					}else {
						state="";
						System.out.println("state >> "+state);
					}
					if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
						city=(String) addressJson1.get("city");
					}else {
						city="";
						System.out.println("city >> "+city);
					}
					if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
						street=(String) addressJson1.get("street");
						System.out.println("street >> "+street);
					}else {
						street="";
						System.out.println("street >> "+street);
					}
					if(addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)){
						pincode=(String) addressJson1.get("pincode");
						System.out.println("pincode >> "+pincode);
					}else {
						pincode="";
						System.out.println("pincode >> "+pincode);
					}if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
						location=(String) addressJson1.get("location");
						System.out.println("location >> "+location);
					}else {
						location="";
						System.out.println("location >> "+location);
					}
				 }
				 else {
					permanentAddress="";
					System.out.println("permanentAddress >> "+permanentAddress);
				}
					///current address write code.. START

				 
				// currentAddressJson=(JSONObject) jsonCand4.get("address");
				 addressJson=(JSONObject) jsonCand4.get("address");
				 
				 if(addressJson.has("currentAddress") && !addressJson.get("currentAddress").equals(null)){
					System.out.println("currentAddress >> "+addressJson.get("currentAddress"));
					//currentAddress1=new JSONObject();
					addressJson1=(JSONObject) addressJson.get("currentAddress");
					System.out.println("currentAddress1 >>> "+addressJson1);
					if (addressJson1.has("country") && !addressJson1.get("country").equals(null)) {
						country=(String) addressJson1.get("country");
						System.out.println("country >> "+country);
					}else {
						country="";
						System.out.println("country current >> "+country);
					}
					if(addressJson1.has("state") && !addressJson1.get("state").equals(null)){
						state=(String) addressJson1.get("state");
						System.out.println("state  current>> "+state);
					}else {
						state="";
						System.out.println("state current>> "+state);
					}
					if (addressJson1.has("city") && !addressJson1.get("city").equals(null)) {
						city=(String) addressJson1.get("city");
					}else {
						city="";
						System.out.println("city current>> "+city);
					}
					if (addressJson1.has("street") && !addressJson1.get("street").equals(null)) {
						street=(String) addressJson1.get("street");
						System.out.println("street current>> "+street);
					}else {
						street="";
						System.out.println("street current>> "+street);
					}
					if(addressJson1.has("pincode") && !addressJson1.get("pincode").equals(null)){
						pincode=(String) addressJson1.get("pincode");
						System.out.println("pincode current>> "+pincode);
					}else {
						pincode="";
						System.out.println("pincode current >> "+pincode);
					}if (addressJson1.has("location") && !addressJson1.get("location").equals(null)) {
						location=(String) addressJson1.get("location");
						System.out.println("location current >> "+location);
					}else {
						location="";
						System.out.println("location current >> "+location);
					}
				 }
				 else {
					 currentAddress="";
					System.out.println("currentAddress current >> "+currentAddress);
				}
			 }else {
				address="";
				System.out.println("address >> "+address);
			}
			 
			 
			 
			 ///Education..
			/* JSONObject ugjson = null;
			 JSONObject ug1 = null;
			 JSONObject pgjson = null;
			 JSONObject pg1 = null;
			 JSONObject twelvethjson = null;
			 JSONObject twelveth1 = null;
			 JSONObject tenthjson =null;
			 JSONObject tenth1 = null;*/
			 
			 JSONObject educationjson = null;
			 JSONObject educationjson1 = null;
			 
			 
			 
			 
			if (jsonCand4.has("education") && !jsonCand4.get("education").equals(null)) {
				 //education=(String) jsonCand4.get("education");
				educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("ug") && !educationjson.get("ug").equals(null)){
					 System.out.println("ug >>> "+educationjson.get("ug"));
					// ug1=new JSONObject();
					 //ug1=(JSONObject) ugjson.get("ug");
					 
					 educationjson1=(JSONObject) educationjson.get("ug");
					 System.out.println("ug1 >> "+educationjson1);
					 if(educationjson1.has("degree") && !educationjson1.get("degree").equals(null)){
						 degree=(String) educationjson1.get("degree");
						 System.out.println("degree >>> "+educationjson1.get("degree"));
					 }else {
						degree="";
						System.out.println("degree >> "+degree);
					}
					
					//has means json field have or not proper work has key in json 
					 if(educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)){
						 degreeType=(String) educationjson1.get("degreeType");
						 System.out.println("degreeType >>> "+educationjson1.get("degreeType"));
					 }else {
						 degreeType="";
						System.out.println("degreeType >> "+degreeType);
					}
					 
					 
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					 if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
						 percentage=(String) educationjson1.get("percentage");
						 System.out.println("percentage >> "+percentage);
					}else {
						percentage="";
						System.out.println("percentage >> "+percentage);
					}		
					
				 }else {
					ug="";
					System.out.println("ug >> "+ug);
				}
				//for pg
				 
				 
				 System.out.println("Hiiiiiiiiiiiii");
				 //pgjson = (JSONObject) jsonCand4.get("education");
				 educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("pg") && !educationjson.get("pg").equals(null)){
					 System.out.println("pg1 Json >>> "+educationjson.get("pg"));
					 
					// pg1=new JSONObject();
					 //System.out.println("pg1 >> "+pg1);
					 //pg1=(JSONObject) pgjson.get("pg");
					 educationjson1=(JSONObject) educationjson.get("pg");
					 System.out.println("pg1 >> "+educationjson1);
					 
					 if(educationjson1.has("degree") && !educationjson1.get("degree").equals(null)){
						 degree=(String) educationjson1.get("degree");
						 System.out.println("degree >>> "+educationjson1.get("degree"));
					 }else {
						degree="";
						System.out.println("degree >> "+degree);
					}
					 if(educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)){
						 degreeType=(String) educationjson1.get("degreeType");
						 System.out.println("degreeType >>> "+educationjson1.get("degreeType"));
					 }else {
						 degreeType="";
						System.out.println("degreeType >> "+degreeType);
					}
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					 if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
						 percentage=(String) educationjson1.get("percentage");
						 System.out.println("percentage >> "+percentage);
					}else {
						percentage="";
						System.out.println("percentage >> "+percentage);
					}	
					 
				 }else {
					pg="";
					System.out.println("pg >>"+pg);
				}//end pg
				 
				 //// doctrate start
				 
				 System.out.println("Hiiiiiiiiiiiii");
				  educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("doctorate") && !educationjson.get("doctorate").equals(null)){
					 System.out.println("doctorate Json >>> "+educationjson.get("doctorate"));
					 
					 //JSONObject doctorate1=new JSONObject();
					// System.out.println("doctorate1 >> "+doctorate1);
					 educationjson1=(JSONObject) educationjson.get("twelveth");
					 System.out.println("doctorate1 >>> "+educationjson1);
					 
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					 if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
						 percentage=(String) educationjson1.get("percentage");
						 System.out.println("percentage >> "+percentage);
					}else {
						percentage="";
						System.out.println("percentage >> "+percentage);
					}	
					 
				 }else {
					 doctorate="";
					System.out.println("doctorate >>"+doctorate);
				}
				 
				 
				 /// start Diploma
				 
				 System.out.println("Hiiiiiiiiiiiii");
				 educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("diploma") && !educationjson.get("diploma").equals(null)){
					 System.out.println("diploma Json >>> "+educationjson.get("diploma"));
					 
					 //JSONObject diploma1=new JSONObject();
					// System.out.println("diploma1 >> "+diploma1);
					 educationjson1=(JSONObject) educationjson.get("diploma");
					 System.out.println("diploma1 >>> "+educationjson1);
					 
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					 if (educationjson1.has("percentage") && !educationjson1.get("percentage").equals(null)) {
						 percentage=(String) educationjson1.get("percentage");
						 System.out.println("percentage >> "+percentage);
					}else {
						percentage="";
						System.out.println("percentage >> "+percentage);
					}	
					 
				 }else {
					 diploma="";
					System.out.println("diploma >>"+diploma);
				}
				 
				 
				
				 
				
				 
				 ////////start 12th
				 System.out.println("Hiiiiiiiiiiiii");
				 educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("twelveth") && !educationjson.get("twelveth").equals(null)){
					 System.out.println("pg1 Json >>> "+educationjson.get("twelveth"));
					 
					 //twelveth1=new JSONObject();
					// System.out.println("twelveth1 >> "+twelveth1);
					 educationjson1=(JSONObject) educationjson.get("twelveth");
					 System.out.println("twelveth1 >>> "+educationjson1);
					 
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					/* if (!educationjson1.get("percentage").equals(null)) {
						 percentage=(String) educationjson1.get("percentage");
						 System.out.println("percentage >> "+percentage);
					}else {
						percentage="";
						System.out.println("percentage >> "+percentage);
					}	*/
					
					 
					 System.out.println("educationjson1 >> "+educationjson1);
					 if (educationjson1.has("percentage")) {
						 if(!educationjson1.get("percentage").equals(null)){
								if(educationjson1.has("percentage")){
									 percentage=(String) educationjson1.get("percentage"); 
								 }
								else {
									percentage="";
									System.out.println("percentage >> "+percentage);
								}
							}
					}
					 
					 
					 
				 }else {
					 twelveth="";
					System.out.println("twelveth >>"+twelveth);
				}
				 
				 //end twelveth
			
				 //Start tenth
				 System.out.println("Hiiiiiiiiiiiii");
				 educationjson = (JSONObject) jsonCand4.get("education");
				 if(educationjson.has("tenth") && !educationjson.get("tenth").equals(null)){
					 System.out.println("tetnth Json >>> "+educationjson.get("tenth"));
					 
					//tenth1=new JSONObject();
					// System.out.println("tenth1 >> "+tenth1);
					 educationjson1=(JSONObject) educationjson.get("tenth");
					 System.out.println("tenth1 >>> "+educationjson1);
					 
					
					 if (educationjson1.has("degree") && !educationjson1.get("degree").equals(null)) {
						 degree=(String) educationjson1.get("degree");
						 System.out.println("degree >>> "+educationjson1.get("degree"));
					 }else {
						degree="";
						System.out.println("degree >> "+degree);
					}
					 if(educationjson1.has("degreeType") && !educationjson1.get("degreeType").equals(null)){
						 degreeType=(String) educationjson1.get("degreeType");
						 System.out.println("degreeType >>> "+educationjson1.get("degreeType"));
					 }else {
						 degreeType="";
						System.out.println("degreeType >> "+degreeType);
					}
					 
					 
					 if(educationjson1.has("course") && !educationjson1.get("course").equals(null)){
						 course=(String) educationjson1.get("course");
						 System.out.println("course >>> "+educationjson1.get("course"));
					 }else {
						 course="";
						System.out.println("course >> "+course);
					}
					 if(educationjson1.has("institute") && !educationjson1.get("institute").equals(null)){
						 institute=(String) educationjson1.get("institute");
						 System.out.println("institute >>> "+educationjson1.get("institute"));
					 }else {
						 institute="";
						System.out.println("institute >> "+institute);
					}
					 if(educationjson1.has("universityOrBoard") && !educationjson1.get("universityOrBoard").equals(null)){
						 universityOrBoard=(String) educationjson1.get("universityOrBoard");
						 System.out.println("universityOrBoard >>> "+educationjson1.get("universityOrBoard"));
					 }else {
						 universityOrBoard="";
						System.out.println("universityOrBoard >> "+universityOrBoard);
					}
					 if(educationjson1.has("city") && !educationjson1.get("city").equals(null)){
						 city=(String) educationjson1.get("city");
						 System.out.println("city >>> "+educationjson1.get("city"));
					 }else {
						 city="";
						System.out.println("city >> "+city);
					}
					 if(educationjson1.has("fromMonth") && !educationjson1.get("fromMonth").equals(null)){
						 fromMonth=(String) educationjson1.get("fromMonth");
						 System.out.println("fromMonth >>> "+educationjson1.get("fromMonth"));
					 }else {
						 fromMonth="";
						System.out.println("fromMonth >> "+fromMonth);
					}
					 if(educationjson1.has("fromYear") && !educationjson1.get("fromYear").equals(null)){
						 fromYear=(String) educationjson1.get("fromYear");
						 System.out.println("fromYear >>> "+educationjson1.get("fromYear"));
					 }else {
						 fromYear="";
						System.out.println("fromYear >> "+fromYear);
					}
					 if (educationjson1.has("toMonth") && !educationjson1.get("toMonth").equals(null)) {
						 toMonth=(String) educationjson1.get("toMonth");
						 System.out.println("toMonth >> "+toMonth);
					}else {
						toMonth="";
						System.out.println("toMonth >> "+toMonth);
					}				
					 if (educationjson1.has("toYear") && !educationjson1.get("toYear").equals(null)) {
						 toYear=(String) educationjson1.get("toYear");
						 System.out.println("toYear >> "+toYear);
					}else {
						toYear="";
						System.out.println("toYear >> "+toYear);
					}		
					 
					 
					 System.out.println("educationjson1 >> "+educationjson1);
					 if (educationjson1.has("percentage")) {
						 if(!educationjson1.get("percentage").equals(null)){
								if(educationjson1.has("percentage")){
									 percentage=(String) educationjson1.get("percentage"); 
								 }
								else {
									percentage="";
									System.out.println("percentage >> "+percentage);
								}
							}
					}
					
					 
					 
					
					 
				 }else {
					 tenth="";
					System.out.println("twelveth >>"+tenth);
				}
				 
				 //end tenth
				 //////////
					 
			}else {
				education="";
				System.out.println("education >> "+education);
			}
			

			
			JSONObject employment1=null;
			JSONObject current1=null;
			JSONArray previous1=null;
			String previousOrganization = "";
	        String previousDesignation  = "";
	        String previousLevel  = "";
	        String previousCity  = "";
	        String previousFromMonth  = "";
	        String previousFromYear  = "";
	        String previousToMonth  = "";
	        String previousToYear  = "";
	        String previousDescription  = "";

			
			if (jsonCand4.has("employment") && !jsonCand4.get("employment").equals(null)) {
				employment1=jsonCand4.getJSONObject("employment");
				if (employment1.has("current") && !employment1.get("current").equals(null)) {
			        current1=employment1.getJSONObject("current");
			        System.out.println("current jsonObject >>"+current);
			        if(current1.has("companyName") && !current1.get("companyName").equals(null)){
			        companyName=current1.getString("companyName");
			        System.out.println("companyName >> "+ companyName);
			        } else{
			              companyName = "";   
			        }
			        if(current1.has("designation") && !current1.get("designation").equals(null)){
			        designation=current1.getString("designation");
			        System.out.println("desidnation >> "+designation);
			        }
			        else{
			              designation = "";
			        }
			        if(current1.has("isCurrent") && !current1.get("isCurrent").equals(null)){
			        isCurrent=current1.getString("isCurrent");
			        System.out.println("isCurrent >>" + isCurrent);
			        }
			        else{
			              isCurrent = "";
			        }
			        if(current1.has("desc") && !current1.get("desc").equals(null)){
			              desc=current1.getString("desc");
			            System.out.println("desc >> "+ desc);  
			        }
			        else{
			              desc="";
			        }
			        if(current1.has("workLocation") && !current1.get("workLocation").equals(null)){
			              workLocation=current1.getString("workLocation");
			            System.out.println("workLocation >>"+ workLocation);
			        }else{
			              workLocation = "";
			        }
			        if(current1.has("role") && !current1.get("role").equals(null)){
			              role=current1.getString("role");
			            System.out.println("role >> "+ role);  
			        }else{
			           role="";   
			        }if(current1.has("level") && !current1.get("level").equals(null)){
			              level=current1.getString("level");
			            System.out.println("level >> " + level);
			        }else{
			              level ="";
			        }if(current1.has("teamSize") && !current1.get("teamSize").equals(null)){
			              teamSize=current1.getString("teamSize");
			            System.out.println("teamSize >> "+ teamSize);
			        }
			        else{
			              teamSize="";
			        }

				}else {
					current="";
				}
				
			}else {
				employment="";
			}
	        
	        

	        if (employment1.has("previous") && !employment1.get("previous").equals(null)) {
		        previous1=employment1.getJSONArray("previous");
		        System.out.println("previous1 >> "+ previous1);
		        int i=0;
		        for(i=0;i<previous1.length();i++){
		              JSONObject jsonprevious = previous1.getJSONObject(i);
		              if(jsonprevious.has("organization") && !jsonprevious.get("organization").equals(null)){
		                     previousOrganization = jsonprevious.getString("organization");
		                     System.out.println("previousOrganization >>"+previousOrganization);
		              }
		              else{
		                     previousOrganization = "";
		              }if(jsonprevious.has("designation") && !jsonprevious.get("designation").equals(null)){
		                     previousDesignation = jsonprevious.getString("designation");
		                     System.out.println("previousDesignation >>" + previousDesignation);
		              }
		              else{
		                     previousDesignation = "";
		              }
		              if(jsonprevious.has("level") && !jsonprevious.get("level").equals(null)){
		                     previousLevel= jsonprevious.getString("level");;
		              }
		              else{
		                     previousLevel="";
		              }
		              if(jsonprevious.has("city") && !jsonprevious.get("city").equals(null)){
		                     previousCity = jsonprevious.getString("city");
		              }
		              else{
		                     previousCity = "";
		              }
		              if(jsonprevious.has("fromMonth") && !jsonprevious.get("fromMonth").equals(null)) {
		                    previousFromMonth = jsonprevious.getString("fromMonth"); 
		              }
		              else{
		                     previousFromMonth ="";
		              }
		              if(jsonprevious.has("fromYear") && !jsonprevious.get("fromYear").equals(null)){
		                     previousFromYear =jsonprevious.getString("fromYear");
		              }
		              else{
		                     previousFromYear ="";
		              }
		              if(jsonprevious.has("toMonth") && !jsonprevious.get("toMonth").equals(null)) {
		                  previousToMonth =jsonprevious.getString("toMonth");   
		              }
		              else{
		                     previousToMonth= "";
		              }if(jsonprevious.has("toYear") && !jsonprevious.get("toYear").equals(null)){
		                  previousToYear =jsonprevious.getString("toYear");   
		              }else{
		                     previousToYear= "";
		              }
		              if(jsonprevious.has("description") && !jsonprevious.get("description").equals(null)){
		                  previousDescription =jsonprevious.getString("description");   
		              }
		              else{
		                     previousDescription= "";
		              }
		           }

			}else {
				previous="";
			}

	        //JSONArray alternateEmailArray = null;
	       /* if(!jsonCand4.get("alternateEmail").equals(null)){
				 alternateEmail=(String) jsonCand4.get("alternateEmail");
				 System.out.println("alternagteEmail....."+alternateEmail);
			 }else{
				 
				 alternateEmail="";
				 System.out.println("alternateEmgdfgsdfgail....."+alternateEmail);
			 }*/
	        JSONArray altenaiteEmail1 = null;
	        int m=0;
			if(jsonCand4.has("alternateEmail") && !jsonCand4.get("alternateEmail").equals(null)){
				 altenaiteEmail1 = (JSONArray) jsonCand4.get("alternateEmail");
			        System.out.println("altenail:::"+altenaiteEmail1);
			        for( m =0; m<altenaiteEmail1.length(); m++){
			        	System.out.println("AlernateEmail ::"+altenaiteEmail1.get(m));
			        }
					 System.out.println("alternateEmail:::"+alternateEmail);
			}else{
				alternateEmail="";
				System.out.println("hello alt enail");
			}
	        
	       
			 

	        
			
			
	         candijson.put("preferredLocation", preferredLocation);
			 candijson.put("createdBy", createdBy);
			 candijson.put("username", username);
			 candijson.put("id", ids);
			 candijson.put("name", name);
			 candijson.put("email", email);
			 candijson.put("birthdate", birthdate);
			 candijson.put("mobileNumber", mobileNumber);
			 candijson.put("lastModified", lastModified);
			 candijson.put("alternateEmail", altenaiteEmail1);
			 candijson.put("experience", experience1);
			 candijson.put("salary", salary1);
			 candijson.put("address", addressJson);
			
			 
			 candijson.put("education", educationjson);
			
			 candijson.put("employment", employment1);
			
			 
			 JSONObject attachCandidateData=new JSONObject();
			 attachCandidateData.put("Candidate", candijson);
			 attachCandidateData.put("Attach", attachjson);
			 
			System.out.println("ALL JSON DAta >> "+attachCandidateData);
			
			System.out.println("candidate JSON >> "+candijson);
			
			mainjson.put("candidate", candijson);
			
			
			

			
			
		//Candidate Collection
			//urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";//,resumeName,resume
			 //id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,currentAddress,preferredLocation,salary,expectedCTC,employment,current,previous,experience,lastModified,createdDate,createdBy,username,username,projectDescription
			/*urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
			System.out.println("urlCandidate >> " + urlCandidate);
			jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
			System.out.println("jsonCandidateData >> "+jsonCandidateData);*/

			
			
			/*JSONObject object = new JSONObject();
			JSONArray array = new JSONArray();
			array.put(0, jsonCandidateData);
			array.put(1, jsonAttachData);
			object.put("response", array);
			 //return jsonCandidateData+jsonAttachData;
			System.out.println(object);*/
			//return object.toString();
			//JSONObject json = new JSONObject(source)
			 
			JSONObject object = new JSONObject();
			object.put("response", mainjson);
			//System.out.println("object:::"+object);
			

			
			
			return object.toString();
			
		}
		

	
	
	
	
	
	
	/////end attach jobid..
	
	//Attach behalf of objectId 09-Aug-2018
	//@SuppressWarnings("unchecked")
	@RequestMapping(value = "/ElasticAPI/attachiddd", method = { RequestMethod.GET })
	public @ResponseBody String esAttachJobid(@RequestParam("jobId") String jobId)
			throws MalformedURLException, URISyntaxException, JSONException {
		//int start = perPage * (next);
		RestTemplate restTemplate=new RestTemplate();
		String urlAttach = "";
		String jsonAttachData = "";
		String urlCandidate = "";
		String jsonCandidateData = "";
		 urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(jobId:\""+jobId+"\")&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume
		/*URL urlAttachdata = new URL(urlAttach);
		String nullFragment = null;
		// System.out.println("urlJobdata >> "+urlJobdata);
		URI uriAttach = new URI(urlAttachdata.getProtocol(), urlAttachdata.getUserInfo(), urlAttachdata.getHost(),
				urlAttachdata.getPort(), urlAttachdata.getPath(), urlAttachdata.getQuery(), nullFragment);*/
		System.out.println("urlAttach >> " + urlAttach);
		jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
		System.out.println("jsonAttachData >> "+jsonAttachData);
		
		
		
		JSONObject jsonObject=new JSONObject(jsonAttachData);
		jsonObject=(JSONObject) jsonObject.get("_shards");
		System.out.println("jsonObject >> "+jsonObject);
		
		JSONObject jsonObject2=new JSONObject(jsonAttachData);
		jsonObject2=(JSONObject) jsonObject2.get("hits");
		System.out.println("jsonObject2 >> "+jsonObject2);
		
		JSONArray jsonarray=(JSONArray) jsonObject2.get("hits");
		System.out.println("jsonArray >> "+jsonarray);
		
		JSONObject jsonObject3=(JSONObject) jsonarray.get(0);
		System.out.println("jsonObject3 >> "+jsonObject3);
		
		JSONObject jsonObject4=new JSONObject(jsonAttachData);
		jsonObject4=(JSONObject) jsonObject3.get("_source");
		System.out.println("jsonObject4 >> "+jsonObject4);
		
		
		String id="";
		String objectId="";
		String jobIdd="";
		String drop="";
		String dropComment="";
		String lastModifiedBy="";
		String createdDate="";
		String anchor="";
		String anchorId="";
		String status="";
		id= jsonObject4.getString("id");
		objectId=jsonObject4.getString("objectId");
		jobIdd=jsonObject4.getString("jobId");
		drop=jsonObject4.getString("dropComment");
		lastModifiedBy=jsonObject4.getString("lastModifiedBy");
		createdDate=jsonObject4.getString("createdDate");
		anchor=jsonObject4.getString("anchor");
		anchorId=jsonObject4.getString("anchorId");
		status=jsonObject4.getString("status");
		//id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment
		 //urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,objectId,jobId,jobName,clientId,clientName,contactId,contactName,attachedBy,lastModifiedBy,lastModified,createdDate,anchor,anchorId,stage,status,drop,dropComment";//,resumeName,resume
		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,jobId,objectId,drop,dropComment,lastModifiedBy,createdDate,anchor,anchorId,status";//,resumeName,resume
		
		System.out.println("urlAttach >> " + urlAttach);
		jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
		System.out.println("jsonAttachData >> "+jsonAttachData);
		
		
		
		urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
		System.out.println("urlCandidate >> " + urlCandidate);
		jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
		System.out.println("jsonCandidateData >> "+jsonCandidateData);
		
		JSONObject jsonCand=new JSONObject(jsonCandidateData);
		jsonCand=(JSONObject) jsonCand.get("_shards");
		System.out.println("jsonCand >> "+jsonObject);
		
		JSONObject jsonCand2=new JSONObject(jsonCandidateData);
		jsonCand2=(JSONObject) jsonCand2.get("hits");
		System.out.println("jsonCand2 >> "+jsonCand2);
		
		JSONArray jsonarrayCand=(JSONArray) jsonCand2.get("hits");
		System.out.println("jsonArrayCand >> "+jsonarrayCand);
		
		/*JSONObject jsonCand3=null;
		JSONObject jsonCand4=null;
		
		for(int i=0; i<=jsonarrayCand.length(); i++){
			 jsonCand3=(JSONObject) jsonarrayCand.get(i);
			System.out.println("jsonCand3 >> "+jsonCand3);
			jsonCand4=new JSONObject(jsonCandidateData);
			jsonCand4=(JSONObject) jsonCand3.get("_source");
			System.out.println("jsonCand4 >> "+jsonCand4);
			
		}
		*/
		
		JSONObject jsonCand3=(JSONObject) jsonarrayCand.get(0);
		System.out.println("jsonCand3 >> "+jsonCand3);
		
		JSONObject jsonCand4=new JSONObject(jsonCandidateData);
		jsonCand4=(JSONObject) jsonCand3.get("_source");
		System.out.println("jsonCand4 >> "+jsonCand4);

	
		
		
		
		
		String ids="";
		String name="";
		String email="";
		String alternateEmail="";
		String birthdate="";
		String mobileNumber="";
		String lastModified="";
		String education="";
		String ug="";
		String degree="";
		String degreeType="";
		String course="";
		String institute="";
		String universityOrBoard="";
		String city="";
		String fromMonth="";
		String fromYear="";
		String toMonth="";
		String toYear="";
		String percentage="";
		String pg="";
		
		String doctorate="";
		String diploma="";
		
		
		
		String twelveth="";
		String tenth="";
		
		String address="";
		String permanentAddress="";
		String country="";
		String state="";
		String street="";
		String pincode="";
		String location="";
		String currentAddress="";
		
		String preferredLocation="";
		String salary="";
		String currentCTCType="";
		String currentCTC="";
		String negotiableCTC="";
		String expectedCTCType="";
		String expectedCTC="";
		String takeHome="";
		String fixed="";
		String employment="";
		String current="";
		String companyName="";
		String designation="";
		
		String isCurrent="";
		String desc="";
		String workLocation="";
		String role="";
		String level="";
		String teamSize="";
		String previous="";
		
		String experience="";
		String months="";
		String TotalExp="";
		String years="";
	
		String createdBy="";
		String username="";

		ids=jsonCand4.getString("id");
		System.out.println("ids >> "+ids);
		name=jsonCand4.getString("name");
		System.out.println("name >> "+name);
		 email=jsonCand4.getString("email");
		 System.out.println("email >> "+email);
		 if(!jsonCand4.get("alternateEmail").equals(null)){
			 alternateEmail=(String) jsonCand4.get("alternateEmail");
			 System.out.println("alternagteEmail....."+alternateEmail);
		 }else{
			 
			 alternateEmail="";
			 System.out.println("alternateEmgdfgsdfgail....."+alternateEmail);
		 }
		
		/* ArrayList<String> alternateEmails = new ArrayList<String>();
			System.out.println("If loop......");
			alternateEmails = (ArrayList<String>) jsonCand4.get("alternateEmail");*/
		 System.out.println("alternateEmail:::"+alternateEmail);
		 
		 
		 birthdate=jsonCand4.getString("birthdate");
		 System.out.println("birthdate >> "+birthdate);
		 mobileNumber=jsonCand4.getString("mobileNumber");
		 if (!jsonCand4.get("lastModified").equals(null)) {
			 lastModified=(String) jsonCand4.get("lastModified");
			 System.out.println("lastModified dfs>> "+lastModified);
		}else {
			lastModified="";
			System.out.println("lastModified fsdss >> "+lastModified);
		}
		 
		 //Address..
		 if(!jsonCand4.get("address").equals(null)){
				JSONObject permanentAddressJson=(JSONObject) jsonCand4.get("address");
				System.out.println("permanentAddresssJson >> "+permanentAddressJson);
				if (!permanentAddressJson.get("permanentAddress").equals(null)) {
					System.out.println("permanentAddress >> "+permanentAddressJson.get("permanentAddress"));
					JSONObject permanentAddress1=new JSONObject();
					permanentAddress1=(JSONObject) permanentAddressJson.get("permanentAddress");
					System.out.println("permanentAddress1 >>> "+permanentAddress1);
					if (!permanentAddress1.get("country").equals(null)) {
						country=(String) permanentAddress1.get("country");
						System.out.println("country >> "+country);
					}else {
						permanentAddress="";
						System.out.println("permanentAddress >> "+permanentAddress);
					}
				}
				else {
					address="";
					System.out.println("address >> "+address);
				}
			}
		 
		 
		 ///Education..
		/* JSONObject edu=new JSONObject();
		 edu=jsonCand4.getJSONObject("education");
		 System.out.println("edu L>> "+edu);*/
		 
		if (!jsonCand4.get("education").equals(null)) {
			 //education=(String) jsonCand4.get("education");
			 JSONObject ugjson = (JSONObject) jsonCand4.get("education");
			 if(!ugjson.get("ug").equals(null)){
				 System.out.println("ug >>> "+ugjson.get("ug"));
				 JSONObject ug1=new JSONObject();
				
				 ug1=(JSONObject) ugjson.get("ug");
				 System.out.println("ug1 >> "+ug1);
				 /*if(!ug1.get("degree").equals(null)){
					 degree=(String) ug1.get("degree");
					 System.out.println("degree >>> "+ug1.get("degree"));
				 }else {
					degree="";
					System.out.println("degree >> "+degree);
				}
				 if(!ug1.get("degreeType").equals(null)){
					 degreeType=(String) ug1.get("degreeType");
					 System.out.println("degreeType >>> "+ug1.get("degreeType"));
				 }else {
					 degreeType="";
					System.out.println("degreeType >> "+degreeType);
				}*/
				 
				 if(!ug1.get("course").equals(null)){
					 course=(String) ug1.get("course");
					 System.out.println("course >>> "+ug1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!ug1.get("institute").equals(null)){
					 institute=(String) ug1.get("institute");
					 System.out.println("institute >>> "+ug1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!ug1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) ug1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+ug1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!ug1.get("city").equals(null)){
					 city=(String) ug1.get("city");
					 System.out.println("city >>> "+ug1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!ug1.get("fromMonth").equals(null)){
					 fromMonth=(String) ug1.get("fromMonth");
					 System.out.println("fromMonth >>> "+ug1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!ug1.get("fromYear").equals(null)){
					 fromYear=(String) ug1.get("fromYear");
					 System.out.println("fromYear >>> "+ug1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!ug1.get("toMonth").equals(null)) {
					 toMonth=(String) ug1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!ug1.get("toYear").equals(null)) {
					 toYear=(String) ug1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				 if (!ug1.get("percentage").equals(null)) {
					 percentage=(String) ug1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}		
				
			 }else {
				ug="";
				System.out.println("ug >> "+ug);
			}
			//for pg
			 System.out.println("Hiiiiiiiiiiiii");
			 JSONObject pgjson = (JSONObject) jsonCand4.get("education");
			 if(!pgjson.get("pg").equals(null)){
				 System.out.println("pg1 Json >>> "+pgjson.get("pg"));
				 
				 JSONObject pg1=new JSONObject();
				 System.out.println("pg1 >> "+pg1);
				 pg1=(JSONObject) pgjson.get("pg");
				 System.out.println("pg1 >> "+pg1);
				 
				 if(!pg1.get("degree").equals(null)){
					 degree=(String) pg1.get("degree");
					 System.out.println("degree >>> "+pg1.get("degree"));
				 }else {
					degree="";
					System.out.println("degree >> "+degree);
				}
				 if(!pg1.get("degreeType").equals(null)){
					 degreeType=(String) pg1.get("degreeType");
					 System.out.println("degreeType >>> "+pg1.get("degreeType"));
				 }else {
					 degreeType="";
					System.out.println("degreeType >> "+degreeType);
				}
				 
				 if(!pg1.get("course").equals(null)){
					 course=(String) pg1.get("course");
					 System.out.println("course >>> "+pg1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!pg1.get("institute").equals(null)){
					 institute=(String) pg1.get("institute");
					 System.out.println("institute >>> "+pg1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!pg1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) pg1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+pg1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!pg1.get("city").equals(null)){
					 city=(String) pg1.get("city");
					 System.out.println("city >>> "+pg1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!pg1.get("fromMonth").equals(null)){
					 fromMonth=(String) pg1.get("fromMonth");
					 System.out.println("fromMonth >>> "+pg1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!pg1.get("fromYear").equals(null)){
					 fromYear=(String) pg1.get("fromYear");
					 System.out.println("fromYear >>> "+pg1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!pg1.get("toMonth").equals(null)) {
					 toMonth=(String) pg1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!pg1.get("toYear").equals(null)) {
					 toYear=(String) pg1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				 if (!pg1.get("percentage").equals(null)) {
					 percentage=(String) pg1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}	
				 
			 }else {
				pg="";
				System.out.println("pg >>"+pg);
			}//end pg
			 
			 //// doctrate start
			 
			/* System.out.println("Hiiiiiiiiiiiii");
			 JSONObject doctoratejson = (JSONObject) jsonCand4.get("education");
			 if(!doctoratejson.get("doctorate").equals(null)){
				 System.out.println("doctorate Json >>> "+doctoratejson.get("doctorate"));
				 
				 JSONObject doctorate1=new JSONObject();
				 System.out.println("doctorate1 >> "+doctorate1);
				 doctorate1=(JSONObject) doctoratejson.get("twelveth");
				 System.out.println("doctorate1 >>> "+doctorate1);
				 
				 
				 if(!doctorate1.get("course").equals(null)){
					 course=(String) doctorate1.get("course");
					 System.out.println("course >>> "+doctorate1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!doctorate1.get("institute").equals(null)){
					 institute=(String) doctorate1.get("institute");
					 System.out.println("institute >>> "+doctorate1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!doctorate1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) doctorate1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+doctorate1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!doctorate1.get("city").equals(null)){
					 city=(String) doctorate1.get("city");
					 System.out.println("city >>> "+doctorate1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!doctorate1.get("fromMonth").equals(null)){
					 fromMonth=(String) doctorate1.get("fromMonth");
					 System.out.println("fromMonth >>> "+doctorate1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!doctorate1.get("fromYear").equals(null)){
					 fromYear=(String) doctorate1.get("fromYear");
					 System.out.println("fromYear >>> "+doctorate1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!doctorate1.get("toMonth").equals(null)) {
					 toMonth=(String) doctorate1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!doctorate1.get("toYear").equals(null)) {
					 toYear=(String) doctorate1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				 if (!doctorate1.get("percentage").equals(null)) {
					 percentage=(String) doctorate1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}	
				 
			 }else {
				 doctorate="";
				System.out.println("doctorate >>"+doctorate);
			}
			 */
			 
			 /// start Diploma
			 
			/* System.out.println("Hiiiiiiiiiiiii");
			 JSONObject diplomajson = (JSONObject) jsonCand4.get("education");
			 if(!diplomajson.get("diploma").equals(null)){
				 System.out.println("diploma Json >>> "+diplomajson.get("diploma"));
				 
				 JSONObject diploma1=new JSONObject();
				 System.out.println("diploma1 >> "+diploma1);
				 diploma1=(JSONObject) diplomajson.get("diploma");
				 System.out.println("diploma1 >>> "+diploma1);
				 
				 
				 if(!diploma1.get("course").equals(null)){
					 course=(String) diploma1.get("course");
					 System.out.println("course >>> "+diploma1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!diploma1.get("institute").equals(null)){
					 institute=(String) diploma1.get("institute");
					 System.out.println("institute >>> "+diploma1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!diploma1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) diploma1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+diploma1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!diploma1.get("city").equals(null)){
					 city=(String) diploma1.get("city");
					 System.out.println("city >>> "+diploma1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!diploma1.get("fromMonth").equals(null)){
					 fromMonth=(String) diploma1.get("fromMonth");
					 System.out.println("fromMonth >>> "+diploma1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!diploma1.get("fromYear").equals(null)){
					 fromYear=(String) diploma1.get("fromYear");
					 System.out.println("fromYear >>> "+diploma1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!diploma1.get("toMonth").equals(null)) {
					 toMonth=(String) diploma1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!diploma1.get("toYear").equals(null)) {
					 toYear=(String) diploma1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				 if (!diploma1.get("percentage").equals(null)) {
					 percentage=(String) diploma1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}	
				 
			 }else {
				 diploma="";
				System.out.println("diploma >>"+diploma);
			}*/
			 
			 
			 
			 
			 
			 
			 ////////start 12th
			 System.out.println("Hiiiiiiiiiiiii");
			 JSONObject twelvethjson = (JSONObject) jsonCand4.get("education");
			 if(!twelvethjson.get("twelveth").equals(null)){
				 System.out.println("pg1 Json >>> "+twelvethjson.get("twelveth"));
				 
				 JSONObject twelveth1=new JSONObject();
				 System.out.println("twelveth1 >> "+twelveth1);
				 twelveth1=(JSONObject) twelvethjson.get("twelveth");
				 System.out.println("twelveth1 >>> "+twelveth1);
				 
				 
				 if(!twelveth1.get("course").equals(null)){
					 course=(String) twelveth1.get("course");
					 System.out.println("course >>> "+twelveth1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!twelveth1.get("institute").equals(null)){
					 institute=(String) twelveth1.get("institute");
					 System.out.println("institute >>> "+twelveth1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!twelveth1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) twelveth1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+twelveth1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!twelveth1.get("city").equals(null)){
					 city=(String) twelveth1.get("city");
					 System.out.println("city >>> "+twelveth1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!twelveth1.get("fromMonth").equals(null)){
					 fromMonth=(String) twelveth1.get("fromMonth");
					 System.out.println("fromMonth >>> "+twelveth1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!twelveth1.get("fromYear").equals(null)){
					 fromYear=(String) twelveth1.get("fromYear");
					 System.out.println("fromYear >>> "+twelveth1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!twelveth1.get("toMonth").equals(null)) {
					 toMonth=(String) twelveth1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!twelveth1.get("toYear").equals(null)) {
					 toYear=(String) twelveth1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				/* if (!twelveth1.get("percentage").equals(null)) {
					 percentage=(String) twelveth1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}*/	
				 
			 }else {
				 twelveth="";
				System.out.println("twelveth >>"+twelveth);
			}
			 
			 //end twelveth
			 
			 //Start tenth
			 System.out.println("Hiiiiiiiiiiiii");
			 JSONObject tenthjson = (JSONObject) jsonCand4.get("education");
			 if(!tenthjson.get("tenth").equals(null)){
				 System.out.println("tetnth Json >>> "+tenthjson.get("tenth"));
				 
				 JSONObject tenth1=new JSONObject();
				 System.out.println("tenth1 >> "+tenth1);
				 tenth1=(JSONObject) tenthjson.get("tenth");
				 System.out.println("tenth1 >>> "+tenth1);
				 
				 /*if(!tenth1.get("degree").equals(null)){
					 degree=(String) tenth1.get("degree");
					 System.out.println("degree >>> "+tenth1.get("degree"));
				 }else {
					degree="";
					System.out.println("degree >> "+degree);
				}
				 if(!tenth1.get("degreeType").equals(null)){
					 degreeType=(String) tenth1.get("degreeType");
					 System.out.println("degreeType >>> "+tenth1.get("degreeType"));
				 }else {
					 degreeType="";
					System.out.println("degreeType >> "+degreeType);
				}*/
				 
				 if(!tenth1.get("course").equals(null)){
					 course=(String) tenth1.get("course");
					 System.out.println("course >>> "+tenth1.get("course"));
				 }else {
					 course="";
					System.out.println("course >> "+course);
				}
				 if(!tenth1.get("institute").equals(null)){
					 institute=(String) tenth1.get("institute");
					 System.out.println("institute >>> "+tenth1.get("institute"));
				 }else {
					 institute="";
					System.out.println("institute >> "+institute);
				}
				 if(!tenth1.get("universityOrBoard").equals(null)){
					 universityOrBoard=(String) tenth1.get("universityOrBoard");
					 System.out.println("universityOrBoard >>> "+tenth1.get("universityOrBoard"));
				 }else {
					 universityOrBoard="";
					System.out.println("universityOrBoard >> "+universityOrBoard);
				}
				 if(!tenth1.get("city").equals(null)){
					 city=(String) tenth1.get("city");
					 System.out.println("city >>> "+tenth1.get("city"));
				 }else {
					 city="";
					System.out.println("city >> "+city);
				}
				 if(!tenth1.get("fromMonth").equals(null)){
					 fromMonth=(String) tenth1.get("fromMonth");
					 System.out.println("fromMonth >>> "+tenth1.get("fromMonth"));
				 }else {
					 fromMonth="";
					System.out.println("fromMonth >> "+fromMonth);
				}
				 if(!tenth1.get("fromYear").equals(null)){
					 fromYear=(String) tenth1.get("fromYear");
					 System.out.println("fromYear >>> "+tenth1.get("fromYear"));
				 }else {
					 fromYear="";
					System.out.println("fromYear >> "+fromYear);
				}
				 if (!tenth1.get("toMonth").equals(null)) {
					 toMonth=(String) tenth1.get("toMonth");
					 System.out.println("toMonth >> "+toMonth);
				}else {
					toMonth="";
					System.out.println("toMonth >> "+toMonth);
				}				
				 if (!tenth1.get("toYear").equals(null)) {
					 toYear=(String) tenth1.get("toYear");
					 System.out.println("toYear >> "+toYear);
				}else {
					toYear="";
					System.out.println("toYear >> "+toYear);
				}		
				 /*if (!tenth1.get("percentage").equals(null)) {
					 percentage=(String) tenth1.get("percentage");
					 System.out.println("percentage >> "+percentage);
				}else {
					percentage="";
					System.out.println("percentage >> "+percentage);
				}*/	
				 
			 }else {
				 tenth="";
				System.out.println("twelveth >>"+tenth);
			}
			 
			 //end tenth
			 //////////
				 
		}else {
			education="";
			System.out.println("education >> "+education);
		}
		

		 
		
		/*degree=jsonCand4.getString("degree");
		 degreeType=jsonCand4.getString("degreeType");
		 course=jsonCand4.getString("course");
		 institute=jsonCand4.getString("institute");
		 universityOrBoard=jsonCand4.getString("universityOrBoard");
		 city=jsonCand4.getString("city");
		 fromMonth=jsonCand4.getString("fromMonth");
		 fromYear=jsonCand4.getString("fromYear");
		 toMonth=jsonCand4.getString("toMonth");
		 toYear=jsonCand4.getString("toYear");
		 percentage=jsonCand4.getString("percentage");*/
		
		
		// pg=jsonCand4.getString("pg");
		 //twelveth=jsonCand4.getString("twelveth");
		// tenth=jsonCand4.getString("tenth");
		 //address=jsonCand4.getString("address");
		// permanentAddress=jsonCand4.getString("permanentAddress");
		 country=jsonCand4.getString("country");
		 state=jsonCand4.getString("state");

		 street=jsonCand4.getString("street");
		 pincode=jsonCand4.getString("pincode");
		 location=jsonCand4.getString("location");
		 currentAddress=jsonCand4.getString("currentAddress");

		 preferredLocation=jsonCand4.getString("preferredLocation");
		 salary=jsonCand4.getString("salary");
		 currentCTCType=jsonCand4.getString("currentCTCType");
		 currentCTC=jsonCand4.getString("currentCTC");
		 negotiableCTC=jsonCand4.getString("negotiableCTC");
		 expectedCTCType=jsonCand4.getString("expectedCTCType");
		 expectedCTC=jsonCand4.getString("expectedCTC");
		 takeHome=jsonCand4.getString("takeHome");
		 fixed=jsonCand4.getString("fixed");
		 employment=jsonCand4.getString("employment");
		 current=jsonCand4.getString("current");
		 companyName=jsonCand4.getString("companyName");
		 designation=jsonCand4.getString("designation");
		
		 isCurrent=jsonCand4.getString("isCurrent");
		 desc=jsonCand4.getString("desc");
		 workLocation=jsonCand4.getString("workLocation");
		 role=jsonCand4.getString("role");
		 level=jsonCand4.getString("level");
		 teamSize=jsonCand4.getString("teamSize");
		 previous=jsonCand4.getString("previous");
		
		 experience=jsonCand4.getString("experience");
		 months=jsonCand4.getString("months");
		 TotalExp=jsonCand4.getString("TotalExp");
		 years=jsonCand4.getString("years");
		
		 createdBy=jsonCand4.getString("createdBy");
		 username=jsonCand4.getString("username");
		 System.out.println("username >> "+username);
		 System.out.println("city >> "+city);
		
		
	//Candidate Collection
		//urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";//,resumeName,resume
		 //id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,currentAddress,preferredLocation,salary,expectedCTC,employment,current,previous,experience,lastModified,createdDate,createdBy,username,username,projectDescription
		urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(id:\""+objectId+"\")&size=10&from=0&pretty=true&_source=id,name,email,alternateEmail,birthdate,mobileNumber,lastModified,education,ug,degree,degreeType,course,institute,universityOrBoard,city,fromMonth,fromYear,toMonth,toYear,percentage,pg,twelveth,tenth,address,permanentAddress,country,state,city,street,pincode,location,currentAddress,currentAddress,country,state,city,street,pincode,location,preferredLocation,salary,currentCTCType,currentCTC,negotiableCTC,expectedCTCType,expectedCTC,takeHome,fixed,employment,current,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,previous,companyName,designation,city,fromMonth,fromYear,toMonth,toYear,isCurrent,desc,workLocation,role,level,teamSize,,experience,months,TotalExp,years,lastModified,createdDate,createdBy,username,username";//,resumeName,resume
		System.out.println("urlCandidate >> " + urlCandidate);
		jsonCandidateData = restTemplate.getForObject(urlCandidate, String.class);
		System.out.println("jsonCandidateData >> "+jsonCandidateData);

		
		
		/*JSONObject object = new JSONObject();
		JSONArray array = new JSONArray();
		array.put(0, jsonCandidateData);
		array.put(1, jsonAttachData);
		object.put("response", array);
		 //return jsonCandidateData+jsonAttachData;
		System.out.println(object);*/
		//return object.toString();
		
		 
		 return jsonCandidateData;
		//return jsonAttachData+jsonCandidateData;

	}

	
	
	//Working Fine API some changes Above...
	
	//Gm 22-Aug-2018  behalf of objectId to get job data in not id
	//Gm 22-Aug-2018  behalf of objectId to get job data in not id
	
	@RequestMapping(value = "/ElasticAPI/jobkey2", method = { RequestMethod.GET })
	public @ResponseBody String esAttachJobid(@RequestParam("objectId") String objectId, @RequestParam("data") String data) throws JSONException {

		String urlJob = "";
		String jsonJobData = "";
		String urlAttach = "";
		String jsonAttachData = "";
		String jobIds = " ";

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=objectId:"
				+ objectId;
		System.out.println("urlAttach...." + urlAttach);

		jsonAttachData = restTemplate.getForObject(urlAttach, String.class);

		org.json.JSONObject hits = new org.json.JSONObject(jsonAttachData).getJSONObject("hits");

		org.json.JSONArray hitsArr = hits.getJSONArray("hits");

		for (int i = 0; i < hitsArr.length(); i++) {
			org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
			org.json.JSONObject _source = arrobj.getJSONObject("_source");

			jobIds = jobIds + "+" + _source.getString("jobId");
		}

		jobIds = jobIds.replaceFirst("[+]", "").trim();
		System.out.println(jobIds);

		if(data.length()>=1){
			//data="\"*"+data+"\"*";
			data="*"+data+"*";
		}else{
			data="*";
		}
		
		if (data.contains("@")) {
			data = data.replaceAll("@", "%40");
		}
		if (data.contains(":")) {
			data = data.replaceAll(":", "%3A");
		}
		if (data.contains("'")) {
			data = data.replaceAll("''", "%27");
		}
		if (data.contains("(") || data.contains(")")) {
			data = data.replaceAll("(", "%28");
			data = data.replaceAll(")", "%29");
		}
		if (data.contains("||")) {
			data = data.replaceAll("||", "%7C%7C");
		}

		if (data.contains(" ")) {
			data = data.replaceAll(" ", "+");
		}
		if (data.contains("Re:")) {
			data.replaceAll("RE:", "Re%3A");
		}
		if (data.contains(": ")) {
			data.replaceAll(": ", "%3A+");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "%20");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "");
		}
		
		
		urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?default_operator=OR&q=NOT(id:"
				+ jobIds + ")OR(name:" + data+")";

		jsonJobData = restTemplate.getForObject(urlJob, String.class);
		/*org.json.JSONObject response = new org.json.JSONObject();
		org.json.JSONArray subRes = new org.json.JSONArray();

		hits = new org.json.JSONObject(jsonJobData).getJSONObject("hits");
		Integer total = hits.getInt("total");

		hitsArr = hits.getJSONArray("hits");

		for (int i = 0; i < hitsArr.length(); i++) {
			org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
			org.json.JSONObject _source = arrobj.getJSONObject("_source");

			JSONObject subResonse = new JSONObject();
			subResonse.put("jobcode", _source.get("jobcode"));
			subResonse.put("funtionalarea", _source.get("funtionalarea"));
			subResonse.put("skills", _source.get("skills"));
			subResonse.put("modifieddate", _source.get("modifieddate"));
			subResonse.put("description", _source.get("description"));
			subResonse.put("experience", _source.get("experience"));
			subResonse.put("clientid_id", _source.get("clientid_id"));
			subResonse.put("@timestamp", _source.get("@timestamp"));
			subResonse.put("education", _source.get("education"));
			subResonse.put("role", _source.get("role"));
			subResonse.put("modifiedby", _source.get("modifiedby"));
			subResonse.put("industrytype", _source.get("industrytype"));
			subResonse.put("industry", _source.get("industry"));
			subResonse.put("expireddate", _source.get("expireddate"));
			subResonse.put("contactid_id", _source.get("contactid_id"));
			subResonse.put("@version", _source.get("@version"));
			subResonse.put("id", _source.get("id"));
			subResonse.put("name", _source.get("name"));
			subResonse.put("postedby", _source.get("postedby"));
			subResonse.put("deleted", _source.get("deleted"));
			subResonse.put("location", _source.get("location"));
			subResonse.put("ctc", _source.get("ctc"));
			subResonse.put("posteddate", _source.get("posteddate"));
			subResonse.put("noofopenings", _source.get("noofopenings"));
			subRes.put(subResonse);

		}

		response.put("total", total);
		response.put("response", subRes);*/

		return jsonJobData.toString();

	}


	//Behalf of anyke API
	@RequestMapping(value = "/ElasticAPI/jobkey", method = { RequestMethod.GET })
	public @ResponseBody String esDataIndexJobAnyKey(@RequestParam("data") String data
			) throws URISyntaxException, MalformedURLException {
		
		RestTemplate restTemplate=new RestTemplate();

		if(data.length()>=1){
			//data="\"*"+data+"\"*";
			data="*"+data+"*";
		}else{
			data="*";
		}
		
		if (data.contains("@")) {
			data = data.replaceAll("@", "%40");
		}
		if (data.contains(":")) {
			data = data.replaceAll(":", "%3A");
		}
		if (data.contains("'")) {
			data = data.replaceAll("''", "%27");
		}
		if (data.contains("(") || data.contains(")")) {
			data = data.replaceAll("(", "%28");
			data = data.replaceAll(")", "%29");
		}
		if (data.contains("||")) {
			data = data.replaceAll("||", "%7C%7C");
		}

		if (data.contains(" ")) {
			data = data.replaceAll(" ", "+");
		}
		if (data.contains("Re:")) {
			data.replaceAll("RE:", "Re%3A");
		}
		if (data.contains(": ")) {
			data.replaceAll(": ", "%3A+");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "%20");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "");
		}
		String urlJob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+data+"&size=10&from=0&pretty=true&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";
		URL urlJobdata = new URL(urlJob);
		String nullFragment = null;
		URI uriJob = new URI(urlJobdata.getProtocol(), urlJobdata.getUserInfo(), urlJobdata.getHost(),
				urlJobdata.getPort(), urlJobdata.getPath(), urlJobdata.getQuery(), nullFragment);
		System.out.println("ESAPI dataindexjob uriJob >> " + uriJob);
		String jsonEsJobUrl = restTemplate.getForObject(uriJob, String.class);
		return jsonEsJobUrl.toString();
	}
	
	//ExternalPortal API Attach and job
	
	@RequestMapping(value = "/ElasticAPI/attachjob", method = RequestMethod.GET)
	public @ResponseBody String attachObjStageJobs(@RequestParam("objectid")String objectId, @RequestParam("statusid")String statusId) throws ParseException, JSONException {
	Job jc=new Job();
	System.out.println("jc.getNumFound() >> "+jc.getNumFound());
	ArrayList  list =new ArrayList();	
	list=getjobDetail1(objectId,statusId);
	
	org.json.JSONObject jsonObject = new org.json.JSONObject();
	jsonObject.put("numFound", jc.getNumFound());
	jsonObject.put("response", list);
		return jsonObject.toString();
	}
	
	public static ArrayList getjobDetail1(String objectid,String statausid) throws JSONException, ParseException{
		ArrayList<JobDetail> j = new ArrayList<JobDetail>(); 
		RestTemplate restTemplate = new RestTemplate();
		  // String JobURL = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(id:"+jobid+")&size=10&from=0&pretty=true&_source=";
		   String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:"+objectid+")AND(statusId:"+statausid+")&size=10&from=0&pretty=true&_source=jobId,objectId,id";	
		           System.out.println("ESURL JobURL jobId  >> " + url);
				   String jsonJobData = restTemplate.getForObject(url, String.class);
				   
				    JSONParser parse = new JSONParser();
				    org.json.simple.JSONObject hits = (org.json.simple.JSONObject) ((org.json.simple.JSONObject) parse.parse(jsonJobData)).get("hits");
					org.json.simple.JSONArray hitsArr = (org.json.simple.JSONArray) hits.get("hits");
						Job jcount= new Job();
					 
						System.out.println("total:::::::"+hits.get("total"));
					        Long total=  (Long) hits.get("total");
					        jcount.setNumFound(total);
						

					Iterator iterator = hitsArr.iterator();
					ArrayList<Job> jlist = new ArrayList<Job>();
					ArrayList<JobDetail> jdlist = new ArrayList<JobDetail>();
					ArrayList jdlist1 = new ArrayList();
					jdlist1.add(jcount);//totalCount
					while(iterator.hasNext()){
						
						Job job = new Job();
						
						org.json.simple.JSONObject jsonObject =(org.json.simple.JSONObject) ((org.json.simple.JSONObject) iterator.next()).get("_source");
						String jobId = (String) jsonObject.get("jobId");
						job.setJobid(jobId);
					    jdlist = getJobDetail(jobId);
						jlist.add(job);
						//System.out.println("jsonObject::::::::::::::::::::"+jsonObject.get("jobId"));
						jdlist1.add(jdlist);
						//System.out.println("jdlist::::::::::::::::::::::::::::"+jdlist);
						}
					
		 System.out.println("jdlist1hhh::::"+jdlist1);
		
		return jdlist1;
		
	}
	
	
	 public static ArrayList<JobDetail> getJobDetail(String jobid) throws JSONException{
		 
		 ArrayList<JobDetail> list = new ArrayList<JobDetail>();
         RestTemplate restTemplate = new RestTemplate();
		    String JobURL = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(id:"+jobid+")&size=10&from=0&pretty=true&_source=";
			System.out.println("ESURL JobURL jobId  >> " + JobURL);
			String jsonJobData = restTemplate.getForObject(JobURL, String.class);
		 
			org.json.JSONObject hits = new org.json.JSONObject(jsonJobData).getJSONObject("hits");
			org.json.JSONArray hitsArr = hits.getJSONArray("hits");
			for (int i = 0; i < hitsArr.length(); i++) {
				System.out.println("length::::"+hitsArr.length());
				JobDetail jd = new JobDetail();
				org.json.JSONObject arrobj = (org.json.JSONObject) hitsArr.get(i);
				org.json.JSONObject  _source = arrobj.getJSONObject("_source");
				
				if (_source.has("id")) {
					String jobids=(String) _source.get("id");
					 //String jobids= "4986f9b7-f872-4b4b-bdd0-6ce9fef4d6a0";s
					 jd.setId(jobids);
				} 
				if (_source.has("clientId")) {
					 String clientId= _source.getString("clientId");
					 jd.setClientId(clientId);
				}
				if (_source.has("contactId")) {
					 String contactId=_source.getString("contactId");
					 jd.setContactId(contactId);
				}
				if (_source.has("name")) {
					 String name=_source.getString("name");
					 jd.setName(name);
				}
				if (_source.has("jobCode") && !_source.get("jobCode").equals(null)) {
					 String jobCode =_source.getString("jobCode");
					 jd.setJobCode(jobCode);
				}
				if (_source.has("noOfOpenings")) {
					 String noOfOpenings=_source.getString("noOfOpenings");
					 jd.setNoOfOpenings(noOfOpenings);
				}
				if (_source.has("experience")) {
					 String experience = _source.getString("experience");
					 jd.setExperience(experience);	
				}
				if (_source.has("ctc")) {
					 String ctc = _source.getString("ctc");
					 jd.setCtc(ctc);
				}
				if (_source.has("location")) {
					 String location = _source.getString("location");
					 jd.setLocation(location);
				}
				if (_source.has("industryType")) {
					 String industryType = _source.getString("industryType");
					 jd.setIndustryType(industryType);
				}
				if (_source.has("industry")) {
					 String industry = _source.getString("industry");
					 jd.setIndustry(industry);
				}
				if (_source.has("funtionalArea")) {
					 String funtionalArea=_source.getString("funtionalArea");
					 jd.setFuntionalArea(funtionalArea);
				}
				if (_source.has("role")) {
					String role=_source.getString("role");
					 jd.setRole(role);
				} 
				if (_source.has("skills")) {
					String skills= _source.getString("skills");
					 jd.setSkills(skills);
				}
				if (_source.has("education")) {
					 String education= _source.getString("education");
					 jd.setEducation(education);
				}
				if (_source.has("description")) {
					 String description=_source.getString("description");
					 jd.setDescription(description);
				}
				if (_source.has("postedDate")) {
					 String postedDate= _source.getString("postedDate");
					 jd.setPostedDate(postedDate);
				}
				if (_source.has("modifiedDate")) {
					 String modifiedDate= _source.getString("modifiedDate");
					 jd.setModifiedDate(modifiedDate);
				}
				if (_source.has("expiredDate")) {
					 String expiredDate=_source.getString("expiredDate");
					 jd.setExpiredDate(expiredDate);
				}
				if (_source.has("postedBy")) {
					 String postedBy=_source.getString("postedBy");
					 jd.setPostedBy(postedBy);
				}
				if (_source.has("modifiedBy")) {
					 String modifiedBy= _source.getString("modifiedBy");
					 jd.setModifiedBy(modifiedBy);
				}
				if (_source.has("deleted")) {
					 int deleted = _source.getInt("deleted");
					 jd.setDeleted(deleted);
				}
				 list.add(jd); 
				 
				 System.out.println("list::::"+list);
				 
				return list;
			}
			//return list;
			return list;
			
	
	  }
	
	
	
	

//////// 24-July-2018 client.. collection behalf of any keyword.
	
	@RequestMapping(value = "/ElasticAPI/client", method = { RequestMethod.GET })
	public @ResponseBody String esClientAnyKey(@RequestParam("data") String data
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		if (data.contains("@")) {
			data = data.replaceAll("@", "%40");
		}
		if (data.contains(":")) {
			data = data.replaceAll(":", "%3A");
		}
		if (data.contains("'")) {
			data = data.replaceAll("''", "%27");
		}
		if (data.contains("(") || data.contains(")")) {
			data = data.replaceAll("(", "%28");
			data = data.replaceAll(")", "%29");
		}
		if (data.contains("||")) {
			data = data.replaceAll("||", "%7C%7C");
		}

		if (data.contains(" ")) {
			data = data.replaceAll(" ", "+");
		}
		if (data.contains("Re:")) {
			data.replaceAll("RE:", "Re%3A");
		}
		if (data.contains(": ")) {
			data.replaceAll(": ", "%3A+");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "%20");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "");
		}

		String urlClient = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/client/_search?q="+data+"&size=10&from=0&pretty=true&_source=domain,modifieddate,deleted,employees,status,name,createdby,billingaddress,modifiedby,@timestamp,panno,shortname,type,level,headquarter,shippingaddress,id,founded,createddate,@version";
		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		URL urlClientdata = new URL(urlClient);
		String nullFragment = null;
		URI uriClient = new URI(urlClientdata.getProtocol(), urlClientdata.getUserInfo(), urlClientdata.getHost(),
				urlClientdata.getPort(), urlClientdata.getPath(), urlClientdata.getQuery(), nullFragment);
		System.out.println("ESAPI client uriClient >> " + uriClient);
		String jsonEsClientUrl = restTemplate.getForObject(uriClient, String.class);
		// System.out.println("jsonEsUrl dataindexjob >>> "+jsonEsJobUrl);
		return jsonEsClientUrl.toString();
	}

	//Contact module collection behalf of any keyword.
	@RequestMapping(value = "/ElasticAPI/contact", method = { RequestMethod.GET })
	public @ResponseBody String esContactAnyKey(@RequestParam("data") String data
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		if (data.contains("@")) {
			data = data.replaceAll("@", "%40");
		}
		if (data.contains(":")) {
			data = data.replaceAll(":", "%3A");
		}
		if (data.contains("'")) {
			data = data.replaceAll("''", "%27");
		}
		if (data.contains("(") || data.contains(")")) {
			data = data.replaceAll("(", "%28");
			data = data.replaceAll(")", "%29");
		}
		if (data.contains("||")) {
			data = data.replaceAll("||", "%7C%7C");
		}

		if (data.contains(" ")) {
			data = data.replaceAll(" ", "+");
		}
		if (data.contains("Re:")) {
			data.replaceAll("RE:", "Re%3A");
		}
		if (data.contains(": ")) {
			data.replaceAll(": ", "%3A+");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "%20");
		}
		if (data.contains(" ")) {
			data = data.replaceAll(" ", "");
		}

		String urlContact = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/contact/_search?q=("+data+")&size=10&from=0&pretty=true&_source=@version,modifieddate,officeemailid,officeno,firstname,clientid_id,salutation,lastname,id,middlename,createddate,@timestamp,designation,modifiedby,fullname,createdby,personalemailid,mobileno,mobileno";
		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		URL urlContactdata = new URL(urlContact);
		String nullFragment = null;
		URI uriContactData = new URI(urlContactdata.getProtocol(), urlContactdata.getUserInfo(), urlContactdata.getHost(),
				urlContactdata.getPort(), urlContactdata.getPath(), urlContactdata.getQuery(), nullFragment);
		System.out.println("ESAPI client uriContactData >> " + uriContactData);
		String jsonEsContactUrl = restTemplate.getForObject(uriContactData, String.class);
		// System.out.println("jsonEsUrl dataindexjob >>> "+jsonEsJobUrl);
		return jsonEsContactUrl.toString();
	}
	
	
	
	

	
	
	//Advanced Search for External Portal 30-July-2018 with exclude objectId
	
	@RequestMapping(value = "/ElasticAPI/epsearch")
    public @ResponseBody String externalPortalAdvancedSearch(@RequestParam("skills") String skills,
                  @RequestParam("location") String location, @RequestParam("experience") String experience,
                  @RequestParam("ctc") String ctc, @RequestParam("industry") String industry,
                  /* @RequestParam("jobcategory")String jobcategory, */ @RequestParam("sort") String sort,
                  @RequestParam("objectId") String objectId) throws JSONException {

           /// RestTemplate restTemplate = new RestTemplate();
           if (sort.equals("modifiedDatea")) {
                  sort = "modifiedDate:" + " asc";
           } else if (sort.equals("modifiedDated")) {
                  sort = "modifiedDate:" + " desc";
           }

           String urlAttach = "";
           String jsonAttachData = "";
           String jobIds = " ";
           urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=objectId:"
                        + objectId;
           System.out.println("urlAttach...." + urlAttach);
           jsonAttachData = restTemplate.getForObject(urlAttach, String.class);
           JSONObject hits = new JSONObject(jsonAttachData).getJSONObject("hits");
           JSONArray hitsArr = hits.getJSONArray("hits");
           for (int i = 0; i < hitsArr.length(); i++) {
                  JSONObject arrobj = (JSONObject) hitsArr.get(i);
                  JSONObject _source = arrobj.getJSONObject("_source");
                  jobIds = jobIds + "+" + _source.getString("jobId");
           }
           jobIds = jobIds.replaceFirst("[+]", "").trim();

           if (skills.length() >= 0) {
                  skills = skills.replace(",", "\") OR (\"");
                  // skills=skills.replace(",", "\")OR(\"");
           }

           /*
           * skills="\""+skills+"\""; location="\""+location+"\"";
           * experience="\""+experience+"\""; ctc="\""+ctc+"\"";
           * industry="\""+industry+"\"";
           */

           String dquery = "";

           /*
           * if (skills.length() >= 1) { skills = "skills:*" + skills + "*";
           * System.out.println("skills >> "+skills); dquery = skills;
           * System.out.println("dquery >> "+dquery); }
           */

           if (skills.length() >= 1) {
                  skills = "(skills:(\"" + skills + "\"))";
                  // skills = "\"" + skills + "\"";
                  if (dquery.equals("")) {
                        dquery = skills;
                  } else {
                        dquery = dquery + " AND " + skills;
                  }
           }

           if (location.length() >= 1) {
                  // location = "location:*" + location + "*";
                  location = "(location:(\"" + location + "\"))";
                  // location = "\"" + location + "\"";
                  if (dquery.equals("")) {
                        dquery = location;
                  } else {
                        dquery = dquery + " AND " + location;
                  }
           }

           if (experience.length() >= 1) {
                  experience = "(experience:(\"" + experience + "\"))";
                  // experience = "\"" + experience + "\"";
                  if (dquery.equals("")) {
                        dquery = experience;
                  } else {
                        dquery = dquery + " AND " + experience;
                  }
           }

           if (ctc.length() >= 1) {
                  ctc = "(ctc:(\"" + ctc + "\"))";
                  // ctc = "\"" + ctc + "\"";
                  if (dquery.equals("")) {
                        dquery = ctc;
                  } else {
                        dquery = dquery + " AND " + ctc;
                  }
           }

           if (industry.length() >= 1) {
                  industry = "(industry:(\"" + industry + "\"))";
                  // industry = "\"" + industry + "\"";
                  if (dquery.equals("")) {
                        dquery = industry;
                  } else {
                        dquery = dquery + " AND " + industry;
                  }
           }

           // Job Category

           /*
           * if (jobcategory.length() >= 1) { jobcategory = "jobcategory:\"" +
           * jobcategory + "\""; if (dquery.equals("")) { dquery = jobcategory; }
           * else { dquery = dquery + " AND " + jobcategory; } }
           */

           // String urljob =
           // "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(skills:("+skills+"))
           // OR (location:("+location+")) OR (experience:("+experience+")) OR
           // (ctc:("+ctc+")) OR
           // (industry:("+industry+"))&size=10&from=0&pretty=true&_source=funtionalArea,role,education,clientId,contactId,expiredDate,jobCode,description,industry,experience,noOfOpenings,postedDate,skills,postedBy,jobId,ctc,industryType,name,modifiedDate,location,modifiedBy,id";

           if (jobIds.length() > 1)
                  dquery = "NOT(id:" + jobIds + ")OR" + dquery;

           String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="
                        + dquery + "&size=10&from=0&pretty=true&sort=" + sort
                        + "&_source=id,clientId,contactId,name,jobCode,noOfOpenings,experience,ctc,location,industryType,industry,funtionalArea,role,skills,education,description,postedDate,modifiedDate,expiredDate,postedBy,modifiedBy,deleted";

           System.out.println("urlJob AdvancedSearch :: " + urljob);

           String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);

           return jsonEsJobUrl.toString();

    }


	
	
/*	@RequestMapping(value="ElasticAPI/epsearch")
	public @ResponseBody String externalPortalAdvancedSearch(@RequestParam("skills")String skills,@RequestParam("location")String location,
			@RequestParam("experience")String experience,@RequestParam("ctc")String ctc,@RequestParam("industry")String industry,
			@RequestParam("jobcategory")String jobcategory, @RequestParam("sort")String sort){
		RestTemplate restTemplate = new RestTemplate(); 
		if (sort.equals("modifiedDatea")) {
			sort="modifiedDate:" + " asc";
		}else if(sort.equals("modifiedDated")) {
			sort="modifiedDate:" + " desc";
		}
		
		if (skills.length()>=0) {
			skills=skills.replace(",", "\") OR (\"");
		}
		
		String dquery = "";
		
		if (skills.length() >= 1) {
			skills = "(skills:(\"" + skills + "\"))";
			//skills = "\"" + skills + "\"";
			if (dquery.equals("")) {
				dquery = skills;
			} else {
				dquery = dquery + " AND " + skills;
			}
		}

		if (location.length() >= 1) {
			//location = "location:*" + location + "*";
			location = "(location:(\"" + location + "\"))";
			//location = "\"" + location + "\"";
			if (dquery.equals("")) {
				dquery = location;
			} else {
				dquery = dquery + " AND " + location;
			}
		}

		if (experience.length() >= 1) {
			experience = "(experience:(\"" + experience + "\"))";
			//experience = "\"" + experience + "\"";			
			if (dquery.equals("")) {
				dquery = experience;
			} else {
				dquery = dquery + " AND " + experience;
			}
		}

		if (ctc.length() >= 1) {
			ctc = "(ctc:(\"" + ctc + "\"))";
			//ctc = "\"" + ctc + "\"";
			if (dquery.equals("")) {
				dquery = ctc;
			} else {
				dquery = dquery + " AND " + ctc;
			}
		}

		if (industry.length() >= 1) {
			industry = "(industry:(\"" + industry + "\"))";
			//industry = "\"" + industry + "\"";
			if (dquery.equals("")) {
				dquery = industry;
			} else {
				dquery = dquery + " AND " + industry;
			}
		}
		
		//String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q=(skills:("+skills+")) OR (location:("+location+")) OR (experience:("+experience+")) OR (ctc:("+ctc+")) OR (industry:("+industry+"))&size=10&from=0&pretty=true&_source=funtionalArea,role,education,clientId,contactId,expiredDate,jobCode,description,industry,experience,noOfOpenings,postedDate,skills,postedBy,jobId,ctc,industryType,name,modifiedDate,location,modifiedBy,id";
		String urljob = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/job/_search?q="+dquery+"&size=10&from=0&pretty=true&sort=" + sort + "&_source=name,skills,role,ctc,experience,location,postedby,id,description,industry,@timestamp,industrytype,education,funtionalarea,posteddate,noofopenings,expireddate,modifieddate,modifiedby";
		System.out.println("urlJob AdvancedSearch :: "+urljob);
		String jsonEsJobUrl = restTemplate.getForObject(urljob, String.class);
		return jsonEsJobUrl;
		
	}*/
	
	//Candidate API for ExternalPortal behalf of emailId email
	
	@RequestMapping(value = "/ElasticAPI/email", method = { RequestMethod.GET })
	public @ResponseBody String epCandidateEmail(@RequestParam("email") String email
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		/*if (email.contains("@")) {
			email = email.replace("@", "%40");
		}
		if (email.contains(":")) {
			email = email.replace(":", "%3A");
		}
		if (email.contains("'")) {
			email = email.replace("''", "%27");
		}
		if (email.contains("(") || email.contains(")")) {
			email = email.replace("(", "%28");
			email = email.replace(")", "%29");
		}
		if (email.contains("||")) {
			email = email.replaceAll("||", "%7C%7C");
		}

		if (email.contains(" ")) {
			email = email.replaceAll(" ", "+");
		}
		if (email.contains("Re:")) {
			email.replace("RE:", "Re%3A");
		}
		if (email.contains(": ")) {
			email.replace(": ", "%3A+");
		}
		if (email.contains(" ")) {
			email = email.replace(" ", "%20");
		}
		if (email.contains(" ")) {
			email = email.replace(" ", "");
		}*/

		//String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=email:("+email+")&size=10&from=0&pretty=true&_source=name,first_name,last_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience";
		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(email:(\""+email+"\"))&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";
		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		/*URL urlCandidatedata = new URL(urlCandidate);
		String nullFragment = null;
		URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(), urlCandidatedata.getHost(),
				urlCandidatedata.getPort(), urlCandidatedata.getPath(), urlCandidatedata.getQuery(), nullFragment);*/
		System.out.println("ESAPI client uriCandidatedata >> " + urlCandidate);
		String jsonEsContactUrl = restTemplate.getForObject(urlCandidate, String.class);
		// System.out.println("jsonEsUrl Candidatedata >>> "+uriCandidatedata);
		return jsonEsContactUrl.toString();
	}
	
	
	@RequestMapping(value = "/ElasticAPI/objid", method = { RequestMethod.GET })
	public @ResponseBody String epCandidateObjectId(@RequestParam("_id") String _id
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(_id:(\""+_id+"\"))&size=10&from=0&pretty=true&_source=name,first_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience,skills,summary,preferredLocation,jobType,employmentType,birthdate,age,gender,category,category,maritalStatus,physicallyChallenged,address,createdDate,createdBy,education,certificates,areaOfSpecialization,otherInterest,fresher,experienced,employment,achievement,project,salary,visibility,notification";
		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		/*URL urlCandidatedata = new URL(urlCandidate);
		String nullFragment = null;
		URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(), urlCandidatedata.getHost(),
				urlCandidatedata.getPort(), urlCandidatedata.getPath(), urlCandidatedata.getQuery(), nullFragment);*/
		System.out.println("ESAPI client uriCandidatedata >> " + urlCandidate);
		String jsonEsContactUrl = restTemplate.getForObject(urlCandidate, String.class);
		// System.out.println("jsonEsUrl Candidatedata >>> "+uriCandidatedata);
		return jsonEsContactUrl.toString();
	}
	

	
	@RequestMapping(value = "/ElasticAPI/anycand", method = { RequestMethod.GET })
	public @ResponseBody String epCandidateAnykey(@RequestParam("data") String data
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		if(data.length()>=1){
			//data="\"*"+data+"\"*";
			data="*"+data+"*";
		}else{
			data="*";
		}
		
		/*if (data.contains("@")) {
			data = data.replace("@", "%40");
		}
		if (data.contains(":")) {
			data = data.replace(":", "%3A");
		}
		if (data.contains("'")) {
			data = data.replace("''", "%27");
		}
		if (data.contains("(") || data.contains(")")) {
			data = data.replace("(", "%28");
			data = data.replace(")", "%29");
		}
		if (data.contains("||")) {
			data = data.replace("||", "%7C%7C");
		}

		if (data.contains(" ")) {
			data = data.replace(" ", "+");
		}
		if (data.contains("Re:")) {
			data.replace("RE:", "Re%3A");
		}
		if (data.contains(": ")) {
			data.replace(": ", "%3A+");
		}
		if (data.contains(" ")) {
			data = data.replace(" ", "%20");
		}
		if (data.contains(" ")) {
			data = data.replace(" ", "");
		}*/

		//String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=email:("+email+")&size=10&from=0&pretty=true&_source=name,first_name,last_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience";
		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q="+data+"&size=10&from=0&pretty=true&_source";
		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		URL urlCandidatedata = new URL(urlCandidate);
		String nullFragment = null;
		URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(), urlCandidatedata.getHost(),
				urlCandidatedata.getPort(), urlCandidatedata.getPath(), urlCandidatedata.getQuery(), nullFragment);
		System.out.println("ESAPI client uriCandidatedata >> " + uriCandidatedata);
		String jsonEsContactUrl = restTemplate.getForObject(uriCandidatedata, String.class);
		// System.out.println("jsonEsUrl Candidatedata >>> "+uriCandidatedata);
		return jsonEsContactUrl.toString();
	}
	
	
	@RequestMapping(value = "/ElasticAPI/city", method = { RequestMethod.GET })
	public @ResponseBody String epCandidateCity(@RequestParam("city") String city
			) throws URISyntaxException, MalformedURLException {
	
		RestTemplate restTemplate=new RestTemplate();

		if(city.length()>=1){
			city="(\""+city+"\")";
			//data="*"+data+"*";
		}else{
			city="*";
		}
		
		if (city.contains("@")) {
			city = city.replace("@", "%40");
		}
		if (city.contains(":")) {
			city = city.replace(":", "%3A");
		}
		if (city.contains("'")) {
			city = city.replace("''", "%27");
		}
		if (city.contains("(") || city.contains(")")) {
			city = city.replace("(", "%28");
			city = city.replace(")", "%29");
		}
		if (city.contains("||")) {
			city = city.replace("||", "%7C%7C");
		}

		if (city.contains(" ")) {
			city = city.replace(" ", "+");
		}
		if (city.contains("Re:")) {
			city.replace("RE:", "Re%3A");
		}
		if (city.contains(": ")) {
			city.replace(": ", "%3A+");
		}
		if (city.contains(" ")) {
			city = city.replace(" ", "%20");
		}
		if (city.contains(" ")) {
			city = city.replace(" ", "");
		}

		//String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=email:("+email+")&size=10&from=0&pretty=true&_source=name,first_name,last_name,username,resumeHeadLine,experiencedIndustry,experiencedFunctionalArea,mobileNumber,isMobileNumberVerified,picture,profile,resume,resumeName,email,experience";
		String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=city:"+city+"&size=10&from=0&pretty=true&_source=address,permanentAddress,pincode,street,city,state,country";
		//String urlCandidate = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate1/_search?q=(city:"+city+")&size=10&from=0&pretty=true&_source=permanentAddress,pincode,street,city,state,country"; //Not Working these fields. in canddidates..

		// System.out.println("ESAPI dataindexjob data anykey :>> "+urlJob);
		URL urlCandidatedata = new URL(urlCandidate);
		String nullFragment = null;
		URI uriCandidatedata = new URI(urlCandidatedata.getProtocol(), urlCandidatedata.getUserInfo(), urlCandidatedata.getHost(),
				urlCandidatedata.getPort(), urlCandidatedata.getPath(), urlCandidatedata.getQuery(), nullFragment);
		System.out.println("ESAPI client uriCandidatedata >> " + uriCandidatedata);
		String jsonEsContactUrl = restTemplate.getForObject(uriCandidatedata, String.class);
		// System.out.println("jsonEsUrl Candidatedata >>> "+uriCandidatedata);
		return jsonEsContactUrl.toString();
	}
	
	
	
	
	
	

	@RequestMapping(value ="/ElasticAPI/esGet")
	public @ResponseBody String elastiSearchGetMethod(/*@RequestHeader HttpHeaders headers*/) {
		/*if (!headers.containsKey("authorization")) {
			System.out.println("No Authentication");
			return "{\"error\":\"Please Provide The Authentication\"}";
		}
		String authString = headers.getFirst("authorization");
		if (!restService.isUserAuthenticated(authString)) {
			System.out.println("Wrong Authentication.....");
			return "{\"error\":\"User not authenticated\"}";
		}*/
		
		
		RestTemplate restTemplate = new RestTemplate();
		String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
		//String url = rootconfig.getEmaildataindex1()+"/_search?size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
		//	String url = Getvalue.getCallDataIndexES()+"/_search?size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";

		System.out.println("ESURL emaildataindex  Data NonParam  >> " + url);
		restTemplate.getMessageConverters().clear();
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		String jsonElasticUrl = restTemplate.getForObject(url, String.class);
		 //System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
		return jsonElasticUrl;
	}

	@RequestMapping(value = "/ElasticAPI/callReport")
	public @ResponseBody String callMsReport(@RequestParam("id") String id)
			throws MalformedURLException, URISyntaxException {
		RestTemplate restTemplate=new RestTemplate();
		String callMsURL ="https://yamuna-1.globalhuntindia.com:8983/solr/callms_shard1_replica2/select?q=accountid:"+id+"&fl=id,parentname,accountname,createdusername,modifiedusername,duration,action,parentid,parenttype,status,direction,device,startdate,createdby,modifiedby,anchorname,createddate,lastmodifieddate,accountid,number,anchorid&start=0&rows=100&omitHeader=true&wt=json&indent=true";
		//System.out.println("Only callMsURL >> " + callMsURL);
		URL url = new URL(callMsURL);
		String nullFragment = null;
		URI u = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(),
				url.getQuery(), nullFragment);
		 System.out.println("callms uuuuu >> "+u);
		
		restTemplate.getMessageConverters().clear();
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

		String jsonDataCall = restTemplate.getForObject(u, String.class);
		 //System.out.println("jsonDataCall >> "+jsonDataCall);
		return jsonDataCall;
	}
	

	// call module behalf of Id
	@RequestMapping(value = "/ElasticAPI/call")
	public @ResponseBody String callES(@RequestParam("callId") String callId) {
		RestTemplate restTemplate=new RestTemplate();
		//String callUrl = Getvalue.getCallDataIndexES()+"/_search?q=callId:"+callId+"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
		String callUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=callId:"+callId+"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
		System.out.println("ESURL calldataindex data callId >> " + callUrl);
		restTemplate.getMessageConverters().clear();
		restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		String jsonCallEs = restTemplate.getForObject(callUrl, String.class);
		// System.out.println("JsonCallES URL Data "+jsonCallEs);
		return jsonCallEs;

	}
	
	//Advanced Search for MailModule
		@RequestMapping(value = "/ElasticAPI/search")
		public @ResponseBody String emailAdvanceSearch(@RequestParam("subject") String subject, @RequestParam("fromMail") String fromMail, 
				@RequestParam("toMail") String toMail, @RequestParam("ccMail") String ccMail, @RequestParam("bccMail") String bccMail,
				@RequestParam("typeId") String typeId , @RequestParam("volumeId") String volumeId, 
				@RequestParam("blobId") String blobId, @RequestParam("parentId") String parentId, 
				@RequestParam("parentType") String parentType, @RequestHeader HttpHeaders headers){
			String jsonElasticUrl ="";		
		try {
			if(subject.length()>=1){
				subject="\""+subject+"\"";
			}else{
				subject="*";
			}
			if(fromMail.length()>=1){
				//fromMail="\""+fromMail+"\"";
				fromMail=fromMail;
			}else{
				fromMail="*";
			}
			if(toMail.length()>=1){
				//toMail="\""+toMail+"\"";
				toMail=toMail;
				}
			else{
				toMail="*";
			}
			if(ccMail.length()>=1){
				ccMail=ccMail;
			}else{
				ccMail="*";
			}
			if(bccMail.length()>=1){
				bccMail=bccMail;
			}else{
				bccMail="*";
			}
			if(bccMail.length()>=1){
				bccMail=bccMail;
			}else{
				bccMail="*";
			}
			if (typeId.length()>=1) {
				typeId="\""+typeId+"\"";
			}else{
				typeId="*";
			}if (volumeId.length()>=1) {
				volumeId="\""+volumeId+"\"";
			}else{
				volumeId="*";
			}if (blobId.length()>=1) {
				blobId="\""+blobId+"\"";
			}else {
				blobId="*";
			}if(parentId.length()>=1){
				parentId="\""+parentId+"\"";
			}else{
				parentId="*";
			}if (parentType.length()>=1) {
				parentType="\""+parentType+"\"";
			}else{
				parentType="*";
			}
			
			//String urlEmail2=null;
			//subject=subject.toLowerCase();
			/*fromMail=fromMail.toLowerCase();
			toMail=toMail.toLowerCase();
			ccMail=ccMail.toLowerCase();
			bccMail=bccMail.toLowerCase();
			//sentDate=sentDate.toLowerCase();
			typeId=typeId.toLowerCase();
			volumeId=volumeId.toLowerCase();s	
			blobId=blobId.toLowerCase();
			parentId=parentId.toLowerCase();
			parentType=parentType.toLowerCase();*/
			
			//if (fromMail.contains("@") || fromMail.contains("%40") || toMail.contains("@") || toMail.contains("%40") || ccMail.contains("@") || ccMail.contains("%40") || bccMail.contains("@") || bccMail.contains("%40")) {
			//fromMail=URLEncoder.encode(fromMail, "UTF-8");
			/*toMail=URLEncoder.encode(toMail, "UTF-8");
			ccMail=URLEncoder.encode(ccMail, "UTF-8");
			bccMail=URLEncoder.encode(bccMail, "UTF-8");
			*/
			
			/* if (!headers.containsKey("authorization")) {
			  System.out.println("No Authentication"); return
			  "{\"error\":\"Please Provide The Authentication\"}"; } String
			 authString = headers.getFirst("authorization"); if
			 (!restService.isUserAuthenticated(authString)) {
			  System.out.println("Wrong Authentication....."); return
			  "{\"error\":\"User not authenticated\"}"; }
			 */
			RestTemplate restTemplate=new RestTemplate();
			//String urlEmail2 = rootconfig.getEmaildataindex1()+"/_search?q=(subject:"+subject+")OR(fromMail:"+URLEncoder.encode(fromMail, "UTF-8")+")OR(toMail:"+URLEncoder.encode(toMail, "UTF-8")+")OR(ccMail:"+URLEncoder.encode(ccMail, "UTF-8")+")OR(bccMail:"+URLEncoder.encode(bccMail, "UTF-8")+")OR(typeId:"+typeId+")OR(volumeId:"+volumeId+")OR(blobId:"+blobId+")OR(parentId:"+parentId+")OR(parentType:"+parentType+")&size=10&from=0&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType,emlFile"; 
			String urlEmail2 ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=(subject:"+subject+")OR(fromMail:"+URLEncoder.encode(fromMail, "UTF-8")+")OR(toMail:"+URLEncoder.encode(toMail, "UTF-8")+")OR(ccMail:"+URLEncoder.encode(ccMail, "UTF-8")+")OR(bccMail:"+URLEncoder.encode(bccMail, "UTF-8")+")OR(typeId:"+typeId+")OR(volumeId:"+volumeId+")OR(blobId:"+blobId+")OR(parentId:"+parentId+")OR(parentType:"+parentType+")&size=10&from=0&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";//,emlFile
			System.out.println("URL for Advanced Search :: "+urlEmail2);
			 jsonElasticUrl = restTemplate.getForObject(urlEmail2, String.class);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return jsonElasticUrl;

	 }
		
/////////////////////////
	@RequestMapping(value = "/ElasticAPI/key")
	public @ResponseBody String elastiMethod(@RequestParam("data") String data, @RequestParam("module") String module,
			@RequestParam("next") Integer next
	/* ,@RequestHeader HttpHeaders headers */) {

		try {
			RestTemplate restTemplate = new RestTemplate();
			String jsonElasticUrl = "";

			/*
			 * if (!headers.containsKey("authorization")) {
			 * System.out.println("No Authentication"); return
			 * "{\"error\":\"Please Provide The Authentication\"}"; } String
			 * authString = headers.getFirst("authorization"); if
			 * (!restService.isUserAuthenticated(authString)) {
			 * System.out.println("Wrong Authentication....."); return
			 * "{\"error\":\"User not authenticated\"}"; }
			 */

			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// specific field query
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=blobId:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// Any field query
			// int start = perPage * (next - 1);
			data = data.toLowerCase();
			module = module.toLowerCase();
			if (module.equals("emaildataindex1")) {
				//int start = 50 * (next - 1);
				int start = 50 * (next);
				String url = "";
				if (data.contains("@") || data.contains("%40")) {
					// data = data.replaceAll("@", "%40");
					data = URLEncoder.encode(data, "UTF-8");

					// url = rootconfig.getEmaildataindex1()+"/_search?q=toMail:"+data+" OR ccMail:"+data+" OR fromMail:"+data+" OR bccMail:"+data+"&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
					url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=toMail:"+data+" OR ccMail:"+data+" OR fromMail:"+data+" OR bccMail:"+data+"&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; // ,emlFile"
					System.out.println("Email URL:::>>" + url);

				}
				// Exact Working behalf of done
				/*
				  else if(data.contains("candidates")){ 
				 url =rootconfig.getEmaildataindex1()+"/_search?q=parentType:\""+ data+ "\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
 					System.out.println("parentType candidates  URL:::>>" + url);
				  } else if(data.contains("candidate")){ 
				  url =rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
 					System.out.println("typeId candidate URL:::>>" +url); }
 					else if(data.contains("hitech")){ 
 					url = rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				 System.out.println("typeId hitech URL:::>>" +url); }
				 else if(data.contains("internal")){ 
				 url =rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				  System.out.println(" typeId internal URL:::>>" +url); }
				  else if(data.contains("job")){ 
				  url =rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				System.out.println("typeId job URL:::>>" + url);
				 }else if(data.contains("lead")){ 
				 url =rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				 System.out.println("typeId lead URL:::>>" + url);
				 }else if(data.contains("other")){
				  url =rootconfig.getEmaildataindex1()+"/_search?q=typeId:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				System.out.println("typeId other URL:::>>" + url);
				}else if(data.contains("contacts")){ 
				url =rootconfig.getEmaildataindex1()+"/_search?q=parentType:\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
				 System.out.println("parentType contacts URL:::>>"+ url); }
				 */

				else {
					url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=\""+data+"\"&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; // ,emlFile
					System.out.println("except email URL:::::>> " + url);
				}

				// data=data.replace(" ", "");
				System.out.println("data::::" + data);
				/*
				 * if (data.contains(":")) { data = data.replaceAll(":", "%3A");
				 * }
				 */
				// String url ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType,emlFile";

				// url = rootconfig.getEmaildataindex1()+"/_search?q="+URLEncoder.encode(data,"UTF-8")+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile

				jsonElasticUrl = restTemplate.getForObject(url, String.class);
				// System.out.println(" emaildataindex JSON Data >> "+jsonElasticUrl);
				
				return jsonElasticUrl;
			}

			if (module.equals("calldataindex")) {
				int start = 100 * (next);
				if (data.contains("@")) {
					data = data.replaceAll("@", "%40");
				}
				
				/*  if (data.contains(":")) { data = data.replaceAll(":", "%3A");
				  }*/
				 
				//data = URLEncoder.encode(data, "UTF-8");

				// String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=%3A%22"+data+"%22%3A&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
				// \""+data+"\"
				// String url = Getvalue.getCallDataIndexES()+"/_search?q=\""+data+"\"&size=100&from="+start+"&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
				String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=\""+data+"\"&size=100&from="+start+"&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
				System.out.println("ESURL calldataindex Data anyparam >> " + url);

				jsonElasticUrl = restTemplate.getForObject(url, String.class);
				// System.out.println("calldataindex JSON Data >>
				return jsonElasticUrl;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	@RequestMapping(value="/ElasticAPI/emaildata")
	public @ResponseBody String emailDataPagination(@RequestParam("data")String data, @RequestParam("type")String type, 
			@RequestParam("next")Integer next/*, @RequestHeader HttpHeaders headers*/) throws UnsupportedEncodingException{
		try{
			/*if (!headers.containsKey("authorization")) {
				System.out.println("No Authentication");
				return "{\"error\":\"Please Provide The Authentication\"}";
			}
			String authString = headers.getFirst("authorization");
			if (!restService.isUserAuthenticated(authString)) {
				System.out.println("Wrong Authentication.....");
				return "{\"error\":\"User not authenticated\"}";
			}*/
			
			RestTemplate restTemplate=new RestTemplate();
			String jsonElasticUrl="";
				
				int start = 50 * (next);
				String url="";
			
					data = data.toLowerCase();
					type = type.toLowerCase();
					//type = URLEncoder.encode(type, "UTF-8");
					//data = data.replaceAll("@", "%40");
					data=URLEncoder.encode(data, "UTF-8");
				if(type.equals("hitech")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("candidate")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("internal")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("job")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("lead")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("other")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(typeId:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}
				if(type.equals("contacts")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(parentType:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}if(type.equals("candidates")){
	                 url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=("+data+")AND(parentType:"+type.toLowerCase()+")&size=50&from="+start+"&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType"; //,emlFile
				}
					 System.out.println("Email URL:::>>" + url);
				// String url ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=\""+data+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType,emlFile";
				
			    jsonElasticUrl = restTemplate.getForObject(url, String.class);
				// System.out.println(" emaildataindex JSON Data >> "+jsonElasticUrl);
				return jsonElasticUrl;
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
					
		return null;
		
	}
	
	
	@RequestMapping(value = "/ElasticAPI/bloburl")
	public @ResponseBody String blobIdSearch(@RequestParam("blobId") String blobId ) {
		try {

			RestTemplate restTemplate=new RestTemplate();
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// specific field query
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=blobId:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// Any field query
			if (blobId.contains("@")) {
				blobId = blobId.replaceAll("@", "%40");
			}

			if (blobId.contains(":")) {
				blobId = blobId.replaceAll(":", "%3A");
			}

			String url ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=blobId:"+blobId+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType,emlFile";
			System.out.println("ESURL emaildataindex Data blobId  >> " + url);

			String jsonElasticUrl = restTemplate.getForObject(url, String.class);
			// System.out.println("jsonURL ElasticSearch Data >>
			// "+jsonElasticUrl);
			// String jsonDataOffer=restTemplate.postForObject(offerMsURL,
			// "http://localhost:8080/HitechReport/attachjid?jobid=66c5c563-7167-4e43-8f82-417196e1ea15",
			// String.class);
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	////////////
	// ExactSearch for Subject
	@RequestMapping(value = "/ElasticAPI/suburl")
	public @ResponseBody String subjectSearch(@RequestParam("subject") String subject) {
		try {//
			RestTemplate restTemplate=new RestTemplate();
			String url = null;
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// specific field query
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=blobId:"+name+"&size=1&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// Any field query
			if (subject.contains("@")) {
				subject = subject.replaceAll("@", "%40");
			}
			if (subject.contains(":")) {
				subject = subject.replaceAll(":", "%3A");
			}
			if (subject.contains("'")) {
				subject = subject.replaceAll("''", "%27");
			}
			if (subject.contains("(") || subject.contains(")")) {
				subject = subject.replaceAll("(", "%28");
				subject = subject.replaceAll(")", "%29");
			}
			if (subject.contains("||")) {
				subject = subject.replaceAll("||", "%7C%7C");
			}

			if (subject.contains(" ")) {
				subject = subject.replaceAll(" ", "+");
			}
			if (subject.contains("Re:")) {
				subject.replaceAll("RE:", "Re%3A");
			}
			if (subject.contains(": ")) {
				subject.replaceAll(": ", "%3A+");
			}
			if (subject.contains(" ")) {
				subject = subject.replaceAll(" ", "%20");
			}

			// subject.toLowerCase();
			// String urlForDotnet=rootconfig.getResumeDataLive()+"/select?q=candidate_name : +\""+canName+"\"~1&fl=id,candidate_name,DesignationText,TotalExp,PresentEmployer,PresentCTC,SkillsText,current_work_loc,graduate,postgraduate,empId,ugYear,pgYear,previousEmployer,previousDesig&wt=json&omitHeader=true&indent=true&rows=5";
			// url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=subject:+\""+subject+"\"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";

			url ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=subject:"+subject+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			System.out.println("ESURL emaildataindex Data subject >> " + url);

			String jsonElasticUrl = restTemplate.getForObject(url, String.class);
			// System.out.println("jsonURL ElasticSearch Data >>"+jsonElasticUrl);
			
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	

	@RequestMapping(value = "/ElasticAPI/call2", method = { RequestMethod.GET })
	public @ResponseBody String callES2(@RequestParam("userName") String userName) {
		RestTemplate restTemplate=new RestTemplate();

		// String callUrl2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=userName:+"+userName+"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
		String callUrl2 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=userName:+\""
				+ userName
				+ "\"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
		System.out.println("ESURL calldataindex Data userName >> " + callUrl2);
		String jsonCall2Es = restTemplate.getForObject(callUrl2, String.class);
		// System.out.println("jsonCall2Es DATA >> "+jsonCall2Es);
		return jsonCall2Es;
	}

	@RequestMapping(value = "/ElasticAPI/call3", method = { RequestMethod.GET })
	public @ResponseBody String callESMulti(@RequestParam("userName")String userName, @RequestParam("direction")String direction) {

		RestTemplate restTemplate=new RestTemplate();
		// String callUrl2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=userName:+"+userName+"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";

		String callUrl3 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q=userName:\""
				+ userName + "\" AND direction:\"" + direction
				+ "\"&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";
		System.out.println("ESURL calldataindex Data userName,direction>> " + callUrl3);
		String jsonCall3Es = restTemplate.getForObject(callUrl3, String.class);
		// System.out.println("jsonCall2Es DATA >> "+jsonCall3Es);
		return jsonCall3Es;
	}

	// one param email
	@RequestMapping(value = "/ElasticAPI/fsearch")
	public @ResponseBody String fullTextSearch(@RequestParam("toMail") String toMail) {
		try {
			RestTemplate restTemplate=new RestTemplate();

			if (toMail.contains("@") || toMail.contains("%40")) {
				toMail = toMail.replaceAll("%40", "@");
				toMail = toMail.replaceAll("@", "@");
				System.out.println("toMail >> " + toMail);
			}

			String url = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=toMail:"
					+ toMail
					+ "&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q="+toMail+" &size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String emailMsURL= rootconfig.getEmailMS_shardUrl()+"/select?q=mailfromaddress:"+emailID+"OR mailtoaddress:"+emailID+"&fl=id,namec,sentdate,lastmodifieddate,parenttype,mailfromaddress,mailtoaddress,parentid,anchorname,modifiedby,createdby,subject&start=0&rows=100&omitHeader=true&wt=json&indent=true&sort="+sort;
			URL urlEmail = new URL(url);
			String nullFragment = null;
			URI uEmail = new URI(urlEmail.getProtocol(), urlEmail.getUserInfo(), urlEmail.getHost(), urlEmail.getPort(),
					urlEmail.getPath(), urlEmail.getQuery(), nullFragment);
			System.out.println("ESURL emaildataindex Data toMail >> " + uEmail);
			String jsonElasticUrl = restTemplate.getForObject(uEmail, String.class);
			// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	// two param email
	@RequestMapping(value = "/ElasticAPI/email2", method = { RequestMethod.GET })
	public @ResponseBody String emailTwoParm(@RequestParam("fromMail") String fromMail, @RequestParam("toMail") String toMail) {
		try {

			RestTemplate restTemplate=new RestTemplate();
			if (fromMail.contains("@")) {
				fromMail = fromMail.replaceAll("@", "%40");
			}
			if (toMail.contains("@")) {
				toMail = toMail.replaceAll("@", "%40");
			}
			String urlEmail2 ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=fromMail:"
					+ fromMail + " AND toMail:" + toMail
					+ "&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			URL urlEmail = new URL(urlEmail2);
			String nullFragment = null;
			URI uriEmail = new URI(urlEmail.getProtocol(), urlEmail.getUserInfo(), urlEmail.getHost(),
					urlEmail.getPort(), urlEmail.getPath(), urlEmail.getQuery(), nullFragment);
			System.out.println("ESURL emaildataindex Data fromMail,toMail  >> " + uriEmail);
			String jsonElasticUrl = restTemplate.getForObject(uriEmail, String.class);
			// System.out.println("jsonURL ElasticSearch email2Data >> "+jsonElasticUrl);
			return jsonElasticUrl;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;

	}

	// onl OR Condition

	@RequestMapping(value = "/ElasticAPI/textor")
	public @ResponseBody String textOrValue(@RequestParam("fieldtext") String fieldtext, @RequestParam("fieldvalue") String fieldvalue) {
		try {
			RestTemplate restTemplate=new RestTemplate();
			
			if (fieldtext.contains("@")) {
				fieldtext = fieldtext.replaceAll("@", "%40");
			}

			if (fieldtext.contains("@")) {
				fieldtext = fieldtext.replaceAll("@", "%40");
			}

			if (fieldtext.contains(":")) {
				fieldtext = fieldtext.replaceAll(":", "%3A");
			}

			// String rooturl= rootconfig.getResumeDataLocal()+"/select?q=(job_id:"+jobid+")AND(ree_resume_id_c:"+resumeid+") &fl=parent_id,date_created,created_by,field_name,after_value_text,modifiedby,columnname,job_id,ree_resume_id_c&start=0&rows=100&omitHeader=true&wt=json&indent=true";
			// String url="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=toMail:"+fieldtext+"AND fromMail:"+fieldtext+"AND sentDate:"+fieldtext+"AND parentId:"+fieldtext+"AND parentType:"+fieldtext+"AND typeId:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";

			// all url working fine.... below..

			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=toMail:"+fieldtext+" AND fromMail:"+fieldtext+" AND ccMail:"+fieldtext+" AND bccMail:"+fieldtext+" AND sentDate:"+fieldtext+" AND parentId:"+fieldtext+" AND parentType:"+fieldtext+" AND typeId:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+fieldtext+" AND toMail:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+fieldtext+" OR toMail:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			String urlEmail2 ="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q=subject:"
					+ fieldtext + " OR fromMail:" + fieldtext + " OR toMail:" + fieldtext + " OR ccMail:" + fieldtext
					+ " OR bccMail:" + fieldtext + " OR sentDate:" + fieldtext + " OR typeId:" + fieldtext
					+ " OR volumeId:" + fieldtext + " OR blobId:" + fieldtext + " OR parentId:" + fieldtext
					+ "OR parentType:" + fieldtext
					+ "&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q="+fieldtext+":"+fieldvalue+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";

			System.out.println("ESURL emaildataindex Data or >> " + urlEmail2);

			URL urlEmail = new URL(urlEmail2);
			String nullFragment = null;
			URI uEmail = new URI(urlEmail.getProtocol(), urlEmail.getUserInfo(), urlEmail.getHost(), urlEmail.getPort(),
					urlEmail.getPath(), urlEmail.getQuery(), nullFragment);

			String jsonElasticUrl = restTemplate.getForObject(uEmail, String.class);
			// System.out.println("jsonURL ElasticSearch Data >> "+jsonElasticUrl);
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;

	}

	// Dynamic fieldText and tieldvalue (key & value) both are API

	@RequestMapping(value = "/ElasticAPI/keyvalue")
	public @ResponseBody String dynamicKeyValueEmail(@RequestParam("keytext")String keytext, @RequestParam("valuetext")String valuetext) {
		try {

			RestTemplate restTemplate=new RestTemplate();

			if (keytext.contains("@")) {
				keytext = keytext.replaceAll("@", "%40");
			}
			if (valuetext.contains("@")) {
				valuetext = valuetext.replaceAll("@", "%40");
			}

			if (keytext.contains(":") || valuetext.contains(":")) {
				keytext = keytext.replaceAll(":", "%3A");
				valuetext = valuetext.replaceAll(":", "%3A");
			}

			// all url working fine.... below..

			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=toMail:"+fieldtext+" AND fromMail:"+fieldtext+" AND ccMail:"+fieldtext+" AND bccMail:"+fieldtext+" AND sentDate:"+fieldtext+" AND parentId:"+fieldtext+" AND parentType:"+fieldtext+" AND typeId:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+fieldtext+" AND toMail:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			
			String urlEmail2 = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex1/_search?q="
					+ keytext + ":" + valuetext
					+ "&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";

			System.out.println("ESURL emaildataindex dynamicQue Data keytext,valuetext >> " + urlEmail2);

			URL urlEmail = new URL(urlEmail2);
			String nullFragment = null;
			URI uEmail = new URI(urlEmail.getProtocol(), urlEmail.getUserInfo(), urlEmail.getHost(), urlEmail.getPort(),
					urlEmail.getPath(), urlEmail.getQuery(), nullFragment);

			String jsonElasticUrl = restTemplate.getForObject(uEmail, String.class);
			// System.out.println("jsonURL ElasticSearch DynamicData >>
			// "+jsonElasticUrl);
			// String jsonDataOffer=restTemplate.postForObject(offerMsURL,
			// "http://localhost:8080/HitechReport/attachjid?jobid=66c5c563-7167-4e43-8f82-417196e1ea15",
			// String.class);
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;

	}
//ok test
	@RequestMapping(value = "/ElasticAPI/keyvalcall")
	public @ResponseBody String dynamicKeyValueCall(@RequestParam("keytext")String keytext,@RequestParam("valuetext")String valuetext) {
		try {

			RestTemplate restTemplate=new RestTemplate();

			if (keytext.contains("@")) {
				keytext = keytext.replaceAll("@", "%40");
			}
			if (valuetext.contains("@")) {
				valuetext = valuetext.replaceAll("@", "%40");
			}

			if (keytext.contains(":") || valuetext.contains(":")) {
				keytext = keytext.replaceAll(":", "%3A");
				valuetext = valuetext.replaceAll(":", "%3A");
			}

			// all url working fine.... below..

			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=toMail:"+fieldtext+" AND fromMail:"+fieldtext+" AND ccMail:"+fieldtext+" AND bccMail:"+fieldtext+" AND sentDate:"+fieldtext+" AND parentId:"+fieldtext+" AND parentType:"+fieldtext+" AND typeId:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q=fromMail:"+fieldtext+" AND toMail:"+fieldtext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			// String urlEmail2="https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/emaildataindex/_search?q="+keytext+":"+valuetext+"&size=10&from=0&pretty=true&_source=subject,fromMail,toMail,ccMail,bccMail,sentDate,typeId,volumeId,blobId,parentId,parentType";
			String callUrlDynamic = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/calldataindex/_search?q="
					+ keytext + ":" + valuetext
					+ "&size=10&from=0&pretty=true&_source=id,callId,fromNumber,toNumber,userName,startTime,duration,parentId,parentName,parentType,callType,direction,device";

			System.out.println("ESURL calldataindex dynamicQue Data keytext,valuetext >> " + callUrlDynamic);

			URL urlCall = new URL(callUrlDynamic);
			String nullFragment = null;
			URI uCall = new URI(urlCall.getProtocol(), urlCall.getUserInfo(), urlCall.getHost(), urlCall.getPort(),
					urlCall.getPath(), urlCall.getQuery(), nullFragment);

			String jsonElasticUrl = restTemplate.getForObject(uCall, String.class);
			// System.out.println("jsonURL ElasticSearch DynamicData >>
			// "+jsonElasticUrl);
			// String jsonDataOffer=restTemplate.postForObject(offerMsURL,
			// "http://localhost:8080/HitechReport/attachjid?jobid=66c5c563-7167-4e43-8f82-417196e1ea15",
			// String.class);
			return jsonElasticUrl;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
   }
}


