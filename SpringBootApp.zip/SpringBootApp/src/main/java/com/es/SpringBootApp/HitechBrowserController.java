package com.es.SpringBootApp;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import ch.qos.logback.core.net.SyslogOutputStream;

@RestController
public class HitechBrowserController {
	RestTemplate restTemplate = new RestTemplate();
	
	
//	  AttachData
	 
	
	@RequestMapping(value = "/ElasticAPI/attachData", method = { RequestMethod.GET })
	public @ResponseBody String getAttachData(@RequestParam("objectId") String objectId) throws JSONException {

		String urlAttach = "";

		urlAttach = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/attach/_search?q=(objectId:\""
				+ objectId + "\")";// ,resumeName,resume

		System.out.println("url :: " + urlAttach);

		String attachdata = restTemplate.getForObject(urlAttach, String.class);

		JSONObject mainjson = new JSONObject();

		JSONArray jsonArray = new JSONArray();

		JSONObject jsonAttach = new JSONObject(attachdata);
		JSONObject hits = jsonAttach.getJSONObject("hits");

		JSONArray hitsArr = hits.getJSONArray("hits");

		for (int i = 0; i < hitsArr.length(); i++) {

			JSONObject map = new JSONObject();

			JSONObject arrobj = (JSONObject) hitsArr.get(i);
			JSONObject arrobj1 = arrobj.getJSONObject("_source");

			if (arrobj1.has("id"))
				map.put("id", arrobj1.get("id"));
			else
				map.put("id", JSONObject.NULL);

			if (arrobj1.has("objectId"))
				map.put("objectId", arrobj1.get("objectId"));
			else
				map.put("objectId", JSONObject.NULL);

			if (arrobj1.has("jobId"))
				map.put("jobId", arrobj1.get("jobId"));
			else
				map.put("jobId", JSONObject.NULL);

			if (arrobj1.has("jobName"))
				map.put("jobName", arrobj1.get("jobName"));
			else
				map.put("jobName", JSONObject.NULL);

			if (arrobj1.has("clientId"))
				map.put("clientId", arrobj1.get("clientId"));
			else
				map.put("clientId", JSONObject.NULL);

			if (arrobj1.has("clientName"))
				map.put("clientName", arrobj1.get("clientName"));
			else
				map.put("clientName", JSONObject.NULL);

			if (arrobj1.has("contactId"))
				map.put("contactId", arrobj1.get("contactId"));
			else
				map.put("contactId", JSONObject.NULL);

			if (arrobj1.has("contactName"))
				map.put("contactName", arrobj1.get("contactName"));
			else
				map.put("contactName", JSONObject.NULL);

			if (arrobj1.has("attachedBy"))
				map.put("attachedBy", arrobj1.get("attachedBy"));
			else
				map.put("attachedBy", JSONObject.NULL);

			if (arrobj1.has("lastModifiedBy"))
				map.put("lastModifiedBy", arrobj1.get("lastModifiedBy"));
			else
				map.put("lastModifiedBy", JSONObject.NULL);

			if (arrobj1.has("lastModified"))
				map.put("lastModified", arrobj1.get("lastModified"));
			else
				map.put("lastModified", JSONObject.NULL);

			if (arrobj1.has("createdDate"))
				map.put("createdDate", arrobj1.get("createdDate"));
			else
				map.put("createdDate", JSONObject.NULL);

			if (arrobj1.has("anchor"))
				map.put("anchor", arrobj1.get("anchor"));
			else
				map.put("anchor", JSONObject.NULL);

			if (arrobj1.has("federated"))
				map.put("federated", arrobj1.get("federated"));
			else
				map.put("federated", JSONObject.NULL);

			if (arrobj1.has("cvSentDate"))
				map.put("cvSentDate", arrobj1.get("cvSentDate"));
			else
				map.put("cvSentDate", JSONObject.NULL);

			if (arrobj1.has("statusChangeDate"))
				map.put("statusChangeDate", arrobj1.get("statusChangeDate"));
			else
				map.put("statusChangeDate", JSONObject.NULL);

			if (arrobj1.has("statusOutcome"))
				map.put("statusOutcome", arrobj1.get("statusOutcome"));
			else
				map.put("statusOutcome", JSONObject.NULL);

			if (arrobj1.has("changeReason"))
				map.put("changeReason", arrobj1.get("changeReason"));
			else
				map.put("changeReason", JSONObject.NULL);

			if (arrobj1.has("clientPortalStatus"))
				map.put("clientPortalStatus", arrobj1.get("clientPortalStatus"));
			else
				map.put("clientPortalStatus", JSONObject.NULL);

			if (arrobj1.has("clientSheetStatus"))
				map.put("clientSheetStatus", arrobj1.get("clientSheetStatus"));
			else
				map.put("clientSheetStatus", JSONObject.NULL);

			if (arrobj1.has("paTestScore"))
				map.put("paTestScore", arrobj1.get("paTestScore"));
			else
				map.put("paTestScore", JSONObject.NULL);

			if (arrobj1.has("testScore"))
				map.put("testScore", arrobj1.get("testScore"));
			else
				map.put("testScore", JSONObject.NULL);

			if (arrobj1.has("avgScore"))
				map.put("avgScore", arrobj1.get("avgScore"));
			else
				map.put("avgScore", JSONObject.NULL);

			if (arrobj1.has("pageUpId"))
				map.put("pageUpId", arrobj1.get("pageUpId"));
			else
				map.put("pageUpId", JSONObject.NULL);

			if (arrobj1.has("isClientSheet"))
				map.put("isClientSheet", arrobj1.get("isClientSheet"));
			else
				map.put("isClientSheet", JSONObject.NULL);

			if (arrobj1.has("ghStatus"))
				map.put("ghStatus", arrobj1.get("ghStatus"));
			else
				map.put("ghStatus", JSONObject.NULL);

			if (arrobj1.has("ghStatusId"))
				map.put("ghStatusId", arrobj1.get("ghStatusId"));
			else
				map.put("ghStatusId", JSONObject.NULL);

			if (arrobj1.has("statusId"))
				map.put("statusId", arrobj1.get("statusId"));
			else
				map.put("statusId", JSONObject.NULL);

			if (arrobj1.has("status"))
				map.put("status", arrobj1.get("status"));
			else
				map.put("status", JSONObject.NULL);

			if (arrobj1.has("dropComment"))
				map.put("dropComment", arrobj1.get("dropComment"));
			else
				map.put("dropComment", JSONObject.NULL);

			if (arrobj1.has("comment"))
				map.put("comment", arrobj1.get("comment"));
			else
				map.put("comment", JSONObject.NULL);

			if (arrobj1.has("withOutId"))
				map.put("withOutId", arrobj1.get("withOutId"));
			else
				map.put("withOutId", JSONObject.NULL);

			if (arrobj1.has("resumeName"))
				map.put("resumeName", arrobj1.get("resumeName"));
			else
				map.put("resumeName", JSONObject.NULL);

			jsonArray.put(map);

		}

		mainjson.put("total", hits.get("total"));
		mainjson.put("response", jsonArray);

		return mainjson.toString();
	}

	
//	  on behalf of email & federated Candidate
	 
	@RequestMapping(value = "/ElasticAPI/candiemailfed&fedrated", method = { RequestMethod.GET })
	public @ResponseBody String getCandidateData(@RequestParam("email") String EmailId,
			@RequestParam("federated") String federated)
			throws JSONException, URISyntaxException, MalformedURLException {

		JSONObject candijson = new JSONObject();

		String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(email:\""
				+ EmailId + "\")AND(federated:\"" + federated + "\")";

		System.out.println("url :: " + candidateUrl);

		URL urlcandiateProfile = new URL(candidateUrl);

		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateUrl);
		String jsonCandidateData = "";
		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

		JSONObject jsonAttach = new JSONObject(jsonCandidateData);
		JSONObject hits = jsonAttach.getJSONObject("hits");

		JSONArray hitsArr = hits.getJSONArray("hits");

		for (int k = 0; k < hitsArr.length(); k++) {

			JSONObject arrobj = (JSONObject) hitsArr.get(k);
			JSONObject arrObj1 = arrobj.getJSONObject("_source");
			if (arrObj1.has("id"))
				candijson.put("id", arrObj1.getString("id"));
			else 
				candijson.put("id", JSONObject.NULL);
			
			if (arrObj1.has("name"))
				candijson.put("name", arrObj1.getString("name"));
			else
				candijson.put("name", JSONObject.NULL);

			if (arrObj1.has("first_name"))
				candijson.put("first_name", arrObj1.getString("first_name"));
			else
				candijson.put("first_name", JSONObject.NULL);

			if (arrObj1.has("middle_name"))
				candijson.put("middle_name", arrObj1.getString("middle_name"));
			else
				candijson.put("middle_name", JSONObject.NULL);

			if (arrObj1.has("last_name"))
				candijson.put("last_name", arrObj1.getString("last_name"));
			else
				candijson.put("last_name", JSONObject.NULL);

			if (arrObj1.has("username"))
				candijson.put("username", arrObj1.getString("username"));
			else
				candijson.put("username", JSONObject.NULL);

			if (arrObj1.has("email"))
				candijson.put("email", arrObj1.getString("email"));
			else
				candijson.put("email", JSONObject.NULL);

			if (arrObj1.has("alternateEmail"))
				candijson.put("alternateEmail", (JSONArray) arrObj1.get("alternateEmail"));
			else
				candijson.put("alternateEmail", JSONObject.NULL);

			if (arrObj1.has("birthdate"))
				candijson.put("birthdate", arrObj1.getString("birthdate"));
			else
				candijson.put("birthdate", JSONObject.NULL);

			if (arrObj1.has("age"))
				candijson.put("age", arrObj1.getInt("age"));
			else
				candijson.put("age", JSONObject.NULL);

			if (arrObj1.has("gender"))
				candijson.put("gender", arrObj1.getString("gender"));
			else
				candijson.put("gender", JSONObject.NULL);

			if (arrObj1.has("picture"))
				candijson.put("picture", arrObj1.get("picture"));
			else
				candijson.put("picture", JSONObject.NULL);

			if (arrObj1.has("profile"))
				candijson.put("profile", arrObj1.getString("profile"));
			else
				candijson.put("profile", JSONObject.NULL);

			if (arrObj1.has("mobileNumber"))
				candijson.put("mobileNumber", arrObj1.getString("mobileNumber"));
			else
				candijson.put("mobileNumber", JSONObject.NULL);

			if (arrObj1.has("alternateMobileNumber"))
				candijson.put("alternateMobileNumber", (JSONArray) arrObj1.get("alternateMobileNumber"));
			else
				candijson.put("alternateMobileNumber", JSONObject.NULL);

			if (arrObj1.has("officePhone"))
				candijson.put("officePhone", arrObj1.getString("officePhone"));
			else
				candijson.put("officePhone", JSONObject.NULL);

			if (arrObj1.has("officePhoneExtention"))
				candijson.put("officePhoneExtention", arrObj1.getString("officePhoneExtention"));
			else
				candijson.put("officePhoneExtention", JSONObject.NULL);

			if (arrObj1.has("isMobileNumberVerified"))
				candijson.put("isMobileNumberVerified", (Boolean) arrObj1.get("isMobileNumberVerified"));
			else
				candijson.put("isMobileNumberVerified", JSONObject.NULL);

			if (arrObj1.has("religion"))
				candijson.put("religion", arrObj1.getString("religion"));
			else
				candijson.put("religion", JSONObject.NULL);

			if (arrObj1.has("maritalStatus"))
				candijson.put("maritalStatus", arrObj1.getString("maritalStatus"));
			else
				candijson.put("maritalStatus", JSONObject.NULL);

			if (arrObj1.has("federated"))
				candijson.put("federated", arrObj1.getString("federated"));
			else
				candijson.put("federated", JSONObject.NULL);


			if (arrObj1.has("address")) {
				
				JSONObject addressJson1 = null;
				JSONObject addressJson = (JSONObject) arrObj1.get("address");

				if (addressJson.has("permanentAddress")) {

					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("permanentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("permanentAddress", addressJ);
				}

				if (addressJson.has("currentAddress")) {
					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("currentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("currentAddress", addressJ);
				}
			} else
				candijson.put("address", JSONObject.NULL);

			if (arrObj1.has("notification")) {

				JSONObject notification = new JSONObject();
				JSONObject getnotification = (JSONObject) arrObj1.get("notification");

				if (getnotification.has("resumeDownload"))
					notification.put("resumeDownload", (Boolean) getnotification.get("resumeDownload"));
				else
					notification.put("resumeDownload", JSONObject.NULL);

				if (getnotification.has("profileViewed"))
					notification.put("profileViewed", (Boolean) getnotification.get("profileViewed"));
				else
					notification.put("profileViewed", JSONObject.NULL);

				if (getnotification.has("newJobPost"))
					notification.put("newJobPost", (Boolean) getnotification.get("newJobPost"));
				else
					notification.put("newJobPost", JSONObject.NULL);

				if (getnotification.has("recruiterConnect"))
					notification.put("recruiterConnect", (Boolean) getnotification.get("recruiterConnect"));
				else
					notification.put("recruiterConnect", JSONObject.NULL);

				if (getnotification.has("google"))
					notification.put("google", (Boolean) getnotification.get("google"));
				else
					notification.put("google", JSONObject.NULL);

				if (getnotification.has("twitter"))
					notification.put("twitter", (Boolean) getnotification.get("twitter"));
				else
					notification.put("twitter", JSONObject.NULL);

				if (getnotification.has("linkedIn"))
					notification.put("linkedIn", (Boolean) getnotification.get("linkedIn"));
				else
					notification.put("linkedIn", JSONObject.NULL);

				if (getnotification.has("facebook"))
					notification.put("facebook", (Boolean) getnotification.get("facebook"));
				else
					notification.put("facebook", JSONObject.NULL);

				candijson.put("notification", notification);
			} else
				candijson.put("notification", JSONObject.NULL);

			if (arrObj1.has("jobType"))
				candijson.put("jobType", arrObj1.getString("jobType"));
			else
				candijson.put("jobType", JSONObject.NULL);

			if (arrObj1.has("employmentType"))
				candijson.put("employmentType", arrObj1.getString("employmentType"));
			else
				candijson.put("employmentType", JSONObject.NULL);

			if (arrObj1.has("createdDate"))
				candijson.put("createdDate", arrObj1.getString("createdDate"));
			else
				candijson.put("createdDate", JSONObject.NULL);

			if (arrObj1.has("lastModified"))
				candijson.put("lastModified", arrObj1.getString("lastModified"));
			else
				candijson.put("lastModified", JSONObject.NULL);

			if (arrObj1.has("createdBy"))
				candijson.put("createdBy", arrObj1.getString("createdBy"));
			else
				candijson.put("createdBy", JSONObject.NULL);

			if (arrObj1.has("lastModifiedBy"))
				candijson.put("lastModifiedBy", arrObj1.getString("lastModifiedBy"));
			else
				candijson.put("lastModifiedBy", JSONObject.NULL);

			if (arrObj1.has("aadharCardNo"))
				candijson.put("aadharCardNo", arrObj1.getString("aadharCardNo"));
			else
				candijson.put("aadharCardNo", JSONObject.NULL);

			if (arrObj1.has("passportNo"))
				candijson.put("passportNo", arrObj1.getString("passportNo"));
			else
				candijson.put("passportNo", JSONObject.NULL);

			if (arrObj1.has("passportValidity"))
				candijson.put("passportValidity", arrObj1.getString("passportValidity"));
			else
				candijson.put("passportValidity", JSONObject.NULL);

			if (arrObj1.has("panNo"))
				candijson.put("panNo", arrObj1.getString("panNo"));
			else
				candijson.put("panNo", JSONObject.NULL);

			if (arrObj1.has("areaOfSpecialization"))
				candijson.put("areaOfSpecialization", arrObj1.getString("areaOfSpecialization"));
			else
				candijson.put("areaOfSpecialization", JSONObject.NULL);

			if (arrObj1.has("category"))
				candijson.put("category", arrObj1.getString("category"));
			else
				candijson.put("category", JSONObject.NULL);

			if (arrObj1.has("confidential"))
				candijson.put("confidential", (Boolean) arrObj1.get("confidential"));
			else
				candijson.put("confidential", JSONObject.NULL);

			if (arrObj1.has("employmentStatus"))
				candijson.put("employmentStatus", arrObj1.getString("employmentStatus"));
			else
				candijson.put("employmentStatus", JSONObject.NULL);

			if (arrObj1.has("nationality"))
				candijson.put("nationality", arrObj1.getString("nationality"));
			else
				candijson.put("nationality", JSONObject.NULL);

			if (arrObj1.has("exNationality"))
				candijson.put("exNationality", arrObj1.getInt("exNationality"));
			else
				candijson.put("exNationality", JSONObject.NULL);

			if (arrObj1.has("experiencedIndustry"))
				candijson.put("experiencedIndustry", arrObj1.getString("experiencedIndustry"));
			else
				candijson.put("experiencedIndustry", JSONObject.NULL);

			if (arrObj1.has("experiencedFunctionalArea"))
				candijson.put("experiencedFunctionalArea", arrObj1.getString("experiencedFunctionalArea"));
			else
				candijson.put("experiencedFunctionalArea", JSONObject.NULL);

			if (arrObj1.has("language"))
				candijson.put("language", arrObj1.getString("language"));
			else
				candijson.put("language", JSONObject.NULL);

			if (arrObj1.has("notes"))
				candijson.put("notes", arrObj1.getString("notes"));
			else
				candijson.put("notes", JSONObject.NULL);

			if (arrObj1.has("preferredLocation"))
				candijson.put("preferredLocation", arrObj1.getString("preferredLocation"));
			else
				candijson.put("preferredLocation", JSONObject.NULL);

			if (arrObj1.has("physicallyChallenged"))
				candijson.put("physicallyChallenged", arrObj1.getString("physicallyChallenged"));
			else
				candijson.put("physicallyChallenged", JSONObject.NULL);

			if (arrObj1.has("reasonForLeaving"))
				candijson.put("reasonForLeaving", arrObj1.getString("reasonForLeaving"));
			else
				candijson.put("reasonForLeaving", JSONObject.NULL);

			if (arrObj1.has("reasonForRelocate"))
				candijson.put("reasonForRelocate", arrObj1.getString("reasonForRelocate"));
			else
				candijson.put("reasonForRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToRelocate"))
				candijson.put("willingToRelocate", arrObj1.getString("willingToRelocate"));
			else
				candijson.put("willingToRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToChangeJob"))
				candijson.put("willingToChangeJob", arrObj1.getString("willingToChangeJob"));
			else
				candijson.put("willingToChangeJob", JSONObject.NULL);

			if (arrObj1.has("resumeHeadLine"))
				candijson.put("resumeHeadLine", arrObj1.getString("resumeHeadLine"));
			else
				candijson.put("resumeHeadLine", JSONObject.NULL);

			if (arrObj1.has("experienced"))
				candijson.put("experienced", (Boolean) arrObj1.get("experienced"));
			else
				candijson.put("experienced", JSONObject.NULL);

			if (arrObj1.has("fresher"))
				candijson.put("fresher", (Boolean) arrObj1.get("fresher"));
			else
				candijson.put("fresher", JSONObject.NULL);

			if (arrObj1.has("skillSummary"))
				candijson.put("skillSummary", arrObj1.getString("skillSummary"));
			else
				candijson.put("skillSummary", JSONObject.NULL);

			if (arrObj1.has("skills")) {
				JSONArray SkillsObj = new JSONArray();

				JSONObject getskillobject = new JSONObject();

				JSONArray skillList = (JSONArray) arrObj1.get("skills");

				for (int i = 0; i < skillList.length(); i++) {

					getskillobject = (JSONObject) skillList.get(i);
					JSONObject Skills = new JSONObject();

					if (getskillobject.has("keySkill"))
						Skills.put("keySkill", getskillobject.getString("keySkill"));
					else
						Skills.put("keySkill", JSONObject.NULL);

					if (getskillobject.has("experience"))
						Skills.put("experience", getskillobject.getString("experience"));
					else
						Skills.put("experience", JSONObject.NULL);

					if (getskillobject.has("fromMonth"))
						Skills.put("fromMonth", getskillobject.getString("fromMonth"));
					else
						Skills.put("fromMonth", JSONObject.NULL);

					if (getskillobject.has("fromYear"))
						Skills.put("fromYear", getskillobject.getString("fromYear"));
					else
						Skills.put("fromYear", JSONObject.NULL);

					if (getskillobject.has("toMonth"))
						Skills.put("toMonth", getskillobject.getString("toMonth"));
					else
						Skills.put("toMonth", JSONObject.NULL);

					if (getskillobject.has("toYear"))
						Skills.put("toYear", getskillobject.getString("toYear"));
					else
						Skills.put("toYear", JSONObject.NULL);

					SkillsObj.put(Skills);
				}

				candijson.put("skills", SkillsObj);
			}

			else
				candijson.put("skills", JSONObject.NULL);

			if (arrObj1.has("education")) {
				JSONObject education = new JSONObject();

				JSONObject educationjson = (JSONObject) arrObj1.get("education");

				if (educationjson.has("ug")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("ug");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("ug", subEdu);
				} else
					education.put("ug", JSONObject.NULL);

				if (educationjson.has("pg")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("pg");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("pg", subEdu);

				} else
					education.put("pg", JSONObject.NULL); // end pg

				if (educationjson.has("doctorate")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("doctorate");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("doctorate", subEdu);

				} else
					education.put("doctorate", JSONObject.NULL);

				if (educationjson.has("diploma")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("diploma");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("diploma", subEdu);

				} else
					education.put("diploma", JSONObject.NULL);

				if (educationjson.has("twelveth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("twelveth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("twelveth", subEdu);

				} else
					education.put("twelveth", JSONObject.NULL);

				if (educationjson.has("tenth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("tenth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("tenth", subEdu);

				} else
					education.put("tenth", JSONObject.NULL);

				candijson.put("education", education);
			} else
				candijson.put("education", JSONObject.NULL);

			if (arrObj1.has("employment")) {

				JSONObject employement = new JSONObject();

				JSONObject getemployment = arrObj1.getJSONObject("employment");

				if (getemployment.has("current")) {

					JSONObject current = new JSONObject();
					JSONObject getcurrent = getemployment.getJSONObject("current");

					if (getcurrent.has("companyName"))
						current.put("companyName", getcurrent.getString("companyName"));
					else
						current.put("companyName", JSONObject.NULL);

					if (getcurrent.has("designation"))
						current.put("designation", getcurrent.getString("designation"));
					else
						current.put("designation", JSONObject.NULL);

					if (getcurrent.has("isCurrent"))
						current.put("isCurrent", getcurrent.get("isCurrent"));
					else
						current.put("isCurrent", JSONObject.NULL);

					if (getcurrent.has("desc"))
						current.put("desc", getcurrent.getString("desc"));
					else
						current.put("desc", JSONObject.NULL);

					if (getcurrent.has("workLocation"))
						current.put("workLocation", getcurrent.getString("workLocation"));
					else
						current.put("workLocation", JSONObject.NULL);

					if (getcurrent.has("role"))
						current.put("role", getcurrent.getString("role"));
					else
						current.put("role", JSONObject.NULL);

					if (getcurrent.has("level"))
						current.put("level", getcurrent.getString("level"));
					else
						current.put("level", JSONObject.NULL);

					if (getcurrent.has("teamSize"))
						current.put("teamSize", getcurrent.getString("teamSize"));
					else
						current.put("teamSize", JSONObject.NULL);

					employement.put("current", current);
				} else
					employement.put("current", JSONObject.NULL);

				if (getemployment.has("previous")) {

					JSONArray previous = new JSONArray();

					JSONArray getprevious = getemployment.getJSONArray("previous");
					int i = 0;

					for (i = 0; i < getprevious.length(); i++) {

						JSONObject jsonprevious = (JSONObject) getprevious.get(i);

						if (jsonprevious.has("organization"))
							jsonprevious.put("organization", jsonprevious.getString("organization"));
						else
							jsonprevious.put("organization", JSONObject.NULL);

						if (jsonprevious.has("designation"))
							jsonprevious.put("designation", jsonprevious.getString("designation"));
						else
							jsonprevious.put("designation", JSONObject.NULL);

						if (jsonprevious.has("level"))
							jsonprevious.put("level", jsonprevious.getString("level"));
						else
							jsonprevious.put("level", JSONObject.NULL);

						if (jsonprevious.has("city"))
							jsonprevious.put("city", jsonprevious.getString("city"));
						else
							jsonprevious.put("city", JSONObject.NULL);

						if (jsonprevious.has("fromMonth"))
							jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
						else
							jsonprevious.put("fromMonth", JSONObject.NULL);

						if (jsonprevious.has("fromYear"))
							jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
						else
							jsonprevious.put("fromYear", JSONObject.NULL);

						if (jsonprevious.has("toMonth"))
							jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
						else
							jsonprevious.put("toMonth", JSONObject.NULL);

						if (jsonprevious.has("toYear"))
							jsonprevious.put("toYear", jsonprevious.getString("toYear"));
						else
							jsonprevious.put("toYear", JSONObject.NULL);

						if (jsonprevious.has("description"))
							jsonprevious.put("description", jsonprevious.getString("description"));
						else
							jsonprevious.put("description", JSONObject.NULL);

						previous.put(jsonprevious);
					}
					employement.put("previous", previous);
				} else
					employement.put("previous", JSONObject.NULL);

				candijson.put("employment", employement);

			} else
				candijson.put("employment", JSONObject.NULL);

			/* salary array */

			if (arrObj1.has("salary") && !arrObj1.get("salary").equals(null)) {

				JSONObject getsalary = (JSONObject) arrObj1.get("salary");
				JSONObject salary = new JSONObject();

				if (getsalary.has("currentCTCType"))
					salary.put("currentCTCType", getsalary.getString("currentCTCType"));
				else
					salary.put("currentCTCType", JSONObject.NULL);

				if (getsalary.has("currentCTC"))
					salary.put("currentCTC", getsalary.getString("currentCTC"));
				else
					salary.put("currentCTC", JSONObject.NULL);

				if (getsalary.has("negotiableCTC"))
					salary.put("negotiableCTC", getsalary.getString("negotiableCTC"));
				else
					salary.put("negotiableCTC", JSONObject.NULL);

				if (getsalary.has("expectedCTCType"))
					salary.put("expectedCTCType", getsalary.getString("expectedCTCType"));
				else
					salary.put("expectedCTCType", JSONObject.NULL);

				if (getsalary.has("expectedCTC"))
					salary.put("expectedCTC", getsalary.getString("expectedCTC"));
				else
					salary.put("expectedCTC", JSONObject.NULL);

				if (getsalary.has("takeHome"))
					salary.put("takeHome", getsalary.getString("takeHome"));
				else
					salary.put("takeHome", JSONObject.NULL);

				if (getsalary.has("fixed"))
					salary.put("fixed", getsalary.getString("fixed"));
				else
					salary.put("fixed", JSONObject.NULL);

				candijson.put("salary", salary);

			} else
				candijson.put("salary", JSONObject.NULL);

			if (arrObj1.has("ctc"))
				candijson.put("ctc", (Double) arrObj1.get("ctc"));
			else
				candijson.put("ctc", JSONObject.NULL);

			if (arrObj1.has("exp"))
				candijson.put("exp", (Double) arrObj1.get("exp"));
			else
				candijson.put("exp", JSONObject.NULL);

			/* experience array */

			if (arrObj1.has("experience")) {

				JSONObject experience = new JSONObject();

				JSONObject getexperience = (JSONObject) arrObj1.get("experience");

				if (getexperience.has("months"))
					experience.put("months", (Integer) getexperience.get("months"));
				else
					experience.put("months", JSONObject.NULL);

				if (getexperience.has("totalExperience"))
					experience.put("totalExperience", getexperience.getString("totalExperience"));
				else
					experience.put("totalExperience", JSONObject.NULL);

				if (getexperience.has("years"))
					experience.put("years", (Integer) getexperience.get("years"));
				else
					experience.put("years", JSONObject.NULL);

				candijson.put("experience", experience);

			} else
				candijson.put("experience", JSONObject.NULL);

			/* Achievements */

			if (arrObj1.has("achievement")) {

				JSONArray achievement = new JSONArray();
				JSONArray getachievement = arrObj1.getJSONArray("achievement");

				for (int i = 0; i < getachievement.length(); i++) {

					JSONObject Achievementobject = (JSONObject) getachievement.get(i);

					if (Achievementobject.has("achievementTitle"))
						Achievementobject.put("achievementTitle", Achievementobject.getString("achievementTitle"));
					else
						Achievementobject.put("achievementTitle", JSONObject.NULL);

					if (Achievementobject.has("achievementRole"))
						Achievementobject.put("achievementRole", Achievementobject.getString("achievementRole"));
					else
						Achievementobject.put("achievementRole", JSONObject.NULL);

					if (Achievementobject.has("achievementDescription"))
						Achievementobject.put("achievementDescription",
								Achievementobject.getString("achievementDescription"));
					else
						Achievementobject.put("achievementDescription", JSONObject.NULL);

					achievement.put(Achievementobject);
				}

				candijson.put("achievement", achievement);

			} else
				candijson.put("achievement", JSONObject.NULL);

			/* Certificates */

			if (arrObj1.has("certificates")) {

				JSONArray getcertificates = (JSONArray) arrObj1.get("certificates");
				JSONArray certificates = new JSONArray();

				for (int i = 0; i < getcertificates.length(); i++) {

					JSONObject certificatesobject = (JSONObject) getcertificates.get(i);

					if (certificatesobject.has("certificatesTitle"))
						certificatesobject.put("certificatesTitle", certificatesobject.getString("certificatesTitle"));
					else
						certificatesobject.put("certificatesTitle", JSONObject.NULL);

					if (certificatesobject.has("month"))
						certificatesobject.put("month", certificatesobject.getString("month"));
					else
						certificatesobject.put("month", JSONObject.NULL);

					if (certificatesobject.has("year"))
						certificatesobject.put("year", certificatesobject.getString("year"));
					else
						certificatesobject.put("year", JSONObject.NULL);

					if (certificatesobject.has("certificatesDescription"))
						certificatesobject.put("certificatesDescription",
								certificatesobject.getString("certificatesDescription"));
					else
						certificatesobject.put("certificatesDescription", JSONObject.NULL);

					certificates.put(certificatesobject);

				}

				candijson.put("certificates", certificates);
			} else
				candijson.put("certificates", JSONObject.NULL);

			/* Project */

			if (arrObj1.has("project")) {

				JSONArray project = new JSONArray();
				JSONArray getproject = (JSONArray) arrObj1.get("project");

				JSONObject projectobject = new JSONObject();

				for (int i = 0; i < getproject.length(); i++) {

					JSONObject projectObj = new JSONObject();

					projectobject = (JSONObject) getproject.get(i);

					if (projectobject.has("projectTitle"))
						projectObj.put("projectTitle", projectobject.getString("projectTitle"));
					else
						projectObj.put("projectTitle", JSONObject.NULL);

					if (projectobject.has("projectRole"))
						projectObj.put("projectRole", projectobject.getString("projectRole"));
					else
						projectObj.put("projectRole", JSONObject.NULL);

					if (projectobject.has("fromMonth"))
						projectObj.put("fromMonth", projectobject.getString("fromMonth"));
					else
						projectObj.put("fromMonth", JSONObject.NULL);

					if (projectobject.has("fromYear"))
						projectObj.put("fromYear", projectobject.getString("fromYear"));
					else
						projectObj.put("fromYear", JSONObject.NULL);

					if (projectobject.has("toMonth"))
						projectObj.put("toMonth", projectobject.getString("toMonth"));
					else
						projectObj.put("toMonth", JSONObject.NULL);

					if (projectobject.has("toYear"))
						projectObj.put("toYear", projectobject.getString("toYear"));
					else
						projectObj.put("toYear", JSONObject.NULL);

					if (projectobject.has("url"))
						projectObj.put("url", projectobject.getString("url"));
					else
						projectObj.put("url", JSONObject.NULL);

					if (projectobject.has("projectDescription"))
						projectObj.put("projectDescription", projectobject.getString("projectDescription"));
					else
						projectObj.put("projectDescription", JSONObject.NULL);

					project.put(projectObj);

				}

				candijson.put("project", project);
			} else
				candijson.put("project", JSONObject.NULL);

			/* html array */

			if (arrObj1.has("html")) {
				JSONObject gethtml = (JSONObject) arrObj1.get("html");
				JSONObject html = new JSONObject();

				if (gethtml.has("naukri")) {

					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();

					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", JSONObject.NULL);

					html.put("naukri", naukri);

				} else
					html.put("naukri", JSONObject.NULL);

				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

					JSONObject linkedIn = new JSONObject();

					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", JSONObject.NULL);

					html.put("linkedIn", linkedIn);

				} else
					html.put("linkedIn", JSONObject.NULL);

				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");

					JSONObject monster = new JSONObject();

					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", JSONObject.NULL);

					html.put("monster", monster);

				} else
					html.put("monster", JSONObject.NULL);

				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

					JSONObject naukriGulf = new JSONObject();

					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", JSONObject.NULL);

					html.put("naukriGulf", naukriGulf);

				} else
					html.put("naukriGulf", JSONObject.NULL);

				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

					JSONObject careerBuilder = new JSONObject();

					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", JSONObject.NULL);

					html.put("careerBuilder", careerBuilder);

				} else
					html.put("careerBuilder", JSONObject.NULL);

				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

					JSONObject monsterUS = new JSONObject();

					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", JSONObject.NULL);

					html.put("monsterUS", monsterUS);

				} else
					html.put("monsterUS", JSONObject.NULL);

				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");

					JSONObject dice = new JSONObject();

					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", JSONObject.NULL);

					html.put("dice", dice);

				} else
					html.put("dice", JSONObject.NULL);

				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

					JSONObject jobDiva = new JSONObject();

					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", JSONObject.NULL);

					html.put("jobDiva", jobDiva);

				} else
					html.put("jobDiva", JSONObject.NULL);

				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");

					JSONObject indeed = new JSONObject();

					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", JSONObject.NULL);

					html.put("indeed", indeed);

				} else
					html.put("indeed", JSONObject.NULL);

				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

					JSONObject jobServe = new JSONObject();

					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", JSONObject.NULL);

					html.put("jobServe", jobServe);

				} else
					html.put("jobServe", JSONObject.NULL);

				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");

					JSONObject other = new JSONObject();

					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", JSONObject.NULL);

					html.put("other", other);

				} else
					html.put("other", JSONObject.NULL);

				candijson.put("html", html);
			} else
				candijson.put("html", JSONObject.NULL);

			if (arrObj1.has("resumeName"))
				candijson.put("resumeName", arrObj1.get("resumeName"));
			else
				candijson.put("resumeName", JSONObject.NULL);

			if (arrObj1.has("resume"))
				candijson.put("resume", arrObj1.get("resume"));
			else
				candijson.put("resume", JSONObject.NULL);

			if (arrObj1.has("connectSocialNetwork")) {

				JSONArray cns = new JSONArray();

				JSONArray getcns = (JSONArray) arrObj1.get("connectSocialNetwork");

				for (int i = 0; i < getcns.length(); i++) {
					JSONObject subcns = new JSONObject();
					JSONObject cnsobject = (JSONObject) getcns.get(i);

					if (cnsobject.has("name"))
						subcns.put("name", cnsobject.getString("name"));
					else
						subcns.put("name", JSONObject.NULL);

					if (cnsobject.has("url"))
						subcns.put("url", cnsobject.getString("url"));
					else
						subcns.put("url", JSONObject.NULL);

					cns.put(subcns);

				}

				candijson.put("connectSocialNetwork", cns);
			} else
				candijson.put("connectSocialNetwork", JSONObject.NULL);

			if (arrObj1.has("family")) {

				JSONArray family = new JSONArray();

				JSONArray getfamily = (JSONArray) arrObj1.get("family");

				for (int i = 0; i < getfamily.length(); i++) {
					JSONObject subfamily = new JSONObject();
					JSONObject familyobject = (JSONObject) getfamily.get(i);

					if (familyobject.has("name"))
						subfamily.put("name", familyobject.getString("name"));
					else
						subfamily.put("name", JSONObject.NULL);

					if (familyobject.has("occupation"))
						subfamily.put("occupation", familyobject.getString("occupation"));
					else
						subfamily.put("occupation", JSONObject.NULL);

					if (familyobject.has("location"))
						subfamily.put("location", familyobject.getString("location"));
					else
						subfamily.put("location", JSONObject.NULL);

					if (familyobject.has("relationship"))
						subfamily.put("relationship", familyobject.getString("relationship"));
					else
						subfamily.put("relationship", JSONObject.NULL);

					family.put(subfamily);

				}

				candijson.put("family", family);
			} else
				candijson.put("family", JSONObject.NULL);

			if (arrObj1.has("referral")) {

				JSONArray referal = new JSONArray();

				JSONArray getreferal = (JSONArray) arrObj1.get("referral");

				for (int i = 0; i < getreferal.length(); i++) {
					JSONObject subreferral = new JSONObject();
					JSONObject referralobject = (JSONObject) getreferal.get(i);

					if (referralobject.has("name"))
						subreferral.put("name", referralobject.getString("name"));
					else
						subreferral.put("name", JSONObject.NULL);

					if (referralobject.has("officeEmail"))
						subreferral.put("officeEmail", referralobject.getString("officeEmail"));
					else
						subreferral.put("officeEmail", JSONObject.NULL);

					if (referralobject.has("officePhone"))
						subreferral.put("officePhone", referralobject.getString("officePhone"));
					else
						subreferral.put("officePhone", JSONObject.NULL);

					if (referralobject.has("company"))
						subreferral.put("company", referralobject.getString("company"));
					else
						subreferral.put("company", JSONObject.NULL);

					if (referralobject.has("title"))
						subreferral.put("title", referralobject.getString("title"));
					else
						subreferral.put("title", JSONObject.NULL);

					if (referralobject.has("description"))
						subreferral.put("description", referralobject.getString("description"));
					else
						subreferral.put("description", JSONObject.NULL);

					referal.put(subreferral);

				}

				candijson.put("referral", referal);
			} else
				candijson.put("referral", JSONObject.NULL);

		}

		return candijson.toString();
	}

	/*
	 * On behalf of email
	 */

	@RequestMapping(value = "/ElasticAPI/candiemail", method = { RequestMethod.GET })
	public @ResponseBody String getCandidateData(@RequestParam("email") String EmailId)
			throws JSONException, URISyntaxException, MalformedURLException {

		JSONObject candijson = new JSONObject();

		String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=email:"
				+ EmailId ;

		System.out.println("url :: " + candidateUrl);

		URL urlcandiateProfile = new URL(candidateUrl);

		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateUrl);
		String jsonCandidateData = "";
		
		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

		JSONObject jsonAttach = new JSONObject(jsonCandidateData);
		JSONObject hits = jsonAttach.getJSONObject("hits");

		JSONArray hitsArr = hits.getJSONArray("hits");

		for (int k = 0; k < hitsArr.length(); k++) {

			JSONObject arrobj = (JSONObject) hitsArr.get(k);
			JSONObject arrObj1 = arrobj.getJSONObject("_source");
			
			if (arrObj1.has("id"))
				candijson.put("id", arrObj1.getString("id"));
			else 
				candijson.put("id", arrObj1.getString("id"));
				
			if (arrObj1.has("name"))
				candijson.put("name", arrObj1.getString("name"));
			else
				candijson.put("name", JSONObject.NULL);

			if (arrObj1.has("first_name"))
				candijson.put("first_name", arrObj1.getString("first_name"));
			else
				candijson.put("first_name", JSONObject.NULL);

			if (arrObj1.has("middle_name"))
				candijson.put("middle_name", arrObj1.getString("middle_name"));
			else
				candijson.put("middle_name", JSONObject.NULL);

			if (arrObj1.has("last_name"))
				candijson.put("last_name", arrObj1.getString("last_name"));
			else
				candijson.put("last_name", JSONObject.NULL);

			if (arrObj1.has("username"))
				candijson.put("username", arrObj1.getString("username"));
			else
				candijson.put("username", JSONObject.NULL);

			if (arrObj1.has("email"))
				candijson.put("email", arrObj1.getString("email"));
			else
				candijson.put("email", JSONObject.NULL);

			if (arrObj1.has("alternateEmail"))
				candijson.put("alternateEmail", (JSONArray) arrObj1.get("alternateEmail"));
			else
				candijson.put("alternateEmail", JSONObject.NULL);

			if (arrObj1.has("birthdate"))
				candijson.put("birthdate", arrObj1.getString("birthdate"));
			else
				candijson.put("birthdate", JSONObject.NULL);

			if (arrObj1.has("age"))
				candijson.put("age", arrObj1.getInt("age"));
			else
				candijson.put("age", JSONObject.NULL);

			if (arrObj1.has("gender"))
				candijson.put("gender", arrObj1.getString("gender"));
			else
				candijson.put("gender", JSONObject.NULL);

			if (arrObj1.has("picture"))
				candijson.put("picture", arrObj1.get("picture"));
			else
				candijson.put("picture", JSONObject.NULL);

			if (arrObj1.has("profile"))
				candijson.put("profile", arrObj1.getString("profile"));
			else
				candijson.put("profile", JSONObject.NULL);

			if (arrObj1.has("mobileNumber"))
				candijson.put("mobileNumber", arrObj1.getString("mobileNumber"));
			else
				candijson.put("mobileNumber", JSONObject.NULL);

			if (arrObj1.has("alternateMobileNumber"))
				candijson.put("alternateMobileNumber", (JSONArray) arrObj1.get("alternateMobileNumber"));
			else
				candijson.put("alternateMobileNumber", JSONObject.NULL);

			if (arrObj1.has("officePhone"))
				candijson.put("officePhone", arrObj1.getString("officePhone"));
			else
				candijson.put("officePhone", JSONObject.NULL);

			if (arrObj1.has("officePhoneExtention"))
				candijson.put("officePhoneExtention", arrObj1.getString("officePhoneExtention"));
			else
				candijson.put("officePhoneExtention", JSONObject.NULL);

			if (arrObj1.has("isMobileNumberVerified"))
				candijson.put("isMobileNumberVerified", (Boolean) arrObj1.get("isMobileNumberVerified"));
			else
				candijson.put("isMobileNumberVerified", JSONObject.NULL);

			if (arrObj1.has("religion"))
				candijson.put("religion", arrObj1.getString("religion"));
			else
				candijson.put("religion", JSONObject.NULL);

			if (arrObj1.has("maritalStatus"))
				candijson.put("maritalStatus", arrObj1.getString("maritalStatus"));
			else
				candijson.put("maritalStatus", JSONObject.NULL);

			if (arrObj1.has("federated"))
				candijson.put("federated", arrObj1.getString("federated"));
			else
				candijson.put("federated", JSONObject.NULL);


			

			if (arrObj1.has("address")) {
				
				JSONObject addressJson1 = null;
				JSONObject addressJson = (JSONObject) arrObj1.get("address");

				if (addressJson.has("permanentAddress")) {

					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("permanentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("permanentAddress", addressJ);
				}

				if (addressJson.has("currentAddress")) {
					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("currentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("currentAddress", addressJ);
				}
			} else
				candijson.put("address", JSONObject.NULL);

			/*
			 * notification Array
			 */
			if (arrObj1.has("notification")) {

				JSONObject notification = new JSONObject();
				JSONObject getnotification = (JSONObject) arrObj1.get("notification");

				if (getnotification.has("resumeDownload"))
					notification.put("resumeDownload", (Boolean) getnotification.get("resumeDownload"));
				else
					notification.put("resumeDownload", JSONObject.NULL);

				if (getnotification.has("profileViewed"))
					notification.put("profileViewed", (Boolean) getnotification.get("profileViewed"));
				else
					notification.put("profileViewed", JSONObject.NULL);

				if (getnotification.has("newJobPost"))
					notification.put("newJobPost", (Boolean) getnotification.get("newJobPost"));
				else
					notification.put("newJobPost", JSONObject.NULL);

				if (getnotification.has("recruiterConnect"))
					notification.put("recruiterConnect", (Boolean) getnotification.get("recruiterConnect"));
				else
					notification.put("recruiterConnect", JSONObject.NULL);

				if (getnotification.has("google"))
					notification.put("google", (Boolean) getnotification.get("google"));
				else
					notification.put("google", JSONObject.NULL);

				if (getnotification.has("twitter"))
					notification.put("twitter", (Boolean) getnotification.get("twitter"));
				else
					notification.put("twitter", JSONObject.NULL);

				if (getnotification.has("linkedIn"))
					notification.put("linkedIn", (Boolean) getnotification.get("linkedIn"));
				else
					notification.put("linkedIn", JSONObject.NULL);

				if (getnotification.has("facebook"))
					notification.put("facebook", (Boolean) getnotification.get("facebook"));
				else
					notification.put("facebook", JSONObject.NULL);

				candijson.put("notification", notification);
			} else
				candijson.put("notification", JSONObject.NULL);

			if (arrObj1.has("jobType"))
				candijson.put("jobType", arrObj1.getString("jobType"));
			else
				candijson.put("jobType", JSONObject.NULL);

			if (arrObj1.has("employmentType"))
				candijson.put("employmentType", arrObj1.getString("employmentType"));
			else
				candijson.put("employmentType", JSONObject.NULL);

			if (arrObj1.has("createdDate"))
				candijson.put("createdDate", arrObj1.getString("createdDate"));
			else
				candijson.put("createdDate", JSONObject.NULL);

			if (arrObj1.has("lastModified"))
				candijson.put("lastModified", arrObj1.getString("lastModified"));
			else
				candijson.put("lastModified", JSONObject.NULL);

			if (arrObj1.has("createdBy"))
				candijson.put("createdBy", arrObj1.getString("createdBy"));
			else
				candijson.put("createdBy", JSONObject.NULL);

			if (arrObj1.has("lastModifiedBy"))
				candijson.put("lastModifiedBy", arrObj1.getString("lastModifiedBy"));
			else
				candijson.put("lastModifiedBy", JSONObject.NULL);

			if (arrObj1.has("aadharCardNo"))
				candijson.put("aadharCardNo", arrObj1.getString("aadharCardNo"));
			else
				candijson.put("aadharCardNo", JSONObject.NULL);

			if (arrObj1.has("passportNo"))
				candijson.put("passportNo", arrObj1.getString("passportNo"));
			else
				candijson.put("passportNo", JSONObject.NULL);

			if (arrObj1.has("passportValidity"))
				candijson.put("passportValidity", arrObj1.getString("passportValidity"));
			else
				candijson.put("passportValidity", JSONObject.NULL);

			if (arrObj1.has("panNo"))
				candijson.put("panNo", arrObj1.getString("panNo"));
			else
				candijson.put("panNo", JSONObject.NULL);

			if (arrObj1.has("areaOfSpecialization"))
				candijson.put("areaOfSpecialization", arrObj1.getString("areaOfSpecialization"));
			else
				candijson.put("areaOfSpecialization", JSONObject.NULL);

			if (arrObj1.has("category"))
				candijson.put("category", arrObj1.getString("category"));
			else
				candijson.put("category", JSONObject.NULL);

			if (arrObj1.has("confidential"))
				candijson.put("confidential", (Boolean) arrObj1.get("confidential"));
			else
				candijson.put("confidential", JSONObject.NULL);

			if (arrObj1.has("employmentStatus"))
				candijson.put("employmentStatus", arrObj1.getString("employmentStatus"));
			else
				candijson.put("employmentStatus", JSONObject.NULL);

			if (arrObj1.has("nationality"))
				candijson.put("nationality", arrObj1.getString("nationality"));
			else
				candijson.put("nationality", JSONObject.NULL);

			if (arrObj1.has("exNationality"))
				candijson.put("exNationality", arrObj1.getInt("exNationality"));
			else
				candijson.put("exNationality", JSONObject.NULL);

			if (arrObj1.has("experiencedIndustry"))
				candijson.put("experiencedIndustry", arrObj1.getString("experiencedIndustry"));
			else
				candijson.put("experiencedIndustry", JSONObject.NULL);

			if (arrObj1.has("experiencedFunctionalArea"))
				candijson.put("experiencedFunctionalArea", arrObj1.getString("experiencedFunctionalArea"));
			else
				candijson.put("experiencedFunctionalArea", JSONObject.NULL);

			if (arrObj1.has("language"))
				candijson.put("language", arrObj1.getString("language"));
			else
				candijson.put("language", JSONObject.NULL);

			if (arrObj1.has("notes"))
				candijson.put("notes", arrObj1.getString("notes"));
			else
				candijson.put("notes", JSONObject.NULL);

			if (arrObj1.has("preferredLocation"))
				candijson.put("preferredLocation", arrObj1.getString("preferredLocation"));
			else
				candijson.put("preferredLocation", JSONObject.NULL);

			if (arrObj1.has("physicallyChallenged"))
				candijson.put("physicallyChallenged", arrObj1.getString("physicallyChallenged"));
			else
				candijson.put("physicallyChallenged", JSONObject.NULL);

			if (arrObj1.has("reasonForLeaving"))
				candijson.put("reasonForLeaving", arrObj1.getString("reasonForLeaving"));
			else
				candijson.put("reasonForLeaving", JSONObject.NULL);

			if (arrObj1.has("reasonForRelocate"))
				candijson.put("reasonForRelocate", arrObj1.getString("reasonForRelocate"));
			else
				candijson.put("reasonForRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToRelocate"))
				candijson.put("willingToRelocate", arrObj1.getString("willingToRelocate"));
			else
				candijson.put("willingToRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToChangeJob"))
				candijson.put("willingToChangeJob", arrObj1.getString("willingToChangeJob"));
			else
				candijson.put("willingToChangeJob", JSONObject.NULL);

			if (arrObj1.has("resumeHeadLine"))
				candijson.put("resumeHeadLine", arrObj1.getString("resumeHeadLine"));
			else
				candijson.put("resumeHeadLine", JSONObject.NULL);

			if (arrObj1.has("experienced"))
				candijson.put("experienced", (Boolean) arrObj1.get("experienced"));
			else
				candijson.put("experienced", JSONObject.NULL);

			if (arrObj1.has("fresher"))
				candijson.put("fresher", (Boolean) arrObj1.get("fresher"));
			else
				candijson.put("fresher", JSONObject.NULL);

			if (arrObj1.has("skillSummary"))
				candijson.put("skillSummary", arrObj1.getString("skillSummary"));
			else
				candijson.put("skillSummary", JSONObject.NULL);

			if (arrObj1.has("skills")) {
				JSONArray SkillsObj = new JSONArray();

				JSONObject getskillobject = new JSONObject();

				JSONArray skillList = (JSONArray) arrObj1.get("skills");

				for (int i = 0; i < skillList.length(); i++) {

					getskillobject = (JSONObject) skillList.get(i);
					JSONObject Skills = new JSONObject();

					if (getskillobject.has("keySkill"))
						Skills.put("keySkill", getskillobject.getString("keySkill"));
					else
						Skills.put("keySkill", JSONObject.NULL);

					if (getskillobject.has("experience"))
						Skills.put("experience", getskillobject.getString("experience"));
					else
						Skills.put("experience", JSONObject.NULL);

					if (getskillobject.has("fromMonth"))
						Skills.put("fromMonth", getskillobject.getString("fromMonth"));
					else
						Skills.put("fromMonth", JSONObject.NULL);

					if (getskillobject.has("fromYear"))
						Skills.put("fromYear", getskillobject.getString("fromYear"));
					else
						Skills.put("fromYear", JSONObject.NULL);

					if (getskillobject.has("toMonth"))
						Skills.put("toMonth", getskillobject.getString("toMonth"));
					else
						Skills.put("toMonth", JSONObject.NULL);

					if (getskillobject.has("toYear"))
						Skills.put("toYear", getskillobject.getString("toYear"));
					else
						Skills.put("toYear", JSONObject.NULL);

					SkillsObj.put(Skills);
				}

				candijson.put("skills", SkillsObj);
			}

			else
				candijson.put("skills", JSONObject.NULL);

			if (arrObj1.has("education")) {
				JSONObject education = new JSONObject();

				JSONObject educationjson = (JSONObject) arrObj1.get("education");

				if (educationjson.has("ug")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("ug");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("ug", subEdu);
				} else
					education.put("ug", JSONObject.NULL);

				if (educationjson.has("pg")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("pg");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("pg", subEdu);

				} else
					education.put("pg", JSONObject.NULL); // end pg

				if (educationjson.has("doctorate")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("doctorate");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("doctorate", subEdu);

				} else
					education.put("doctorate", JSONObject.NULL);

				if (educationjson.has("diploma")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("diploma");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("diploma", subEdu);

				} else
					education.put("diploma", JSONObject.NULL);

				if (educationjson.has("twelveth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("twelveth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("twelveth", subEdu);

				} else
					education.put("twelveth", JSONObject.NULL);

				if (educationjson.has("tenth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("tenth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("tenth", subEdu);

				} else
					education.put("tenth", JSONObject.NULL);

				candijson.put("education", education);
			} else
				candijson.put("education", JSONObject.NULL);

			if (arrObj1.has("employment")) {

				JSONObject employement = new JSONObject();

				JSONObject getemployment = arrObj1.getJSONObject("employment");

				if (getemployment.has("current")) {

					JSONObject current = new JSONObject();
					JSONObject getcurrent = getemployment.getJSONObject("current");

					if (getcurrent.has("companyName"))
						current.put("companyName", getcurrent.getString("companyName"));
					else
						current.put("companyName", JSONObject.NULL);

					if (getcurrent.has("designation"))
						current.put("designation", getcurrent.getString("designation"));
					else
						current.put("designation", JSONObject.NULL);

					if (getcurrent.has("isCurrent"))
						current.put("isCurrent", getcurrent.get("isCurrent"));
					else
						current.put("isCurrent", JSONObject.NULL);

					if (getcurrent.has("desc"))
						current.put("desc", getcurrent.getString("desc"));
					else
						current.put("desc", JSONObject.NULL);

					if (getcurrent.has("workLocation"))
						current.put("workLocation", getcurrent.getString("workLocation"));
					else
						current.put("workLocation", JSONObject.NULL);

					if (getcurrent.has("role"))
						current.put("role", getcurrent.getString("role"));
					else
						current.put("role", JSONObject.NULL);

					if (getcurrent.has("level"))
						current.put("level", getcurrent.getString("level"));
					else
						current.put("level", JSONObject.NULL);

					if (getcurrent.has("teamSize"))
						current.put("teamSize", getcurrent.getString("teamSize"));
					else
						current.put("teamSize", JSONObject.NULL);

					employement.put("current", current);
				} else
					employement.put("current", JSONObject.NULL);

				if (getemployment.has("previous")) {

					JSONArray previous = new JSONArray();

					JSONArray getprevious = getemployment.getJSONArray("previous");
					int i = 0;

					for (i = 0; i < getprevious.length(); i++) {

						JSONObject jsonprevious = (JSONObject) getprevious.get(i);

						if (jsonprevious.has("organization"))
							jsonprevious.put("organization", jsonprevious.getString("organization"));
						else
							jsonprevious.put("organization", JSONObject.NULL);

						if (jsonprevious.has("designation"))
							jsonprevious.put("designation", jsonprevious.getString("designation"));
						else
							jsonprevious.put("designation", JSONObject.NULL);

						if (jsonprevious.has("level"))
							jsonprevious.put("level", jsonprevious.getString("level"));
						else
							jsonprevious.put("level", JSONObject.NULL);

						if (jsonprevious.has("city"))
							jsonprevious.put("city", jsonprevious.getString("city"));
						else
							jsonprevious.put("city", JSONObject.NULL);

						if (jsonprevious.has("fromMonth"))
							jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
						else
							jsonprevious.put("fromMonth", JSONObject.NULL);

						if (jsonprevious.has("fromYear"))
							jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
						else
							jsonprevious.put("fromYear", JSONObject.NULL);

						if (jsonprevious.has("toMonth"))
							jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
						else
							jsonprevious.put("toMonth", JSONObject.NULL);

						if (jsonprevious.has("toYear"))
							jsonprevious.put("toYear", jsonprevious.getString("toYear"));
						else
							jsonprevious.put("toYear", JSONObject.NULL);

						if (jsonprevious.has("description"))
							jsonprevious.put("description", jsonprevious.getString("description"));
						else
							jsonprevious.put("description", JSONObject.NULL);

						previous.put(jsonprevious);
					}
					employement.put("previous", previous);
				} else
					employement.put("previous", JSONObject.NULL);

				candijson.put("employment", employement);

			} else
				candijson.put("employment", JSONObject.NULL);

			/* salary array */

			if (arrObj1.has("salary") && !arrObj1.get("salary").equals(null)) {

				JSONObject getsalary = (JSONObject) arrObj1.get("salary");
				JSONObject salary = new JSONObject();

				if (getsalary.has("currentCTCType"))
					salary.put("currentCTCType", getsalary.getString("currentCTCType"));
				else
					salary.put("currentCTCType", JSONObject.NULL);

				if (getsalary.has("currentCTC"))
					salary.put("currentCTC", getsalary.getString("currentCTC"));
				else
					salary.put("currentCTC", JSONObject.NULL);

				if (getsalary.has("negotiableCTC"))
					salary.put("negotiableCTC", getsalary.getString("negotiableCTC"));
				else
					salary.put("negotiableCTC", JSONObject.NULL);

				if (getsalary.has("expectedCTCType"))
					salary.put("expectedCTCType", getsalary.getString("expectedCTCType"));
				else
					salary.put("expectedCTCType", JSONObject.NULL);

				if (getsalary.has("expectedCTC"))
					salary.put("expectedCTC", getsalary.getString("expectedCTC"));
				else
					salary.put("expectedCTC", JSONObject.NULL);

				if (getsalary.has("takeHome"))
					salary.put("takeHome", getsalary.getString("takeHome"));
				else
					salary.put("takeHome", JSONObject.NULL);

				if (getsalary.has("fixed"))
					salary.put("fixed", getsalary.getString("fixed"));
				else
					salary.put("fixed", JSONObject.NULL);

				candijson.put("salary", salary);

			} else
				candijson.put("salary", JSONObject.NULL);

			if (arrObj1.has("ctc"))
				candijson.put("ctc", (Double) arrObj1.get("ctc"));
			else
				candijson.put("ctc", JSONObject.NULL);

			if (arrObj1.has("exp"))
				candijson.put("exp", (Double) arrObj1.get("exp"));
			else
				candijson.put("exp", JSONObject.NULL);

			/* experience array */

			if (arrObj1.has("experience")) {

				JSONObject experience = new JSONObject();

				JSONObject getexperience = (JSONObject) arrObj1.get("experience");

				if (getexperience.has("months"))
					experience.put("months", (Integer) getexperience.get("months"));
				else
					experience.put("months", JSONObject.NULL);

				if (getexperience.has("totalExperience"))
					experience.put("totalExperience", getexperience.getString("totalExperience"));
				else
					experience.put("totalExperience", JSONObject.NULL);

				if (getexperience.has("years"))
					experience.put("years", (Integer) getexperience.get("years"));
				else
					experience.put("years", JSONObject.NULL);

				candijson.put("experience", experience);

			} else
				candijson.put("experience", JSONObject.NULL);

			/* Achievements */

			if (arrObj1.has("achievement")) {

				JSONArray achievement = new JSONArray();
				JSONArray getachievement = arrObj1.getJSONArray("achievement");

				for (int i = 0; i < getachievement.length(); i++) {

					JSONObject Achievementobject = (JSONObject) getachievement.get(i);

					if (Achievementobject.has("achievementTitle"))
						Achievementobject.put("achievementTitle", Achievementobject.getString("achievementTitle"));
					else
						Achievementobject.put("achievementTitle", JSONObject.NULL);

					if (Achievementobject.has("achievementRole"))
						Achievementobject.put("achievementRole", Achievementobject.getString("achievementRole"));
					else
						Achievementobject.put("achievementRole", JSONObject.NULL);

					if (Achievementobject.has("achievementDescription"))
						Achievementobject.put("achievementDescription",
								Achievementobject.getString("achievementDescription"));
					else
						Achievementobject.put("achievementDescription", JSONObject.NULL);

					achievement.put(Achievementobject);
				}

				candijson.put("achievement", achievement);

			} else
				candijson.put("achievement", JSONObject.NULL);

			/* Certificates */

			if (arrObj1.has("certificates")) {

				JSONArray getcertificates = (JSONArray) arrObj1.get("certificates");
				JSONArray certificates = new JSONArray();

				for (int i = 0; i < getcertificates.length(); i++) {

					JSONObject certificatesobject = (JSONObject) getcertificates.get(i);

					if (certificatesobject.has("certificatesTitle"))
						certificatesobject.put("certificatesTitle", certificatesobject.getString("certificatesTitle"));
					else
						certificatesobject.put("certificatesTitle", JSONObject.NULL);

					if (certificatesobject.has("month"))
						certificatesobject.put("month", certificatesobject.getString("month"));
					else
						certificatesobject.put("month", JSONObject.NULL);

					if (certificatesobject.has("year"))
						certificatesobject.put("year", certificatesobject.getString("year"));
					else
						certificatesobject.put("year", JSONObject.NULL);

					if (certificatesobject.has("certificatesDescription"))
						certificatesobject.put("certificatesDescription",
								certificatesobject.getString("certificatesDescription"));
					else
						certificatesobject.put("certificatesDescription", JSONObject.NULL);

					certificates.put(certificatesobject);

				}

				candijson.put("certificates", certificates);
			} else
				candijson.put("certificates", JSONObject.NULL);

			/* Project */

			if (arrObj1.has("project")) {

				JSONArray project = new JSONArray();
				JSONArray getproject = (JSONArray) arrObj1.get("project");

				JSONObject projectobject = new JSONObject();

				for (int i = 0; i < getproject.length(); i++) {

					JSONObject projectObj = new JSONObject();

					projectobject = (JSONObject) getproject.get(i);

					if (projectobject.has("projectTitle"))
						projectObj.put("projectTitle", projectobject.getString("projectTitle"));
					else
						projectObj.put("projectTitle", JSONObject.NULL);

					if (projectobject.has("projectRole"))
						projectObj.put("projectRole", projectobject.getString("projectRole"));
					else
						projectObj.put("projectRole", JSONObject.NULL);

					if (projectobject.has("fromMonth"))
						projectObj.put("fromMonth", projectobject.getString("fromMonth"));
					else
						projectObj.put("fromMonth", JSONObject.NULL);

					if (projectobject.has("fromYear"))
						projectObj.put("fromYear", projectobject.getString("fromYear"));
					else
						projectObj.put("fromYear", JSONObject.NULL);

					if (projectobject.has("toMonth"))
						projectObj.put("toMonth", projectobject.getString("toMonth"));
					else
						projectObj.put("toMonth", JSONObject.NULL);

					if (projectobject.has("toYear"))
						projectObj.put("toYear", projectobject.getString("toYear"));
					else
						projectObj.put("toYear", JSONObject.NULL);

					if (projectobject.has("url"))
						projectObj.put("url", projectobject.getString("url"));
					else
						projectObj.put("url", JSONObject.NULL);

					if (projectobject.has("projectDescription"))
						projectObj.put("projectDescription", projectobject.getString("projectDescription"));
					else
						projectObj.put("projectDescription", JSONObject.NULL);

					project.put(projectObj);

				}

				candijson.put("project", project);
			} else
				candijson.put("project", JSONObject.NULL);

			/* html array */

			if (arrObj1.has("html")) {
				JSONObject gethtml = (JSONObject) arrObj1.get("html");
				JSONObject html = new JSONObject();

				if (gethtml.has("naukri")) {

					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();

					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", JSONObject.NULL);

					html.put("naukri", naukri);

				} else
					html.put("naukri", JSONObject.NULL);

				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

					JSONObject linkedIn = new JSONObject();

					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", JSONObject.NULL);

					html.put("linkedIn", linkedIn);

				} else
					html.put("linkedIn", JSONObject.NULL);

				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");

					JSONObject monster = new JSONObject();

					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", JSONObject.NULL);

					html.put("monster", monster);

				} else
					html.put("monster", JSONObject.NULL);

				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

					JSONObject naukriGulf = new JSONObject();

					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", JSONObject.NULL);

					html.put("naukriGulf", naukriGulf);

				} else
					html.put("naukriGulf", JSONObject.NULL);

				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

					JSONObject careerBuilder = new JSONObject();

					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", JSONObject.NULL);

					html.put("careerBuilder", careerBuilder);

				} else
					html.put("careerBuilder", JSONObject.NULL);

				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

					JSONObject monsterUS = new JSONObject();

					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", JSONObject.NULL);

					html.put("monsterUS", monsterUS);

				} else
					html.put("monsterUS", JSONObject.NULL);

				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");

					JSONObject dice = new JSONObject();

					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", JSONObject.NULL);

					html.put("dice", dice);

				} else
					html.put("dice", JSONObject.NULL);

				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

					JSONObject jobDiva = new JSONObject();

					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", JSONObject.NULL);

					html.put("jobDiva", jobDiva);

				} else
					html.put("jobDiva", JSONObject.NULL);

				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");

					JSONObject indeed = new JSONObject();

					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", JSONObject.NULL);

					html.put("indeed", indeed);

				} else
					html.put("indeed", JSONObject.NULL);

				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

					JSONObject jobServe = new JSONObject();

					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", JSONObject.NULL);

					html.put("jobServe", jobServe);

				} else
					html.put("jobServe", JSONObject.NULL);

				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");

					JSONObject other = new JSONObject();

					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", JSONObject.NULL);

					html.put("other", other);

				} else
					html.put("other", JSONObject.NULL);

				candijson.put("html", html);
			} else
				candijson.put("html", JSONObject.NULL);

			if (arrObj1.has("resumeName"))
				candijson.put("resumeName", arrObj1.get("resumeName"));
			else
				candijson.put("resumeName", JSONObject.NULL);

			if (arrObj1.has("resume"))
				candijson.put("resume", arrObj1.get("resume"));
			else
				candijson.put("resume", JSONObject.NULL);

			if (arrObj1.has("connectSocialNetwork")) {

				JSONArray cns = new JSONArray();

				JSONArray getcns = (JSONArray) arrObj1.get("connectSocialNetwork");

				for (int i = 0; i < getcns.length(); i++) {
					JSONObject subcns = new JSONObject();
					JSONObject cnsobject = (JSONObject) getcns.get(i);

					if (cnsobject.has("name"))
						subcns.put("name", cnsobject.getString("name"));
					else
						subcns.put("name", JSONObject.NULL);

					if (cnsobject.has("url"))
						subcns.put("url", cnsobject.getString("url"));
					else
						subcns.put("url", JSONObject.NULL);

					cns.put(subcns);

				}

				candijson.put("connectSocialNetwork", cns);
			} else
				candijson.put("connectSocialNetwork", JSONObject.NULL);

			if (arrObj1.has("family")) {

				JSONArray family = new JSONArray();

				JSONArray getfamily = (JSONArray) arrObj1.get("family");

				for (int i = 0; i < getfamily.length(); i++) {
					JSONObject subfamily = new JSONObject();
					JSONObject familyobject = (JSONObject) getfamily.get(i);

					if (familyobject.has("name"))
						subfamily.put("name", familyobject.getString("name"));
					else
						subfamily.put("name", JSONObject.NULL);

					if (familyobject.has("occupation"))
						subfamily.put("occupation", familyobject.getString("occupation"));
					else
						subfamily.put("occupation", JSONObject.NULL);

					if (familyobject.has("location"))
						subfamily.put("location", familyobject.getString("location"));
					else
						subfamily.put("location", JSONObject.NULL);

					if (familyobject.has("relationship"))
						subfamily.put("relationship", familyobject.getString("relationship"));
					else
						subfamily.put("relationship", JSONObject.NULL);

					family.put(subfamily);

				}

				candijson.put("family", family);
			} else
				candijson.put("family", JSONObject.NULL);

			if (arrObj1.has("referral")) {

				JSONArray referal = new JSONArray();

				JSONArray getreferal = (JSONArray) arrObj1.get("referral");

				for (int i = 0; i < getreferal.length(); i++) {
					JSONObject subreferral = new JSONObject();
					JSONObject referralobject = (JSONObject) getreferal.get(i);

					if (referralobject.has("name"))
						subreferral.put("name", referralobject.getString("name"));
					else
						subreferral.put("name", JSONObject.NULL);

					if (referralobject.has("officeEmail"))
						subreferral.put("officeEmail", referralobject.getString("officeEmail"));
					else
						subreferral.put("officeEmail", JSONObject.NULL);

					if (referralobject.has("officePhone"))
						subreferral.put("officePhone", referralobject.getString("officePhone"));
					else
						subreferral.put("officePhone", JSONObject.NULL);

					if (referralobject.has("company"))
						subreferral.put("company", referralobject.getString("company"));
					else
						subreferral.put("company", JSONObject.NULL);

					if (referralobject.has("title"))
						subreferral.put("title", referralobject.getString("title"));
					else
						subreferral.put("title", JSONObject.NULL);

					if (referralobject.has("description"))
						subreferral.put("description", referralobject.getString("description"));
					else
						subreferral.put("description", JSONObject.NULL);

					referal.put(subreferral);

				}

				candijson.put("referral", referal);
			} else
				candijson.put("referral", JSONObject.NULL);

		}

		return candijson.toString();
	}
	
	// to Get federated & id to get Candidate profile with html,resume
	
	@RequestMapping(value = "/ElasticAPI/candfedid", method = { RequestMethod.GET })
	public @ResponseBody String getCandidateFederatedId(@RequestParam("id") String id,
			@RequestParam("federated") String federated)
			throws JSONException, URISyntaxException, MalformedURLException {

		JSONObject candijson = new JSONObject();

		String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
				+ id + "\")AND(federated:\"" + federated + "\")";

		System.out.println("url :: " + candidateUrl);

		URL urlcandiateProfile = new URL(candidateUrl);

		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateUrl);
		String jsonCandidateData = "";
		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

		JSONObject jsonAttach = new JSONObject(jsonCandidateData);
		JSONObject hits = jsonAttach.getJSONObject("hits");

		JSONArray hitsArr = hits.getJSONArray("hits");

		for (int k = 0; k < hitsArr.length(); k++) {

			JSONObject arrobj = (JSONObject) hitsArr.get(k);
			JSONObject arrObj1 = arrobj.getJSONObject("_source");

			if (arrObj1.has("id"))
				candijson.put("id", arrObj1.getString("id"));
			else
				candijson.put("id", JSONObject.NULL);
					
			if (arrObj1.has("name"))
				candijson.put("name", arrObj1.getString("name"));
			else
				candijson.put("name", JSONObject.NULL);

			if (arrObj1.has("first_name"))
				candijson.put("first_name", arrObj1.getString("first_name"));
			else
				candijson.put("first_name", JSONObject.NULL);

			if (arrObj1.has("middle_name"))
				candijson.put("middle_name", arrObj1.getString("middle_name"));
			else
				candijson.put("middle_name", JSONObject.NULL);

			if (arrObj1.has("last_name"))
				candijson.put("last_name", arrObj1.getString("last_name"));
			else
				candijson.put("last_name", JSONObject.NULL);

			if (arrObj1.has("username"))
				candijson.put("username", arrObj1.getString("username"));
			else
				candijson.put("username", JSONObject.NULL);

			if (arrObj1.has("email"))
				candijson.put("email", arrObj1.getString("email"));
			else
				candijson.put("email", JSONObject.NULL);

			if (arrObj1.has("alternateEmail"))
				candijson.put("alternateEmail", (JSONArray) arrObj1.get("alternateEmail"));
			else
				candijson.put("alternateEmail", JSONObject.NULL);

			if (arrObj1.has("birthdate"))
				candijson.put("birthdate", arrObj1.getString("birthdate"));
			else
				candijson.put("birthdate", JSONObject.NULL);

			if (arrObj1.has("age"))
				candijson.put("age", arrObj1.getInt("age"));
			else
				candijson.put("age", JSONObject.NULL);

			if (arrObj1.has("gender"))
				candijson.put("gender", arrObj1.getString("gender"));
			else
				candijson.put("gender", JSONObject.NULL);

			if (arrObj1.has("picture"))
				candijson.put("picture", arrObj1.get("picture"));
			else
				candijson.put("picture", JSONObject.NULL);

			if (arrObj1.has("profile"))
				candijson.put("profile", arrObj1.getString("profile"));
			else
				candijson.put("profile", JSONObject.NULL);

			if (arrObj1.has("mobileNumber"))
				candijson.put("mobileNumber", arrObj1.getString("mobileNumber"));
			else
				candijson.put("mobileNumber", JSONObject.NULL);

			if (arrObj1.has("alternateMobileNumber"))
				candijson.put("alternateMobileNumber", (JSONArray) arrObj1.get("alternateMobileNumber"));
			else
				candijson.put("alternateMobileNumber", JSONObject.NULL);

			if (arrObj1.has("officePhone"))
				candijson.put("officePhone", arrObj1.getString("officePhone"));
			else
				candijson.put("officePhone", JSONObject.NULL);

			if (arrObj1.has("officePhoneExtention"))
				candijson.put("officePhoneExtention", arrObj1.getString("officePhoneExtention"));
			else
				candijson.put("officePhoneExtention", JSONObject.NULL);

			if (arrObj1.has("isMobileNumberVerified"))
				candijson.put("isMobileNumberVerified", (Boolean) arrObj1.get("isMobileNumberVerified"));
			else
				candijson.put("isMobileNumberVerified", JSONObject.NULL);

			if (arrObj1.has("religion"))
				candijson.put("religion", arrObj1.getString("religion"));
			else
				candijson.put("religion", JSONObject.NULL);

			if (arrObj1.has("maritalStatus"))
				candijson.put("maritalStatus", arrObj1.getString("maritalStatus"));
			else
				candijson.put("maritalStatus", JSONObject.NULL);

			if (arrObj1.has("federated"))
				candijson.put("federated", arrObj1.getString("federated"));
			else
				candijson.put("federated", JSONObject.NULL);


			if (arrObj1.has("address")) {
				
				JSONObject addressJson1 = null;
				JSONObject addressJson = (JSONObject) arrObj1.get("address");

				if (addressJson.has("permanentAddress")) {

					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("permanentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("permanentAddress", addressJ);
				}

				if (addressJson.has("currentAddress")) {
					JSONObject addressJ = new JSONObject();

					addressJson1 = (JSONObject) addressJson.get("currentAddress");

					if (addressJson1.has("country"))
						addressJ.put("country", addressJson1.getString("country"));
					else
						addressJ.put("country", JSONObject.NULL);

					if (addressJson1.has("state"))
						addressJ.put("state", addressJson1.getString("state"));
					else
						addressJ.put("state", JSONObject.NULL);

					if (addressJson1.has("city"))
						addressJ.put("city", addressJson1.getString("city"));
					else
						addressJ.put("city", JSONObject.NULL);

					if (addressJson1.has("street"))
						addressJ.put("street", addressJson1.getString("street"));
					else
						addressJ.put("street", JSONObject.NULL);

					if (addressJson1.has("pincode"))
						addressJ.put("pincode", addressJson1.getString("pincode"));
					else
						addressJ.put("pincode", JSONObject.NULL);

					if (addressJson1.has("location"))
						addressJ.put("location", addressJson1.getString("location"));
					else
						addressJ.put("location", JSONObject.NULL);

					candijson.put("currentAddress", addressJ);
				}
			} else
				candijson.put("address", JSONObject.NULL);

			if (arrObj1.has("notification")) {

				JSONObject notification = new JSONObject();
				JSONObject getnotification = (JSONObject) arrObj1.get("notification");

				if (getnotification.has("resumeDownload"))
					notification.put("resumeDownload", (Boolean) getnotification.get("resumeDownload"));
				else
					notification.put("resumeDownload", JSONObject.NULL);

				if (getnotification.has("profileViewed"))
					notification.put("profileViewed", (Boolean) getnotification.get("profileViewed"));
				else
					notification.put("profileViewed", JSONObject.NULL);

				if (getnotification.has("newJobPost"))
					notification.put("newJobPost", (Boolean) getnotification.get("newJobPost"));
				else
					notification.put("newJobPost", JSONObject.NULL);

				if (getnotification.has("recruiterConnect"))
					notification.put("recruiterConnect", (Boolean) getnotification.get("recruiterConnect"));
				else
					notification.put("recruiterConnect", JSONObject.NULL);

				if (getnotification.has("google"))
					notification.put("google", (Boolean) getnotification.get("google"));
				else
					notification.put("google", JSONObject.NULL);

				if (getnotification.has("twitter"))
					notification.put("twitter", (Boolean) getnotification.get("twitter"));
				else
					notification.put("twitter", JSONObject.NULL);

				if (getnotification.has("linkedIn"))
					notification.put("linkedIn", (Boolean) getnotification.get("linkedIn"));
				else
					notification.put("linkedIn", JSONObject.NULL);

				if (getnotification.has("facebook"))
					notification.put("facebook", (Boolean) getnotification.get("facebook"));
				else
					notification.put("facebook", JSONObject.NULL);

				candijson.put("notification", notification);
			} else
				candijson.put("notification", JSONObject.NULL);

			if (arrObj1.has("jobType"))
				candijson.put("jobType", arrObj1.getString("jobType"));
			else
				candijson.put("jobType", JSONObject.NULL);

			if (arrObj1.has("employmentType"))
				candijson.put("employmentType", arrObj1.getString("employmentType"));
			else
				candijson.put("employmentType", JSONObject.NULL);

			if (arrObj1.has("createdDate"))
				candijson.put("createdDate", arrObj1.getString("createdDate"));
			else
				candijson.put("createdDate", JSONObject.NULL);

			if (arrObj1.has("lastModified"))
				candijson.put("lastModified", arrObj1.getString("lastModified"));
			else
				candijson.put("lastModified", JSONObject.NULL);

			if (arrObj1.has("createdBy"))
				candijson.put("createdBy", arrObj1.getString("createdBy"));
			else
				candijson.put("createdBy", JSONObject.NULL);

			if (arrObj1.has("lastModifiedBy"))
				candijson.put("lastModifiedBy", arrObj1.getString("lastModifiedBy"));
			else
				candijson.put("lastModifiedBy", JSONObject.NULL);

			if (arrObj1.has("aadharCardNo"))
				candijson.put("aadharCardNo", arrObj1.getString("aadharCardNo"));
			else
				candijson.put("aadharCardNo", JSONObject.NULL);

			if (arrObj1.has("passportNo"))
				candijson.put("passportNo", arrObj1.getString("passportNo"));
			else
				candijson.put("passportNo", JSONObject.NULL);

			if (arrObj1.has("passportValidity"))
				candijson.put("passportValidity", arrObj1.getString("passportValidity"));
			else
				candijson.put("passportValidity", JSONObject.NULL);

			if (arrObj1.has("panNo"))
				candijson.put("panNo", arrObj1.getString("panNo"));
			else
				candijson.put("panNo", JSONObject.NULL);

			if (arrObj1.has("areaOfSpecialization"))
				candijson.put("areaOfSpecialization", arrObj1.getString("areaOfSpecialization"));
			else
				candijson.put("areaOfSpecialization", JSONObject.NULL);

			if (arrObj1.has("category"))
				candijson.put("category", arrObj1.getString("category"));
			else
				candijson.put("category", JSONObject.NULL);

			if (arrObj1.has("confidential"))
				candijson.put("confidential", (Boolean) arrObj1.get("confidential"));
			else
				candijson.put("confidential", JSONObject.NULL);

			if (arrObj1.has("employmentStatus"))
				candijson.put("employmentStatus", arrObj1.getString("employmentStatus"));
			else
				candijson.put("employmentStatus", JSONObject.NULL);

			if (arrObj1.has("nationality"))
				candijson.put("nationality", arrObj1.getString("nationality"));
			else
				candijson.put("nationality", JSONObject.NULL);

			if (arrObj1.has("exNationality"))
				candijson.put("exNationality", arrObj1.getInt("exNationality"));
			else
				candijson.put("exNationality", JSONObject.NULL);

			if (arrObj1.has("experiencedIndustry"))
				candijson.put("experiencedIndustry", arrObj1.getString("experiencedIndustry"));
			else
				candijson.put("experiencedIndustry", JSONObject.NULL);

			if (arrObj1.has("experiencedFunctionalArea"))
				candijson.put("experiencedFunctionalArea", arrObj1.getString("experiencedFunctionalArea"));
			else
				candijson.put("experiencedFunctionalArea", JSONObject.NULL);

			if (arrObj1.has("language"))
				candijson.put("language", arrObj1.getString("language"));
			else
				candijson.put("language", JSONObject.NULL);

			if (arrObj1.has("notes"))
				candijson.put("notes", arrObj1.getString("notes"));
			else
				candijson.put("notes", JSONObject.NULL);

			if (arrObj1.has("preferredLocation"))
				candijson.put("preferredLocation", arrObj1.getString("preferredLocation"));
			else
				candijson.put("preferredLocation", JSONObject.NULL);

			if (arrObj1.has("physicallyChallenged"))
				candijson.put("physicallyChallenged", arrObj1.getString("physicallyChallenged"));
			else
				candijson.put("physicallyChallenged", JSONObject.NULL);

			if (arrObj1.has("reasonForLeaving"))
				candijson.put("reasonForLeaving", arrObj1.getString("reasonForLeaving"));
			else
				candijson.put("reasonForLeaving", JSONObject.NULL);

			if (arrObj1.has("reasonForRelocate"))
				candijson.put("reasonForRelocate", arrObj1.getString("reasonForRelocate"));
			else
				candijson.put("reasonForRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToRelocate"))
				candijson.put("willingToRelocate", arrObj1.getString("willingToRelocate"));
			else
				candijson.put("willingToRelocate", JSONObject.NULL);

			if (arrObj1.has("willingToChangeJob"))
				candijson.put("willingToChangeJob", arrObj1.getString("willingToChangeJob"));
			else
				candijson.put("willingToChangeJob", JSONObject.NULL);

			if (arrObj1.has("resumeHeadLine"))
				candijson.put("resumeHeadLine", arrObj1.getString("resumeHeadLine"));
			else
				candijson.put("resumeHeadLine", JSONObject.NULL);

			if (arrObj1.has("experienced"))
				candijson.put("experienced", (Boolean) arrObj1.get("experienced"));
			else
				candijson.put("experienced", JSONObject.NULL);

			if (arrObj1.has("fresher"))
				candijson.put("fresher", (Boolean) arrObj1.get("fresher"));
			else
				candijson.put("fresher", JSONObject.NULL);

			if (arrObj1.has("skillSummary"))
				candijson.put("skillSummary", arrObj1.getString("skillSummary"));
			else
				candijson.put("skillSummary", JSONObject.NULL);

			if (arrObj1.has("skills")) {
				JSONArray SkillsObj = new JSONArray();

				JSONObject getskillobject = new JSONObject();

				JSONArray skillList = (JSONArray) arrObj1.get("skills");

				for (int i = 0; i < skillList.length(); i++) {

					getskillobject = (JSONObject) skillList.get(i);
					JSONObject Skills = new JSONObject();

					if (getskillobject.has("keySkill"))
						Skills.put("keySkill", getskillobject.getString("keySkill"));
					else
						Skills.put("keySkill", JSONObject.NULL);

					if (getskillobject.has("experience"))
						Skills.put("experience", getskillobject.getString("experience"));
					else
						Skills.put("experience", JSONObject.NULL);

					if (getskillobject.has("fromMonth"))
						Skills.put("fromMonth", getskillobject.getString("fromMonth"));
					else
						Skills.put("fromMonth", JSONObject.NULL);

					if (getskillobject.has("fromYear"))
						Skills.put("fromYear", getskillobject.getString("fromYear"));
					else
						Skills.put("fromYear", JSONObject.NULL);

					if (getskillobject.has("toMonth"))
						Skills.put("toMonth", getskillobject.getString("toMonth"));
					else
						Skills.put("toMonth", JSONObject.NULL);

					if (getskillobject.has("toYear"))
						Skills.put("toYear", getskillobject.getString("toYear"));
					else
						Skills.put("toYear", JSONObject.NULL);

					SkillsObj.put(Skills);
				}

				candijson.put("skills", SkillsObj);
			}

			else
				candijson.put("skills", JSONObject.NULL);

			if (arrObj1.has("education")) {
				JSONObject education = new JSONObject();

				JSONObject educationjson = (JSONObject) arrObj1.get("education");

				if (educationjson.has("ug")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("ug");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("ug", subEdu);
				} else
					education.put("ug", JSONObject.NULL);

				if (educationjson.has("pg")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("pg");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("pg", subEdu);

				} else
					education.put("pg", JSONObject.NULL); // end pg

				if (educationjson.has("doctorate")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("doctorate");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("doctorate", subEdu);

				} else
					education.put("doctorate", JSONObject.NULL);

				if (educationjson.has("diploma")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("diploma");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("diploma", subEdu);

				} else
					education.put("diploma", JSONObject.NULL);

				if (educationjson.has("twelveth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("twelveth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("twelveth", subEdu);

				} else
					education.put("twelveth", JSONObject.NULL);

				if (educationjson.has("tenth")) {

					JSONObject subEdu = new JSONObject();

					JSONObject educationjson1 = (JSONObject) educationjson.get("tenth");

					if (educationjson1.has("degree"))
						subEdu.put("degree", educationjson1.getString("degree"));
					else
						subEdu.put("degree", JSONObject.NULL);

					if (educationjson1.has("degreeType"))
						subEdu.put("degreeType", educationjson1.getString("degreeType"));
					else
						subEdu.put("degreeType", JSONObject.NULL);

					if (educationjson1.has("course"))
						subEdu.put("course", educationjson1.getString("course"));
					else
						subEdu.put("course", JSONObject.NULL);

					if (educationjson1.has("institute"))
						subEdu.put("institute", educationjson1.getString("institute"));
					else
						subEdu.put("institute", JSONObject.NULL);

					if (educationjson1.has("universityOrBoard"))
						subEdu.put("universityOrBoard", educationjson1.getString("universityOrBoard"));
					else
						subEdu.put("universityOrBoard", JSONObject.NULL);

					if (educationjson1.has("city"))
						subEdu.put("city", educationjson1.getString("city"));
					else
						subEdu.put("city", JSONObject.NULL);

					if (educationjson1.has("fromMonth"))
						subEdu.put("fromMonth", educationjson1.getString("fromMonth"));
					else
						subEdu.put("fromMonth", JSONObject.NULL);

					if (educationjson1.has("fromYear"))
						subEdu.put("fromYear", educationjson1.getString("fromYear"));
					else
						subEdu.put("fromYear", JSONObject.NULL);

					if (educationjson1.has("toMonth"))
						subEdu.put("toMonth", educationjson1.getString("toMonth"));
					else
						subEdu.put("toMonth", JSONObject.NULL);

					if (educationjson1.has("toYear"))
						subEdu.put("toYear", educationjson1.getString("toYear"));
					else
						subEdu.put("toYear", JSONObject.NULL);

					if (educationjson1.has("percentage"))
						subEdu.put("percentage", educationjson1.getString("percentage"));
					else
						subEdu.put("percentage", JSONObject.NULL);

					education.put("tenth", subEdu);

				} else
					education.put("tenth", JSONObject.NULL);

				candijson.put("education", education);
			} else
				candijson.put("education", JSONObject.NULL);

			if (arrObj1.has("employment")) {

				JSONObject employement = new JSONObject();

				JSONObject getemployment = arrObj1.getJSONObject("employment");

				if (getemployment.has("current")) {

					JSONObject current = new JSONObject();
					JSONObject getcurrent = getemployment.getJSONObject("current");

					if (getcurrent.has("companyName"))
						current.put("companyName", getcurrent.getString("companyName"));
					else
						current.put("companyName", JSONObject.NULL);

					if (getcurrent.has("designation"))
						current.put("designation", getcurrent.getString("designation"));
					else
						current.put("designation", JSONObject.NULL);

					if (getcurrent.has("isCurrent"))
						current.put("isCurrent", getcurrent.get("isCurrent"));
					else
						current.put("isCurrent", JSONObject.NULL);

					if (getcurrent.has("desc"))
						current.put("desc", getcurrent.getString("desc"));
					else
						current.put("desc", JSONObject.NULL);

					if (getcurrent.has("workLocation"))
						current.put("workLocation", getcurrent.getString("workLocation"));
					else
						current.put("workLocation", JSONObject.NULL);

					if (getcurrent.has("role"))
						current.put("role", getcurrent.getString("role"));
					else
						current.put("role", JSONObject.NULL);

					if (getcurrent.has("level"))
						current.put("level", getcurrent.getString("level"));
					else
						current.put("level", JSONObject.NULL);

					if (getcurrent.has("teamSize"))
						current.put("teamSize", getcurrent.getString("teamSize"));
					else
						current.put("teamSize", JSONObject.NULL);

					employement.put("current", current);
				} else
					employement.put("current", JSONObject.NULL);

				if (getemployment.has("previous")) {

					JSONArray previous = new JSONArray();

					JSONArray getprevious = getemployment.getJSONArray("previous");
					int i = 0;

					for (i = 0; i < getprevious.length(); i++) {

						JSONObject jsonprevious = (JSONObject) getprevious.get(i);

						if (jsonprevious.has("organization"))
							jsonprevious.put("organization", jsonprevious.getString("organization"));
						else
							jsonprevious.put("organization", JSONObject.NULL);

						if (jsonprevious.has("designation"))
							jsonprevious.put("designation", jsonprevious.getString("designation"));
						else
							jsonprevious.put("designation", JSONObject.NULL);

						if (jsonprevious.has("level"))
							jsonprevious.put("level", jsonprevious.getString("level"));
						else
							jsonprevious.put("level", JSONObject.NULL);

						if (jsonprevious.has("city"))
							jsonprevious.put("city", jsonprevious.getString("city"));
						else
							jsonprevious.put("city", JSONObject.NULL);

						if (jsonprevious.has("fromMonth"))
							jsonprevious.put("fromMonth", jsonprevious.getString("fromMonth"));
						else
							jsonprevious.put("fromMonth", JSONObject.NULL);

						if (jsonprevious.has("fromYear"))
							jsonprevious.put("fromYear", jsonprevious.getString("fromYear"));
						else
							jsonprevious.put("fromYear", JSONObject.NULL);

						if (jsonprevious.has("toMonth"))
							jsonprevious.put("toMonth", jsonprevious.getString("toMonth"));
						else
							jsonprevious.put("toMonth", JSONObject.NULL);

						if (jsonprevious.has("toYear"))
							jsonprevious.put("toYear", jsonprevious.getString("toYear"));
						else
							jsonprevious.put("toYear", JSONObject.NULL);

						if (jsonprevious.has("description"))
							jsonprevious.put("description", jsonprevious.getString("description"));
						else
							jsonprevious.put("description", JSONObject.NULL);

						previous.put(jsonprevious);
					}
					employement.put("previous", previous);
				} else
					employement.put("previous", JSONObject.NULL);

				candijson.put("employment", employement);

			} else
				candijson.put("employment", JSONObject.NULL);

			/* salary array */

			if (arrObj1.has("salary") && !arrObj1.get("salary").equals(null)) {

				JSONObject getsalary = (JSONObject) arrObj1.get("salary");
				JSONObject salary = new JSONObject();

				if (getsalary.has("currentCTCType"))
					salary.put("currentCTCType", getsalary.getString("currentCTCType"));
				else
					salary.put("currentCTCType", JSONObject.NULL);

				if (getsalary.has("currentCTC"))
					salary.put("currentCTC", getsalary.getString("currentCTC"));
				else
					salary.put("currentCTC", JSONObject.NULL);

				if (getsalary.has("negotiableCTC"))
					salary.put("negotiableCTC", getsalary.getString("negotiableCTC"));
				else
					salary.put("negotiableCTC", JSONObject.NULL);

				if (getsalary.has("expectedCTCType"))
					salary.put("expectedCTCType", getsalary.getString("expectedCTCType"));
				else
					salary.put("expectedCTCType", JSONObject.NULL);

				if (getsalary.has("expectedCTC"))
					salary.put("expectedCTC", getsalary.getString("expectedCTC"));
				else
					salary.put("expectedCTC", JSONObject.NULL);

				if (getsalary.has("takeHome"))
					salary.put("takeHome", getsalary.getString("takeHome"));
				else
					salary.put("takeHome", JSONObject.NULL);

				if (getsalary.has("fixed"))
					salary.put("fixed", getsalary.getString("fixed"));
				else
					salary.put("fixed", JSONObject.NULL);

				candijson.put("salary", salary);

			} else
				candijson.put("salary", JSONObject.NULL);

			if (arrObj1.has("ctc"))
				candijson.put("ctc", (Double) arrObj1.get("ctc"));
			else
				candijson.put("ctc", JSONObject.NULL);

			if (arrObj1.has("exp"))
				candijson.put("exp", (Double) arrObj1.get("exp"));
			else
				candijson.put("exp", JSONObject.NULL);

			/* experience array */

			if (arrObj1.has("experience")) {

				JSONObject experience = new JSONObject();

				JSONObject getexperience = (JSONObject) arrObj1.get("experience");

				if (getexperience.has("months"))
					experience.put("months", (Integer) getexperience.get("months"));
				else
					experience.put("months", JSONObject.NULL);

				if (getexperience.has("totalExperience"))
					experience.put("totalExperience", getexperience.getString("totalExperience"));
				else
					experience.put("totalExperience", JSONObject.NULL);

				if (getexperience.has("years"))
					experience.put("years", (Integer) getexperience.get("years"));
				else
					experience.put("years", JSONObject.NULL);

				candijson.put("experience", experience);

			} else
				candijson.put("experience", JSONObject.NULL);

			/* Achievements */

			if (arrObj1.has("achievement")) {

				JSONArray achievement = new JSONArray();
				JSONArray getachievement = arrObj1.getJSONArray("achievement");

				for (int i = 0; i < getachievement.length(); i++) {

					JSONObject Achievementobject = (JSONObject) getachievement.get(i);

					if (Achievementobject.has("achievementTitle"))
						Achievementobject.put("achievementTitle", Achievementobject.getString("achievementTitle"));
					else
						Achievementobject.put("achievementTitle", JSONObject.NULL);

					if (Achievementobject.has("achievementRole"))
						Achievementobject.put("achievementRole", Achievementobject.getString("achievementRole"));
					else
						Achievementobject.put("achievementRole", JSONObject.NULL);

					if (Achievementobject.has("achievementDescription"))
						Achievementobject.put("achievementDescription",
								Achievementobject.getString("achievementDescription"));
					else
						Achievementobject.put("achievementDescription", JSONObject.NULL);

					achievement.put(Achievementobject);
				}

				candijson.put("achievement", achievement);

			} else
				candijson.put("achievement", JSONObject.NULL);

			/* Certificates */

			if (arrObj1.has("certificates")) {

				JSONArray getcertificates = (JSONArray) arrObj1.get("certificates");
				JSONArray certificates = new JSONArray();

				for (int i = 0; i < getcertificates.length(); i++) {

					JSONObject certificatesobject = (JSONObject) getcertificates.get(i);

					if (certificatesobject.has("certificatesTitle"))
						certificatesobject.put("certificatesTitle", certificatesobject.getString("certificatesTitle"));
					else
						certificatesobject.put("certificatesTitle", JSONObject.NULL);

					if (certificatesobject.has("month"))
						certificatesobject.put("month", certificatesobject.getString("month"));
					else
						certificatesobject.put("month", JSONObject.NULL);

					if (certificatesobject.has("year"))
						certificatesobject.put("year", certificatesobject.getString("year"));
					else
						certificatesobject.put("year", JSONObject.NULL);

					if (certificatesobject.has("certificatesDescription"))
						certificatesobject.put("certificatesDescription",
								certificatesobject.getString("certificatesDescription"));
					else
						certificatesobject.put("certificatesDescription", JSONObject.NULL);

					certificates.put(certificatesobject);

				}

				candijson.put("certificates", certificates);
			} else
				candijson.put("certificates", JSONObject.NULL);

			/* Project */

			if (arrObj1.has("project")) {

				JSONArray project = new JSONArray();
				JSONArray getproject = (JSONArray) arrObj1.get("project");

				JSONObject projectobject = new JSONObject();

				for (int i = 0; i < getproject.length(); i++) {

					JSONObject projectObj = new JSONObject();

					projectobject = (JSONObject) getproject.get(i);

					if (projectobject.has("projectTitle"))
						projectObj.put("projectTitle", projectobject.getString("projectTitle"));
					else
						projectObj.put("projectTitle", JSONObject.NULL);

					if (projectobject.has("projectRole"))
						projectObj.put("projectRole", projectobject.getString("projectRole"));
					else
						projectObj.put("projectRole", JSONObject.NULL);

					if (projectobject.has("fromMonth"))
						projectObj.put("fromMonth", projectobject.getString("fromMonth"));
					else
						projectObj.put("fromMonth", JSONObject.NULL);

					if (projectobject.has("fromYear"))
						projectObj.put("fromYear", projectobject.getString("fromYear"));
					else
						projectObj.put("fromYear", JSONObject.NULL);

					if (projectobject.has("toMonth"))
						projectObj.put("toMonth", projectobject.getString("toMonth"));
					else
						projectObj.put("toMonth", JSONObject.NULL);

					if (projectobject.has("toYear"))
						projectObj.put("toYear", projectobject.getString("toYear"));
					else
						projectObj.put("toYear", JSONObject.NULL);

					if (projectobject.has("url"))
						projectObj.put("url", projectobject.getString("url"));
					else
						projectObj.put("url", JSONObject.NULL);

					if (projectobject.has("projectDescription"))
						projectObj.put("projectDescription", projectobject.getString("projectDescription"));
					else
						projectObj.put("projectDescription", JSONObject.NULL);

					project.put(projectObj);

				}

				candijson.put("project", project);
			} else
				candijson.put("project", JSONObject.NULL);

			/* html array */

			if (arrObj1.has("html")) {
				JSONObject gethtml = (JSONObject) arrObj1.get("html");
				JSONObject html = new JSONObject();

				if (gethtml.has("naukri")) {

					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();

					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", JSONObject.NULL);

					html.put("naukri", naukri);

				} else
					html.put("naukri", JSONObject.NULL);

				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

					JSONObject linkedIn = new JSONObject();

					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", JSONObject.NULL);

					html.put("linkedIn", linkedIn);

				} else
					html.put("linkedIn", JSONObject.NULL);

				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");

					JSONObject monster = new JSONObject();

					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", JSONObject.NULL);

					html.put("monster", monster);

				} else
					html.put("monster", JSONObject.NULL);

				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

					JSONObject naukriGulf = new JSONObject();

					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", JSONObject.NULL);

					html.put("naukriGulf", naukriGulf);

				} else
					html.put("naukriGulf", JSONObject.NULL);

				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

					JSONObject careerBuilder = new JSONObject();

					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", JSONObject.NULL);

					html.put("careerBuilder", careerBuilder);

				} else
					html.put("careerBuilder", JSONObject.NULL);

				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

					JSONObject monsterUS = new JSONObject();

					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", JSONObject.NULL);

					html.put("monsterUS", monsterUS);

				} else
					html.put("monsterUS", JSONObject.NULL);

				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");

					JSONObject dice = new JSONObject();

					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", JSONObject.NULL);

					html.put("dice", dice);

				} else
					html.put("dice", JSONObject.NULL);

				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

					JSONObject jobDiva = new JSONObject();

					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", JSONObject.NULL);

					html.put("jobDiva", jobDiva);

				} else
					html.put("jobDiva", JSONObject.NULL);

				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");

					JSONObject indeed = new JSONObject();

					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", JSONObject.NULL);

					html.put("indeed", indeed);

				} else
					html.put("indeed", JSONObject.NULL);

				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

					JSONObject jobServe = new JSONObject();

					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", JSONObject.NULL);

					html.put("jobServe", jobServe);

				} else
					html.put("jobServe", JSONObject.NULL);

				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");

					JSONObject other = new JSONObject();

					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", JSONObject.NULL);

					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", JSONObject.NULL);

					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", JSONObject.NULL);

					html.put("other", other);

				} else
					html.put("other", JSONObject.NULL);

				candijson.put("html", html);
			} else
				candijson.put("html", JSONObject.NULL);

			if (arrObj1.has("resumeName"))
				candijson.put("resumeName", arrObj1.get("resumeName"));
			else
				candijson.put("resumeName", JSONObject.NULL);

			if (arrObj1.has("resume"))
				candijson.put("resume", arrObj1.get("resume"));
			else
				candijson.put("resume", JSONObject.NULL);

			if (arrObj1.has("connectSocialNetwork")) {

				JSONArray cns = new JSONArray();

				JSONArray getcns = (JSONArray) arrObj1.get("connectSocialNetwork");

				for (int i = 0; i < getcns.length(); i++) {
					JSONObject subcns = new JSONObject();
					JSONObject cnsobject = (JSONObject) getcns.get(i);

					if (cnsobject.has("name"))
						subcns.put("name", cnsobject.getString("name"));
					else
						subcns.put("name", JSONObject.NULL);

					if (cnsobject.has("url"))
						subcns.put("url", cnsobject.getString("url"));
					else
						subcns.put("url", JSONObject.NULL);

					cns.put(subcns);

				}

				candijson.put("connectSocialNetwork", cns);
			} else
				candijson.put("connectSocialNetwork", JSONObject.NULL);

			if (arrObj1.has("family")) {

				JSONArray family = new JSONArray();

				JSONArray getfamily = (JSONArray) arrObj1.get("family");

				for (int i = 0; i < getfamily.length(); i++) {
					JSONObject subfamily = new JSONObject();
					JSONObject familyobject = (JSONObject) getfamily.get(i);

					if (familyobject.has("name"))
						subfamily.put("name", familyobject.getString("name"));
					else
						subfamily.put("name", JSONObject.NULL);

					if (familyobject.has("occupation"))
						subfamily.put("occupation", familyobject.getString("occupation"));
					else
						subfamily.put("occupation", JSONObject.NULL);

					if (familyobject.has("location"))
						subfamily.put("location", familyobject.getString("location"));
					else
						subfamily.put("location", JSONObject.NULL);

					if (familyobject.has("relationship"))
						subfamily.put("relationship", familyobject.getString("relationship"));
					else
						subfamily.put("relationship", JSONObject.NULL);

					family.put(subfamily);

				}

				candijson.put("family", family);
			} else
				candijson.put("family", JSONObject.NULL);

			if (arrObj1.has("referral")) {

				JSONArray referal = new JSONArray();

				JSONArray getreferal = (JSONArray) arrObj1.get("referral");

				for (int i = 0; i < getreferal.length(); i++) {
					JSONObject subreferral = new JSONObject();
					JSONObject referralobject = (JSONObject) getreferal.get(i);

					if (referralobject.has("name"))
						subreferral.put("name", referralobject.getString("name"));
					else
						subreferral.put("name", JSONObject.NULL);

					if (referralobject.has("officeEmail"))
						subreferral.put("officeEmail", referralobject.getString("officeEmail"));
					else
						subreferral.put("officeEmail", JSONObject.NULL);

					if (referralobject.has("officePhone"))
						subreferral.put("officePhone", referralobject.getString("officePhone"));
					else
						subreferral.put("officePhone", JSONObject.NULL);

					if (referralobject.has("company"))
						subreferral.put("company", referralobject.getString("company"));
					else
						subreferral.put("company", JSONObject.NULL);

					if (referralobject.has("title"))
						subreferral.put("title", referralobject.getString("title"));
					else
						subreferral.put("title", JSONObject.NULL);

					if (referralobject.has("description"))
						subreferral.put("description", referralobject.getString("description"));
					else
						subreferral.put("description", JSONObject.NULL);

					referal.put(subreferral);

				}

				candijson.put("referral", referal);
			} else
				candijson.put("referral", JSONObject.NULL);

		}

		return candijson.toString();
	}

	/// behalf of empid to get html and fedrated,id
	
		@RequestMapping(value = "/ElasticAPI/empid", method = { RequestMethod.GET })
		public @ResponseBody String getCandidateEmpIdFed(@RequestParam("empid") String empid,
				@RequestParam("federated") String federated)
				throws JSONException, URISyntaxException, MalformedURLException {
		
			JSONObject candijson = new JSONObject();
		
		//	String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(id:\""
		//			+ id + "\")AND(federated:\"" + federated + "\")";
			String candidateUrl ="";
		//	naukriIndia
			if (!empid.equals("") && federated.equals("naukriIndia")) {
				candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.naukri.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
				System.out.println("url :: " + candidateUrl);
			
				URL urlcandiateProfile = new URL(candidateUrl);
			
				URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
						urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
						urlcandiateProfile.getQuery(), candidateUrl);
				String jsonCandidateData = "";
				jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
			
				JSONObject jsonAttach = new JSONObject(jsonCandidateData);
				JSONObject hits = jsonAttach.getJSONObject("hits");
			
				JSONArray hitsArr = hits.getJSONArray("hits");
			
				for (int k = 0; k < hitsArr.length(); k++) {
			
					JSONObject arrobj = (JSONObject) hitsArr.get(k);
					JSONObject arrObj1 = arrobj.getJSONObject("_source");
			
					if (arrObj1.has("id"))
						candijson.put("id", arrObj1.getString("id"));
					else
						candijson.put("id", JSONObject.NULL);
			
					
					if (arrObj1.has("federated"))
						candijson.put("federated", arrObj1.getString("federated"));
					else
						candijson.put("federated", JSONObject.NULL);
			
			
					/* html array */
			
					if (arrObj1.has("html")) {
						JSONObject gethtml = (JSONObject) arrObj1.get("html");
						JSONObject html = new JSONObject();
			
						if (gethtml.has("naukri")) {
			
							JSONObject subHTML = (JSONObject) gethtml.get("naukri");
							JSONObject naukri = new JSONObject();
			
							if (subHTML.has("empId"))
								naukri.put("empId", subHTML.getString("empId"));
							else
								naukri.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								naukri.put("lastModified", subHTML.getString("lastModified"));
							else
								naukri.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								naukri.put("html", subHTML.getString("html"));
							else
								naukri.put("html", JSONObject.NULL);
			
							html.put("naukri", naukri);
			
						} else
							html.put("naukri", JSONObject.NULL);
			
						if (gethtml.has("linkedIn")) {
							JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
			
							JSONObject linkedIn = new JSONObject();
			
							if (subHTML.has("empId"))
								linkedIn.put("empId", subHTML.getString("empId"));
							else
								linkedIn.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								linkedIn.put("lastModified", subHTML.getString("lastModified"));
							else
								linkedIn.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								linkedIn.put("html", subHTML.getString("html"));
							else
								linkedIn.put("html", JSONObject.NULL);
			
							html.put("linkedIn", linkedIn);
			
						} else
							html.put("linkedIn", JSONObject.NULL);
			
						if (gethtml.has("monster")) {
							JSONObject subHTML = (JSONObject) gethtml.get("monster");
			
							JSONObject monster = new JSONObject();
			
							if (subHTML.has("empId"))
								monster.put("empId", subHTML.getString("empId"));
							else
								monster.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								monster.put("lastModified", subHTML.getString("lastModified"));
							else
								monster.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								monster.put("html", subHTML.getString("html"));
							else
								monster.put("html", JSONObject.NULL);
			
							html.put("monster", monster);
			
						} else
							html.put("monster", JSONObject.NULL);
			
						if (gethtml.has("naukriGulf")) {
							JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
			
							JSONObject naukriGulf = new JSONObject();
			
							if (subHTML.has("empId"))
								naukriGulf.put("empId", subHTML.getString("empId"));
							else
								naukriGulf.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								naukriGulf.put("lastModified", subHTML.getString("lastModified"));
							else
								naukriGulf.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								naukriGulf.put("html", subHTML.getString("html"));
							else
								naukriGulf.put("html", JSONObject.NULL);
			
							html.put("naukriGulf", naukriGulf);
			
						} else
							html.put("naukriGulf", JSONObject.NULL);
			
						if (gethtml.has("careerBuilder")) {
							JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
			
							JSONObject careerBuilder = new JSONObject();
			
							if (subHTML.has("empId"))
								careerBuilder.put("empId", subHTML.getString("empId"));
							else
								careerBuilder.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								careerBuilder.put("lastModified", subHTML.getString("lastModified"));
							else
								careerBuilder.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								careerBuilder.put("html", subHTML.getString("html"));
							else
								careerBuilder.put("html", JSONObject.NULL);
			
							html.put("careerBuilder", careerBuilder);
			
						} else
							html.put("careerBuilder", JSONObject.NULL);
			
						if (gethtml.has("monsterUS")) {
							JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
			
							JSONObject monsterUS = new JSONObject();
			
							if (subHTML.has("empId"))
								monsterUS.put("empId", subHTML.getString("empId"));
							else
								monsterUS.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								monsterUS.put("lastModified", subHTML.getString("lastModified"));
							else
								monsterUS.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								monsterUS.put("html", subHTML.getString("html"));
							else
								monsterUS.put("html", JSONObject.NULL);
			
							html.put("monsterUS", monsterUS);
			
						} else
							html.put("monsterUS", JSONObject.NULL);
			
						if (gethtml.has("dice")) {
							JSONObject subHTML = (JSONObject) gethtml.get("dice");
			
							JSONObject dice = new JSONObject();
			
							if (subHTML.has("empId"))
								dice.put("empId", subHTML.getString("empId"));
							else
								dice.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								dice.put("lastModified", subHTML.getString("lastModified"));
							else
								dice.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								dice.put("html", subHTML.getString("html"));
							else
								dice.put("html", JSONObject.NULL);
			
							html.put("dice", dice);
			
						} else
							html.put("dice", JSONObject.NULL);
			
						if (gethtml.has("jobDiva")) {
							JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
			
							JSONObject jobDiva = new JSONObject();
			
							if (subHTML.has("empId"))
								jobDiva.put("empId", subHTML.getString("empId"));
							else
								jobDiva.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								jobDiva.put("lastModified", subHTML.getString("lastModified"));
							else
								jobDiva.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								jobDiva.put("html", subHTML.getString("html"));
							else
								jobDiva.put("html", JSONObject.NULL);
			
							html.put("jobDiva", jobDiva);
			
						} else
							html.put("jobDiva", JSONObject.NULL);
			
						if (gethtml.has("indeed")) {
							JSONObject subHTML = (JSONObject) gethtml.get("indeed");
			
							JSONObject indeed = new JSONObject();
			
							if (subHTML.has("empId"))
								indeed.put("empId", subHTML.getString("empId"));
							else
								indeed.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								indeed.put("lastModified", subHTML.getString("lastModified"));
							else
								indeed.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								indeed.put("html", subHTML.getString("html"));
							else
								indeed.put("html", JSONObject.NULL);
			
							html.put("indeed", indeed);
			
						} else
							html.put("indeed", JSONObject.NULL);
			
						if (gethtml.has("jobServe")) {
							JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
			
							JSONObject jobServe = new JSONObject();
			
							if (subHTML.has("empId"))
								jobServe.put("empId", subHTML.getString("empId"));
							else
								jobServe.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								jobServe.put("lastModified", subHTML.getString("lastModified"));
							else
								jobServe.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								jobServe.put("html", subHTML.getString("html"));
							else
								jobServe.put("html", JSONObject.NULL);
			
							html.put("jobServe", jobServe);
			
						} else
							html.put("jobServe", JSONObject.NULL);
			
						if (gethtml.has("other")) {
							JSONObject subHTML = (JSONObject) gethtml.get("other");
			
							JSONObject other = new JSONObject();
			
							if (subHTML.has("empId"))
								other.put("empId", subHTML.getString("empId"));
							else
								other.put("empId", JSONObject.NULL);
			
							if (subHTML.has("lastModified"))
								other.put("lastModified", subHTML.getString("lastModified"));
							else
								other.put("lastModified", JSONObject.NULL);
			
							if (subHTML.has("html"))
								other.put("html", subHTML.getString("html"));
							else
								other.put("html", JSONObject.NULL);
			
							html.put("other", other);
			
						} else
							html.put("other", JSONObject.NULL);
			
						candijson.put("html", html);
					} else
						candijson.put("html", JSONObject.NULL);
				}
				return candijson.toString();
			}
			
			// linkedIn
	if (!empid.equals("") && federated.equals("linkedIn")) {
		candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.linkedIn.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
		System.out.println("url :: " + candidateUrl);
	
		URL urlcandiateProfile = new URL(candidateUrl);
	
		URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
				urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
				urlcandiateProfile.getQuery(), candidateUrl);
		String jsonCandidateData = "";
		jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
	
		JSONObject jsonAttach = new JSONObject(jsonCandidateData);
		JSONObject hits = jsonAttach.getJSONObject("hits");
	
		JSONArray hitsArr = hits.getJSONArray("hits");
	
		for (int k = 0; k < hitsArr.length(); k++) {
	
			JSONObject arrobj = (JSONObject) hitsArr.get(k);
			JSONObject arrObj1 = arrobj.getJSONObject("_source");
	
			if (arrObj1.has("id"))
				candijson.put("id", arrObj1.getString("id"));
			else
				candijson.put("id", JSONObject.NULL);
	
			
			if (arrObj1.has("federated"))
				candijson.put("federated", arrObj1.getString("federated"));
			else
				candijson.put("federated", JSONObject.NULL);
	
	
			/* html array */
	
			if (arrObj1.has("html")) {
				JSONObject gethtml = (JSONObject) arrObj1.get("html");
				JSONObject html = new JSONObject();
	
				if (gethtml.has("naukri")) {
	
					JSONObject subHTML = (JSONObject) gethtml.get("naukri");
					JSONObject naukri = new JSONObject();
	
					if (subHTML.has("empId"))
						naukri.put("empId", subHTML.getString("empId"));
					else
						naukri.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						naukri.put("lastModified", subHTML.getString("lastModified"));
					else
						naukri.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						naukri.put("html", subHTML.getString("html"));
					else
						naukri.put("html", JSONObject.NULL);
	
					html.put("naukri", naukri);
	
				} else
					html.put("naukri", JSONObject.NULL);
	
				if (gethtml.has("linkedIn")) {
					JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
	
					JSONObject linkedIn = new JSONObject();
	
					if (subHTML.has("empId"))
						linkedIn.put("empId", subHTML.getString("empId"));
					else
						linkedIn.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						linkedIn.put("lastModified", subHTML.getString("lastModified"));
					else
						linkedIn.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						linkedIn.put("html", subHTML.getString("html"));
					else
						linkedIn.put("html", JSONObject.NULL);
	
					html.put("linkedIn", linkedIn);
	
				} else
					html.put("linkedIn", JSONObject.NULL);
	
				if (gethtml.has("monster")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monster");
	
					JSONObject monster = new JSONObject();
	
					if (subHTML.has("empId"))
						monster.put("empId", subHTML.getString("empId"));
					else
						monster.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						monster.put("lastModified", subHTML.getString("lastModified"));
					else
						monster.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						monster.put("html", subHTML.getString("html"));
					else
						monster.put("html", JSONObject.NULL);
	
					html.put("monster", monster);
	
				} else
					html.put("monster", JSONObject.NULL);
	
				if (gethtml.has("naukriGulf")) {
					JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
	
					JSONObject naukriGulf = new JSONObject();
	
					if (subHTML.has("empId"))
						naukriGulf.put("empId", subHTML.getString("empId"));
					else
						naukriGulf.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						naukriGulf.put("lastModified", subHTML.getString("lastModified"));
					else
						naukriGulf.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						naukriGulf.put("html", subHTML.getString("html"));
					else
						naukriGulf.put("html", JSONObject.NULL);
	
					html.put("naukriGulf", naukriGulf);
	
				} else
					html.put("naukriGulf", JSONObject.NULL);
	
				if (gethtml.has("careerBuilder")) {
					JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
	
					JSONObject careerBuilder = new JSONObject();
	
					if (subHTML.has("empId"))
						careerBuilder.put("empId", subHTML.getString("empId"));
					else
						careerBuilder.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						careerBuilder.put("lastModified", subHTML.getString("lastModified"));
					else
						careerBuilder.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						careerBuilder.put("html", subHTML.getString("html"));
					else
						careerBuilder.put("html", JSONObject.NULL);
	
					html.put("careerBuilder", careerBuilder);
	
				} else
					html.put("careerBuilder", JSONObject.NULL);
	
				if (gethtml.has("monsterUS")) {
					JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
	
					JSONObject monsterUS = new JSONObject();
	
					if (subHTML.has("empId"))
						monsterUS.put("empId", subHTML.getString("empId"));
					else
						monsterUS.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						monsterUS.put("lastModified", subHTML.getString("lastModified"));
					else
						monsterUS.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						monsterUS.put("html", subHTML.getString("html"));
					else
						monsterUS.put("html", JSONObject.NULL);
	
					html.put("monsterUS", monsterUS);
	
				} else
					html.put("monsterUS", JSONObject.NULL);
	
				if (gethtml.has("dice")) {
					JSONObject subHTML = (JSONObject) gethtml.get("dice");
	
					JSONObject dice = new JSONObject();
	
					if (subHTML.has("empId"))
						dice.put("empId", subHTML.getString("empId"));
					else
						dice.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						dice.put("lastModified", subHTML.getString("lastModified"));
					else
						dice.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						dice.put("html", subHTML.getString("html"));
					else
						dice.put("html", JSONObject.NULL);
	
					html.put("dice", dice);
	
				} else
					html.put("dice", JSONObject.NULL);
	
				if (gethtml.has("jobDiva")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
	
					JSONObject jobDiva = new JSONObject();
	
					if (subHTML.has("empId"))
						jobDiva.put("empId", subHTML.getString("empId"));
					else
						jobDiva.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						jobDiva.put("lastModified", subHTML.getString("lastModified"));
					else
						jobDiva.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						jobDiva.put("html", subHTML.getString("html"));
					else
						jobDiva.put("html", JSONObject.NULL);
	
					html.put("jobDiva", jobDiva);
	
				} else
					html.put("jobDiva", JSONObject.NULL);
	
				if (gethtml.has("indeed")) {
					JSONObject subHTML = (JSONObject) gethtml.get("indeed");
	
					JSONObject indeed = new JSONObject();
	
					if (subHTML.has("empId"))
						indeed.put("empId", subHTML.getString("empId"));
					else
						indeed.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						indeed.put("lastModified", subHTML.getString("lastModified"));
					else
						indeed.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						indeed.put("html", subHTML.getString("html"));
					else
						indeed.put("html", JSONObject.NULL);
	
					html.put("indeed", indeed);
	
				} else
					html.put("indeed", JSONObject.NULL);
	
				if (gethtml.has("jobServe")) {
					JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
	
					JSONObject jobServe = new JSONObject();
	
					if (subHTML.has("empId"))
						jobServe.put("empId", subHTML.getString("empId"));
					else
						jobServe.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						jobServe.put("lastModified", subHTML.getString("lastModified"));
					else
						jobServe.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						jobServe.put("html", subHTML.getString("html"));
					else
						jobServe.put("html", JSONObject.NULL);
	
					html.put("jobServe", jobServe);
	
				} else
					html.put("jobServe", JSONObject.NULL);
	
				if (gethtml.has("other")) {
					JSONObject subHTML = (JSONObject) gethtml.get("other");
	
					JSONObject other = new JSONObject();
	
					if (subHTML.has("empId"))
						other.put("empId", subHTML.getString("empId"));
					else
						other.put("empId", JSONObject.NULL);
	
					if (subHTML.has("lastModified"))
						other.put("lastModified", subHTML.getString("lastModified"));
					else
						other.put("lastModified", JSONObject.NULL);
	
					if (subHTML.has("html"))
						other.put("html", subHTML.getString("html"));
					else
						other.put("html", JSONObject.NULL);
	
					html.put("other", other);
	
				} else
					html.put("other", JSONObject.NULL);
	
				candijson.put("html", html);
			} else
				candijson.put("html", JSONObject.NULL);
		}
		return candijson.toString();
	}
		
		//	monsterIndia
		if (!empid.equals("") && federated.equals("monsterIndia")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.monster.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}


		//	naukriGulf
		if (!empid.equals("") && federated.equals("naukriGulf")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.naukriGulf.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}

	
		//	careerBuilderUS
		if (!empid.equals("") && federated.equals("careerBuilderUS")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.careerBuilder.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}

		

		//	monsterUS
		if (!empid.equals("") && federated.equals("monsterUS")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.monsterUS.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}

//	dice
if (!empid.equals("") && federated.equals("dice")) {
	candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.dice.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
	System.out.println("url :: " + candidateUrl);

	URL urlcandiateProfile = new URL(candidateUrl);

	URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
			urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
			urlcandiateProfile.getQuery(), candidateUrl);
	String jsonCandidateData = "";
	jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	JSONObject jsonAttach = new JSONObject(jsonCandidateData);
	JSONObject hits = jsonAttach.getJSONObject("hits");

	JSONArray hitsArr = hits.getJSONArray("hits");

	for (int k = 0; k < hitsArr.length(); k++) {

		JSONObject arrobj = (JSONObject) hitsArr.get(k);
		JSONObject arrObj1 = arrobj.getJSONObject("_source");

		if (arrObj1.has("id"))
			candijson.put("id", arrObj1.getString("id"));
		else
			candijson.put("id", JSONObject.NULL);

		
		if (arrObj1.has("federated"))
			candijson.put("federated", arrObj1.getString("federated"));
		else
			candijson.put("federated", JSONObject.NULL);


		/* html array */

		if (arrObj1.has("html")) {
			JSONObject gethtml = (JSONObject) arrObj1.get("html");
			JSONObject html = new JSONObject();

			if (gethtml.has("naukri")) {

				JSONObject subHTML = (JSONObject) gethtml.get("naukri");
				JSONObject naukri = new JSONObject();

				if (subHTML.has("empId"))
					naukri.put("empId", subHTML.getString("empId"));
				else
					naukri.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					naukri.put("lastModified", subHTML.getString("lastModified"));
				else
					naukri.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					naukri.put("html", subHTML.getString("html"));
				else
					naukri.put("html", JSONObject.NULL);

				html.put("naukri", naukri);

			} else
				html.put("naukri", JSONObject.NULL);

			if (gethtml.has("linkedIn")) {
				JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

				JSONObject linkedIn = new JSONObject();

				if (subHTML.has("empId"))
					linkedIn.put("empId", subHTML.getString("empId"));
				else
					linkedIn.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					linkedIn.put("lastModified", subHTML.getString("lastModified"));
				else
					linkedIn.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					linkedIn.put("html", subHTML.getString("html"));
				else
					linkedIn.put("html", JSONObject.NULL);

				html.put("linkedIn", linkedIn);

			} else
				html.put("linkedIn", JSONObject.NULL);

			if (gethtml.has("monster")) {
				JSONObject subHTML = (JSONObject) gethtml.get("monster");

				JSONObject monster = new JSONObject();

				if (subHTML.has("empId"))
					monster.put("empId", subHTML.getString("empId"));
				else
					monster.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					monster.put("lastModified", subHTML.getString("lastModified"));
				else
					monster.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					monster.put("html", subHTML.getString("html"));
				else
					monster.put("html", JSONObject.NULL);

				html.put("monster", monster);

			} else
				html.put("monster", JSONObject.NULL);

			if (gethtml.has("naukriGulf")) {
				JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

				JSONObject naukriGulf = new JSONObject();

				if (subHTML.has("empId"))
					naukriGulf.put("empId", subHTML.getString("empId"));
				else
					naukriGulf.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					naukriGulf.put("lastModified", subHTML.getString("lastModified"));
				else
					naukriGulf.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					naukriGulf.put("html", subHTML.getString("html"));
				else
					naukriGulf.put("html", JSONObject.NULL);

				html.put("naukriGulf", naukriGulf);

			} else
				html.put("naukriGulf", JSONObject.NULL);

			if (gethtml.has("careerBuilder")) {
				JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

				JSONObject careerBuilder = new JSONObject();

				if (subHTML.has("empId"))
					careerBuilder.put("empId", subHTML.getString("empId"));
				else
					careerBuilder.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					careerBuilder.put("lastModified", subHTML.getString("lastModified"));
				else
					careerBuilder.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					careerBuilder.put("html", subHTML.getString("html"));
				else
					careerBuilder.put("html", JSONObject.NULL);

				html.put("careerBuilder", careerBuilder);

			} else
				html.put("careerBuilder", JSONObject.NULL);

			if (gethtml.has("monsterUS")) {
				JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

				JSONObject monsterUS = new JSONObject();

				if (subHTML.has("empId"))
					monsterUS.put("empId", subHTML.getString("empId"));
				else
					monsterUS.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					monsterUS.put("lastModified", subHTML.getString("lastModified"));
				else
					monsterUS.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					monsterUS.put("html", subHTML.getString("html"));
				else
					monsterUS.put("html", JSONObject.NULL);

				html.put("monsterUS", monsterUS);

			} else
				html.put("monsterUS", JSONObject.NULL);

			if (gethtml.has("dice")) {
				JSONObject subHTML = (JSONObject) gethtml.get("dice");

				JSONObject dice = new JSONObject();

				if (subHTML.has("empId"))
					dice.put("empId", subHTML.getString("empId"));
				else
					dice.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					dice.put("lastModified", subHTML.getString("lastModified"));
				else
					dice.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					dice.put("html", subHTML.getString("html"));
				else
					dice.put("html", JSONObject.NULL);

				html.put("dice", dice);

			} else
				html.put("dice", JSONObject.NULL);

			if (gethtml.has("jobDiva")) {
				JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

				JSONObject jobDiva = new JSONObject();

				if (subHTML.has("empId"))
					jobDiva.put("empId", subHTML.getString("empId"));
				else
					jobDiva.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					jobDiva.put("lastModified", subHTML.getString("lastModified"));
				else
					jobDiva.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					jobDiva.put("html", subHTML.getString("html"));
				else
					jobDiva.put("html", JSONObject.NULL);

				html.put("jobDiva", jobDiva);

			} else
				html.put("jobDiva", JSONObject.NULL);

			if (gethtml.has("indeed")) {
				JSONObject subHTML = (JSONObject) gethtml.get("indeed");

				JSONObject indeed = new JSONObject();

				if (subHTML.has("empId"))
					indeed.put("empId", subHTML.getString("empId"));
				else
					indeed.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					indeed.put("lastModified", subHTML.getString("lastModified"));
				else
					indeed.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					indeed.put("html", subHTML.getString("html"));
				else
					indeed.put("html", JSONObject.NULL);

				html.put("indeed", indeed);

			} else
				html.put("indeed", JSONObject.NULL);

			if (gethtml.has("jobServe")) {
				JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

				JSONObject jobServe = new JSONObject();

				if (subHTML.has("empId"))
					jobServe.put("empId", subHTML.getString("empId"));
				else
					jobServe.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					jobServe.put("lastModified", subHTML.getString("lastModified"));
				else
					jobServe.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					jobServe.put("html", subHTML.getString("html"));
				else
					jobServe.put("html", JSONObject.NULL);

				html.put("jobServe", jobServe);

			} else
				html.put("jobServe", JSONObject.NULL);

			if (gethtml.has("other")) {
				JSONObject subHTML = (JSONObject) gethtml.get("other");

				JSONObject other = new JSONObject();

				if (subHTML.has("empId"))
					other.put("empId", subHTML.getString("empId"));
				else
					other.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					other.put("lastModified", subHTML.getString("lastModified"));
				else
					other.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					other.put("html", subHTML.getString("html"));
				else
					other.put("html", JSONObject.NULL);

				html.put("other", other);

			} else
				html.put("other", JSONObject.NULL);

			candijson.put("html", html);
		} else
			candijson.put("html", JSONObject.NULL);
	}
	return candijson.toString();
}
	
		
		//	jobDiva
		if (!empid.equals("") && federated.equals("jobDiva")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.jobDiva.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}

//	indeed
if (!empid.equals("") && federated.equals("indeed")) {
	candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.indeed.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
	System.out.println("url :: " + candidateUrl);

	URL urlcandiateProfile = new URL(candidateUrl);

	URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
			urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
			urlcandiateProfile.getQuery(), candidateUrl);
	String jsonCandidateData = "";
	jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	JSONObject jsonAttach = new JSONObject(jsonCandidateData);
	JSONObject hits = jsonAttach.getJSONObject("hits");

	JSONArray hitsArr = hits.getJSONArray("hits");

	for (int k = 0; k < hitsArr.length(); k++) {

		JSONObject arrobj = (JSONObject) hitsArr.get(k);
		JSONObject arrObj1 = arrobj.getJSONObject("_source");

		if (arrObj1.has("id"))
			candijson.put("id", arrObj1.getString("id"));
		else
			candijson.put("id", JSONObject.NULL);

		
		if (arrObj1.has("federated"))
			candijson.put("federated", arrObj1.getString("federated"));
		else
			candijson.put("federated", JSONObject.NULL);


		/* html array */

		if (arrObj1.has("html")) {
			JSONObject gethtml = (JSONObject) arrObj1.get("html");
			JSONObject html = new JSONObject();

			if (gethtml.has("naukri")) {

				JSONObject subHTML = (JSONObject) gethtml.get("naukri");
				JSONObject naukri = new JSONObject();

				if (subHTML.has("empId"))
					naukri.put("empId", subHTML.getString("empId"));
				else
					naukri.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					naukri.put("lastModified", subHTML.getString("lastModified"));
				else
					naukri.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					naukri.put("html", subHTML.getString("html"));
				else
					naukri.put("html", JSONObject.NULL);

				html.put("naukri", naukri);

			} else
				html.put("naukri", JSONObject.NULL);

			if (gethtml.has("linkedIn")) {
				JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");

				JSONObject linkedIn = new JSONObject();

				if (subHTML.has("empId"))
					linkedIn.put("empId", subHTML.getString("empId"));
				else
					linkedIn.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					linkedIn.put("lastModified", subHTML.getString("lastModified"));
				else
					linkedIn.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					linkedIn.put("html", subHTML.getString("html"));
				else
					linkedIn.put("html", JSONObject.NULL);

				html.put("linkedIn", linkedIn);

			} else
				html.put("linkedIn", JSONObject.NULL);

			if (gethtml.has("monster")) {
				JSONObject subHTML = (JSONObject) gethtml.get("monster");

				JSONObject monster = new JSONObject();

				if (subHTML.has("empId"))
					monster.put("empId", subHTML.getString("empId"));
				else
					monster.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					monster.put("lastModified", subHTML.getString("lastModified"));
				else
					monster.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					monster.put("html", subHTML.getString("html"));
				else
					monster.put("html", JSONObject.NULL);

				html.put("monster", monster);

			} else
				html.put("monster", JSONObject.NULL);

			if (gethtml.has("naukriGulf")) {
				JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");

				JSONObject naukriGulf = new JSONObject();

				if (subHTML.has("empId"))
					naukriGulf.put("empId", subHTML.getString("empId"));
				else
					naukriGulf.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					naukriGulf.put("lastModified", subHTML.getString("lastModified"));
				else
					naukriGulf.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					naukriGulf.put("html", subHTML.getString("html"));
				else
					naukriGulf.put("html", JSONObject.NULL);

				html.put("naukriGulf", naukriGulf);

			} else
				html.put("naukriGulf", JSONObject.NULL);

			if (gethtml.has("careerBuilder")) {
				JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");

				JSONObject careerBuilder = new JSONObject();

				if (subHTML.has("empId"))
					careerBuilder.put("empId", subHTML.getString("empId"));
				else
					careerBuilder.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					careerBuilder.put("lastModified", subHTML.getString("lastModified"));
				else
					careerBuilder.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					careerBuilder.put("html", subHTML.getString("html"));
				else
					careerBuilder.put("html", JSONObject.NULL);

				html.put("careerBuilder", careerBuilder);

			} else
				html.put("careerBuilder", JSONObject.NULL);

			if (gethtml.has("monsterUS")) {
				JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");

				JSONObject monsterUS = new JSONObject();

				if (subHTML.has("empId"))
					monsterUS.put("empId", subHTML.getString("empId"));
				else
					monsterUS.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					monsterUS.put("lastModified", subHTML.getString("lastModified"));
				else
					monsterUS.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					monsterUS.put("html", subHTML.getString("html"));
				else
					monsterUS.put("html", JSONObject.NULL);

				html.put("monsterUS", monsterUS);

			} else
				html.put("monsterUS", JSONObject.NULL);

			if (gethtml.has("dice")) {
				JSONObject subHTML = (JSONObject) gethtml.get("dice");

				JSONObject dice = new JSONObject();

				if (subHTML.has("empId"))
					dice.put("empId", subHTML.getString("empId"));
				else
					dice.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					dice.put("lastModified", subHTML.getString("lastModified"));
				else
					dice.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					dice.put("html", subHTML.getString("html"));
				else
					dice.put("html", JSONObject.NULL);

				html.put("dice", dice);

			} else
				html.put("dice", JSONObject.NULL);

			if (gethtml.has("jobDiva")) {
				JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");

				JSONObject jobDiva = new JSONObject();

				if (subHTML.has("empId"))
					jobDiva.put("empId", subHTML.getString("empId"));
				else
					jobDiva.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					jobDiva.put("lastModified", subHTML.getString("lastModified"));
				else
					jobDiva.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					jobDiva.put("html", subHTML.getString("html"));
				else
					jobDiva.put("html", JSONObject.NULL);

				html.put("jobDiva", jobDiva);

			} else
				html.put("jobDiva", JSONObject.NULL);

			if (gethtml.has("indeed")) {
				JSONObject subHTML = (JSONObject) gethtml.get("indeed");

				JSONObject indeed = new JSONObject();

				if (subHTML.has("empId"))
					indeed.put("empId", subHTML.getString("empId"));
				else
					indeed.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					indeed.put("lastModified", subHTML.getString("lastModified"));
				else
					indeed.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					indeed.put("html", subHTML.getString("html"));
				else
					indeed.put("html", JSONObject.NULL);

				html.put("indeed", indeed);

			} else
				html.put("indeed", JSONObject.NULL);

			if (gethtml.has("jobServe")) {
				JSONObject subHTML = (JSONObject) gethtml.get("jobServe");

				JSONObject jobServe = new JSONObject();

				if (subHTML.has("empId"))
					jobServe.put("empId", subHTML.getString("empId"));
				else
					jobServe.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					jobServe.put("lastModified", subHTML.getString("lastModified"));
				else
					jobServe.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					jobServe.put("html", subHTML.getString("html"));
				else
					jobServe.put("html", JSONObject.NULL);

				html.put("jobServe", jobServe);

			} else
				html.put("jobServe", JSONObject.NULL);

			if (gethtml.has("other")) {
				JSONObject subHTML = (JSONObject) gethtml.get("other");

				JSONObject other = new JSONObject();

				if (subHTML.has("empId"))
					other.put("empId", subHTML.getString("empId"));
				else
					other.put("empId", JSONObject.NULL);

				if (subHTML.has("lastModified"))
					other.put("lastModified", subHTML.getString("lastModified"));
				else
					other.put("lastModified", JSONObject.NULL);

				if (subHTML.has("html"))
					other.put("html", subHTML.getString("html"));
				else
					other.put("html", JSONObject.NULL);

				html.put("other", other);

			} else
				html.put("other", JSONObject.NULL);

			candijson.put("html", html);
		} else
			candijson.put("html", JSONObject.NULL);
	}
	return candijson.toString();
}
	
		//	jobServe
		if (!empid.equals("") && federated.equals("jobServe")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.jobServe.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}


		//	other
		if (!empid.equals("") && federated.equals("other")) {
			candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=(html.other.empId:\""+ empid + "\")AND(federated:\""+federated+"\")";			
			System.out.println("url :: " + candidateUrl);
		
			URL urlcandiateProfile = new URL(candidateUrl);
		
			URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
					urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
					urlcandiateProfile.getQuery(), candidateUrl);
			String jsonCandidateData = "";
			jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);
		
			JSONObject jsonAttach = new JSONObject(jsonCandidateData);
			JSONObject hits = jsonAttach.getJSONObject("hits");
		
			JSONArray hitsArr = hits.getJSONArray("hits");
		
			for (int k = 0; k < hitsArr.length(); k++) {
		
				JSONObject arrobj = (JSONObject) hitsArr.get(k);
				JSONObject arrObj1 = arrobj.getJSONObject("_source");
		
				if (arrObj1.has("id"))
					candijson.put("id", arrObj1.getString("id"));
				else
					candijson.put("id", JSONObject.NULL);
		
				
				if (arrObj1.has("federated"))
					candijson.put("federated", arrObj1.getString("federated"));
				else
					candijson.put("federated", JSONObject.NULL);
		
		
				/* html array */
		
				if (arrObj1.has("html")) {
					JSONObject gethtml = (JSONObject) arrObj1.get("html");
					JSONObject html = new JSONObject();
		
					if (gethtml.has("naukri")) {
		
						JSONObject subHTML = (JSONObject) gethtml.get("naukri");
						JSONObject naukri = new JSONObject();
		
						if (subHTML.has("empId"))
							naukri.put("empId", subHTML.getString("empId"));
						else
							naukri.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukri.put("lastModified", subHTML.getString("lastModified"));
						else
							naukri.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukri.put("html", subHTML.getString("html"));
						else
							naukri.put("html", JSONObject.NULL);
		
						html.put("naukri", naukri);
		
					} else
						html.put("naukri", JSONObject.NULL);
		
					if (gethtml.has("linkedIn")) {
						JSONObject subHTML = (JSONObject) gethtml.get("linkedIn");
		
						JSONObject linkedIn = new JSONObject();
		
						if (subHTML.has("empId"))
							linkedIn.put("empId", subHTML.getString("empId"));
						else
							linkedIn.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							linkedIn.put("lastModified", subHTML.getString("lastModified"));
						else
							linkedIn.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							linkedIn.put("html", subHTML.getString("html"));
						else
							linkedIn.put("html", JSONObject.NULL);
		
						html.put("linkedIn", linkedIn);
		
					} else
						html.put("linkedIn", JSONObject.NULL);
		
					if (gethtml.has("monster")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monster");
		
						JSONObject monster = new JSONObject();
		
						if (subHTML.has("empId"))
							monster.put("empId", subHTML.getString("empId"));
						else
							monster.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monster.put("lastModified", subHTML.getString("lastModified"));
						else
							monster.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monster.put("html", subHTML.getString("html"));
						else
							monster.put("html", JSONObject.NULL);
		
						html.put("monster", monster);
		
					} else
						html.put("monster", JSONObject.NULL);
		
					if (gethtml.has("naukriGulf")) {
						JSONObject subHTML = (JSONObject) gethtml.get("naukriGulf");
		
						JSONObject naukriGulf = new JSONObject();
		
						if (subHTML.has("empId"))
							naukriGulf.put("empId", subHTML.getString("empId"));
						else
							naukriGulf.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							naukriGulf.put("lastModified", subHTML.getString("lastModified"));
						else
							naukriGulf.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							naukriGulf.put("html", subHTML.getString("html"));
						else
							naukriGulf.put("html", JSONObject.NULL);
		
						html.put("naukriGulf", naukriGulf);
		
					} else
						html.put("naukriGulf", JSONObject.NULL);
		
					if (gethtml.has("careerBuilder")) {
						JSONObject subHTML = (JSONObject) gethtml.get("careerBuilder");
		
						JSONObject careerBuilder = new JSONObject();
		
						if (subHTML.has("empId"))
							careerBuilder.put("empId", subHTML.getString("empId"));
						else
							careerBuilder.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							careerBuilder.put("lastModified", subHTML.getString("lastModified"));
						else
							careerBuilder.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							careerBuilder.put("html", subHTML.getString("html"));
						else
							careerBuilder.put("html", JSONObject.NULL);
		
						html.put("careerBuilder", careerBuilder);
		
					} else
						html.put("careerBuilder", JSONObject.NULL);
		
					if (gethtml.has("monsterUS")) {
						JSONObject subHTML = (JSONObject) gethtml.get("monsterUS");
		
						JSONObject monsterUS = new JSONObject();
		
						if (subHTML.has("empId"))
							monsterUS.put("empId", subHTML.getString("empId"));
						else
							monsterUS.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							monsterUS.put("lastModified", subHTML.getString("lastModified"));
						else
							monsterUS.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							monsterUS.put("html", subHTML.getString("html"));
						else
							monsterUS.put("html", JSONObject.NULL);
		
						html.put("monsterUS", monsterUS);
		
					} else
						html.put("monsterUS", JSONObject.NULL);
		
					if (gethtml.has("dice")) {
						JSONObject subHTML = (JSONObject) gethtml.get("dice");
		
						JSONObject dice = new JSONObject();
		
						if (subHTML.has("empId"))
							dice.put("empId", subHTML.getString("empId"));
						else
							dice.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							dice.put("lastModified", subHTML.getString("lastModified"));
						else
							dice.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							dice.put("html", subHTML.getString("html"));
						else
							dice.put("html", JSONObject.NULL);
		
						html.put("dice", dice);
		
					} else
						html.put("dice", JSONObject.NULL);
		
					if (gethtml.has("jobDiva")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobDiva");
		
						JSONObject jobDiva = new JSONObject();
		
						if (subHTML.has("empId"))
							jobDiva.put("empId", subHTML.getString("empId"));
						else
							jobDiva.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobDiva.put("lastModified", subHTML.getString("lastModified"));
						else
							jobDiva.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobDiva.put("html", subHTML.getString("html"));
						else
							jobDiva.put("html", JSONObject.NULL);
		
						html.put("jobDiva", jobDiva);
		
					} else
						html.put("jobDiva", JSONObject.NULL);
		
					if (gethtml.has("indeed")) {
						JSONObject subHTML = (JSONObject) gethtml.get("indeed");
		
						JSONObject indeed = new JSONObject();
		
						if (subHTML.has("empId"))
							indeed.put("empId", subHTML.getString("empId"));
						else
							indeed.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							indeed.put("lastModified", subHTML.getString("lastModified"));
						else
							indeed.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							indeed.put("html", subHTML.getString("html"));
						else
							indeed.put("html", JSONObject.NULL);
		
						html.put("indeed", indeed);
		
					} else
						html.put("indeed", JSONObject.NULL);
		
					if (gethtml.has("jobServe")) {
						JSONObject subHTML = (JSONObject) gethtml.get("jobServe");
		
						JSONObject jobServe = new JSONObject();
		
						if (subHTML.has("empId"))
							jobServe.put("empId", subHTML.getString("empId"));
						else
							jobServe.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							jobServe.put("lastModified", subHTML.getString("lastModified"));
						else
							jobServe.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							jobServe.put("html", subHTML.getString("html"));
						else
							jobServe.put("html", JSONObject.NULL);
		
						html.put("jobServe", jobServe);
		
					} else
						html.put("jobServe", JSONObject.NULL);
		
					if (gethtml.has("other")) {
						JSONObject subHTML = (JSONObject) gethtml.get("other");
		
						JSONObject other = new JSONObject();
		
						if (subHTML.has("empId"))
							other.put("empId", subHTML.getString("empId"));
						else
							other.put("empId", JSONObject.NULL);
		
						if (subHTML.has("lastModified"))
							other.put("lastModified", subHTML.getString("lastModified"));
						else
							other.put("lastModified", JSONObject.NULL);
		
						if (subHTML.has("html"))
							other.put("html", subHTML.getString("html"));
						else
							other.put("html", JSONObject.NULL);
		
						html.put("other", other);
		
					} else
						html.put("other", JSONObject.NULL);
		
					candijson.put("html", html);
				} else
					candijson.put("html", JSONObject.NULL);
			}
			return candijson.toString();
		}

			return "";
		}


		//Behalf of empid to get html fedrated and id

	       @RequestMapping(value = "/ElasticAPI/empidhtml", method = { RequestMethod.GET })
	       public @ResponseBody String empIdHTMl(@RequestParam("empid") String empId)
	                     throws JSONException, URISyntaxException, MalformedURLException {
	              String htmlFlag = "notFound";
	              JSONObject candijson = new JSONObject();

	              String candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.naukri.empId:\""
	                           + empId + "\"";

	              System.out.println("url :: " + candidateUrl);

	              URL urlcandiateProfile = new URL(candidateUrl);

	              URI uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                           urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                           urlcandiateProfile.getQuery(), candidateUrl);
	              String jsonCandidateData = "";

	              jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	              System.out.println(jsonCandidateData);

	              JSONObject jsonAttach = new JSONObject(jsonCandidateData);
	              JSONObject hits = jsonAttach.getJSONObject("hits");

	              JSONArray hitsArr = hits.getJSONArray("hits");

	              if (hitsArr.length() > 0)
	                     htmlFlag = "naukri";

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.linkedIn.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "linkedIn";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.monster.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "monster";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.naukriGulf.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "naukriGulf";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.careerBuilder.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "careerBuilder";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.monsterUS.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "monsterUS";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.dice.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "dice";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.jobDiva.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "jobDiva";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.indeed.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "indeed";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.jobServe.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "jobServe";
	              }

	              if (hitsArr.length() == 0) {

	                     candidateUrl = "https://search-hitech-tuxhxhzzt4sw2d5sak3l6e2mny.ap-south-1.es.amazonaws.com/candidate/_search?q=html.other.empId:\""
	                                  + empId + "\"";

	                     System.out.println("url :: " + candidateUrl);

	                     urlcandiateProfile = new URL(candidateUrl);

	                     uriCandidate = new URI(urlcandiateProfile.getProtocol(), urlcandiateProfile.getUserInfo(),
	                                  urlcandiateProfile.getHost(), urlcandiateProfile.getPort(), urlcandiateProfile.getPath(),
	                                  urlcandiateProfile.getQuery(), candidateUrl);

	                     jsonCandidateData = restTemplate.getForObject(uriCandidate, String.class);

	                     System.out.println(jsonCandidateData);

	                     jsonAttach = new JSONObject(jsonCandidateData);
	                     hits = jsonAttach.getJSONObject("hits");
	                     hitsArr = hits.getJSONArray("hits");

	                     if (hitsArr.length() > 0)
	                           htmlFlag = "other";
	              }

	              for (int k = 0; k < hitsArr.length(); k++) {

	                     JSONObject arrobj = (JSONObject) hitsArr.get(k);
	                     JSONObject arrObj1 = arrobj.getJSONObject("_source");

	                     if (arrObj1.has("id"))
	                           candijson.put("id", arrObj1.getString("id"));
	                     else
	                           candijson.put("id", JSONObject.NULL);

	                     if (arrObj1.has("federated"))
	                           candijson.put("federated", arrObj1.getString("federated"));
	                     else
	                           candijson.put("federated", JSONObject.NULL);

	                     /* html array */

	                     if (arrObj1.has("html")) {
	                           JSONObject gethtml = (JSONObject) arrObj1.get("html");
	                           JSONObject html = new JSONObject();

	                           if (gethtml.has(htmlFlag)) {

	                                  JSONObject subHTML = (JSONObject) gethtml.get("naukri");
	                                  JSONObject putJson = new JSONObject();

	                                  if (subHTML.has("empId"))
	                                         putJson.put("empId", subHTML.getString("empId"));
	                                  else
	                                         putJson.put("empId", JSONObject.NULL);

	                                  if (subHTML.has("lastModified"))
	                                         putJson.put("lastModified", subHTML.getString("lastModified"));
	                                  else
	                                         putJson.put("lastModified", JSONObject.NULL);

	                                  if (subHTML.has("html"))
	                                         putJson.put("html", subHTML.getString("html"));
	                                  else
	                                         putJson.put("html", JSONObject.NULL);

	                                  html.put(htmlFlag, putJson);

	                           }

	                           candijson.put("html", html);
	                     } else
	                           candijson.put("html", JSONObject.NULL);

	              }

	              return candijson.toString();
	       }


}
